#![cfg(feature = "net")]
#![allow(missing_docs)]

//! Durable history for the native consensus protocol. This module does not
//! decide consensus validity: callers validate proposals and quorum certificates
//! before committing them. Imported legacy histories are validated in full.

use super::evm::EvmChainState;
use super::native_chain::{
    FinalizedNativeBlock, NativeAccount, NativeBlockProposal, NativeChainState, NativeTransaction,
};
use rusqlite::{
    limits::Limit, params, Connection, OpenFlags, OptionalExtension, TransactionBehavior,
};
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc, Mutex, MutexGuard,
    },
    time::{Duration, SystemTime, UNIX_EPOCH},
};

const APPLICATION_ID: i64 = 0x4d464e58;
const SCHEMA_VERSION: i64 = 1;
const PAGE_BYTES: u64 = 4096;
const MIB: u64 = 1024 * 1024;
const MAX_RECORD_BYTES: usize = 4 * MIB as usize;
const MAX_QUERY_BLOCKS: usize = 1024;
const MAX_RANGE_BYTES: usize = MIB as usize;
const MAX_RECENT_BYTES: usize = 512 * 1024;
const RECENT_BLOCKS: usize = 256;
const CHECKPOINT_INTERVAL: u64 = 256;
const WAL_CHECKPOINT_BYTES: u64 = 256 * 1024;
const WAL_BUSY_ALLOWANCE_BYTES: u64 = MIB;
const MIN_BUDGET_BYTES: u64 = 16 * MIB;
const FREE_SPACE_RESERVE: u64 = 32 * MIB;
static TEMP_SEQUENCE: AtomicU64 = AtomicU64::new(0);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StateSnapshot {
    pub schema: String,
    pub chain_id: u64,
    pub validators: Vec<String>,
    pub quorum: usize,
    pub genesis_accounts: BTreeMap<String, NativeAccount>,
    pub accounts: BTreeMap<String, NativeAccount>,
    pub evm: Option<EvmChainState>,
}

impl StateSnapshot {
    pub fn from_state(state: &NativeChainState) -> Self {
        Self {
            schema: state.schema.clone(),
            chain_id: state.chain_id,
            validators: state.validators.clone(),
            quorum: state.quorum,
            genesis_accounts: state.genesis_accounts.clone(),
            accounts: state.accounts.clone(),
            evm: state.evm.clone(),
        }
    }

    fn same_identity(&self, other: &Self) -> bool {
        self.schema == other.schema
            && self.chain_id == other.chain_id
            && self.validators == other.validators
            && self.quorum == other.quorum
            && self.genesis_accounts == other.genesis_accounts
            && self.evm.as_ref().map(|e| e.activation_height)
                == other.evm.as_ref().map(|e| e.activation_height)
    }
}

#[derive(Debug, Clone)]
pub struct StoredHead {
    pub snapshot: StateSnapshot,
    pub genesis: FinalizedNativeBlock,
    pub recent_blocks: Vec<FinalizedNativeBlock>,
    pub votes_cast: BTreeMap<u64, String>,
    pub pending_proposal: Option<NativeBlockProposal>,
}

/// One serialized connection per validator. Prepared statements, page cache,
/// returned ranges and records are bounded; history never resides in this object.
#[derive(Debug)]
pub struct NativeStore {
    path: PathBuf,
    connection: Mutex<Connection>,
    max_bytes: Option<u64>,
    read_only: bool,
}

impl NativeStore {
    pub fn sqlite_version() -> &'static str {
        rusqlite::version()
    }

    /// Main-file ceiling after reserving space for an atomic WAL transaction.
    pub fn main_file_budget(&self) -> Option<u64> {
        self.max_bytes.map(|bytes| page_budget(bytes) * PAGE_BYTES)
    }

    /// Import into a new destination. An existing destination is never replaced;
    /// the original JSON remains the caller's recovery evidence.
    pub fn import_legacy(
        path: &Path,
        state: &NativeChainState,
        max_bytes: Option<u64>,
    ) -> Result<Arc<Self>, String> {
        state.validate()?;
        check_budget_setting(max_bytes)?;
        if path.exists() {
            return Err("native database destination already exists".into());
        }
        if state.blocks.first().map(|b| b.proposal.number) != Some(0)
            || state.blocks.len() as u64 != state.latest_number().saturating_add(1)
        {
            return Err("migration requires the complete legacy history".into());
        }
        let parent = parent_dir(path);
        fs::create_dir_all(parent).map_err(io_error)?;
        check_free_space(parent)?;
        let temp = create_temporary(path)?;
        let imported: Result<(), String> = (|| {
            let mut conn = connect(&temp, false, max_bytes)?;
            conn.execute_batch(SCHEMA).map_err(db_error)?;
            conn.pragma_update(None, "application_id", APPLICATION_ID)
                .map_err(db_error)?;
            conn.pragma_update(None, "user_version", SCHEMA_VERSION)
                .map_err(db_error)?;
            let tx = conn
                .transaction_with_behavior(TransactionBehavior::Immediate)
                .map_err(db_error)?;
            let snapshot = StateSnapshot::from_state(state);
            let mut initial = snapshot.clone();
            initial.accounts = initial.genesis_accounts.clone();
            initial.evm = snapshot.evm.as_ref().map(|e| {
                EvmChainState::from_native(e.activation_height, &snapshot.genesis_accounts)
            });
            let initial_id = put_snapshot(&tx, &initial)?;
            let current_id = put_snapshot(&tx, &snapshot)?;
            for block in &state.blocks {
                insert_block(&tx, block)?;
            }
            tx.execute(
                "INSERT INTO checkpoints(height,snapshot_id) VALUES(0,?1)",
                [&initial_id],
            )
            .map_err(db_error)?;
            tx.execute(
                "INSERT INTO checkpoints(height,snapshot_id) VALUES(?1,?2) ON CONFLICT(height) DO UPDATE SET snapshot_id=excluded.snapshot_id",
                params![height(state.latest_number())?, current_id],
            ).map_err(db_error)?;
            tx.execute(
                "INSERT INTO head(id,height,hash,snapshot_id) VALUES(1,?1,?2,?3)",
                params![
                    height(state.latest_number())?,
                    state.latest_hash(),
                    current_id
                ],
            )
            .map_err(db_error)?;
            for (number, hash) in &state.votes_cast {
                tx.execute(
                    "INSERT INTO signing_locks(height,hash,proposal,digest,voted) VALUES(?1,?2,NULL,NULL,1)",
                    params![height(*number)?, hash],
                ).map_err(db_error)?;
            }
            if let Some(proposal) = &state.pending_proposal {
                persist_pending_tx(
                    &tx,
                    proposal,
                    state.votes_cast.contains_key(&proposal.number),
                )?;
            }
            tx.commit().map_err(db_error)?;
            integrity(&conn)?;
            conn.close().map_err(|(_, e)| db_error(e))?;
            fs::File::open(&temp)
                .map_err(io_error)?
                .sync_all()
                .map_err(io_error)?;
            check_file_budget(&temp, max_bytes)?;
            publish_new(&temp, path)?;
            sync_directory(parent)?;
            Ok(())
        })();
        let _ = fs::remove_file(&temp);
        if imported.is_err() {
            remove_temporary_sidecars(&temp);
        }
        imported?;
        Self::open(path, max_bytes)
    }

    pub fn open(path: &Path, max_bytes: Option<u64>) -> Result<Arc<Self>, String> {
        Self::open_mode(path, max_bytes, false)
    }

    /// Open existing history without modifying the source database or its WAL
    /// configuration. Suitable for inspection and consistent backup services.
    pub fn open_read_only(path: &Path, max_bytes: Option<u64>) -> Result<Arc<Self>, String> {
        Self::open_mode(path, max_bytes, true)
    }

    fn open_mode(
        path: &Path,
        max_bytes: Option<u64>,
        read_only: bool,
    ) -> Result<Arc<Self>, String> {
        check_budget_setting(max_bytes)?;
        if !path.is_file() {
            return Err("native database does not exist".into());
        }
        check_file_budget(path, max_bytes)?;
        let conn = if read_only {
            connect_read_only(path)?
        } else {
            connect(path, true, max_bytes)?
        };
        let app: i64 = conn
            .pragma_query_value(None, "application_id", |r| r.get(0))
            .map_err(db_error)?;
        let version: i64 = conn
            .pragma_query_value(None, "user_version", |r| r.get(0))
            .map_err(db_error)?;
        if app != APPLICATION_ID || version != SCHEMA_VERSION {
            return Err("unrecognized native database schema".into());
        }
        let store = Arc::new(Self {
            path: path.to_owned(),
            connection: Mutex::new(conn),
            max_bytes,
            read_only,
        });
        // Bounded startup validation: content digests, head links and safety state.
        // Full imported history was already replayed before activation.
        store.load_head()?;
        Ok(store)
    }

    pub fn load_head(&self) -> Result<StoredHead, String> {
        let conn = self.lock()?;
        let tx = conn.unchecked_transaction().map_err(db_error)?;
        let (tip, tip_hash, snapshot_id) = head_row(&tx)?;
        let snapshot = get_snapshot(&tx, &snapshot_id)?;
        let genesis = get_block(&tx, 0)?.ok_or("native database has no genesis")?;
        let recent_blocks = recent_blocks(&tx, tip)?;
        let last = recent_blocks.last().unwrap_or(&genesis);
        if last.proposal.number != tip || last.proposal.hash != tip_hash {
            return Err("native database head does not match stored block".into());
        }
        if genesis.proposal.chain_id != snapshot.chain_id {
            return Err("native database snapshot has a different chain identity".into());
        }
        let mut votes_cast = BTreeMap::new();
        let mut pending_proposal = None;
        let mut stmt = tx.prepare("SELECT height,hash,proposal,digest,voted FROM signing_locks ORDER BY height LIMIT 2").map_err(db_error)?;
        let mut rows = stmt.query([]).map_err(db_error)?;
        while let Some(row) = rows.next().map_err(db_error)? {
            let number = unsigned(row.get::<_, i64>(0).map_err(db_error)?)?;
            let hash: String = row.get(1).map_err(db_error)?;
            if number != tip.checked_add(1).ok_or("native height overflow")? {
                return Err("invalid persisted signing-lock height".into());
            }
            let voted: bool = row.get(4).map_err(db_error)?;
            if voted {
                votes_cast.insert(number, hash.clone());
            }
            let body: Option<Vec<u8>> = row.get(2).map_err(db_error)?;
            let digest: Option<String> = row.get(3).map_err(db_error)?;
            match (body, digest) {
                (Some(body), Some(digest)) => {
                    let proposal: NativeBlockProposal = decode(&body, &digest)?;
                    if proposal.number != number || proposal.hash != hash {
                        return Err("persisted proposal does not match signing lock".into());
                    }
                    pending_proposal = Some(proposal);
                }
                (None, None) if voted => {}
                _ => return Err("corrupt persisted signing lock".into()),
            }
        }
        drop(rows);
        drop(stmt);
        tx.commit().map_err(db_error)?;
        Ok(StoredHead {
            snapshot,
            genesis,
            recent_blocks,
            votes_cast,
            pending_proposal,
        })
    }

    pub fn block_by_number(&self, number: u64) -> Result<Option<FinalizedNativeBlock>, String> {
        let conn = self.lock()?;
        let block = get_block(&conn, number)?;
        if block.is_none() && number <= head_row(&conn)?.0 {
            return Err("native finalized history has a missing block".into());
        }
        Ok(block)
    }

    pub fn block_by_hash(&self, hash: &str) -> Result<Option<FinalizedNativeBlock>, String> {
        let conn = self.lock()?;
        let found = conn
            .query_row(
                "SELECT height FROM blocks WHERE hash=?1 COLLATE NOCASE",
                [hash],
                |r| r.get::<_, i64>(0),
            )
            .optional()
            .map_err(db_error)?;
        found
            .map(|number| {
                get_block(&conn, unsigned(number)?)?.ok_or("native block index is corrupt".into())
            })
            .transpose()
    }

    pub fn transaction(
        &self,
        hash: &str,
    ) -> Result<Option<(FinalizedNativeBlock, usize, NativeTransaction)>, String> {
        let conn = self.lock()?;
        let found = conn
            .query_row(
                "SELECT height,position FROM transactions WHERE hash=?1 COLLATE NOCASE",
                [hash],
                |r| Ok((r.get::<_, i64>(0)?, r.get::<_, i64>(1)?)),
            )
            .optional()
            .map_err(db_error)?;
        let Some((number, position)) = found else {
            return Ok(None);
        };
        let block = get_block(&conn, unsigned(number)?)?
            .ok_or("native transaction index refers to a missing block")?;
        let index = usize::try_from(position).map_err(|_| "invalid native transaction position")?;
        let transaction = block
            .proposal
            .transactions
            .get(index)
            .ok_or("native transaction index is corrupt")?
            .clone();
        if !transaction.hash.eq_ignore_ascii_case(hash) {
            return Err("native transaction index hash mismatch".into());
        }
        Ok(Some((block, index, transaction)))
    }

    pub fn blocks_range(
        &self,
        start: u64,
        end_inclusive: u64,
        max_count: usize,
    ) -> Result<Vec<FinalizedNativeBlock>, String> {
        let conn = self.lock()?;
        range(&conn, start, end_inclusive, max_count)
    }

    pub fn nearest_checkpoint(&self, number: u64) -> Result<Option<(u64, StateSnapshot)>, String> {
        let conn = self.lock()?;
        let found = conn.query_row(
            "SELECT height,snapshot_id FROM checkpoints WHERE height<=?1 ORDER BY height DESC LIMIT 1",
            [height(number)?], |r| Ok((r.get::<_, i64>(0)?, r.get::<_, String>(1)?)),
        ).optional().map_err(db_error)?;
        found
            .map(|(number, id)| Ok((unsigned(number)?, get_snapshot(&conn, &id)?)))
            .transpose()
    }

    pub fn persist_pending(
        &self,
        proposal: &NativeBlockProposal,
        voted: bool,
    ) -> Result<(), String> {
        let mut conn = self.lock()?;
        self.before_write(&conn)?;
        let tx = conn
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(db_error)?;
        persist_pending_tx(&tx, proposal, voted)?;
        tx.commit().map_err(db_error)
    }

    pub fn finalize(
        &self,
        block: &FinalizedNativeBlock,
        changed_snapshot: Option<&StateSnapshot>,
    ) -> Result<(), String> {
        let mut conn = self.lock()?;
        self.before_write(&conn)?;
        let tx = conn
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(db_error)?;
        let (tip, tip_hash, current_id) = head_row(&tx)?;
        if block.proposal.number <= tip {
            let existing = get_block(&tx, block.proposal.number)?
                .ok_or("native finalized history has a gap")?;
            if existing.proposal != block.proposal {
                return Err("conflicting finalized block".into());
            }
            return Ok(());
        }
        if block.proposal.number != tip.checked_add(1).ok_or("native height overflow")?
            || block.proposal.parent_hash != tip_hash
        {
            return Err("finalized block does not extend the persisted tip".into());
        }
        let snapshot_id = if let Some(snapshot) = changed_snapshot {
            if !snapshot.same_identity(&get_snapshot(&tx, &current_id)?) {
                return Err("finalized snapshot changes immutable chain identity".into());
            }
            put_snapshot(&tx, snapshot)?
        } else {
            current_id.clone()
        };
        insert_block(&tx, block)?;
        if block.proposal.number % CHECKPOINT_INTERVAL == 0 {
            tx.execute(
                "INSERT INTO checkpoints(height,snapshot_id) VALUES(?1,?2)",
                params![height(block.proposal.number)?, snapshot_id],
            )
            .map_err(db_error)?;
        }
        tx.execute(
            "UPDATE head SET height=?1,hash=?2,snapshot_id=?3 WHERE id=1",
            params![
                height(block.proposal.number)?,
                block.proposal.hash,
                snapshot_id
            ],
        )
        .map_err(db_error)?;
        tx.execute(
            "DELETE FROM signing_locks WHERE height<=?1",
            [height(block.proposal.number)?],
        )
        .map_err(db_error)?;
        // Intermediate state blobs are not historical checkpoints. Retain only
        // blobs referenced by the current head or an explicit replay checkpoint.
        tx.execute(
            "DELETE FROM state_blobs WHERE id=?1 AND NOT EXISTS(SELECT 1 FROM head WHERE snapshot_id=?1) AND NOT EXISTS(SELECT 1 FROM checkpoints WHERE snapshot_id=?1)",
            [&current_id],
        ).map_err(db_error)?;
        tx.commit().map_err(db_error)
    }

    /// Check all SQLite pages and foreign keys. This is an explicit maintenance
    /// operation, not an unbounded scan on each validator startup.
    pub fn integrity_check(&self) -> Result<(), String> {
        let conn = self.lock()?;
        integrity(&conn)
    }

    /// A failed/busy checkpoint is reported, never treated as successful cleanup.
    pub fn checkpoint(&self) -> Result<(), String> {
        if self.read_only {
            return Err("native database was opened read-only".into());
        }
        let conn = self.lock()?;
        checkpoint_connection(&conn)
    }

    /// Produce a complete consistent SQLite backup without copying a live WAL.
    /// The destination is activated only after integrity checking and fsync.
    pub fn backup_to(&self, path: &Path) -> Result<(), String> {
        if path.exists() {
            return Err("native backup destination already exists".into());
        }
        let parent = parent_dir(path);
        fs::create_dir_all(parent).map_err(io_error)?;
        check_free_space(parent)?;
        let temp = create_temporary(path)?;
        let result = (|| {
            let conn = self.lock()?;
            let pages: i64 = conn
                .query_row("PRAGMA page_count", [], |row| row.get(0))
                .map_err(db_error)?;
            check_free_space_for(parent, unsigned(pages)?.saturating_mul(PAGE_BYTES))?;
            let mut dest = connect(&temp, false, self.max_bytes)?;
            {
                let backup = rusqlite::backup::Backup::new(&conn, &mut dest).map_err(db_error)?;
                let deadline = std::time::Instant::now() + Duration::from_secs(30);
                loop {
                    match backup.step(64).map_err(db_error)? {
                        rusqlite::backup::StepResult::Done => break,
                        rusqlite::backup::StepResult::More => {}
                        rusqlite::backup::StepResult::Busy
                        | rusqlite::backup::StepResult::Locked => {
                            return Err("native backup is blocked by another connection".into());
                        }
                        _ => return Err("unsupported SQLite backup status".into()),
                    }
                    if std::time::Instant::now() >= deadline {
                        return Err("native backup exceeded its 30-second copy budget".into());
                    }
                }
            }
            // SQLite's backup API copies the source header, including WAL
            // journal mode. Normalize only this newly owned destination after
            // the copy so subsequent read-only verification needs no sidecars.
            let mode: String = dest
                .query_row("PRAGMA journal_mode=DELETE", [], |row| row.get(0))
                .map_err(db_error)?;
            if mode != "delete" {
                return Err("native backup requires standalone DELETE journal mode".into());
            }
            integrity(&dest)?;
            dest.close().map_err(|(_, e)| db_error(e))?;
            fs::File::open(&temp)
                .map_err(io_error)?
                .sync_all()
                .map_err(io_error)?;
            check_file_budget(&temp, self.max_bytes)?;
            publish_new(&temp, path)?;
            sync_directory(parent)
        })();
        let _ = fs::remove_file(&temp);
        if result.is_err() {
            remove_temporary_sidecars(&temp);
        }
        result
    }

    fn lock(&self) -> Result<MutexGuard<'_, Connection>, String> {
        self.connection
            .lock()
            .map_err(|_| "native database mutex is poisoned".into())
    }

    fn before_write(&self, conn: &Connection) -> Result<(), String> {
        if self.read_only {
            return Err("native database was opened read-only".into());
        }
        check_free_space(parent_dir(&self.path))?;
        let wal_bytes = sidecar_size(&self.path, "-wal")?;
        if wal_bytes > WAL_CHECKPOINT_BYTES
            && !try_checkpoint(conn)?
            && wal_bytes > WAL_BUSY_ALLOWANCE_BYTES
        {
            return Err("native database WAL reserve is held by another connection".into());
        }
        check_file_budget(&self.path, self.max_bytes)
    }
}

fn connect(path: &Path, wal: bool, max_bytes: Option<u64>) -> Result<Connection, String> {
    if rusqlite::version_number() < 3_051_003 {
        return Err("SQLite 3.51.3 or newer is required".into());
    }
    let conn = Connection::open_with_flags(
        path,
        OpenFlags::SQLITE_OPEN_READ_WRITE | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(db_error)?;
    if wal {
        check_page_size(&conn)?;
    }
    conn.busy_timeout(Duration::from_millis(250))
        .map_err(db_error)?;
    conn.set_prepared_statement_cache_capacity(8);
    conn.set_limit(Limit::SQLITE_LIMIT_LENGTH, (MAX_RECORD_BYTES + 4096) as i32)
        .map_err(db_error)?;
    conn.set_limit(Limit::SQLITE_LIMIT_SQL_LENGTH, 64 * 1024)
        .map_err(db_error)?;
    conn.execute_batch("PRAGMA foreign_keys=ON; PRAGMA trusted_schema=OFF; PRAGMA page_size=4096; PRAGMA cache_size=-512; PRAGMA mmap_size=0; PRAGMA temp_store=FILE; PRAGMA cache_spill=OFF;").map_err(db_error)?;
    if let Some(bytes) = max_bytes {
        // With spilling disabled a transaction emits at most one WAL frame per
        // dirty page. Reserve a second database image plus WAL/SHM framing.
        let pages = page_budget(bytes);
        let actual: i64 = conn
            .query_row(&format!("PRAGMA max_page_count={pages}"), [], |r| r.get(0))
            .map_err(db_error)?;
        if unsigned(actual)? > pages {
            return Err("native database exceeds configured page budget".into());
        }
    }
    if wal {
        let mode: String = conn
            .query_row("PRAGMA journal_mode=WAL", [], |r| r.get(0))
            .map_err(db_error)?;
        if mode != "wal" {
            return Err("SQLite WAL mode is unavailable".into());
        }
        conn.execute_batch("PRAGMA synchronous=FULL; PRAGMA wal_autocheckpoint=64; PRAGMA journal_size_limit=262144;").map_err(db_error)?;
    } else {
        conn.execute_batch("PRAGMA journal_mode=DELETE; PRAGMA synchronous=EXTRA;")
            .map_err(db_error)?;
    }
    Ok(conn)
}

fn connect_read_only(path: &Path) -> Result<Connection, String> {
    if rusqlite::version_number() < 3_051_003 {
        return Err("SQLite 3.51.3 or newer is required".into());
    }
    let conn = Connection::open_with_flags(
        path,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )
    .map_err(db_error)?;
    check_page_size(&conn)?;
    conn.busy_timeout(Duration::from_millis(250))
        .map_err(db_error)?;
    conn.set_prepared_statement_cache_capacity(8);
    conn.set_limit(Limit::SQLITE_LIMIT_LENGTH, (MAX_RECORD_BYTES + 4096) as i32)
        .map_err(db_error)?;
    conn.set_limit(Limit::SQLITE_LIMIT_SQL_LENGTH, 64 * 1024)
        .map_err(db_error)?;
    conn.execute_batch("PRAGMA query_only=ON; PRAGMA trusted_schema=OFF; PRAGMA cache_size=-512; PRAGMA mmap_size=0; PRAGMA temp_store=FILE;").map_err(db_error)?;
    Ok(conn)
}

fn check_page_size(conn: &Connection) -> Result<(), String> {
    let bytes: i64 = conn
        .pragma_query_value(None, "page_size", |row| row.get(0))
        .map_err(db_error)?;
    if unsigned(bytes)? != PAGE_BYTES {
        return Err("native database page size must be 4096 bytes".into());
    }
    Ok(())
}

fn persist_pending_tx(
    conn: &Connection,
    proposal: &NativeBlockProposal,
    voted: bool,
) -> Result<(), String> {
    let (tip, tip_hash, _) = head_row(conn)?;
    if proposal.number != tip.checked_add(1).ok_or("native height overflow")?
        || proposal.parent_hash != tip_hash
    {
        return Err("pending proposal does not extend the persisted tip".into());
    }
    let body = encode(proposal)?;
    let digest = checksum(&body);
    let old = conn
        .query_row(
            "SELECT hash,proposal,voted FROM signing_locks WHERE height=?1",
            [height(proposal.number)?],
            |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, Option<Vec<u8>>>(1)?,
                    r.get::<_, bool>(2)?,
                ))
            },
        )
        .optional()
        .map_err(db_error)?;
    if let Some((hash, prior, was_voted)) = &old {
        if hash != &proposal.hash || prior.as_ref().is_some_and(|previous| previous != &body) {
            return Err("proposal conflicts with durable signing lock".into());
        }
        if prior.is_some() && (!voted || *was_voted) {
            return Ok(());
        }
    }
    conn.execute(
        "INSERT INTO signing_locks(height,hash,proposal,digest,voted) VALUES(?1,?2,?3,?4,?5) ON CONFLICT(height) DO UPDATE SET proposal=excluded.proposal,digest=excluded.digest,voted=MAX(signing_locks.voted,excluded.voted)",
        params![height(proposal.number)?, proposal.hash, body, digest, voted],
    ).map_err(db_error)?;
    Ok(())
}

fn insert_block(conn: &Connection, block: &FinalizedNativeBlock) -> Result<(), String> {
    let body = encode(block)?;
    conn.execute(
        "INSERT INTO blocks(height,hash,parent,timestamp,body,digest) VALUES(?1,?2,?3,?4,?5,?6)",
        params![
            height(block.proposal.number)?,
            block.proposal.hash,
            block.proposal.parent_hash,
            height(block.proposal.timestamp)?,
            body,
            checksum(&body)
        ],
    )
    .map_err(db_error)?;
    let mut stmt = conn
        .prepare_cached("INSERT INTO transactions(hash,height,position) VALUES(?1,?2,?3)")
        .map_err(db_error)?;
    for (position, transaction) in block.proposal.transactions.iter().enumerate() {
        stmt.execute(params![
            transaction.hash,
            height(block.proposal.number)?,
            position as i64
        ])
        .map_err(db_error)?;
    }
    Ok(())
}

fn get_block(conn: &Connection, number: u64) -> Result<Option<FinalizedNativeBlock>, String> {
    let row = conn
        .query_row(
            "SELECT hash,parent,timestamp,body,digest FROM blocks WHERE height=?1",
            [height(number)?],
            |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, i64>(2)?,
                    r.get::<_, Vec<u8>>(3)?,
                    r.get::<_, String>(4)?,
                ))
            },
        )
        .optional()
        .map_err(db_error)?;
    row.map(|(hash, parent, timestamp, body, digest)| {
        let block: FinalizedNativeBlock = decode(&body, &digest)?;
        if block.proposal.number != number
            || block.proposal.hash != hash
            || block.proposal.parent_hash != parent
            || block.proposal.timestamp != unsigned(timestamp)?
        {
            return Err("native block index does not match block contents".into());
        }
        Ok(block)
    })
    .transpose()
}

fn range(
    conn: &Connection,
    start: u64,
    end: u64,
    max_count: usize,
) -> Result<Vec<FinalizedNativeBlock>, String> {
    let count = end
        .checked_sub(start)
        .and_then(|n| n.checked_add(1))
        .ok_or("invalid native block range")?;
    if max_count == 0 || max_count > MAX_QUERY_BLOCKS || count > max_count as u64 {
        return Err("native block range exceeds its query bound".into());
    }
    let mut blocks = Vec::with_capacity(count as usize);
    let mut bytes = 0usize;
    for number in start..=end {
        bytes = bytes
            .checked_add(block_size(conn, number)?)
            .ok_or("native storage resource limit: range size overflow")?;
        if bytes > MAX_RANGE_BYTES {
            return Err("native storage resource limit: block range exceeds 1 MiB".into());
        }
        let block =
            get_block(conn, number)?.ok_or("native block range contains a missing block")?;
        if blocks.last().is_some_and(|last: &FinalizedNativeBlock| {
            last.proposal.hash != block.proposal.parent_hash
        }) {
            return Err("native block range has a broken parent link".into());
        }
        blocks.push(block);
    }
    Ok(blocks)
}

fn block_size(conn: &Connection, number: u64) -> Result<usize, String> {
    let length: i64 = conn
        .query_row(
            "SELECT length(body) FROM blocks WHERE height=?1",
            [height(number)?],
            |r| r.get(0),
        )
        .map_err(db_error)?;
    let length = usize::try_from(length).map_err(|_| "invalid native block record size")?;
    if length > MAX_RECORD_BYTES {
        return Err("native storage resource limit: block exceeds record bound".into());
    }
    Ok(length)
}

fn recent_blocks(conn: &Connection, tip: u64) -> Result<Vec<FinalizedNativeBlock>, String> {
    let mut blocks = Vec::new();
    let mut bytes = 0usize;
    for number in (tip.saturating_sub((RECENT_BLOCKS - 1) as u64).max(1)..=tip).rev() {
        let size = block_size(conn, number)?;
        if !blocks.is_empty() && bytes.saturating_add(size) > MAX_RECENT_BYTES {
            break;
        }
        let block = get_block(conn, number)?.ok_or("native recent history has a missing block")?;
        if blocks.last().is_some_and(|newer: &FinalizedNativeBlock| {
            newer.proposal.parent_hash != block.proposal.hash
        }) {
            return Err("native recent history has a broken parent link".into());
        }
        bytes = bytes.saturating_add(size);
        blocks.push(block);
    }
    blocks.reverse();
    Ok(blocks)
}

fn put_snapshot(conn: &Connection, snapshot: &StateSnapshot) -> Result<String, String> {
    let body = encode(snapshot)?;
    let digest = checksum(&body);
    conn.execute(
        "INSERT OR IGNORE INTO state_blobs(id,body) VALUES(?1,?2)",
        params![digest, body],
    )
    .map_err(db_error)?;
    Ok(digest)
}

fn get_snapshot(conn: &Connection, id: &str) -> Result<StateSnapshot, String> {
    let body: Vec<u8> = conn
        .query_row("SELECT body FROM state_blobs WHERE id=?1", [id], |r| {
            r.get(0)
        })
        .map_err(db_error)?;
    decode(&body, id)
}

fn head_row(conn: &Connection) -> Result<(u64, String, String), String> {
    let (height, hash, snapshot) = conn
        .query_row(
            "SELECT height,hash,snapshot_id FROM head WHERE id=1",
            [],
            |r| Ok((r.get::<_, i64>(0)?, r.get(1)?, r.get(2)?)),
        )
        .map_err(db_error)?;
    Ok((unsigned(height)?, hash, snapshot))
}

fn encode<T: Serialize>(value: &T) -> Result<Vec<u8>, String> {
    struct Bounded(Vec<u8>);
    impl std::io::Write for Bounded {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            if bytes.len() > MAX_RECORD_BYTES.saturating_sub(self.0.len()) {
                return Err(std::io::Error::other(
                    "native storage record exceeds its byte bound",
                ));
            }
            self.0.extend_from_slice(bytes);
            Ok(bytes.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    let mut output = Bounded(Vec::new());
    serde_json::to_writer(&mut output, value)
        .map_err(|e| format!("native storage serialization: {e}"))?;
    Ok(output.0)
}

fn decode<T: DeserializeOwned>(bytes: &[u8], digest: &str) -> Result<T, String> {
    if bytes.len() > MAX_RECORD_BYTES || checksum(bytes) != digest {
        return Err("native storage record checksum mismatch".into());
    }
    serde_json::from_slice(bytes).map_err(|e| format!("invalid native storage record: {e}"))
}

fn checksum(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}
fn height(value: u64) -> Result<i64, String> {
    i64::try_from(value).map_err(|_| "native height exceeds SQLite integer range".into())
}
fn unsigned(value: i64) -> Result<u64, String> {
    u64::try_from(value).map_err(|_| "negative native database integer".into())
}
fn db_error(error: rusqlite::Error) -> String {
    format!("native database: {error}")
}
fn io_error(error: std::io::Error) -> String {
    format!("native storage I/O: {error}")
}

fn integrity(conn: &Connection) -> Result<(), String> {
    let result: String = conn
        .query_row("PRAGMA integrity_check", [], |r| r.get(0))
        .map_err(db_error)?;
    if result != "ok" {
        return Err(format!("native database integrity failure: {result}"));
    }
    let foreign_key_error = conn
        .prepare("PRAGMA foreign_key_check")
        .map_err(db_error)?
        .exists([])
        .map_err(db_error)?;
    if foreign_key_error {
        return Err("native database foreign-key integrity failure".into());
    }
    Ok(())
}

fn checkpoint_connection(conn: &Connection) -> Result<(), String> {
    if !try_checkpoint(conn)? {
        return Err("native database checkpoint is blocked by another connection".into());
    }
    Ok(())
}

fn try_checkpoint(conn: &Connection) -> Result<bool, String> {
    let (busy, _, _): (i64, i64, i64) = conn
        .query_row("PRAGMA wal_checkpoint(TRUNCATE)", [], |r| {
            Ok((r.get(0)?, r.get(1)?, r.get(2)?))
        })
        .map_err(db_error)?;
    Ok(busy == 0)
}

fn check_budget_setting(bytes: Option<u64>) -> Result<(), String> {
    if bytes.is_some_and(|value| value < MIN_BUDGET_BYTES) {
        return Err("native database disk budget must be at least 16 MiB".into());
    }
    Ok(())
}

fn page_budget(bytes: u64) -> u64 {
    (bytes.saturating_sub(MIB) / 100 * 49) / PAGE_BYTES
}

fn sidecar(path: &Path, suffix: &str) -> PathBuf {
    let mut name = path.as_os_str().to_owned();
    name.push(suffix);
    PathBuf::from(name)
}
fn sidecar_size(path: &Path, suffix: &str) -> Result<u64, String> {
    match fs::metadata(sidecar(path, suffix)) {
        Ok(m) => Ok(m.len()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(0),
        Err(e) => Err(io_error(e)),
    }
}
fn check_file_budget(path: &Path, max_bytes: Option<u64>) -> Result<(), String> {
    if let Some(max) = max_bytes {
        let total = fs::metadata(path)
            .map_err(io_error)?
            .len()
            .saturating_add(sidecar_size(path, "-wal")?)
            .saturating_add(sidecar_size(path, "-shm")?);
        if total > max {
            return Err("native database exceeds configured total disk budget".into());
        }
    }
    Ok(())
}

#[cfg(unix)]
fn check_free_space_for(path: &Path, additional: u64) -> Result<(), String> {
    use std::os::unix::ffi::OsStrExt;
    let path = std::ffi::CString::new(path.as_os_str().as_bytes())
        .map_err(|_| "invalid native database path")?;
    let mut info = std::mem::MaybeUninit::<libc::statvfs>::uninit();
    // SAFETY: path is NUL-terminated and info points to writable statvfs storage.
    let result = unsafe { libc::statvfs(path.as_ptr(), info.as_mut_ptr()) };
    if result != 0 {
        return Err(io_error(std::io::Error::last_os_error()));
    }
    // SAFETY: successful statvfs initializes the complete output structure.
    let info = unsafe { info.assume_init() };
    let available = (info.f_bavail as u64).saturating_mul(info.f_frsize as u64);
    if available < FREE_SPACE_RESERVE.saturating_add(additional) {
        return Err("native storage free-space reserve is exhausted".into());
    }
    Ok(())
}
#[cfg(not(unix))]
fn check_free_space_for(_path: &Path, _additional: u64) -> Result<(), String> {
    Ok(())
}

fn check_free_space(path: &Path) -> Result<(), String> {
    check_free_space_for(path, 0)
}

fn parent_dir(path: &Path) -> &Path {
    path.parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."))
}
fn sync_directory(path: &Path) -> Result<(), String> {
    fs::File::open(path)
        .map_err(io_error)?
        .sync_all()
        .map_err(io_error)
}

#[cfg(target_os = "linux")]
fn publish_new(source: &Path, destination: &Path) -> Result<(), String> {
    use std::os::unix::ffi::OsStrExt;
    let source = std::ffi::CString::new(source.as_os_str().as_bytes())
        .map_err(|_| "invalid storage source path")?;
    let destination = std::ffi::CString::new(destination.as_os_str().as_bytes())
        .map_err(|_| "invalid storage destination path")?;
    // SAFETY: both paths are valid NUL-terminated strings. RENAME_NOREPLACE
    // atomically rejects an existing destination without any hard-link window.
    let result = unsafe {
        libc::renameat2(
            libc::AT_FDCWD,
            source.as_ptr(),
            libc::AT_FDCWD,
            destination.as_ptr(),
            libc::RENAME_NOREPLACE,
        )
    };
    if result != 0 {
        return Err(io_error(std::io::Error::last_os_error()));
    }
    Ok(())
}

#[cfg(not(target_os = "linux"))]
fn publish_new(_source: &Path, _destination: &Path) -> Result<(), String> {
    Err("atomic native database publication currently requires Linux renameat2".into())
}
fn create_temporary(path: &Path) -> Result<PathBuf, String> {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|_| "system clock precedes Unix epoch")?
        .as_nanos();
    let suffix = format!(
        ".import-{}-{now}-{}",
        std::process::id(),
        TEMP_SEQUENCE.fetch_add(1, Ordering::Relaxed)
    );
    let temp = sidecar(path, &suffix);
    let mut options = fs::OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    options.open(&temp).map_err(io_error)?;
    Ok(temp)
}
fn remove_temporary_sidecars(path: &Path) {
    for suffix in ["-journal", "-wal", "-shm"] {
        let _ = fs::remove_file(sidecar(path, suffix));
    }
}

const SCHEMA: &str = "
CREATE TABLE state_blobs(id TEXT PRIMARY KEY, body BLOB NOT NULL) STRICT;
CREATE TABLE blocks(height INTEGER PRIMARY KEY CHECK(height>=0), hash TEXT NOT NULL UNIQUE COLLATE NOCASE, parent TEXT NOT NULL, timestamp INTEGER NOT NULL CHECK(timestamp>=0), body BLOB NOT NULL, digest TEXT NOT NULL) STRICT;
CREATE TABLE transactions(hash TEXT PRIMARY KEY COLLATE NOCASE, height INTEGER NOT NULL REFERENCES blocks(height), position INTEGER NOT NULL CHECK(position>=0), UNIQUE(height,position)) STRICT;
CREATE TABLE checkpoints(height INTEGER PRIMARY KEY REFERENCES blocks(height), snapshot_id TEXT NOT NULL REFERENCES state_blobs(id)) STRICT;
CREATE INDEX checkpoint_snapshots ON checkpoints(snapshot_id);
CREATE TABLE head(id INTEGER PRIMARY KEY CHECK(id=1), height INTEGER NOT NULL REFERENCES blocks(height), hash TEXT NOT NULL, snapshot_id TEXT NOT NULL REFERENCES state_blobs(id)) STRICT;
CREATE TABLE signing_locks(height INTEGER PRIMARY KEY CHECK(height>0), hash TEXT NOT NULL, proposal BLOB, digest TEXT, voted INTEGER NOT NULL CHECK(voted IN(0,1)), CHECK((proposal IS NULL)=(digest IS NULL))) STRICT;
";

#[cfg(test)]
pub(crate) use super::native_chain::{signed_test_block, signed_test_empty_block};

#[cfg(test)]
mod tests {
    use super::*;
    use crate::net::encode_public_key_base64;
    use ed25519_dalek::SigningKey;

    struct Directory(PathBuf);
    impl Directory {
        fn new() -> Self {
            let name = format!(
                "mfenx-native-store-test-{}-{}-{}",
                std::process::id(),
                SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap()
                    .as_nanos(),
                TEMP_SEQUENCE.fetch_add(1, Ordering::Relaxed)
            );
            let path = std::env::temp_dir().join(name);
            fs::create_dir(&path).unwrap();
            Self(path)
        }
        fn path(&self, name: &str) -> PathBuf {
            self.0.join(name)
        }
    }
    impl Drop for Directory {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    fn history(count: u64) -> NativeChainState {
        let dir = Directory::new();
        let signing = SigningKey::from_bytes(&[93; 32]);
        let validator = encode_public_key_base64(&signing.verifying_key());
        let mut state = NativeChainState::load_or_initialize(
            &dir.path("legacy.json"),
            2026092601,
            None,
            vec![validator],
            1,
        )
        .unwrap();
        for number in 1..=count {
            let block = signed_test_empty_block(&state, &signing, number);
            state.blocks.push(block);
        }
        state.validate().unwrap();
        state
    }

    #[test]
    fn migration_keeps_complete_history_beyond_the_resident_cache() {
        let dir = Directory::new();
        let legacy = history(300);
        let bytes = serde_json::to_vec(&legacy).unwrap();
        fs::write(dir.path("legacy.json"), &bytes).unwrap();
        let store = NativeStore::import_legacy(&dir.path("chain.sqlite3"), &legacy, Some(32 * MIB))
            .unwrap();
        let head = store.load_head().unwrap();
        assert_eq!(head.genesis, legacy.blocks[0]);
        assert_eq!(head.recent_blocks.len(), RECENT_BLOCKS);
        assert_eq!(head.recent_blocks.first().unwrap().proposal.number, 45);
        assert_eq!(
            store.block_by_number(1).unwrap(),
            Some(legacy.blocks[1].clone())
        );
        assert_eq!(
            store
                .block_by_hash(&legacy.blocks[2].proposal.hash.to_uppercase())
                .unwrap(),
            Some(legacy.blocks[2].clone())
        );
        assert_eq!(store.blocks_range(0, 3, 4).unwrap(), legacy.blocks[0..4]);
        assert!(store.blocks_range(0, 3, 3).is_err());
        assert!(store.block_by_number(301).unwrap().is_none());
        assert_eq!(head.snapshot, StateSnapshot::from_state(&legacy));
        assert_eq!(fs::read(dir.path("legacy.json")).unwrap(), bytes);
        store.integrity_check().unwrap();
        assert!(rusqlite::version_number() >= 3_051_003);
    }

    #[test]
    fn invalid_import_and_existing_destination_are_never_activated() {
        let dir = Directory::new();
        let mut legacy = history(2);
        legacy.blocks[1].votes[0].signature = "invalid".into();
        let path = dir.path("invalid.sqlite3");
        assert!(NativeStore::import_legacy(&path, &legacy, None).is_err());
        assert!(!path.exists());
        let legacy = history(1);
        fs::write(&path, b"existing recovery evidence").unwrap();
        assert!(NativeStore::import_legacy(&path, &legacy, None).is_err());
        assert_eq!(fs::read(path).unwrap(), b"existing recovery evidence");
        assert!(NativeStore::import_legacy(&dir.path("tiny.sqlite3"), &legacy, Some(MIB)).is_err());
        assert!(!dir.path("tiny.sqlite3").exists());
    }

    #[test]
    fn durable_lock_rejects_conflicts_and_cannot_be_downgraded() {
        let dir = Directory::new();
        let all = history(2);
        let mut legacy = all.clone();
        legacy.blocks.pop();
        let path = dir.path("chain.sqlite3");
        let store = NativeStore::import_legacy(&path, &legacy, None).unwrap();
        let proposal = &all.blocks[2].proposal;
        store.persist_pending(proposal, true).unwrap();
        store.persist_pending(proposal, false).unwrap();
        drop(store);
        let store = NativeStore::open(&path, None).unwrap();
        let head = store.load_head().unwrap();
        assert_eq!(head.votes_cast.get(&2), Some(&proposal.hash));
        assert_eq!(head.pending_proposal.as_ref(), Some(proposal));
        let mut conflict = proposal.clone();
        conflict.hash = format!("0x{}", "ab".repeat(32));
        assert!(store
            .persist_pending(&conflict, true)
            .unwrap_err()
            .contains("conflicts"));
        assert_eq!(
            store.load_head().unwrap().pending_proposal.as_ref(),
            Some(proposal)
        );
    }

    #[test]
    fn finality_clears_locks_atomically_and_deduplicates_empty_state() {
        let dir = Directory::new();
        let all = history(257);
        let mut legacy = all.clone();
        legacy.blocks.truncate(2);
        let store = NativeStore::import_legacy(&dir.path("chain.sqlite3"), &legacy, None).unwrap();
        for block in all.blocks.iter().skip(2) {
            store.persist_pending(&block.proposal, true).unwrap();
            store.finalize(block, None).unwrap();
        }
        let head = store.load_head().unwrap();
        assert_eq!(head.recent_blocks.last(), all.blocks.last());
        assert!(head.votes_cast.is_empty());
        assert!(head.pending_proposal.is_none());
        assert_eq!(store.nearest_checkpoint(257).unwrap().unwrap().0, 256);
        let snapshots: i64 = store
            .lock()
            .unwrap()
            .query_row("SELECT count(*) FROM state_blobs", [], |r| r.get(0))
            .unwrap();
        assert_eq!(snapshots, 1);
        store.finalize(&all.blocks[257], None).unwrap();
        let mut conflict = all.blocks[257].clone();
        conflict.proposal.hash = format!("0x{}", "cc".repeat(32));
        assert!(store.finalize(&conflict, None).is_err());
    }

    #[test]
    fn changing_execution_state_retains_only_checkpoint_and_current_blobs() {
        let dir = Directory::new();
        let mut state = history(0);
        state.enable_evm(1).unwrap();
        let store = NativeStore::import_legacy(&dir.path("chain.sqlite3"), &state, None).unwrap();
        let signing = SigningKey::from_bytes(&[93; 32]);
        for nonce in 0..5 {
            let transaction =
                crate::net::evm::signed_test_transaction(nonce, &[0x33; 20], &[], 0, 30_000);
            let number = state.latest_number() + 1;
            let block = signed_test_block(&state, &signing, number, vec![transaction.clone()]);
            let context = state.execution_context(number, number).unwrap();
            let (next, _) = state
                .evm
                .as_ref()
                .unwrap()
                .execute(&context, &transaction)
                .unwrap();
            state.evm = Some(next);
            state.blocks.push(block.clone());
            state.validate().unwrap();
            store
                .finalize(&block, Some(&StateSnapshot::from_state(&state)))
                .unwrap();
        }
        let snapshots: i64 = store
            .lock()
            .unwrap()
            .query_row("SELECT count(*) FROM state_blobs", [], |r| r.get(0))
            .unwrap();
        assert_eq!(snapshots, 2); // Genesis replay checkpoint plus current state.
        assert_eq!(
            store.load_head().unwrap().snapshot,
            StateSnapshot::from_state(&state)
        );
    }

    #[test]
    fn sqlite_full_rolls_back_tip_and_preserves_the_vote_lock() {
        let dir = Directory::new();
        let all = history(2);
        let mut legacy = all.clone();
        legacy.blocks.pop();
        let path = dir.path("chain.sqlite3");
        let store = NativeStore::import_legacy(&path, &legacy, None).unwrap();
        store
            .persist_pending(&all.blocks[2].proposal, true)
            .unwrap();
        {
            let conn = store.lock().unwrap();
            let pages: i64 = conn
                .query_row("PRAGMA page_count", [], |r| r.get(0))
                .unwrap();
            conn.query_row(&format!("PRAGMA max_page_count={pages}"), [], |r| {
                r.get::<_, i64>(0)
            })
            .unwrap();
        }
        // Exceed the available page allocation inside the same finality transaction.
        // Consensus validation is a caller responsibility; this isolates I/O failure.
        let mut changed = StateSnapshot::from_state(&legacy);
        for index in 0..4000 {
            changed.accounts.insert(
                format!("0x{index:040x}"),
                NativeAccount {
                    balance: 1,
                    nonce: 0,
                },
            );
        }
        assert!(store
            .finalize(&all.blocks[2], Some(&changed))
            .unwrap_err()
            .contains("full"));
        drop(store);
        let store = NativeStore::open(&path, None).unwrap();
        let head = store.load_head().unwrap();
        assert_eq!(head.recent_blocks.last().unwrap().proposal.number, 1);
        assert_eq!(head.votes_cast.get(&2), Some(&all.blocks[2].proposal.hash));
        assert!(store.block_by_number(2).unwrap().is_none());
        store.integrity_check().unwrap();
    }

    #[test]
    fn bounded_queries_and_corruption_errors_are_distinct_from_unknown_blocks() {
        let dir = Directory::new();
        let legacy = history(80);
        let store = NativeStore::import_legacy(&dir.path("chain.sqlite3"), &legacy, None).unwrap();
        {
            let conn = store.lock().unwrap();
            for block in legacy.blocks.iter().skip(1) {
                // JSON whitespace changes storage size without changing signed data.
                let mut body = encode(block).unwrap();
                body.extend(std::iter::repeat_n(b' ', 20 * 1024));
                conn.execute(
                    "UPDATE blocks SET body=?1,digest=?2 WHERE height=?3",
                    params![
                        body,
                        checksum(&body),
                        height(block.proposal.number).unwrap()
                    ],
                )
                .unwrap();
            }
        }
        let head = store.load_head().unwrap();
        assert!(head.recent_blocks.len() < 30);
        assert_eq!(head.recent_blocks.last().unwrap().proposal.number, 80);
        assert!(store
            .blocks_range(1, 80, 80)
            .unwrap_err()
            .contains("resource limit"));
        assert!(store.block_by_number(81).unwrap().is_none());
        {
            let conn = store.lock().unwrap();
            conn.execute("UPDATE blocks SET digest='invalid' WHERE height=1", [])
                .unwrap();
        }
        assert!(store.block_by_number(1).unwrap_err().contains("checksum"));
        assert!(store
            .block_by_hash(&legacy.blocks[1].proposal.hash)
            .is_err());
    }

    #[test]
    fn consistent_backup_includes_committed_wal_and_signing_locks() {
        let dir = Directory::new();
        let all = history(2);
        let mut legacy = all.clone();
        legacy.blocks.pop();
        let store = NativeStore::import_legacy(&dir.path("chain.sqlite3"), &legacy, None).unwrap();
        store
            .persist_pending(&all.blocks[2].proposal, true)
            .unwrap();
        let backup = dir.path("backup.sqlite3");
        store.backup_to(&backup).unwrap();
        let restored = NativeStore::open(&backup, None).unwrap();
        assert_eq!(
            restored.load_head().unwrap().pending_proposal,
            Some(all.blocks[2].proposal.clone())
        );
        assert_eq!(
            restored.load_head().unwrap().votes_cast.get(&2),
            Some(&all.blocks[2].proposal.hash)
        );
        restored.integrity_check().unwrap();
        assert!(store.backup_to(&backup).is_err());
    }

    #[test]
    fn read_only_inspection_can_back_up_but_cannot_change_safety_state() {
        let dir = Directory::new();
        let all = history(2);
        let mut legacy = all.clone();
        legacy.blocks.pop();
        let path = dir.path("chain.sqlite3");
        let writer = NativeStore::import_legacy(&path, &legacy, Some(32 * MIB)).unwrap();
        writer
            .persist_pending(&all.blocks[2].proposal, true)
            .unwrap();
        let reader = NativeStore::open_read_only(&path, Some(32 * MIB)).unwrap();
        assert_eq!(
            reader.main_file_budget(),
            Some(page_budget(32 * MIB) * PAGE_BYTES)
        );
        assert!(reader
            .persist_pending(&all.blocks[2].proposal, true)
            .unwrap_err()
            .contains("read-only"));
        assert!(reader
            .finalize(&all.blocks[2], None)
            .unwrap_err()
            .contains("read-only"));
        assert!(reader.checkpoint().unwrap_err().contains("read-only"));
        let before = fs::read(&path).unwrap();
        let wal_before = fs::read(sidecar(&path, "-wal")).unwrap();
        let backup_path = dir.path("read-only-backup.sqlite3");
        reader.backup_to(&backup_path).unwrap();
        assert_eq!(fs::read(&path).unwrap(), before);
        assert_eq!(fs::read(sidecar(&path, "-wal")).unwrap(), wal_before);
        assert_eq!(
            reader
                .lock()
                .unwrap()
                .pragma_query_value(None, "journal_mode", |row| row.get::<_, String>(0))
                .unwrap(),
            "wal"
        );
        assert!(reader.load_head().unwrap().votes_cast.contains_key(&2));
        let backup_before = fs::read(&backup_path).unwrap();
        for suffix in ["-wal", "-shm"] {
            assert!(!sidecar(&backup_path, suffix).exists());
        }
        let restored = NativeStore::open_read_only(&backup_path, None).unwrap();
        assert_eq!(
            restored.load_head().unwrap().pending_proposal,
            Some(all.blocks[2].proposal.clone())
        );
        restored.integrity_check().unwrap();
        assert_eq!(
            restored
                .lock()
                .unwrap()
                .pragma_query_value(None, "journal_mode", |row| row.get::<_, String>(0))
                .unwrap(),
            "delete"
        );
        drop(restored);
        assert_eq!(fs::read(&backup_path).unwrap(), backup_before);
        for suffix in ["-wal", "-shm"] {
            assert!(!sidecar(&backup_path, suffix).exists());
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::MetadataExt;
            assert_eq!(
                fs::metadata(dir.path("read-only-backup.sqlite3"))
                    .unwrap()
                    .nlink(),
                1
            );
        }
    }

    #[test]
    fn brief_reader_contention_does_not_fail_writes_below_the_wal_reserve() {
        let dir = Directory::new();
        let all = history(120);
        let mut legacy = all.clone();
        legacy.blocks.truncate(2);
        let path = dir.path("chain.sqlite3");
        let writer = NativeStore::import_legacy(&path, &legacy, Some(32 * MIB)).unwrap();
        writer.lock().unwrap().busy_timeout(Duration::ZERO).unwrap();
        let reader = NativeStore::open_read_only(&path, Some(32 * MIB)).unwrap();
        let conn = reader.lock().unwrap();
        conn.execute_batch("BEGIN; SELECT height FROM head;")
            .unwrap();
        for block in all.blocks.iter().skip(2).take(19) {
            writer.finalize(block, None).unwrap();
        }
        assert!(sidecar_size(&path, "-wal").unwrap() > WAL_CHECKPOINT_BYTES);
        assert!(writer.checkpoint().unwrap_err().contains("blocked"));
        let mut blocked_at = None;
        for block in all.blocks.iter().skip(21) {
            if let Err(error) = writer.finalize(block, None) {
                assert!(error.contains("WAL reserve"), "{error}");
                blocked_at = Some(block.proposal.number);
                break;
            }
        }
        let blocked_at = blocked_at.expect("a long reader must not permit unbounded WAL growth");
        assert_eq!(
            writer
                .load_head()
                .unwrap()
                .recent_blocks
                .last()
                .unwrap()
                .proposal
                .number,
            blocked_at - 1
        );
        conn.execute_batch("ROLLBACK").unwrap();
        drop(conn);
        writer.checkpoint().unwrap();
        writer
            .finalize(&all.blocks[blocked_at as usize], None)
            .unwrap();
        assert_eq!(
            writer
                .load_head()
                .unwrap()
                .recent_blocks
                .last()
                .unwrap()
                .proposal
                .number,
            blocked_at
        );
        check_file_budget(&path, Some(32 * MIB)).unwrap();
    }

    #[test]
    fn unexpected_database_page_size_is_rejected_before_budgeting_or_backup() {
        let dir = Directory::new();
        let path = dir.path("chain.sqlite3");
        let store = NativeStore::import_legacy(&path, &history(1), Some(32 * MIB)).unwrap();
        drop(store);
        let connection = Connection::open(&path).unwrap();
        connection
            .execute_batch("PRAGMA journal_mode=DELETE; PRAGMA page_size=8192; VACUUM;")
            .unwrap();
        drop(connection);
        assert!(NativeStore::open_read_only(&path, Some(32 * MIB))
            .unwrap_err()
            .contains("page size"));
        assert!(NativeStore::open(&path, Some(32 * MIB))
            .unwrap_err()
            .contains("page size"));
        let connection = Connection::open(&path).unwrap();
        assert_eq!(
            connection
                .pragma_query_value(None, "page_size", |r| r.get::<_, i64>(0))
                .unwrap(),
            8192
        );
        assert_eq!(
            connection
                .pragma_query_value(None, "journal_mode", |r| r.get::<_, String>(0))
                .unwrap(),
            "delete"
        );
    }

    #[test]
    fn process_exit_before_and_after_commit_recovers_consistent_safety_state() {
        for mode in [
            "pending-before",
            "pending-after",
            "finalize-before",
            "finalize-after",
        ] {
            let dir = Directory::new();
            let all = history(2);
            let mut legacy = all.clone();
            legacy.blocks.pop();
            let path = dir.path("chain.sqlite3");
            let store = NativeStore::import_legacy(&path, &legacy, None).unwrap();
            if mode.starts_with("finalize") {
                store
                    .persist_pending(&all.blocks[2].proposal, true)
                    .unwrap();
            }
            drop(store);
            fs::write(dir.path("block.json"), encode(&all.blocks[2]).unwrap()).unwrap();
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "net::native_store::tests::crash_child",
                    "--nocapture",
                ])
                .env("MFENX_STORE_TEST_EXIT", mode)
                .env("MFENX_STORE_TEST_DIRECTORY", &dir.0)
                .stdout(std::process::Stdio::null())
                .stderr(std::process::Stdio::null())
                .status()
                .unwrap();
            assert_eq!(status.code(), Some(86), "{mode}");
            let store = NativeStore::open(&path, None).unwrap();
            let head = store.load_head().unwrap();
            let committed_finality = mode == "finalize-after";
            assert_eq!(
                head.recent_blocks.last().unwrap().proposal.number,
                if committed_finality { 2 } else { 1 },
                "{mode}"
            );
            let lock_present = mode == "pending-after" || mode == "finalize-before";
            assert_eq!(head.votes_cast.contains_key(&2), lock_present, "{mode}");
            assert_eq!(head.pending_proposal.is_some(), lock_present, "{mode}");
            store.integrity_check().unwrap();
        }
    }

    #[test]
    fn crash_child() {
        let Ok(mode) = std::env::var("MFENX_STORE_TEST_EXIT") else {
            return;
        };
        let dir = PathBuf::from(std::env::var_os("MFENX_STORE_TEST_DIRECTORY").unwrap());
        let store = NativeStore::open(&dir.join("chain.sqlite3"), None).unwrap();
        let block: FinalizedNativeBlock =
            serde_json::from_slice(&fs::read(dir.join("block.json")).unwrap()).unwrap();
        match mode.as_str() {
            "pending-before" => {
                let mut conn = store.lock().unwrap();
                let tx = conn
                    .transaction_with_behavior(TransactionBehavior::Immediate)
                    .unwrap();
                persist_pending_tx(&tx, &block.proposal, true).unwrap();
                std::process::exit(86);
            }
            "pending-after" => store.persist_pending(&block.proposal, true).unwrap(),
            "finalize-before" => {
                let mut conn = store.lock().unwrap();
                let tx = conn
                    .transaction_with_behavior(TransactionBehavior::Immediate)
                    .unwrap();
                insert_block(&tx, &block).unwrap();
                tx.execute(
                    "UPDATE head SET height=?1,hash=?2 WHERE id=1",
                    params![height(block.proposal.number).unwrap(), block.proposal.hash],
                )
                .unwrap();
                tx.execute("DELETE FROM signing_locks", []).unwrap();
                std::process::exit(86);
            }
            "finalize-after" => store.finalize(&block, None).unwrap(),
            _ => panic!("invalid child test mode"),
        }
        // Exit without Rust destructors or an orderly SQLite close.
        std::process::exit(86);
    }
}
