#!/usr/bin/env python3
"""Storage allocation and growth observations, separate from consensus health."""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import time

import backup
import guard
import policy

MIN_GROWTH_WINDOW = 300
MAX_GROWTH_WINDOW = 900
MAX_GROWTH_SAMPLES = 32


def growth_observation(usage, previous, now, mode):
    databases = usage["state"].get("databases", {})
    main = {node: files.get(policy.DATABASE_NAME, 0) for node, files in databases.items()}
    persistent = sum(main.values()) if mode == "sqlite" else usage["state"]["bytes"]
    sample = {"sampled_at_unix": now, "persistent_bytes": persistent, "main": main}
    history = []
    if (previous.get("ok") is True and previous.get("storage_mode") == mode
            and previous.get("database_main_limit_bytes") == usage["database_main_limit_bytes"]):
        supplied = previous.get("growth_samples", [])
        if isinstance(supplied, list):
            for item in supplied[-MAX_GROWTH_SAMPLES:]:
                if not isinstance(item, dict):
                    continue
                stamp, total, sizes = item.get("sampled_at_unix"), item.get("persistent_bytes"), item.get("main")
                if (type(stamp) not in (int, float) or not math.isfinite(stamp)
                        or not now - MAX_GROWTH_WINDOW <= stamp < now
                        or type(total) is not int or total < 0 or not isinstance(sizes, dict)
                        or set(sizes) != set(main)
                        or any(type(size) is not int or not 0 <= size <= policy.MAX_DATABASE_MAIN_BYTES for size in sizes.values())
                        or (mode == "sqlite" and total != sum(sizes.values()))):
                    continue
                if not history or stamp - history[-1]["sampled_at_unix"] >= 30:
                    history.append(item)
    result = {"persistent_database_bytes": persistent, "growth_samples": history,
              "growth_window_seconds": None, "growth_bytes_per_second": None,
              "main_growth_bytes_per_second": {}, "estimated_seconds_to_boundary": None,
              "wal_usage_bytes": {node: files.get(policy.DATABASE_NAME + "-wal", 0) for node, files in databases.items()},
              "shm_usage_bytes": {node: files.get(policy.DATABASE_NAME + "-shm", 0) for node, files in databases.items()},
              "forecast_scope": "Persistent main-file growth; WAL/SHM usage is reported separately", "warning": None}
    if history and now - history[0]["sampled_at_unix"] >= MIN_GROWTH_WINDOW:
        oldest = history[0]
        elapsed = now - oldest["sampled_at_unix"]
        rates = {node: max(0, size - oldest["main"][node]) / elapsed for node, size in main.items()}
        growth = sum(rates.values()) if mode == "sqlite" else max(0, persistent - oldest["persistent_bytes"]) / elapsed
        result.update(growth_window_seconds=elapsed, growth_bytes_per_second=growth,
                      main_growth_bytes_per_second=rates)
        if growth:
            # Retained full snapshots grow with the persistent database images.
            # Reserve the complete next backup workspace before estimating the
            # remaining disk margin. This is an explicit constant-rate model.
            workspace = 2 * policy.MAX_ARCHIVE_BYTES if mode == "sqlite" else 12 * policy.MIB
            disk_margin = usage["free_bytes"] - usage["reserve_bytes"] - workspace
            seconds = min((usage["state_limit_bytes"] - usage["state"]["bytes"]) / growth,
                          disk_margin / ((1 + policy.RETAIN_BACKUPS) * growth))
            for node, rate in rates.items():
                if rate:
                    seconds = min(seconds, (policy.MAX_DATABASE_MAIN_BYTES - main[node]) / rate)
            result["estimated_seconds_to_boundary"] = max(0, seconds)
            if seconds < 7 * 86400:
                result["warning"] = "observed_growth_reaches_storage_boundary_within_seven_days"
    if not history or now - history[-1]["sampled_at_unix"] >= 30:
        history.append(sample)
    result["growth_samples"] = history[-MAX_GROWTH_SAMPLES:]
    return result


def backup_observation(backup_root, mode, now):
    result = {"last_success_at_unix": None, "age_seconds": None,
              "cadence_seconds": backup.BACKUP_CADENCE_SECONDS,
              "stale_after_seconds": backup.BACKUP_STALE_SECONDS, "warning": None}
    try:
        receipt = backup.read_receipt(backup_root)
    except FileNotFoundError:
        result["warning"] = "backup_receipt_missing"
        return result
    except (OSError, ValueError, KeyError, TypeError, OverflowError, RecursionError):
        result["warning"] = "backup_receipt_invalid"
        return result
    age = now - receipt["completed_at_unix"]
    result.update(last_success_at_unix=receipt["completed_at_unix"],
                  age_seconds=max(0, age), archive=receipt["archive"],
                  sha256=receipt["sha256"], validators=receipt["validators"])
    try:
        metadata = policy.regular_file(backup_root / receipt["archive"], policy.MAX_ARCHIVE_BYTES, private=True)
        if metadata.st_size != receipt["bytes"]:
            raise ValueError("Backup archive size differs from receipt")
    except FileNotFoundError:
        result["warning"] = "backup_archive_missing"
    except (OSError, ValueError):
        result["warning"] = "backup_archive_metadata_invalid"
    if result["warning"] is None:
        if age < -60:
            result["warning"] = "backup_receipt_time_invalid"
        elif receipt["storage_mode"] != mode:
            result["warning"] = "backup_storage_mode_mismatch"
        elif age > backup.BACKUP_STALE_SECONDS:
            result["warning"] = "backup_stale"
    # Periodic observation checks metadata only; archive checksums are computed
    # during backup publication and off-host receipt, not every status sample.
    result["archive_checksum_rechecked"] = False
    return result


def observation(state_root, backup_root, mode, previous=None, now=None):
    now = time.time() if now is None else now
    usage = guard.check_storage(state_root, backup_root, mode)
    current = {"schema": "mfenx.native-storage-observation.v1", "sampled_at_unix": now,
               "ok": True, **usage, "growth_bytes_per_second": None,
               "estimated_seconds_to_boundary": None, "warning": None}
    previous = previous if isinstance(previous, dict) else {}
    current.update(growth_observation(usage, previous, now, mode))
    if usage["free_bytes"] < usage["reserve_bytes"] + policy.GIB:
        current["warning"] = "disk_reserve_margin_below_one_gib"
    current["backup"] = backup_observation(backup_root, mode, now)
    current["warnings"] = [warning for warning in (current["warning"], current["backup"]["warning"]) if warning]
    if current["warning"] is None:
        current["warning"] = current["backup"]["warning"]
    return current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-root", type=Path, default=policy.STATE_ROOT)
    parser.add_argument("--backup-root", type=Path, default=policy.BACKUP_ROOT)
    parser.add_argument("--output", type=Path, default=policy.STATE_ROOT / "gateway/storage-status.json")
    parser.add_argument("--storage-mode", choices=("json", "sqlite"), default=os.environ.get("MFENX_NATIVE_STORAGE", "json"))
    args = parser.parse_args()
    previous = None
    try:
        if args.output.exists():
            policy.regular_file(args.output, 65536)
            previous = json.loads(args.output.read_bytes())
        value = observation(args.state_root, args.backup_root, args.storage_mode, previous)
    except (OSError, ValueError, KeyError, TypeError, guard.GuardError):
        value = {"schema": "mfenx.native-storage-observation.v1", "sampled_at_unix": time.time(),
                 "ok": False, "warning": "storage_observation_failed"}
    policy.atomic_json(args.output, value, mode=0o644)
    print(json.dumps(value, sort_keys=True))
    return 0 if value["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
