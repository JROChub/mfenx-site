#!/usr/bin/env python3
"""Verify and prepare a snapshot in a new directory; never activate a signer."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tarfile

import policy


def prepare_restore(archive_path, destination, tool, expected_sha256=None):
    policy.regular_file(archive_path, policy.MAX_ARCHIVE_BYTES)
    if expected_sha256 is not None:
        h = hashlib.sha256()
        with archive_path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(65536), b""):
                h.update(chunk)
        if h.hexdigest() != expected_sha256:
            raise ValueError("Archive digest does not match the retained receipt")
    if destination.exists() or destination.is_symlink():
        raise ValueError("Recovery destination must be new")
    destination.mkdir(mode=0o700)
    complete = False
    try:
        with tarfile.open(archive_path, mode="r:") as archive:
            # Do not use extract/extractall: no archive-controlled filesystem
            # paths, symbolic links, devices, ownership or permissions apply.
            members = []
            for member in archive:
                members.append(member)
                if len(members) > 4 or not member.isfile():
                    raise ValueError("Unexpected archive member")
            names = [member.name for member in members]
            if len(names) != 4 or len(set(names)) != 4 or "snapshot.json" not in names:
                raise ValueError("Incomplete or duplicate snapshot members")
            meta_member = archive.getmember("snapshot.json")
            if not 0 < meta_member.size <= 65536:
                raise ValueError("Manifest size limit")
            manifest = json.loads(archive.extractfile(meta_member).read(65537))
            mode = manifest.get("storage_mode")
            if (manifest.get("schema") != "mfenx.native-snapshot.v2"
                    or manifest.get("chain_id") != policy.CHAIN_ID
                    or manifest.get("genesis_hash") != policy.GENESIS
                    or mode not in ("json", "sqlite")):
                raise ValueError("Unexpected snapshot identity")
            filename = policy.DATABASE_NAME if mode == "sqlite" else policy.LEGACY_NAME
            expected = {f"{node}/{filename}" for node in policy.VALIDATORS}
            records = manifest.get("ledgers", [])
            if (not isinstance(records, list) or len(records) != 3
                    or {row["name"] for row in records} != expected
                    or set(names) != expected | {"snapshot.json"}):
                raise ValueError("Unexpected validator membership")
            maximum = policy.MAX_DATABASE_MAIN_BYTES if mode == "sqlite" else policy.MAX_LEGACY_BYTES
            for record in records:
                member = archive.getmember(record["name"])
                if (type(record.get("bytes")) is not int or not 0 < member.size <= maximum
                        or member.size != record["bytes"]):
                    raise ValueError("Ledger size mismatch")
                output = destination / record["name"]
                output.parent.mkdir(mode=0o700)
                h = hashlib.sha256()
                with archive.extractfile(member) as source, output.open("xb") as stream:
                    os.fchmod(stream.fileno(), 0o600)
                    while chunk := source.read(65536):
                        stream.write(chunk)
                        h.update(chunk)
                    stream.flush()
                    os.fsync(stream.fileno())
                if h.hexdigest() != record.get("sha256"):
                    raise ValueError("Ledger checksum mismatch")
                if mode == "sqlite":
                    observed = policy.run_store(tool, "verify", output, timeout=600)
                else:
                    observed = policy.legacy_metadata(output.read_bytes())
                recorded = record["ledger"]
                policy.validate_metadata(recorded, require_integrity=True if mode == "sqlite" else None)
                for key in ("chain_id", "genesis_hash", "height", "block_hash", "state_root", "quorum", "validator_count"):
                    if observed[key] != recorded[key]:
                        raise ValueError("Restored ledger commitment mismatch")
                if mode == "sqlite":
                    for key in ("votes_cast", "pending_proposal"):
                        if observed.get(key) != recorded.get(key):
                            raise ValueError("Restored signer-lock metadata mismatch")
                policy.fsync_directory(output.parent)
            policy.atomic_json(destination / "snapshot.json", manifest)
            policy.atomic_json(destination / "RECOVERY-NOT-ACTIVATED.json", {
                "schema": "mfenx.native-recovery-preparation.v1", "activated": False,
                "storage_mode": mode,
                "verification": "Full SQLite integrity and history replay" if mode == "sqlite" else "JSON identity and checksums only; full legacy replay is still required",
                "required_before_activation": [
                    "Recover the matching validator identities and configuration separately; ledger archives contain no signing keys.",
                    "Stop the old instance of each signing identity and preserve its durable vote locks.",
                    "Compare recovered history with a trusted finalized checkpoint and reconcile any later votes.",
                    "Retain the original JSON ledger and explicit storage-mode configuration.",
                    "Activate only through a reviewed service handoff; this tool never starts services."
                ]})
            policy.fsync_directory(destination.parent)
            complete = True
            return {"prepared": str(destination), "activated": False, "storage_mode": mode,
                    "ledgers": records}
    finally:
        if not complete:
            shutil.rmtree(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--store-tool", type=Path, default=policy.STORE_TOOL)
    parser.add_argument("--expected-sha256")
    args = parser.parse_args()
    try:
        print(json.dumps(prepare_restore(args.archive, args.destination, args.store_tool, args.expected_sha256), sort_keys=True))
        return 0
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError):
        print('{"ok":false,"reason":"recovery_verification_failed","activated":false}')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
