"""Offline migration/backup/recovery check against explicitly supplied fixtures.

Set MFENX_TEST_STORE_TOOL to the built absolute binary path and
MFENX_TEST_LEGACY_FIXTURES to a directory containing validator-{1,2,3}/ ledgers.
The fixture files are read only and copied into a new temporary directory.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import backup
import guard
import policy
import recovery


@unittest.skipUnless(os.environ.get("MFENX_TEST_STORE_TOOL") and os.environ.get("MFENX_TEST_LEGACY_FIXTURES"),
                     "requires a built store CLI and explicit nonsecret legacy fixtures")
class StoreIntegration(unittest.TestCase):
    def test_offline_migration_consistent_backup_and_recovery(self):
        tool = Path(os.environ["MFENX_TEST_STORE_TOOL"]).resolve()
        fixtures = Path(os.environ["MFENX_TEST_LEGACY_FIXTURES"]).resolve()
        old_umask = os.umask(0o077)
        try:
            with tempfile.TemporaryDirectory(dir=os.environ.get("MFENX_OPS_TEST_TMPDIR")) as directory:
                root = Path(directory)
                state, archives = root / "state", root / "archives"
                state.mkdir(mode=0o700)
                archives.mkdir(mode=0o700)
                (state / "gateway").mkdir(mode=0o700)
                original = {}
                for node in policy.VALIDATORS:
                    node_dir = state / node
                    node_dir.mkdir(mode=0o700)
                    source = fixtures / node / policy.LEGACY_NAME
                    original[node] = source.read_bytes()
                    legacy = node_dir / policy.LEGACY_NAME
                    shutil.copyfile(source, legacy)
                    database = node_dir / policy.DATABASE_NAME
                    subprocess.run([str(tool), "migrate", "--legacy", str(legacy), "--database", str(database),
                                    "--max-bytes", str(policy.MAX_DATABASE_BYTES), "--json"],
                                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.PIPE, check=True, timeout=120)
                    self.assertEqual(legacy.read_bytes(), original[node])
                    metadata = policy.run_store(tool, "inspect", database)
                    observed = policy.legacy_metadata(original[node])
                    for key in ("chain_id", "genesis_hash", "height", "block_hash", "state_root"):
                        self.assertEqual(metadata[key], observed[key])
                with patch.object(guard, "ROOT_UID", os.getuid()):
                    saved = backup.create_backup(state, archives, tool, "sqlite")
                    restored = recovery.prepare_restore(archives / saved["backup"], root / "restored", tool,
                                                        expected_sha256=saved["sha256"])
                self.assertFalse(restored["activated"])
                self.assertEqual(len(restored["ledgers"]), 3)
                for node in policy.VALIDATORS:
                    self.assertEqual((state / node / policy.LEGACY_NAME).read_bytes(), original[node])
                    self.assertEqual((fixtures / node / policy.LEGACY_NAME).read_bytes(), original[node])
        finally:
            os.umask(old_umask)


if __name__ == "__main__":
    unittest.main()
