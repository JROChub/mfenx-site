#!/usr/bin/env python3
"""Observe finalized block progress through both public MFENX RPC endpoints."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import tempfile
import time
import urllib.error
import urllib.request

RPC_URLS = ("https://rpc.mfenx.com/2026/", "https://license.mfenx.com/network/2026/")
MANIFEST_URL = RPC_URLS[1] + "network-manifest.json"
STATUS_URL = RPC_URLS[1] + "network-status.json"
CHAIN_ID = 2026092601
GENESIS_HASH = "0x3b0b36b6acdcc5f0d7a1e38dd6621c58a9546a0e1a98cb58911b7646a0de5e8e"
HISTORY_ID = "mfenx-native-2026-09-27"
BLOCK_INTERVAL = 12
MAX_AGE = BLOCK_INTERVAL + 90
MAX_BODY = 131072
HASH = re.compile(r"0x[0-9a-fA-F]{64}\Z")
QUANTITY = re.compile(r"0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,15})\Z")


class CheckError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def require(condition, code, message):
    if not condition:
        raise CheckError(code, message)


def utc(timestamp):
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat().replace("+00:00", "Z")


def integer(value):
    return type(value) is int and 0 <= value <= 2**64 - 1


def quantity(value, field):
    require(isinstance(value, str) and QUANTITY.fullmatch(value), "invalid_quantity", field)
    return int(value, 16)


def block_hash(value, field):
    require(isinstance(value, str) and HASH.fullmatch(value), "invalid_hash", field)
    return value.lower()


def decode(raw):
    require(len(raw) <= MAX_BODY, "response_too_large", "Response exceeds 128 KiB")

    def pairs(entries):
        result = {}
        for key, value in entries:
            require(key not in result, "invalid_json", "Duplicate JSON key")
            result[key] = value
        return result

    def invalid_constant(_value):
        raise CheckError("invalid_json", "Nonfinite JSON number")

    try:
        result = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                            parse_constant=invalid_constant)
    except (ValueError, UnicodeError, RecursionError) as error:
        raise CheckError("invalid_json", "Response is not bounded UTF-8 JSON") from error
    pending = [(result, 0)]
    while pending:
        value, depth = pending.pop()
        require(depth <= 32, "invalid_json", "JSON nesting exceeds 32 levels")
        require(not isinstance(value, float) or math.isfinite(value),
                "invalid_json", "Nonfinite JSON number")
        if isinstance(value, dict):
            pending.extend((item, depth + 1) for item in value.values())
        elif isinstance(value, list):
            pending.extend((item, depth + 1) for item in value)
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, _request, _fp, _code, _message, _headers, _newurl):
        raise CheckError("http_redirect", "Pinned endpoint returned a redirect")


class Fetcher:
    def __init__(self, timeout=8.0):
        self.timeout = timeout
        self.next_request = 0.0
        self.opener = urllib.request.build_opener(NoRedirect())

    def __call__(self, url, payload=None):
        require(url in (*RPC_URLS, MANIFEST_URL, STATUS_URL), "endpoint_mismatch", "Unpinned endpoint")
        # Both public names share admission capacity. Space all HTTP requests.
        delay = self.next_request - time.monotonic()
        if delay > 0:
            time.sleep(delay)
        self.next_request = time.monotonic() + 0.35
        body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode()
        request = urllib.request.Request(url, data=body, headers={
            "Accept": "application/json", "Content-Type": "application/json",
            "User-Agent": "mfenx-finalized-progress/1", "Cache-Control": "no-cache",
        })
        started = time.monotonic()
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                length = response.headers.get("Content-Length")
                if length is not None:
                    require(length.isdecimal() and int(length) <= MAX_BODY,
                            "response_too_large", "Invalid or oversized response length")
                raw = bytearray()
                while True:
                    require(time.monotonic() - started <= self.timeout,
                            "request_timeout", "HTTP response exceeded its time budget")
                    chunk = response.read1(min(4096, MAX_BODY + 1 - len(raw)))
                    require(time.monotonic() - started <= self.timeout,
                            "request_timeout", "HTTP response exceeded its time budget")
                    if not chunk:
                        break
                    raw.extend(chunk)
                    require(len(raw) <= MAX_BODY, "response_too_large", "Response exceeds 128 KiB")
                return decode(bytes(raw))
        except urllib.error.HTTPError as error:
            raise CheckError("http_error", f"HTTP status {error.code}") from error
        except (OSError, urllib.error.URLError, TimeoutError) as error:
            raise CheckError("transport_error", "Endpoint request failed or timed out") from error


def rpc(fetch, url, method, params):
    response = fetch(url, {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    require(isinstance(response, dict) and response.get("jsonrpc") == "2.0"
            and type(response.get("id")) is int and response["id"] == 1,
            "rpc_envelope", f"Invalid {method} response envelope")
    require("error" not in response, "rpc_method_error", f"{method} returned an RPC error")
    require("result" in response, "rpc_envelope", f"{method} result is missing")
    return response["result"]


def read_block(fetch, url, height):
    value = rpc(fetch, url, "eth_getBlockByNumber", [hex(height), False])
    require(isinstance(value, dict), "block_missing", "Reported finalized block is unavailable")
    number = quantity(value.get("number"), "block number")
    require(number == height, "block_height_mismatch", "Block number differs from requested height")
    return {"height": number, "hash": block_hash(value.get("hash"), "block hash"),
            "parent_hash": block_hash(value.get("parentHash"), "parent hash"),
            "timestamp": quantity(value.get("timestamp"), "block timestamp")}


def identity(document):
    value = document.get("identity") if isinstance(document, dict) else None
    require(isinstance(value, dict) and type(value.get("chain_id")) is int
            and value["chain_id"] == CHAIN_ID and value.get("genesis_hash") == GENESIS_HASH
            and value.get("history_id") == HISTORY_ID,
            "identity_mismatch", "Published identity differs from pinned history")


def timestamp(value):
    require(isinstance(value, str) and len(value) <= 40, "invalid_timestamp", "Missing ISO timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        require(parsed.tzinfo is not None, "invalid_timestamp", "Timestamp lacks a timezone")
        return parsed.timestamp()
    except (ValueError, OverflowError) as error:
        raise CheckError("invalid_timestamp", "Invalid ISO timestamp") from error


def fresh(observed, now, field):
    require(-30 <= now - observed <= MAX_AGE, "stale_timestamp", f"{field} is stale or in the future")


def check_manifest(value):
    identity(value)
    require(value.get("schema") == "mfenx.network-manifest.v1", "manifest_schema", "Unknown manifest schema")
    limits = value.get("limits", {})
    require(isinstance(limits, dict) and limits.get("empty_block_interval_seconds") == BLOCK_INTERVAL,
            "cadence_mismatch", "Manifest does not advertise the required 12-second cadence")
    require(isinstance(value.get("rpc"), list) and set(value["rpc"]) == set(RPC_URLS),
            "endpoint_mismatch", "Manifest RPC endpoints differ from pinned endpoints")
    validators = value.get("validators")
    topology = value.get("topology", {})
    require(isinstance(validators, list) and len(validators) == 3
            and all(isinstance(v, dict) and isinstance(v.get("node_id"), str) for v in validators),
            "validator_identity", "Expected three distinct validators")
    names = {v["node_id"] for v in validators}
    require(len(names) == 3 and isinstance(topology, dict) and topology.get("quorum") == 2
            and topology.get("validator_count") == 3,
            "validator_identity", "Unexpected validator count or quorum")
    return names


def check_status(value, names, now):
    identity(value)
    require(value.get("schema") == "mfenx.network-status.v1", "status_schema", "Unknown status schema")
    require(value.get("empty_block_interval_seconds") == BLOCK_INTERVAL,
            "cadence_mismatch", "Status does not advertise the required 12-second cadence")
    fresh(timestamp(value.get("sampled_at")), now, "Status sample")
    fresh(timestamp(value.get("generated_at")), now, "Status document")
    fresh(timestamp(value.get("last_finalized_at")), now, "Status finalized tip")
    height = value.get("block_height")
    tip = block_hash(value.get("tip_hash"), "status tip hash")
    require(integer(height), "invalid_quantity", "Invalid status block height")
    require(value.get("quorum_agreement") is True, "status_quorum", "Status reports no quorum agreement")
    validators = value.get("validators")
    require(isinstance(validators, list) and len(validators) == len(names)
            and all(isinstance(v, dict) for v in validators)
            and {v.get("node_id") for v in validators} == names,
            "validator_identity", "Status validator membership differs from manifest")
    votes = Counter()
    for validator in validators:
        require(validator.get("genesis_hash") == GENESIS_HASH,
                "identity_mismatch", "Validator reports an unexpected genesis")
        if validator.get("healthy") is True:
            require(integer(validator.get("height")), "invalid_quantity", "Invalid validator height")
            votes[(validator["height"], block_hash(validator.get("tip_hash"), "validator tip hash"))] += 1
    require(votes[(height, tip)] >= 2, "status_quorum", "Status tip lacks two matching healthy validators")
    return {"height": height, "hash": tip, "sampled_at": value["sampled_at"],
            "last_finalized_at": value["last_finalized_at"]}


def run_monitor(fetch, *, duration=36.0, interval=12.0, clock=time.time,
                monotonic=time.monotonic, sleep=time.sleep):
    report = {"schema": "mfenx.live-progress.v1", "started_at": utc(clock()), "ok": False,
              "identity": {"chain_id": CHAIN_ID, "genesis_hash": GENESIS_HASH, "history_id": HISTORY_ID},
              "duration_seconds": duration if isinstance(duration, (int, float)) and math.isfinite(duration) else None,
              "sample_interval_seconds": interval if isinstance(interval, (int, float)) and math.isfinite(interval) else None,
              "max_finalized_age_seconds": MAX_AGE, "samples": [], "errors": []}
    try:
        require(math.isfinite(duration) and math.isfinite(interval) and 12 <= duration <= 3600
                and 1 <= interval <= duration and math.ceil(duration / interval) <= 120,
                "invalid_configuration", "Sampling duration or interval is outside its bounds")
        names = check_manifest(fetch(MANIFEST_URL))
        for url in RPC_URLS:
            require(quantity(rpc(fetch, url, "eth_chainId", []), "chain ID") == CHAIN_ID,
                    "identity_mismatch", "RPC chain ID differs from pinned history")
            require(read_block(fetch, url, 0)["hash"] == GENESIS_HASH,
                    "identity_mismatch", "RPC genesis differs from pinned history")

        start = monotonic()
        offsets = [min(index * interval, duration) for index in range(math.ceil(duration / interval) + 1)]
        previous = {}
        pending_status = []
        for offset in offsets:
            sleep(max(0.0, start + offset - monotonic()))
            sample = {"observed_at": utc(clock()), "elapsed_seconds": monotonic() - start, "rpc": {}}
            report["samples"].append(sample)
            status = check_status(fetch(STATUS_URL), names, clock())
            sample["status"] = status
            sample["status_tip_endpoints_checked"] = 0
            pending_status.append((status, sample, set()))
            cache = {}

            def at(url, height):
                key = (url, height)
                if key not in cache:
                    cache[key] = read_block(fetch, url, height)
                return cache[key]

            for url in RPC_URLS:
                height = quantity(rpc(fetch, url, "eth_blockNumber", []), "RPC block height")
                block = at(url, height)
                fresh(block["timestamp"], clock(), "RPC finalized tip")
                old = previous.get(url)
                if old:
                    require(height >= old["height"], "height_regression", "RPC finalized height decreased")
                    if height == old["height"]:
                        require(block == old, "finalized_block_changed", "Finalized block changed at the same height")
                    else:
                        require(block["hash"] != old["hash"] and block["timestamp"] > old["timestamp"],
                                "counter_without_block", "Height advanced without a new finalized block")
                        if height == old["height"] + 1:
                            require(block["parent_hash"] == old["hash"],
                                    "parent_mismatch", "New finalized block does not extend the observed tip")
                        else:
                            require(at(url, old["height"]) == old,
                                    "finalized_block_changed", "Previously observed history changed")
                sample["rpc"][url] = block
                previous[url] = block

            common_height = min(block["height"] for block in sample["rpc"].values())
            common = [at(url, common_height) for url in RPC_URLS]
            require(common[0] == common[1], "endpoint_fork", "RPC endpoints disagree at the same finalized height")
            sample["common_height"] = common_height
            sample["common_hash"] = common[0]["hash"]
            # A status sampler may observe the next finalized height before
            # either RPC read. Retain that commitment for a later sample;
            # unequal observation heights alone do not establish a fork.
            for observed, source_sample, checked in pending_status:
                for url in RPC_URLS:
                    if url not in checked and observed["height"] <= sample["rpc"][url]["height"]:
                        require(at(url, observed["height"])["hash"] == observed["hash"],
                                "status_tip_mismatch", "Status hash differs from RPC at the corresponding height")
                        checked.add(url)
                        source_sample["status_tip_endpoints_checked"] = len(checked)
                        source_sample["status_tip_checked_at"] = utc(clock())
            pending_status = [entry for entry in pending_status if len(entry[2]) < len(RPC_URLS)]

        first, last = report["samples"][0], report["samples"][-1]
        advances = {url: last["rpc"][url]["height"] - first["rpc"][url]["height"] for url in RPC_URLS}
        report["height_advances"] = advances
        require(all(value > 0 for value in advances.values()), "stalled_height", "Finalized height did not advance on both endpoints")
        require(any(sample["status_tip_endpoints_checked"] > 0 for sample in report["samples"]),
                "status_unverified", "No published status tip could be checked against finalized RPC history")
        report["ok"] = True
    except CheckError as error:
        report["errors"].append({"code": error.code, "message": str(error)})
    except (OSError, ValueError, TypeError, KeyError, OverflowError, RecursionError):
        report["errors"].append({"code": "observation_failed", "message": "Malformed or unavailable observation"})
    report["finished_at"] = utc(clock())
    return report


def save_report(destination, report):
    descriptor, name = tempfile.mkstemp(prefix=destination.name + ".", suffix=".tmp", dir=destination.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w") as stream:
            json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
        directory = os.open(destination.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--duration", type=float, default=36)
    parser.add_argument("--sample-interval", type=float, default=12)
    parser.add_argument("--timeout", type=float, default=8)
    args = parser.parse_args(argv)
    if not math.isfinite(args.timeout) or not 1 <= args.timeout <= 30:
        parser.error("timeout must be between 1 and 30 seconds")
    report = run_monitor(Fetcher(args.timeout), duration=args.duration, interval=args.sample_interval)
    try:
        save_report(args.output, report)
    except OSError:
        report["ok"] = False
        report["errors"].append({"code": "evidence_write_failed", "message": "Could not save observation evidence"})
    print(json.dumps(report, sort_keys=True, allow_nan=False))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
