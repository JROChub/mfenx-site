#!/usr/bin/env python3
"""Measure isolated validators and real maintenance in one bounded user slice.

The coordinator stays outside the measured slice. Public test seeds initialize
a distinct loopback chain. Maintenance uses separate copies of offline captured
ledgers, so its production identity checks remain enabled. No production service,
key, RPC or database is accessed. Only the traffic-control result and local file
owner are substituted for maintenance. This is a finite empty-block test.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import uuid

import local_soak as fixture


OPS = Path(__file__).resolve().parent


def control(*arguments, check=True):
    return subprocess.run(["systemctl", "--user", *map(str, arguments)], check=check,
                          stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, text=True, timeout=30)


def properties(unit):
    value = control("show", unit, "--no-pager", "--property=ActiveState,SubState,Result,ExecMainStatus,MainPID,ControlGroup").stdout
    return dict(line.split("=", 1) for line in value.splitlines() if "=" in line)


def resources(group):
    path = Path("/sys/fs/cgroup") / group.lstrip("/")
    def read(name):
        return (path / name).read_text().strip()
    return {"memory_current": int(read("memory.current")), "memory_peak": int(read("memory.peak")),
            "memory_max": read("memory.max"), "memory_high": read("memory.high"),
            "memory_swap_max": read("memory.swap.max"), "pids_current": int(read("pids.current")),
            "pids_max": read("pids.max"), "cpu_max": read("cpu.max"),
            "memory_events": {key: int(value) for key, value in (line.split() for line in read("memory.events").splitlines())},
            "cpu_stat": {key: int(value) for key, value in (line.split() for line in read("cpu.stat").splitlines())}}


class Services:
    def __init__(self, root):
        self.prefix = "mfenxaccept" + uuid.uuid4().hex[:10]
        self.slice = self.prefix + ".slice"
        self.root = root
        self.units = []

    def start(self, label, command, env=None, memory=None, tasks=16, oneshot=False, timeout=60):
        unit = self.prefix + "-" + label + ".service"
        log = self.root / (label + ".log")
        options = ["systemd-run", "--user", "--quiet", "--unit=" + unit, "--slice=" + self.slice,
                   "-p", "Type=exec", "-p", "KillSignal=SIGINT", "-p", "TimeoutStopSec=20",
                   "-p", "UMask=0077", "-p", "NoNewPrivileges=yes", "-p", "LimitNOFILE=256",
                   "-p", "TasksMax=" + str(tasks), "-p", "OOMScoreAdjust=700",
                   "-p", "StandardOutput=append:" + str(log), "-p", "StandardError=append:" + str(log)]
        if memory:
            options += ["-p", "MemoryMax=" + memory]
        if oneshot:
            options += ["-p", "RemainAfterExit=yes", "-p", "RuntimeMaxSec=" + str(timeout)]
        environment = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": str(self.root), **(env or {})}
        options += ["/usr/bin/env", "-i", *(key + "=" + str(value) for key, value in environment.items()), *map(str, command)]
        subprocess.run(options, check=True, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, timeout=30)
        self.units.append(unit)
        return unit

    def stop(self, unit):
        control("stop", unit)

    def close(self):
        if self.units:
            control("stop", *self.units, check=False)
            control("reset-failed", *self.units, check=False)
        control("stop", self.slice, check=False)


def wait_rpc(port, unit):
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        if properties(unit).get("ActiveState") != "active":
            raise ValueError("Isolated validator exited during startup")
        try:
            if fixture.rpc(port, "eth_chainId", []) == hex(fixture.CHAIN_ID):
                return
        except (OSError, ValueError, KeyError):
            pass
        time.sleep(.2)
    raise ValueError("Isolated validator startup timeout")


def maintenance_command(role, root, barrier, ready):
    # The short wait keeps the imported real oneshots resident together while
    # the backup child runs. It adds no allocated payload or synthetic memory.
    code = ("import os,sys,time;from pathlib import Path;sys.path.insert(0," + repr(str(OPS)) + ");"
            "import guard;guard.ROOT_UID=os.getuid();")
    state, backups = root / "maintenance-state", root / "maintenance-backups"
    if role == "guard":
        tc = '[{"root":true,"kind":"tbf","handle":"c0de:","options":{"rate":64000,"burst":8192,"limit":16384}}]'
        code += ("original_check=guard.check_storage;guard.check_storage=lambda **kw:original_check(Path("
                 + repr(str(state)) + "),Path(" + repr(str(backups)) + "),**kw);"
                 "guard.read_tc=lambda:" + repr(tc.encode()) + ";run=guard.main;")
        extra = []
    else:
        code += "import " + role + ";run=" + role + ".main;"
        extra = ["--state-root", str(state), "--backup-root", str(backups), "--storage-mode", "sqlite"]
        if role == "status":
            extra += ["--output", str(state / "gateway/storage-status.json")]
    code += ("Path(" + repr(str(ready)) + ").touch();deadline=time.monotonic()+30\n"
             "while not Path(" + repr(str(barrier)) + ").exists():\n"
             " if time.monotonic()>deadline: raise RuntimeError('maintenance barrier timeout')\n"
             " time.sleep(.05)\n"
             "result=run()\n" + ("time.sleep(3)\n" if role != "backup" else "") + "raise SystemExit(result)\n")
    return [sys.executable, "-B", "-c", code, *extra]


def run(args):
    args.work_parent.mkdir(parents=True, exist_ok=True)
    report = {"schema": "mfenx.cluster-maintenance-soak.v1", "production_access": False,
              "duration_seconds": args.seconds, "chain_id": fixture.CHAIN_ID,
              "binary_sha256": {"julian": fixture.file_sha256(args.julian),
                                "native-store-tool": fixture.file_sha256(args.store_tool)},
              "database_budget_bytes": fixture.DATABASE_BUDGET_BYTES,
              "maintenance_input_sha256": fixture.file_sha256(args.maintenance_snapshot),
              "python_version": sys.version.split()[0], "samples": [], "maintenance_cycles": [], "passed": False,
              "scope": "Three isolated empty-block validators and gateway; actual guard/status/backup on separate copied height-37 ledgers. Local file ownership and tc output are fixture substitutions. Guard/status remain resident for 3 seconds after their operation to force memory overlap. Coordinator excluded; no production traffic, live production WAL or sustained load is modeled."}
    old_umask = os.umask(0o077)
    with tempfile.TemporaryDirectory(prefix="cluster-maintenance-", dir=args.work_parent) as directory:
        root = Path(directory)
        services = Services(root)
        group = None
        try:
            for port in [args.p2p_base + n for n in range(3)] + [args.rpc_base + n for n in range(3)] + [args.edge_port]:
                with socket.socket() as probe:
                    probe.bind(("127.0.0.1", port))
            services.start("anchor", ["/usr/bin/true"], oneshot=True, timeout=args.seconds + 300)
            control("set-property", "--runtime", services.slice, "MemoryHigh=80M", "MemoryMax=96M",
                    "MemorySwapMax=0", "CPUQuota=20%", "TasksMax=64")
            group = properties(services.slice)["ControlGroup"]
            self_group = next(line.split("::", 1)[1] for line in Path("/proc/self/cgroup").read_text().splitlines() if line.startswith("0::"))
            if self_group == group or self_group.startswith(group + "/"):
                raise ValueError("Coordinator must remain outside the measured slice")
            initial = resources(group)
            quota, period = initial["cpu_max"].split()
            if (initial["memory_max"] != str(96 * 1024**2) or initial["memory_high"] != str(80 * 1024**2)
                    or initial["memory_swap_max"] != "0" or initial["pids_max"] != "64"
                    or quota == "max" or int(quota) / int(period) != .2):
                raise ValueError("Shared slice resource policy did not apply")
            report["resource_start"] = initial
            report["coordinator_outside_slice"] = True
            policy_path = root / "validators.json"
            policy_path.write_text(json.dumps({"backend": "static", "allowlist": fixture.PUBLIC_KEYS}))
            peers = [None] * 3
            nodes = []
            environment = {"MFENX_NATIVE_STORAGE": "json", "MFENX_NATIVE_EMPTY_BLOCK_SECONDS": "12",
                           "MFENX_NATIVE_MAX_DATABASE_BYTES": str(fixture.DATABASE_BUDGET_BYTES),
                           "MFENX_NATIVE_MAX_PENDING": "16", "MFENX_NATIVE_MAX_ORPHAN_BLOCKS": "16",
                           "MFENX_NATIVE_MAX_STATE_BYTES": "1572864", "MFENX_EVM_ACTIVATION_HEIGHT": "1"}
            def launch(index, mode):
                node = root / f"validator-{index + 1}"
                (node / "logs").mkdir(parents=True, exist_ok=True)
                command = [args.julian, "net", "start", "--node-id", f"validator-{index + 1}",
                           "--key", "ed25519://" + fixture.SEEDS[index], "--policy", policy_path,
                           "--quorum", "2", "--attestation-quorum", "2", "--tokio-threads", "1",
                           "--blob-dir", node, "--log-dir", node / "logs",
                           "--listen", f"/ip4/127.0.0.1/tcp/{args.p2p_base + index}",
                           "--evm-rpc-listen", f"127.0.0.1:{args.rpc_base + index}",
                           "--evm-chain-id", fixture.CHAIN_ID, "--broadcast-interval", "1500",
                           "--checkpoint-interval", "0", "--anchor-topic", "isolated-native-sqlite-soak"]
                for other, peer in enumerate(peers):
                    if peer and other != index:
                        command += ["--bootstrap", f"/ip4/127.0.0.1/tcp/{args.p2p_base + other}/p2p/{peer}"]
                label = f"node-{index + 1}-{mode}"
                unit = services.start(label, command, {**environment, "MFENX_NATIVE_STORAGE": mode})
                wait_rpc(args.rpc_base + index, unit)
                matches = re.findall(r"\bpeer=([A-Za-z0-9]+)", (root / (label + ".log")).read_text(errors="replace"))
                if not matches:
                    raise ValueError("Isolated peer identifier missing")
                peers[index] = matches[0]
                return unit
            for index in range(3):
                nodes.append(launch(index, "json"))
            for unit in nodes:
                services.stop(unit)
            frozen = {}
            for index in range(3):
                node = root / f"validator-{index + 1}"
                frozen[index] = fixture.file_sha256(node / "native_chain_state.json")
                fixture.tool_json(args.store_tool, "migrate", "--legacy", node / "native_chain_state.json",
                                  "--database", node / "native_chain_state.sqlite3")
            nodes = [launch(index, "sqlite") for index in range(3)]
            genesis = fixture.rpc(args.rpc_base, "eth_getBlockByNumber", ["0x0", False])["hash"]
            report["genesis_hash"] = genesis
            gateway_state = root / "gateway"
            gateway_state.mkdir()
            config = {"manifest": {"identity": {"name": "Isolated maintenance soak", "chain_id": fixture.CHAIN_ID,
                       "history_id": "isolated-native-sqlite-soak", "genesis_hash": genesis,
                       "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 60)),
                       "previous_chain_id": 177155, "previous_history_restored": False},
                       "topology": {"validator_count": 3, "quorum": 2, "host_count": 1, "failure_domain_count": 1, "regions": ["local"]},
                       "public_rpc_mode": "evm_contracts", "transaction_submission": "public_signed_evm",
                       "execution": {"profile": "mfenx-evm-cancun-fee-free-v1", "activation_height": 1, "validator_replay": True},
                       "runtime": {"client": "local-maintenance-soak"}},
                      "nodes": [{"node_id": f"validator-{i + 1}", "peer_id": peers[i],
                                 "public_key": fixture.PUBLIC_KEYS[i], "rpc_port": args.rpc_base + i} for i in range(3)]}
            config_path = root / "gateway.json"
            config_path.write_text(json.dumps(config))
            code = ("import sys;sys.path.insert(0," + repr(str(OPS)) + ");import gateway;gateway.CHAIN_ID="
                    + str(fixture.CHAIN_ID) + ";gateway.HISTORY_ID='isolated-native-sqlite-soak';gateway.main()")
            edge = services.start("edge", [sys.executable, "-B", "-c", code, "--config", config_path,
                                  "--state-dir", gateway_state, "--port", args.edge_port], environment)
            state, backups = root / "maintenance-state", root / "maintenance-backups"
            state.mkdir(mode=0o700)
            backups.mkdir(mode=0o700)
            for name in ("validator-1", "validator-2", "validator-3", "gateway"):
                (state / name).mkdir(mode=0o700)
                if name.startswith("validator"):
                    shutil.copyfile(args.maintenance_snapshot, state / name / "native_chain_state.sqlite3")
                    shutil.copyfile(args.legacy_fixtures / name / "native_chain_state.json", state / name / "native_chain_state.json")
            began, next_cycle = time.monotonic(), 15
            active_cycle = None
            while time.monotonic() - began < args.seconds:
                elapsed = time.monotonic() - began
                for unit in [*nodes, edge]:
                    if properties(unit).get("SubState") != "running":
                        raise ValueError("Cluster service exited under the shared resource boundary")
                tips = [fixture.rpc(args.rpc_base + i, "eth_getBlockByNumber", ["latest", False]) for i in range(3)]
                shared = min(int(tip["number"], 16) for tip in tips)
                common = [fixture.rpc(args.rpc_base + i, "eth_getBlockByNumber", [hex(shared), False])["hash"] for i in range(3)]
                if len(set(common)) != 1:
                    raise ValueError("Validators disagree at a common finalized height")
                report["samples"].append({"elapsed_seconds": elapsed,
                    "heights": [int(tip["number"], 16) for tip in tips], "hashes": [tip["hash"] for tip in tips],
                    "shared_height": shared, "shared_hash": common[0], "resources": resources(group)})
                if active_cycle:
                    states = {role: properties(unit) for role, unit in active_cycle["units"].items()}
                    if any(value.get("ActiveState") == "failed" or value.get("Result") not in ("success", "") for value in states.values()):
                        raise ValueError("Maintenance service failed under the shared resource boundary")
                    if all(value.get("SubState") == "exited" for value in states.values()):
                        active_cycle["completed_elapsed_seconds"] = elapsed
                        active_cycle["results"] = states
                        receipt = json.loads((backups / "latest.json").read_text())
                        if (set(receipt["validators"]) != {"validator-1", "validator-2", "validator-3"}
                                or not all(value.get("integrity_ok") is True and value.get("integrity_checked") is True
                                           and value.get("height") == 37 for value in receipt["validators"].values())):
                            raise ValueError("Copied-ledger backup failed full verification")
                        active_cycle["backup_sha256"] = receipt["sha256"]
                        active_cycle["backup_verified_heights"] = {key: value["height"] for key, value in receipt["validators"].items()}
                        report["maintenance_cycles"].append(active_cycle)
                        active_cycle = None
                if elapsed >= next_cycle and active_cycle is None:
                    index = len(report["maintenance_cycles"])
                    barrier = root / f"cycle-{index}-go"
                    units = {}
                    for role in ("guard", "status", "backup"):
                        ready = root / f"cycle-{index}-{role}-ready"
                        command = maintenance_command(role, root, barrier, ready)
                        if role == "backup":
                            command += ["--store-tool", str(args.store_tool)]
                        units[role] = services.start(f"cycle-{index}-{role}", command,
                            {"MFENX_NATIVE_STORAGE": "sqlite", "MFENX_NATIVE_MAX_DATABASE_BYTES": str(fixture.DATABASE_BUDGET_BYTES)},
                            memory="48M" if role == "backup" else "24M", tasks=8 if role == "status" else 16,
                            oneshot=True, timeout=60)
                    deadline = time.monotonic() + 30
                    while not all((root / f"cycle-{index}-{role}-ready").exists() for role in units):
                        if time.monotonic() > deadline or any(properties(unit).get("ActiveState") == "failed" for unit in units.values()):
                            raise ValueError("Concurrent maintenance did not reach its start barrier")
                        time.sleep(.1)
                    active_cycle = {"started_elapsed_seconds": time.monotonic() - began, "units": units,
                                    "overlap_resources": resources(group)}
                    barrier.touch()
                    next_cycle += 60
                time.sleep(3)
            if active_cycle:
                raise ValueError("Maintenance still running at end of observation")
            final = report["samples"][-1]
            first = report["samples"][0]
            report["resource_end"] = resources(group)
            report["elapsed_seconds"] = time.monotonic() - began
            report["originals_unchanged"] = (report["maintenance_input_sha256"] == fixture.file_sha256(args.maintenance_snapshot)
                and all(frozen[i] == fixture.file_sha256(root / f"validator-{i + 1}/native_chain_state.json") for i in range(3)))
            report["height_advance"] = min(final["heights"]) - max(first["heights"])
            report["passed"] = (report["height_advance"] >= args.seconds // 30
                and len(report["maintenance_cycles"]) >= 3 and report["originals_unchanged"]
                and not any(report["resource_end"]["memory_events"].get(key, 0) for key in ("oom", "oom_kill", "oom_group_kill")))
            if not report["passed"]:
                raise ValueError("Whole-cluster maintenance acceptance criteria were not met")
        except Exception as error:
            report["failure"] = type(error).__name__ + ": " + str(error)
            if group:
                report["resource_end"] = resources(group)
            report["service_results"] = {unit: properties(unit) for unit in services.units}
            report["fixture_log_tails"] = {path.name: path.read_text(errors="replace")[-4096:] for path in root.glob("*.log")}
        finally:
            services.close()
            os.umask(old_umask)
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("julian", "store-tool", "maintenance-snapshot", "legacy-fixtures", "work-parent", "report"):
        parser.add_argument("--" + option, type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=180)
    parser.add_argument("--p2p-base", type=int, default=30601)
    parser.add_argument("--rpc-base", type=int, default=31645)
    parser.add_argument("--edge-port", type=int, default=31093)
    args = parser.parse_args()
    if not 180 <= args.seconds <= 3600 or any(not getattr(args, option).is_absolute() for option in
            ("julian", "store_tool", "maintenance_snapshot", "legacy_fixtures", "work_parent", "report")):
        parser.error("Use absolute paths and a duration between 180 and 3600 seconds")
    fixture.require_standalone(args.maintenance_snapshot)
    raise SystemExit(run(args))


if __name__ == "__main__":
    main()
