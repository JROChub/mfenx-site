#!/usr/bin/env python3
"""Test the backup capability boundary on a disposable local snapshot.

Requires local noninteractive sudo for transient systemd services. The supplied
source must be an offline standalone SQLite copy, never an active validator DB.
Only copies under a private temporary directory are passed to the root services.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import tempfile
import uuid

import policy


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def source_files(source):
    return {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)}
            for suffix in ("", "-wal", "-shm")
            if (path := Path(str(source) + suffix)).exists()}


@contextmanager
def held_wal_fixture(source, enabled):
    if not enabled:
        yield None
        return
    # Only the disposable local copy is opened through Python SQLite. The
    # original input and production databases are never passed to this API.
    connection = sqlite3.connect(source, isolation_level=None, timeout=5)
    try:
        original_version = connection.execute("PRAGMA user_version").fetchone()[0]
        if connection.execute("PRAGMA journal_mode=WAL").fetchone()[0] != "wal":
            raise ValueError("Local SQLite did not enable the WAL fixture")
        connection.execute("PRAGMA wal_autocheckpoint=0")
        connection.execute("BEGIN IMMEDIATE")
        # Write the existing header value to produce a committed WAL frame
        # without changing ledger data or the native-store schema version.
        connection.execute(f"PRAGMA user_version={int(original_version)}")
        connection.execute("COMMIT")
        if connection.execute("PRAGMA user_version").fetchone()[0] != original_version:
            raise ValueError("WAL fixture changed the schema version")
        wal = Path(str(source) + "-wal")
        shm = Path(str(source) + "-shm")
        if not wal.is_file() or wal.stat().st_size <= 32 or not shm.is_file():
            raise ValueError("Local SQLite did not retain a committed WAL and shared-memory file")
        yield {"sqlite_version": sqlite3.sqlite_version, "user_version": original_version,
               "committed_wal_bytes": wal.stat().st_size, "writer_connection_retained": True}
    finally:
        # Closing can checkpoint the fixture. All comparisons are made before
        # this point, while the original writer connection still holds it open.
        connection.close()


def run(args):
    if os.geteuid() == 0:
        raise ValueError("Launch as the local unprivileged operator so source ownership differs from root")
    if any(Path(str(args.source) + suffix).exists() for suffix in ("-wal", "-shm")):
        raise ValueError("Use an offline standalone backup, not a database with live sidecars")
    input_digest = sha(args.source)
    with tempfile.TemporaryDirectory(prefix="mfenx-capability-") as directory:
        work = Path(directory)
        source, executable, output = work / "source.sqlite3", work / "native-store-tool", work / "output"
        shutil.copyfile(args.source, source)
        source.chmod(0o600)
        shutil.copyfile(args.store_tool, executable)
        executable.chmod(0o755)
        output.mkdir(mode=0o777)
        # The enclosing directory is operator-owned0700. This leaf permits the
        # bounded root service to create output without CAP_DAC_OVERRIDE.
        output.chmod(0o777)
        def service(operation, database, extra=()):
            unit = "mfenx-local-capability-" + uuid.uuid4().hex[:12]
            command = ["sudo", "-n", "systemd-run", "--wait", "--pipe", "--collect", "--quiet",
                       "--unit=" + unit, "-p", "User=root", "-p", "Group=root",
                       "-p", "CapabilityBoundingSet=CAP_DAC_READ_SEARCH", "-p", "NoNewPrivileges=yes",
                       "-p", "ProtectSystem=strict", "-p", "ProtectHome=yes", "-p", "PrivateTmp=no",
                       "-p", "RestrictAddressFamilies=AF_UNIX", "-p", "ReadOnlyPaths=" + str(source),
                       "-p", "ReadWritePaths=" + str(output), "-p", "MemoryMax=48M",
                       "-p", "CPUQuota=20%", "-p", "TasksMax=16", "-p", "TimeoutStartSec=180",
                       "-p", "UMask=0077", str(executable), operation, "--database", str(database),
                       "--max-bytes", str(policy.MAX_DATABASE_BYTES),
                       *map(str, extra), "--json"]
            result = subprocess.run(command, check=True, timeout=200, stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if len(result.stdout) > 65536:
                raise ValueError("Capability command output limit")
            return json.loads(result.stdout)
        with held_wal_fixture(source, args.wal_fixture) as fixture:
            before = source_files(source)
            inspected = service("inspect", source)
            after_inspect = source_files(source)
            saved = service("backup", source, ("--output", output / "backup.sqlite3"))
            after_backup = source_files(source)
            verified = service("verify", output / "backup.sqlite3")
            after = source_files(source)
            unchanged = before == after_inspect == after_backup == after
            same_files = before.keys() == after.keys()
            input_unchanged = input_digest == sha(args.source)
            report = {"schema": "mfenx.local-backup-capability-test.v1", "production_access": False,
                      "fixture_kind": "committed-wal" if fixture else "standalone", "wal_fixture": fixture,
                      "capabilities": ["CAP_DAC_READ_SEARCH"], "source_owned_by_root": source.stat().st_uid == 0,
                      "source_unchanged": unchanged, "source_sidecars_not_created": same_files,
                      "input_unchanged": input_unchanged, "source_files_before": before,
                      "source_files_after": after,
                      "inspect": inspected, "backup": saved, "verify": verified,
                      "scope": ("Cross-owner read-only committed WAL snapshot with an idle writer connection retained; concurrent writes are tested separately by local_soak.py"
                                if fixture else "Cross-owner read-only standalone snapshot; live WAL concurrency is tested separately by local_soak.py"),
                      "passed": unchanged and same_files and input_unchanged and inspected.get("head_valid") is True
                        and inspected.get("integrity_checked") is False and saved.get("integrity_ok") is True
                        and verified.get("integrity_ok") is True}
            args.report.write_text(json.dumps(report, indent=2) + "\n")
            return 0 if report["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--store-tool", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--wal-fixture", action="store_true",
                        help="Create a committed WAL on the disposable copy and retain its local writer during root reads")
    args = parser.parse_args()
    raise SystemExit(run(args))


if __name__ == "__main__":
    main()
