Native SQLite operations

This release preserves chain `2026092601`, genesis
`0x3b0b36b6acdcc5f0d7a1e38dd6621c58a9546a0e1a98cb58911b7646a0de5e8e`,
the existing validator identities and finalized history. Three validator processes
and the loopback gateway remain on one host. The aggregate boundary remains
96 MiB RAM, no swap, 20% CPU and 64 tasks. Host loss still stops the entire network;
this storage upgrade does not provide independent failure domains.

`legacy/` contains the captured nonsecret operating scripts and unit definitions,
with hashes in `legacy/capture-manifest.json`. It contains no signing keys,
production configuration files or ledger snapshots. Candidate files under
`systemd/` are not installed automatically.

Storage and backup boundaries

`policy.py` defines a 512 MiB total SQLite allocation per validator, including
WAL/SHM headroom. The SQLite main-file page ceiling is
`((512 MiB - 1 MiB) // 100 * 49) // 4096 * 4096`: 262,549,504 bytes per node.
The guard additionally bounds each WAL to 32 MiB and each SHM file to 1 MiB,
all active state to 1 GiB, backup archives and staging to 4 GiB, and preserves
2 GiB free on the filesystem. It rejects a runtime allocation that differs from
the reviewed policy. The original JSON file remains unchanged and retains its
1.5 MiB limit; JSON-mode aggregate state/backup limits remain 64 MiB/20 MiB.

The guard reads filesystem metadata and the existing egress cap. It never opens
SQLite. `status.py` uses a bounded five-to-fifteen-minute observation window to
estimate persistent main-file growth toward the earliest main-file,
aggregate-state or disk-reserve boundary. Current WAL/SHM usage is reported
separately; checkpoint cycles are not extrapolated as permanent growth. The disk
model includes three retained full snapshots and reserves the next backup
workspace. This constant-rate estimate is not a retention guarantee. Finite disk still bounds
retained history; crossing a hard limit closes admission instead of deleting
finalized history.

A standalone archive is bounded by three main-file ceilings plus 8 MiB for
framing: 796,037,120 bytes. Three retained archives plus the next three snapshots
and archive require at most five archive bounds, 3,980,185,600 bytes, below the
4 GiB backup limit. The policy is passed explicitly as `--max-bytes 536870912`
to maintenance commands; it does not rely on the CLI's default allocation.

`capacity-report.json` separates measurements from projections. Empty blocks
still consume permanent rows and indexes. At 1.5–4 KiB of persistent growth per
block, a twelve-second schedule would exhaust the present main allocation in
approximately 24–9 days from a small database. These illustrative rates are not
a measured retention guarantee. A hypothetical accepted 240 KiB payload in
every block would consume that allocation in at most 3.6 hours, before indexing
and checkpoint overhead. Transaction admission limits bound individual requests,
not lifetime storage demand. Capacity warnings require operator action before
the hard boundary; this release does not provide indefinite history retention.

`backup.py` calls `native-store-tool backup`, which uses the pinned Rust SQLite
implementation and a read-only source connection. Python never opens a live
SQLite database. Each copy is consistent and fully verified before archival.
The three snapshots are captured sequentially and may have different heights;
the manifest records their individual commitments. An exclusive lock prevents
overlapping backups, workspace is reserved before copying, publication is atomic,
and only then are archives beyond the newest three removed. No signing keys are
included. Each validator backup and full verification has a 600-second deadline;
the backup service allows 2,000 seconds for all three copies and archival.
The timer runs every fifteen minutes; it is not evidence that a backup
succeeded or reached another machine.
`latest.json` binds the most recently published archive, its digest, completion
time and each verified validator commitment. Status reports a missing or stale
receipt, with a forty-five-minute age threshold. A status sample checks archive
metadata; checksum and replay verification occur during backup and recovery.

`recovery.py` accepts only the four expected members of a version-2 snapshot,
checks their identities, sizes and SHA-256 digests, and runs full Rust verification
for SQLite copies. It prepares a new directory and never starts a signer or
overwrites live state. Legacy JSON snapshots receive identity/checksum validation
only; run the full legacy replay tool before treating them as a validated recovery.
Signing identities and runtime configuration must be recovered separately.

Local acceptance

Build the candidate binaries once with the repository's locked dependency graph.
Run the operational unit tests:

```sh
python3 -B -m unittest discover -s ops -p 'test_*.py' -v
```

The real migration/backup/recovery test is enabled with `MFENX_TEST_STORE_TOOL`
pointing to the absolute candidate `native-store-tool` path and
`MFENX_TEST_LEGACY_FIXTURES` pointing to a read-only capture directory containing
`validator-1/`, `validator-2/`, and `validator-3/native_chain_state.json`.
Set `MFENX_OPS_TEST_TMPDIR` to a filesystem with at least 4 GiB free. The test
copies all fixtures, confirms the original JSON digests remain unchanged,
migrates and inspects each copy, then creates and replay-verifies an isolated
recovery snapshot. It never loads signing keys.

Run `local_soak.py` in a disposable systemd user service. It uses public test
seeds, chain `313372026`, a distinct genesis, temporary files and loopback ports
only. The candidate gateway's identity constants are substituted solely for this
fixture; its admission, sampling and forwarding code remains the candidate code.
The harness initializes a fresh JSON history, stops it, migrates all three stores,
then tests the SQLite runtime at a twelve-second empty-block cadence with the
gateway, an online backup/full verification, and a validator kill/restart:

```sh
systemd-run --user --wait --pipe --collect \
  --unit=mfenx-local-sqlite-soak \
  -p MemoryMax=96M -p MemorySwapMax=0 -p CPUQuota=20% -p TasksMax=64 \
  /usr/bin/python3 -B /absolute/source/ops/local_soak.py \
  --julian /absolute/build/julian \
  --store-tool /absolute/build/native-store-tool \
  --work-parent /absolute/local/scratch \
  --report /absolute/local/soak-report.json --seconds 600
```

The report records both binary SHA-256 digests, the explicit allocation,
cgroup peaks, CPU usage/throttling, OOM events, database sizes,
tip agreement, history advancement, original-JSON preservation and backup results.
The harness refuses to run without the required cgroup limits. It does not model
the complete host's kernel, TLS proxy, disk latency or unrelated services. A ten
minute soak is an initial acceptance test; a longer observation is still needed
before claiming sustained operating capacity.

`cluster_maintenance_soak.py` places validators, gateway and concurrent guard,
storage-status and backup processes in a shared transient user slice. Its
coordinator remains outside the measured slice. Maintenance operates on separate
copies of captured ledgers, with the traffic-control response and local owner ID
substituted for the fixture. The CLI help specifies its snapshot and legacy
fixture inputs. This test checks overlapping maintenance memory and block
progress; it does not establish performance at the database capacity ceiling.

`capability_sandbox.py` prepares the maintenance capability test from a standalone
offline SQLite snapshot. It requires local noninteractive sudo and creates only
temporary files and transient local services. The test uses a source database owned by
the local operator with mode `0600`, and a separate writable output directory.
Run the staged CLI in a local root systemd service with
`CapabilityBoundingSet=CAP_DAC_READ_SEARCH`, `NoNewPrivileges=yes`,
`ProtectSystem=strict`, `ReadOnlyPaths=<source directory>` and
`ReadWritePaths=<output directory>`. The source directory must be traversable
through the capability, and the output directory must be owned by the service
user. Require inspect and backup/verify to pass without `CAP_DAC_OVERRIDE` and
without changing source DB/WAL/SHM bytes. Ordinary user tests do not establish
this capability boundary. Do not point this test at production files.

Coordinated activation

1. Record the candidate source commit, binary hashes, Rust/SQLite versions and all
   acceptance results. Keep the candidate release immutable once selected.
2. Publish the complete corresponding source as a new versioned archive, for
   example `public/network/validator-execution-20261019.1.tar.gz`, with a SHA-256
   digest. Include `Cargo.lock`, runtime and CLI sources, tests, license and these
   operations files. Exclude build output, keys, local state and captured ledgers.
   Retain `validator-execution-20261008.3.tar.gz` unchanged for historical replay.
   The source provenance record should identify the release, archive URL/SHA-256,
   basis archive URL/SHA-256, lockfile digest, toolchain, and deployed binary hashes.
   The runtime repository began from an imported published archive. A local Git
   revision is not a published Power House GitHub commit: either omit the ambiguous
   `commit` field or label it explicitly as a local revision, with the archive
   digest as the public content binding. Do not construct an unavailable GitHub
   commit link. The source release remains separate from the Power House crate.
3. Deploy and verify the prepared website cadence transition before changing the
   live runtime. The transition accepts exactly the reviewed old/new values
   `86400` and `12`, with tip freshness derived from the observed interval plus
   90 seconds. Preserve the separate 86,400-second availability observation
   window. Test both schedules and their overdue-tip rejection, retaining the
   chain, genesis and topology checks. Confirm the deployed status client and
   text describe the observed schedule; a prepared change is not deployment
   evidence.
4. Stage the new immutable runtime release and operations files on the existing
   host with the preserved chain identity. Capture a
   final legacy snapshot and verified off-host archive before the maintenance
   window. Stop `mfenx-native.target` and explicitly stop
   `mfenx-native-backup.timer`, `mfenx-native-guard.timer`,
   `mfenx-native-storage-status.timer`, `mfenx-native-backup.service`,
   `mfenx-native-guard.service`, and `mfenx-native-storage-status.service` when
   present. Confirm these units are inactive and every validator and edge process
   has exited before migration or changing the release link and environment.
   Stopping a timer does not terminate an already-running maintenance service.
5. Record each stopped validator's tip, state root, pending proposal and durable
   vote locks. As the matching validator UID, run `native-store-tool migrate
   --legacy <node>/native_chain_state.json --database
   <node>/native_chain_state.sqlite3 --max-bytes 536870912 --json`. The destination
   must not exist. Confirm the original JSON hash is unchanged, and the database
   is `0600` and owned by that validator UID. Running import as root without an
   ownership handoff would leave it unreadable to the validator service.
6. Run full `verify --max-bytes 536870912` on each migrated database and compare identity, tip, state
   root and signing locks against the stopped source. Do not activate partially
   migrated or inconsistent nodes. The supplied deployment plan contains the
   required files and service changes; apply them as one reviewed maintenance
   change, including runtime, gateway, guard, backup, storage status and timers.
7. Set the candidate environment only after migration succeeds. Stage the
   reviewed `gateway.json` manifest before starting the edge: its runtime/client
   identity and binary digest, source provenance, twelve-second interval and
   storage limits must describe the selected release. The gateway reads this
   configuration at startup; a later file edit requires an edge restart. The same
   `storage.env` must reach all validators, the gateway and maintenance services.
   Keep the old runtime environment's unrelated limits. The proposed twelve-second
   cadence is enabled only after measured acceptance. Run the SQLite-mode guard,
   validate systemd configuration, then start the same three loopback validators.
8. Verify original genesis/history, all three current tips/state roots, admission,
   both public RPC paths, historical calls/receipts, twelve-second progression,
   fresh status samples and aggregate resource limits. Create a new consistent
   backup, replay-verify its recovery copy, and retain an off-host copy.
9. Verify the served gateway manifest matches the staged release metadata.
   Update website `network/2026092601.json` validatorSource release, explicitly
   local source revision, URL and digest together. Update source links and reproduction commands
   in `network/contracts.html` and archive assertions in
   `tests/test_network_status.mjs`. Keep the October 8 execution record and its
   original receipt/ledger files as historical evidence, rather than rewriting
   them as evidence for the new runtime.
10. Once live twelve-second status is confirmed, finish the website transition:
    pin the reviewed new schedule in the status client and fixture, update
    `status.html` daily-block wording and `docs/NETWORK_STATUS_CONTRACT.md`, and
    remove stale read-only/operator-only submission claims in that contract to
    match the existing signed-public-EVM gateway. Preserve the single-host scope
    and finite-storage limits. Verify the deployed source URL/hash and both live
    status consumers before considering publication complete.

Rollback and off-host copies

A stopped migration can be abandoned only while the SQLite history, pending
proposal and vote locks still match the retained JSON for each signing identity.
Compare those records after all signers have stopped. Matching finalized heights
alone is insufficient: a proposal or vote can become durable before its block
finalizes. Preserve a failed database for diagnosis; do not silently delete or
recreate it at service startup.

Any subsequent SQLite signing activity or finalized block can make the retained
JSON stale. Never restart a signer from that stale JSON, truncate finalized blocks
or clear signing locks. Stop the affected signers, preserve current SQLite/WAL
files and recover with a compatible SQLite binary and verified current history
and signing locks. A return to JSON requires an explicit complete export of both
history and current signing state, followed by a replay-verified handoff; the
candidate tools do not implement that downgrade. A website rollback must not
conceal the actual runtime cadence.

`check_live_progress.py` checks both public RPC paths, the published chain and
genesis, actual finalized-block progression, shared-height commitments and tip
freshness. Its default observation spans 36 seconds. The optional user units in
`systemd-user/` repeat this observation five minutes after the preceding run
finishes, using the release installed on the existing operator computer. A
failure produces a nonzero service result and a JSON report. This is an
observation point while that computer is online, not an independent hosted
availability service or a notification delivery guarantee.

`receive.py` pulls an explicitly selected archive onto an existing operator
computer over SSH. Supply the archive's SHA-256 from the completed backup result:

```sh
python3 -B ops/receive.py --host operator@host \
  --archive ledger-YYYYMMDDTHHMMSS.ffffffZ.tar \
  --expected-sha256 <64-lowercase-hex-digest> \
  --destination /absolute/private/backup-directory
```

The remote command only reads that archive. The receiver verifies the digest,
publishes atomically and retains three copies. It does not replay the ledger;
use `recovery.py` with `--expected-sha256` for that step. The local computer must
be available for a transfer to occur. A configured receiver or timer is not proof
of an off-host recovery point; record the received archive, digest and successful
isolated recovery result.

`receive_latest.py` reads only the remote `latest.json` receipt, validates its
archive name and digest, and uses the same bounded receiver. With `--store-tool`,
it additionally replays all three extracted ledgers in a newly created private
temporary directory before marking the local receipt as verified or pruning
older archives:

```sh
python3 -B ops/receive_latest.py --host operator@host \
  --identity-file /absolute/private/ssh-identity \
  --store-tool /absolute/build/native-store-tool \
  --destination /absolute/private/backup-directory
```

The explicit identity option disables SSH configuration loading, permits only
that identity and requires an existing trusted host key. Neither receiver reads
identity contents. Reuse the existing receiver service and timer when enabling
this command; no additional timer is installed by these files. The transfer
deadline is six hours; the service timeout must allow transfer and replay
(`TimeoutStartSec=24000`). At the existing 64,000-byte/second egress ceiling,
three main images near their allocation need at least 3.4 hours to transfer,
before protocol overhead or other traffic. A serialized hourly trigger therefore
cannot guarantee an hourly off-host recovery point near capacity. Record the
actual successful receipt and replay time.
