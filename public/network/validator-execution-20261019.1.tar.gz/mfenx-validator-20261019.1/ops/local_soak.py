#!/usr/bin/env python3
"""Local three-validator SQLite soak using public test seeds and loopback only.

Run inside a disposable systemd user unit with MemoryMax=96M, CPUQuota=20%,
MemorySwapMax=0 and TasksMax=64. No production keys, ledgers or RPCs are used.
The temporary test history deliberately has a different chain/genesis identity.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

CHAIN_ID = 313372026
DATABASE_BUDGET_BYTES = 512 * 1024**2
SEEDS = ("cluster-a", "cluster-b", "cluster-c")
PUBLIC_KEYS = ("gIFdYcN4MVLieYSow0mkqFoPntyI1Jl1WIntgaHQZ5U=",
               "FmWXfDF/CHrTrmRp9e0fmZV0eNfAA8Pu2EbiG0rgJJk=",
               "VGvK1rRmPbiJK0EuhQg39gB+foKbqbbnYOlUGaCwtkM=")


def file_sha256(path):
    value = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(65536), b""):
            value.update(chunk)
    return value.hexdigest()


def require_standalone(path):
    if any(Path(str(path) + suffix).exists() for suffix in ("-wal", "-shm", "-journal")):
        raise ValueError("Backup output is not a standalone database")


def rpc(port, method, params):
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode()
    request = urllib.request.Request(f"http://127.0.0.1:{port}/", data=body,
                                     headers={"Content-Type": "application/json"})
    # Ignore desktop proxy settings for all loopback traffic.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=4) as response:
        raw = response.read(131073)
    if len(raw) > 131072:
        raise ValueError("RPC response limit")
    result = json.loads(raw)
    if "error" in result:
        raise ValueError("Local RPC returned an error")
    return result["result"]


def wait_rpc(port, process, timeout=45):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise ValueError("Local validator exited during startup")
        try:
            if rpc(port, "eth_chainId", []) == hex(CHAIN_ID):
                return
        except (OSError, ValueError, KeyError):
            pass
        time.sleep(0.2)
    raise ValueError("Local validator startup timed out")


def stop(process):
    if process is None or process.poll() is not None:
        return
    process.send_signal(signal.SIGINT)
    try:
        process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def cgroup_observation():
    group = next((line.split("::", 1)[1] for line in Path("/proc/self/cgroup").read_text().splitlines()
                  if line.startswith("0::")), None)
    if group is None:
        raise ValueError("cgroup v2 is required for resource evidence")
    path = Path("/sys/fs/cgroup") / group.lstrip("/")
    def read(name):
        return (path / name).read_text().strip()
    return {"path": str(path), "memory_current": int(read("memory.current")),
            "memory_peak": int(read("memory.peak")), "memory_max": read("memory.max"),
            "memory_events": dict(line.split() for line in read("memory.events").splitlines()),
            "cpu_max": read("cpu.max"),
            "cpu_stat": {k: int(v) for k, v in (line.split() for line in read("cpu.stat").splitlines())}}


def tool_json(tool, *args):
    result = subprocess.run([str(tool), *map(str, args), "--max-bytes", str(DATABASE_BUDGET_BYTES), "--json"], check=True, timeout=180,
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    if len(result.stdout) > 65536:
        raise ValueError("Store CLI output limit")
    return json.loads(result.stdout)


def run(args):
    resource_start = cgroup_observation()
    quota, period = resource_start["cpu_max"].split()
    if (resource_start["memory_max"] != str(96 * 1024**2)
            or quota == "max" or int(quota) / int(period) > 0.2):
        raise ValueError("Soak must run inside the reviewed 96 MiB / 20% CPU cgroup")
    for port in [args.p2p_base + n for n in range(3)] + [args.rpc_base + n for n in range(3)] + [args.edge_port]:
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", port))
    args.work_parent.mkdir(parents=True, exist_ok=True)
    processes, streams = [None] * 3, []
    edge = None
    temporary = None
    report = {"schema": "mfenx.local-sqlite-soak.v1", "production_access": False,
              "chain_id": CHAIN_ID, "duration_seconds": args.seconds,
              "binary_sha256": {"julian": file_sha256(args.julian),
                                "native-store-tool": file_sha256(args.store_tool)},
              "database_budget_bytes": DATABASE_BUDGET_BYTES,
              "resource_start": resource_start, "samples": [], "passed": False}
    old_umask = os.umask(0o077)
    try:
        temporary = tempfile.TemporaryDirectory(prefix="native-soak-", dir=args.work_parent)
        name = temporary.name
        work = Path(name)
        policy_path = work / "policy.json"
        policy_path.write_text(json.dumps({"backend": "static", "allowlist": PUBLIC_KEYS}))
        peers = [None] * 3
        def launch(index, mode):
            node = work / f"validator-{index + 1}"
            node.mkdir(exist_ok=True)
            (node / "logs").mkdir(exist_ok=True)
            command = [str(args.julian), "net", "start", "--node-id", f"validator-{index + 1}",
                       "--key", "ed25519://" + SEEDS[index], "--policy", str(policy_path),
                       "--quorum", "2", "--attestation-quorum", "2", "--tokio-threads", "1",
                       "--blob-dir", str(node), "--log-dir", str(node / "logs"),
                       "--listen", f"/ip4/127.0.0.1/tcp/{args.p2p_base + index}",
                       "--evm-rpc-listen", f"127.0.0.1:{args.rpc_base + index}",
                       "--evm-chain-id", str(CHAIN_ID), "--broadcast-interval", "1500",
                       "--checkpoint-interval", "0", "--anchor-topic", "isolated-native-sqlite-soak"]
            for other, peer in enumerate(peers):
                if peer and other != index:
                    command += ["--bootstrap", f"/ip4/127.0.0.1/tcp/{args.p2p_base + other}/p2p/{peer}"]
            env = {"PATH": "/usr/bin:/bin", "HOME": str(work), "LANG": "C.UTF-8",
                   "MFENX_NATIVE_STORAGE": mode, "MFENX_NATIVE_EMPTY_BLOCK_SECONDS": "12",
                   "MFENX_NATIVE_MAX_DATABASE_BYTES": str(DATABASE_BUDGET_BYTES),
                   "MFENX_NATIVE_MAX_PENDING": "16", "MFENX_NATIVE_MAX_ORPHAN_BLOCKS": "16",
                   "MFENX_NATIVE_MAX_STATE_BYTES": "1572864", "MFENX_EVM_ACTIVATION_HEIGHT": "1"}
            stream = (work / f"node-{index + 1}-{mode}.log").open("ab", buffering=0)
            streams.append(stream)
            process = subprocess.Popen(command, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=stream)
            processes[index] = process
            wait_rpc(args.rpc_base + index, process)
            log = Path(stream.name).read_text(errors="replace")
            matches = re.findall(r"\bpeer=([A-Za-z0-9]+)", log)
            if not matches:
                raise ValueError("Unable to identify isolated local peer")
            peers[index] = matches[0]
            return process
        for index in range(3):
            launch(index, "json")
        for process in processes:
            stop(process)
        frozen = {}
        for index in range(3):
            node = work / f"validator-{index + 1}"
            legacy = node / "native_chain_state.json"
            frozen[index] = hashlib.sha256(legacy.read_bytes()).hexdigest()
            tool_json(args.store_tool, "migrate", "--legacy", legacy, "--database", node / "native_chain_state.sqlite3")
        for index in range(3):
            launch(index, "sqlite")
        genesis = rpc(args.rpc_base, "eth_getBlockByNumber", ["0x0", False])["hash"]
        report["genesis_hash"] = genesis
        started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 60))
        config = {"manifest": {"identity": {"name": "Isolated SQLite soak", "chain_id": CHAIN_ID,
                   "history_id": "isolated-native-sqlite-soak", "genesis_hash": genesis, "started_at": started,
                   "previous_chain_id": 177155, "previous_history_restored": False},
                   "topology": {"validator_count": 3, "quorum": 2, "host_count": 1,
                                "failure_domain_count": 1, "regions": ["local"]},
                   "public_rpc_mode": "evm_contracts", "transaction_submission": "public_signed_evm",
                   "execution": {"profile": "mfenx-evm-cancun-fee-free-v1", "activation_height": 1, "validator_replay": True},
                   "runtime": {"client": "local-sqlite-soak"}},
                  "nodes": [{"node_id": f"validator-{i + 1}", "peer_id": peers[i], "public_key": PUBLIC_KEYS[i],
                             "rpc_port": args.rpc_base + i} for i in range(3)]}
        config_path = work / "gateway.json"
        config_path.write_text(json.dumps(config))
        (work / "gateway").mkdir()
        # Only the isolated fixture identity is substituted; admission,
        # sampling, RPC forwarding and resource behavior use candidate code.
        code = ("import sys;sys.path.insert(0," + repr(str(Path(__file__).parent.resolve())) + ");"
                "import gateway;gateway.CHAIN_ID=" + str(CHAIN_ID) + ";"
                "gateway.HISTORY_ID='isolated-native-sqlite-soak';gateway.main()")
        edge = subprocess.Popen([sys.executable, "-B", "-c", code, "--config", str(config_path),
                                 "--state-dir", str(work / "gateway"), "--port", str(args.edge_port)],
                                env={"PATH": "/usr/bin:/bin", "MFENX_NATIVE_EMPTY_BLOCK_SECONDS": "12"},
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        began, copied, restarted = time.monotonic(), False, False
        while time.monotonic() - began < args.seconds:
            if any(p.poll() is not None for p in processes) or edge.poll() is not None:
                raise ValueError("A bounded local service exited during soak")
            tips = [rpc(args.rpc_base + i, "eth_getBlockByNumber", ["latest", False]) for i in range(3)]
            report["samples"].append({"elapsed_seconds": time.monotonic() - began,
                "heights": [int(t["number"], 16) for t in tips], "hashes": [t["hash"] for t in tips],
                "database_main_bytes": [(work / f"validator-{i + 1}/native_chain_state.sqlite3").stat().st_size for i in range(3)],
                "resources": cgroup_observation()})
            elapsed = time.monotonic() - began
            if not copied and elapsed > args.seconds / 3:
                backup_path = work / "consistent.sqlite3"
                report["online_backup"] = tool_json(args.store_tool, "backup", "--database",
                    work / "validator-1/native_chain_state.sqlite3", "--output", backup_path)
                require_standalone(backup_path)
                backup_hash = file_sha256(backup_path)
                report["backup_verification"] = tool_json(args.store_tool, "verify", "--database", backup_path)
                require_standalone(backup_path)
                if file_sha256(backup_path) != backup_hash:
                    raise ValueError("Read-only backup verification changed the database")
                report["backup_standalone_verified"] = True
                copied = True
            if not restarted and elapsed > args.seconds * 2 / 3:
                processes[1].kill()
                processes[1].wait()
                launch(1, "sqlite")
                restarted = True
            time.sleep(5)
        final = report["samples"][-1]
        first = report["samples"][0]
        report["resource_end"] = cgroup_observation()
        report["legacy_json_unchanged"] = all(hashlib.sha256((work / f"validator-{i + 1}/native_chain_state.json").read_bytes()).hexdigest() == frozen[i] for i in range(3))
        report["database_sizes"] = {str(p.relative_to(work)): p.stat().st_size for p in work.glob("validator-*/*.sqlite3*")}
        report["restart_tested"] = restarted
        report["passed"] = (len(set(final["heights"])) == 1 and len(set(final["hashes"])) == 1
            and min(final["heights"]) - max(first["heights"]) >= max(3, args.seconds // 30)
            and report["legacy_json_unchanged"] and copied and restarted
            and int(report["resource_end"]["memory_events"].get("oom_kill", "0")) == 0)
        if not report["passed"]:
            raise ValueError("Soak acceptance criteria were not met")
    except Exception as error:
        report["failure"] = type(error).__name__ + ": " + str(error)
        if temporary is not None:
            report["local_fixture_log_tails"] = {
                p.name: p.read_text(errors="replace")[-8192:]
                for p in Path(temporary.name).glob("node-*.log")
            }
    finally:
        for process in processes:
            stop(process)
        stop(edge)
        for stream in streams:
            stream.close()
        if temporary is not None:
            temporary.cleanup()
        os.umask(old_umask)
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--julian", type=Path, required=True)
    parser.add_argument("--store-tool", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--work-parent", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=600)
    parser.add_argument("--p2p-base", type=int, default=27601)
    parser.add_argument("--rpc-base", type=int, default=28645)
    parser.add_argument("--edge-port", type=int, default=28093)
    args = parser.parse_args()
    if not 180 <= args.seconds <= 86400 or not args.julian.is_absolute() or not args.store_tool.is_absolute():
        parser.error("Use absolute binaries and a duration between 180 and 86400 seconds")
    raise SystemExit(run(args))


if __name__ == "__main__":
    main()
