#!/usr/bin/env python3
"""Receive an explicitly selected ledger archive over SSH onto this computer.

The remote command only reads the selected archive. Existing SSH authentication
is used by ssh itself; this script never reads private keys. No paid storage or
service changes are involved. Verify/replay with recovery.py before activation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shlex
import shutil
import stat
import subprocess
import tempfile
import time

import policy


def ssh_argv(host, command, identity_file=None):
    if not isinstance(host, str) or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.@:-]{0,253}", host):
        raise ValueError("Invalid SSH host")
    options = ["ssh"]
    if identity_file is not None:
        identity_file = Path(identity_file)
        if not identity_file.is_absolute() or ".." in identity_file.parts:
            raise ValueError("SSH identity path must be absolute")
        options += ["-F", "/dev/null", "-i", str(identity_file), "-oIdentitiesOnly=yes",
                    "-oBatchMode=yes", "-oStrictHostKeyChecking=yes", "-oConnectTimeout=10"]
    else:
        options += ["-oBatchMode=yes", "-oConnectTimeout=10"]
    return [*options, host, command]


def receive(host, archive, expected_sha256, destination, timeout=21600, identity_file=None,
            defer_completion=False):
    if not re.fullmatch(r"ledger-\d{8}T\d{6}\.\d{6}Z\.tar", archive):
        raise ValueError("Invalid archive name")
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
        raise ValueError("Expected archive SHA-256 is required")
    remote_path = str(policy.BACKUP_ROOT / archive)
    command = "sudo -n /usr/bin/cat -- " + shlex.quote(remote_path)
    argv = ssh_argv(host, command, identity_file)
    destination.mkdir(mode=0o700, parents=True, exist_ok=True)
    metadata = destination.lstat()
    if (not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != os.geteuid()
            or stat.S_IMODE(metadata.st_mode) & 0o077):
        raise ValueError("Destination must be a private owned directory")
    if shutil.disk_usage(destination).free < policy.MAX_ARCHIVE_BYTES + policy.GIB:
        raise ValueError("Insufficient local disk reserve")
    final = destination / archive
    if final.exists() or final.is_symlink():
        raise ValueError("Archive already exists")
    process = subprocess.Popen(argv,
                               stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    descriptor, temporary = tempfile.mkstemp(prefix=".receiving-", dir=destination)
    h, total = hashlib.sha256(), 0
    deadline = time.monotonic() + timeout
    try:
        with os.fdopen(descriptor, "wb") as output, selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selector.select(remaining):
                    raise ValueError("SSH archive transfer timed out")
                chunk = os.read(process.stdout.fileno(), 65536)
                if not chunk:
                    break
                total += len(chunk)
                if total > policy.MAX_ARCHIVE_BYTES:
                    raise ValueError("Archive exceeds transfer limit")
                output.write(chunk)
                h.update(chunk)
            if (process.wait(timeout=max(0.01, deadline - time.monotonic())) != 0
                    or total == 0 or h.hexdigest() != expected_sha256):
                raise ValueError("Incomplete or mismatched archive transfer")
            output.flush()
            os.fsync(output.fileno())
        os.link(temporary, final, follow_symlinks=False)
        os.unlink(temporary)
        policy.fsync_directory(destination)
        receipt = {"archive": archive, "bytes": total, "sha256": h.hexdigest(),
                   "received_at_unix": time.time(), "replay_verified": False}
        # The latest-receipt orchestrator may require independent replay before
        # retention. Standalone receipt/rotation behavior remains unchanged.
        if not defer_completion:
            archives = sorted(destination.glob("ledger-*.tar"))
            for old in archives[:-policy.RETAIN_BACKUPS]:
                policy.regular_file(old, policy.MAX_ARCHIVE_BYTES, private=True)
                old.unlink()
            policy.fsync_directory(destination)
            policy.atomic_json(destination / "latest-receipt.json", receipt)
        return receipt
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        process.stdout.close()
        if os.path.exists(temporary):
            os.unlink(temporary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--archive", required=True)
    parser.add_argument("--expected-sha256", required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--identity-file", type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(receive(args.host, args.archive, args.expected_sha256, args.destination,
                                 identity_file=args.identity_file), sort_keys=True))
        return 0
    except (OSError, ValueError):
        print('{"ok":false,"reason":"archive_receive_failed"}')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
