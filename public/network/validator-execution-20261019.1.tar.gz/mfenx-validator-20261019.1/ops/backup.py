#!/usr/bin/env python3
"""Bounded consistent ledger snapshots; never copy a live SQLite database file."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import stat
import tarfile
import tempfile

import guard
import policy

RECEIPT_SCHEMA = "mfenx.native-backup-receipt.v1"
MAX_RECEIPT_BYTES = 16384
BACKUP_CADENCE_SECONDS = 15 * 60
BACKUP_STALE_SECONDS = 45 * 60
ARCHIVE_PATTERN = r"ledger-\d{8}T\d{6}\.\d{6}Z\.tar"


def validate_receipt(value):
    if (not isinstance(value, dict) or value.get("schema") != RECEIPT_SCHEMA
            or value.get("chain_id") != policy.CHAIN_ID or value.get("genesis_hash") != policy.GENESIS
            or value.get("storage_mode") not in ("json", "sqlite")
            or not isinstance(value.get("archive"), str)
            or re.fullmatch(ARCHIVE_PATTERN, value["archive"]) is None
            or not isinstance(value.get("sha256"), str)
            or re.fullmatch(r"[0-9a-f]{64}", value["sha256"]) is None
            or type(value.get("bytes")) is not int
            or not 0 < value["bytes"] <= policy.MAX_ARCHIVE_BYTES):
        raise ValueError("Invalid backup receipt identity or archive")
    epoch = value.get("completed_at_unix")
    if type(epoch) not in (int, float) or not math.isfinite(epoch) or epoch < 0:
        raise ValueError("Invalid backup completion time")
    completed = datetime.strptime(value["completed_at"], "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)
    if abs(completed.timestamp() - epoch) > 0.001:
        raise ValueError("Backup completion times disagree")
    validators = value.get("validators")
    if not isinstance(validators, dict) or set(validators) != set(policy.VALIDATORS):
        raise ValueError("Incomplete backup validator records")
    for metadata in validators.values():
        policy.validate_metadata(metadata, require_integrity=True if value["storage_mode"] == "sqlite" else None)
        if value["storage_mode"] == "json" and (
                metadata.get("integrity_ok") is not False or metadata.get("integrity_checked") is not False):
            raise ValueError("Legacy backup must retain its limited verification scope")
    return value


def decode_receipt(raw):
    if not 0 < len(raw) <= MAX_RECEIPT_BYTES:
        raise ValueError("Backup receipt size limit")
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("Duplicate backup receipt field")
            value[key] = item
        return value
    return validate_receipt(json.loads(raw, object_pairs_hook=pairs))


def read_receipt(root):
    path = root / "latest.json"
    policy.regular_file(path, MAX_RECEIPT_BYTES, private=True)
    with path.open("rb") as stream:
        return decode_receipt(stream.read(MAX_RECEIPT_BYTES + 1))


def digest(path, maximum=policy.MAX_ARCHIVE_BYTES):
    hasher = hashlib.sha256()
    total = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            total += len(chunk)
            if total > maximum:
                raise ValueError("Checksum input exceeds size limit")
            hasher.update(chunk)
    return hasher.hexdigest()


def add_bytes(archive, name, content):
    info = tarfile.TarInfo(name)
    info.size, info.mode, info.uid, info.gid = len(content), 0o600, 0, 0
    archive.addfile(info, io.BytesIO(content))


def snapshots(root):
    result = []
    for path in root.glob("ledger-*.tar"):
        policy.regular_file(path, policy.MAX_ARCHIVE_BYTES, private=True)
        result.append(path)
    return sorted(result)


def create_backup(state_root, backup_root, tool, storage_mode):
    """Serialize backups with flock; publish before pruning older snapshots.

    Each validator snapshot is internally consistent. Their heights may differ
    during sequential capture; the manifest records this without claiming a
    simultaneous cluster checkpoint. Validator signing keys are never read.
    """
    guard.check_storage(state_root, backup_root, storage_mode)
    lock_fd = os.open(backup_root / ".backup.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        metadata = os.fstat(lock_fd)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
            raise ValueError("Unsafe backup lock")
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        status = guard.check_storage(state_root, backup_root, storage_mode)
        # At peak both independent SQLite copies and the new tar coexist.
        workspace_limit = 2 * policy.MAX_ARCHIVE_BYTES if storage_mode == "sqlite" else 12 * policy.MIB
        if (status["free_bytes"] - workspace_limit < policy.MIN_FREE_BYTES
                or status["backups"]["bytes"] + workspace_limit > status["backup_limit_bytes"]):
            raise ValueError("Insufficient bounded backup workspace or disk reserve")
        records = []
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        with tempfile.TemporaryDirectory(prefix=".snapshot-", dir=backup_root) as work_name:
            work = Path(work_name)
            for node in policy.VALIDATORS:
                source_dir = state_root / node
                if storage_mode == "sqlite":
                    source = source_dir / policy.DATABASE_NAME
                    policy.regular_file(source, policy.MAX_DATABASE_BYTES)
                    target = work / (node + ".sqlite3")
                    metadata = policy.run_store(tool, "backup", source, output=target, timeout=600)
                    policy.regular_file(target, policy.MAX_DATABASE_BYTES, private=True)
                    # Online backup must produce a standalone database, not a
                    # second database dependent on an unarchived WAL file.
                    if any(Path(str(target) + suffix).exists() for suffix in ("-wal", "-shm")):
                        raise ValueError("Snapshot retains SQLite sidecars")
                    filename = policy.DATABASE_NAME
                else:
                    source = source_dir / policy.LEGACY_NAME
                    policy.regular_file(source, policy.MAX_LEGACY_BYTES)
                    # Atomic JSON replacement means this descriptor observes
                    # one complete legacy version even during finalization.
                    with source.open("rb") as stream:
                        content = stream.read(policy.MAX_LEGACY_BYTES + 1)
                    metadata = policy.legacy_metadata(content)
                    target = work / (node + ".json")
                    target.write_bytes(content)
                    target.chmod(0o600)
                    filename = policy.LEGACY_NAME
                records.append({"name": f"{node}/{filename}", "sha256": digest(target),
                                "bytes": target.stat().st_size, "ledger": metadata,
                                "temporary_path": target})
            manifest = {"schema": "mfenx.native-snapshot.v2", "created_at": stamp,
                        "storage_mode": storage_mode, "chain_id": policy.CHAIN_ID,
                        "genesis_hash": policy.GENESIS,
                        "capture": "Sequential consistent validator snapshots; heights may differ",
                        "ledgers": [{k: v for k, v in record.items() if k != "temporary_path"}
                                    for record in records]}
            staged = work / "snapshot.tar"
            with staged.open("xb") as output:
                os.fchmod(output.fileno(), 0o600)
                with tarfile.open(fileobj=output, mode="w") as archive:
                    for record in records:
                        path = record["temporary_path"]
                        info = tarfile.TarInfo(record["name"])
                        info.size, info.mode = record["bytes"], 0o600
                        with path.open("rb") as stream:
                            archive.addfile(info, stream)
                    add_bytes(archive, "snapshot.json", json.dumps(manifest, sort_keys=True).encode())
                output.flush()
                os.fsync(output.fileno())
            policy.regular_file(staged, policy.MAX_ARCHIVE_BYTES, private=True)
            destination = backup_root / ("ledger-" + stamp + ".tar")
            # The private root and held lock serialize publishers. Rename
            # avoids a transient hardlink that the concurrent guard rejects.
            if destination.exists() or destination.is_symlink():
                raise ValueError("Snapshot destination already exists")
            os.rename(staged, destination)
            policy.fsync_directory(backup_root)
        archive_hash = digest(destination)
        guard.check_storage(state_root, backup_root, storage_mode)
        completed = datetime.now(timezone.utc)
        receipt = validate_receipt({
            "schema": RECEIPT_SCHEMA, "completed_at": completed.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "completed_at_unix": completed.timestamp(), "archive": destination.name,
            "sha256": archive_hash, "bytes": destination.stat().st_size,
            "storage_mode": storage_mode, "chain_id": policy.CHAIN_ID, "genesis_hash": policy.GENESIS,
            "validators": {node: record["ledger"] for node, record in zip(policy.VALIDATORS, records)},
        })
        # Receipt publication follows archive fsync and checksum. Do not prune
        # the previous successful archive if receipt publication fails.
        try:
            policy.atomic_json(backup_root / "latest.json", receipt)
        except (OSError, ValueError):
            # If replacement did not occur, discard only this unpublished
            # archive. If replacement occurred but directory fsync failed,
            # keep the archive named by the visible receipt for recovery.
            try:
                current = read_receipt(backup_root)
            except FileNotFoundError:
                current = None
            if current is None or current["archive"] != destination.name:
                destination.unlink()
                policy.fsync_directory(backup_root)
            raise
        for old in snapshots(backup_root)[:-policy.RETAIN_BACKUPS]:
            old.unlink()
        policy.fsync_directory(backup_root)
        guard.check_storage(state_root, backup_root, storage_mode)
        return {"backup": destination.name, "sha256": archive_hash,
                "bytes": destination.stat().st_size, "manifest": manifest, "receipt": receipt}
    finally:
        os.close(lock_fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-root", type=Path, default=policy.STATE_ROOT)
    parser.add_argument("--backup-root", type=Path, default=policy.BACKUP_ROOT)
    parser.add_argument("--store-tool", type=Path, default=policy.STORE_TOOL)
    parser.add_argument("--storage-mode", choices=("json", "sqlite"), default=os.environ.get("MFENX_NATIVE_STORAGE", "json"))
    args = parser.parse_args()
    try:
        result = create_backup(args.state_root, args.backup_root, args.store_tool, args.storage_mode)
        print(json.dumps(result, sort_keys=True))
        return 0
    except (OSError, ValueError, KeyError, TypeError, guard.GuardError):
        print('{"ok":false,"reason":"backup_failed"}')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
