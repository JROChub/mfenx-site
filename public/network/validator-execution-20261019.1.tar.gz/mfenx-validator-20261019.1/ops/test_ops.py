"""Operational regressions; all fixtures use temporary files and no live services."""
from __future__ import annotations

import hashlib
from http.client import HTTPConnection
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import backup
import gateway
import guard
import policy
import recovery
import receive
import receive_latest
import status


def ledger(height=0):
    proposal = {"number": height, "hash": policy.GENESIS if height == 0 else "0x" + "2" * 64,
                "state_root": "0x" + "3" * 64}
    genesis = {"proposal": {**proposal, "number": 0, "hash": policy.GENESIS}}
    return json.dumps({"schema": "mfenx.powerhouse.native-chain-state.v1",
                       "chain_id": policy.CHAIN_ID, "quorum": 2, "validators": ["a", "b", "c"],
                       "genesis_accounts": {}, "blocks": [genesis] + ([{"proposal": proposal}] if height else [])}).encode()


class OperationsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.state, self.backups = self.root / "state", self.root / "backups"
        self.state.mkdir(mode=0o700)
        self.backups.mkdir(mode=0o700)
        for node in (*policy.VALIDATORS, "gateway"):
            (self.state / node).mkdir(mode=0o700)
        for node in policy.VALIDATORS:
            (self.state / node / policy.LEGACY_NAME).write_bytes(ledger(1))
        self.owner = patch.object(guard, "ROOT_UID", os.getuid())
        self.owner.start()
        self.capacity = patch.object(guard.os, "fstatvfs", return_value=SimpleNamespace(
            f_bavail=8 * policy.GIB // 4096, f_frsize=4096))
        self.capacity.start()

    def tearDown(self):
        self.owner.stop()
        self.capacity.stop()
        self.temporary.cleanup()

    def add_databases(self):
        for node in policy.VALIDATORS:
            (self.state / node / policy.DATABASE_NAME).write_bytes(b"active database, must not be copied raw")

    def fake_store(self, tool, command, database, output=None, **kwargs):
        if command == "backup":
            # The returned snapshot differs from the live bytes. This catches
            # accidental raw-file backup substitutions.
            output.write_bytes(b"consistent snapshot")
            output.chmod(0o600)
        return {**policy.legacy_metadata(ledger(1)), "head_valid": True,
                "integrity_checked": True, "integrity_ok": True}

    def test_legacy_limits_preserved(self):
        self.assertEqual(guard.check_storage(self.state, self.backups)["state_limit_bytes"], 64 * policy.MIB)
        (self.state / "validator-1" / policy.LEGACY_NAME).write_bytes(b"x" * (policy.MAX_LEGACY_BYTES + 1))
        with self.assertRaises(guard.GuardError):
            guard.check_storage(self.state, self.backups)

    def test_sqlite_requires_all_three_and_counts_wal(self):
        with self.assertRaises(guard.GuardError):
            guard.check_storage(self.state, self.backups, "sqlite")

        self.add_databases()
        result = guard.check_storage(self.state, self.backups, "sqlite")
        self.assertEqual(len(result["state"]["databases"]), 3)
        wal = self.state / "validator-2" / (policy.DATABASE_NAME + "-wal")
        with wal.open("wb") as stream:
            stream.truncate(policy.MAX_WAL_BYTES + 1)
        with self.assertRaises(guard.GuardError):
            guard.check_storage(self.state, self.backups, "sqlite")

    def test_runtime_budget_drift_is_rejected(self):
        self.add_databases()
        with patch.dict(os.environ, {"MFENX_NATIVE_MAX_DATABASE_BYTES": str(1024 * policy.MIB)}):
            with self.assertRaisesRegex(guard.GuardError, "differs"):
                guard.check_storage(self.state, self.backups, "sqlite")

    def test_full_database_and_backup_workspace_fit_existing_boundaries(self):
        self.assertEqual(policy.MAX_DATABASE_BYTES, 536870912)
        self.assertEqual(policy.MAX_DATABASE_MAIN_BYTES, 262549504)
        self.assertEqual(policy.MAX_ARCHIVE_BYTES, 3 * policy.MAX_DATABASE_MAIN_BYTES + 8 * policy.MIB)
        peak_backup = (policy.RETAIN_BACKUPS + 2) * policy.MAX_ARCHIVE_BYTES
        peak_state = 3 * (policy.MAX_DATABASE_MAIN_BYTES + policy.MAX_WAL_BYTES
                          + policy.MAX_SHM_BYTES + policy.MAX_LEGACY_BYTES)
        self.assertLess(peak_backup, policy.MAX_BACKUP_BYTES)
        self.assertLess(peak_state, policy.MAX_STATE_BYTES)
        self.assertLess(policy.MAX_STATE_BYTES + peak_backup + policy.MIN_FREE_BYTES, 8215719936)

    def test_rejects_symlinks_and_hardlinks(self):
        link = self.state / "validator-1" / "leak"
        link.symlink_to(self.state / "validator-2" / policy.LEGACY_NAME)
        with self.assertRaises(guard.GuardError):
            guard.check_storage(self.state, self.backups)
        link.unlink()
        os.link(self.state / "validator-2" / policy.LEGACY_NAME, link)
        with self.assertRaises(guard.GuardError):
            guard.check_storage(self.state, self.backups)

    def test_reserve_failure_is_closed(self):
        with patch.object(guard.os, "fstatvfs", return_value=SimpleNamespace(f_bavail=1, f_frsize=4096)):
            with self.assertRaisesRegex(guard.GuardError, "disk_reserve"):
                guard.check_storage(self.state, self.backups)

    def test_backup_uses_consistent_cli_and_preserves_original(self):
        self.add_databases()
        originals = {node: (self.state / node / policy.DATABASE_NAME).read_bytes() for node in policy.VALIDATORS}
        with patch.object(policy, "run_store", side_effect=self.fake_store) as cli:
            result = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")
        self.assertEqual(cli.call_count, 3)
        with tarfile.open(self.backups / result["backup"]) as archive:
            for node in policy.VALIDATORS:
                self.assertEqual(archive.extractfile(node + "/" + policy.DATABASE_NAME).read(), b"consistent snapshot")
                self.assertEqual((self.state / node / policy.DATABASE_NAME).read_bytes(), originals[node])
        self.assertEqual(len(list(self.backups.glob(".snapshot-*"))), 0)

    def test_failed_snapshot_never_publishes_or_prunes(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=ValueError("corrupt snapshot")):
            with self.assertRaises(ValueError):
                backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")
        self.assertEqual(list(self.backups.glob("ledger-*.tar")), [])
        self.assertEqual(list(self.backups.glob(".snapshot-*")), [])

    def test_backup_receipt_binds_published_archive_and_verified_nodes(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=self.fake_store):
            result = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")
        receipt = backup.read_receipt(self.backups)
        archive = self.backups / receipt["archive"]
        self.assertEqual(receipt["sha256"], backup.digest(archive))
        self.assertEqual(receipt["bytes"], archive.stat().st_size)
        self.assertEqual(receipt["archive"], result["backup"])
        self.assertEqual(set(receipt["validators"]), set(policy.VALIDATORS))
        for metadata in receipt["validators"].values():
            self.assertEqual(metadata["height"], 1)
            self.assertEqual(metadata["block_hash"], "0x" + "2" * 64)
            self.assertTrue(metadata["integrity_ok"])
            self.assertTrue(metadata["integrity_checked"])
        self.assertEqual((self.backups / "latest.json").stat().st_mode & 0o777, 0o600)

    def test_receipt_publication_failure_preserves_previous_success_and_archives(self):
        for _ in range(3):
            prior = backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        receipt_before = (self.backups / "latest.json").read_bytes()
        archives_before = set(self.backups.glob("ledger-*.tar"))
        with patch.object(policy, "atomic_json", side_effect=OSError("receipt write failed")):
            with self.assertRaises(OSError):
                backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        self.assertEqual((self.backups / "latest.json").read_bytes(), receipt_before)
        self.assertTrue(archives_before.issubset(set(self.backups.glob("ledger-*.tar"))))
        self.assertTrue((self.backups / prior["backup"]).is_file())
        self.assertEqual(len(list(self.backups.glob("ledger-*.tar"))), 3)

    def test_receipt_fsync_failure_never_removes_the_newly_named_archive(self):
        original = policy.atomic_json
        def replaced_then_failed(path, value, **kwargs):
            original(path, value, **kwargs)
            raise OSError("directory fsync failed after replacement")
        with patch.object(policy, "atomic_json", side_effect=replaced_then_failed):
            with self.assertRaises(OSError):
                backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        receipt = backup.read_receipt(self.backups)
        self.assertEqual(backup.digest(self.backups / receipt["archive"]), receipt["sha256"])

    def test_backup_status_reports_missing_fresh_stale_and_wrong_mode(self):
        self.assertEqual(status.backup_observation(self.backups, "json", time.time())["warning"], "backup_receipt_missing")
        result = backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        completed = result["receipt"]["completed_at_unix"]
        fresh = status.backup_observation(self.backups, "json", completed + 900)
        self.assertEqual(fresh["age_seconds"], 900)
        self.assertIsNone(fresh["warning"])
        self.assertFalse(fresh["archive_checksum_rechecked"])
        self.assertFalse(fresh["validators"]["validator-1"]["integrity_checked"])
        self.assertEqual(status.backup_observation(self.backups, "json", completed + 2701)["warning"], "backup_stale")
        self.assertEqual(status.backup_observation(self.backups, "sqlite", completed + 1)["warning"], "backup_storage_mode_mismatch")
        (self.backups / result["backup"]).unlink()
        self.assertEqual(status.backup_observation(self.backups, "json", completed + 1)["warning"], "backup_archive_missing")

    def test_receipt_rejects_paths_hashes_duplicate_fields_and_unverified_sqlite(self):
        result = backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        value = result["receipt"]
        for field, invalid in (("archive", "../../keys"), ("sha256", "g" * 64),
                               ("bytes", True), ("storage_mode", "sqlite")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                backup.validate_receipt({**value, field: invalid})
        raw = json.dumps(value).encode()
        duplicated = raw[:-1] + b',"archive":"../../keys"}'
        with self.assertRaises(ValueError):
            backup.decode_receipt(duplicated)
        (self.backups / "latest.json").write_bytes(duplicated)
        self.assertEqual(status.backup_observation(self.backups, "json", time.time())["warning"], "backup_receipt_invalid")

    def local_ssh_process(self, content):
        # Local pipe producer exercises the real bounded SSH read loop while
        # making no network connection and reading no authentication material.
        return subprocess.Popen([sys.executable, "-c", "import sys;sys.stdout.buffer.write(" + repr(content) + ")"],
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)

    def test_latest_receiver_reads_only_fixed_bounded_receipt(self):
        value = backup.create_backup(self.state, self.backups, Path("/unused"), "json")["receipt"]
        process = self.local_ssh_process(json.dumps(value).encode())
        with patch.object(receive_latest.subprocess, "Popen", return_value=process) as ssh:
            self.assertEqual(receive_latest.fetch_receipt("validator-host"), value)
        command = ssh.call_args.args[0]
        self.assertEqual(command[-1], "sudo -n /usr/bin/cat -- /var/lib/mfenx-native-backups/latest.json")
        process = self.local_ssh_process(b"x" * (backup.MAX_RECEIPT_BYTES + 1))
        with patch.object(receive_latest.subprocess, "Popen", return_value=process):
            with self.assertRaisesRegex(ValueError, "size limit"):
                receive_latest.fetch_receipt("validator-host")
        with patch.object(receive_latest.subprocess, "Popen") as ssh:
            with self.assertRaises(ValueError):
                receive_latest.fetch_receipt("-oProxyCommand=bad")
            ssh.assert_not_called()

    def test_explicit_ssh_identity_is_forwarded_without_reading_its_contents(self):
        identity = self.root / "identity-not-readable"
        identity.write_bytes(b"not a real key")
        identity.chmod(0)
        expected = ["ssh", "-F", "/dev/null", "-i", str(identity), "-oIdentitiesOnly=yes",
                    "-oBatchMode=yes", "-oStrictHostKeyChecking=yes", "-oConnectTimeout=10"]
        self.assertEqual(receive.ssh_argv("validator-host", "fixed command", identity),
                         [*expected, "validator-host", "fixed command"])
        with self.assertRaises(ValueError):
            receive.ssh_argv("validator-host", "fixed command", Path("relative-identity"))
        source = backup.create_backup(self.state, self.backups, Path("/unused"), "json")["receipt"]
        process = self.local_ssh_process(json.dumps(source).encode())
        with patch.object(receive_latest.subprocess, "Popen", return_value=process) as ssh:
            receive_latest.fetch_receipt("validator-host", identity_file=identity)
        self.assertEqual(ssh.call_args.args[0][:-2], expected)
        process = self.local_ssh_process((self.backups / source["archive"]).read_bytes())
        with patch.object(receive_latest, "fetch_receipt", return_value=source) as fetch, \
                patch.object(receive.subprocess, "Popen", return_value=process) as ssh, \
                patch.object(receive.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)):
            receive_latest.receive_latest("validator-host", self.root / "received", identity_file=identity)
        fetch.assert_called_once_with("validator-host", identity_file=identity)
        self.assertEqual(ssh.call_args.args[0][:-2], expected)

    def test_receiver_replays_retained_sqlite_archive_and_marks_failed_retry_unverified(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=self.fake_store):
            created = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")
        source = created["receipt"]
        destination = self.root / "received"
        destination.mkdir(mode=0o700)
        archive = destination / source["archive"]
        archive.write_bytes((self.backups / source["archive"]).read_bytes())
        archive.chmod(0o600)
        sentinel = self.root / "unrelated-user-file"
        sentinel.write_bytes(b"preserved")
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive_latest.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)), \
                patch.object(policy, "run_store", side_effect=self.fake_store) as verifier, \
                patch.object(receive, "receive") as transfer:
            result = receive_latest.receive_latest("validator-host", destination, store_tool=Path("/store-tool"))
        transfer.assert_not_called()
        self.assertEqual(verifier.call_count, 3)
        self.assertTrue(all(call.args[1] == "verify" for call in verifier.call_args_list))
        self.assertTrue(result["replay_verified"])
        self.assertGreater(result["replay_verified_at_unix"], 0)
        self.assertEqual(set(result["verified_validators"]), set(policy.VALIDATORS))
        self.assertEqual(list(self.root.glob(".mfenx-replay-*")), [])
        self.assertEqual(sentinel.read_bytes(), b"preserved")
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive_latest.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)), \
                patch.object(policy, "run_store", side_effect=ValueError("replay rejected")):
            with self.assertRaisesRegex(ValueError, "replay rejected"):
                receive_latest.receive_latest("validator-host", destination, store_tool=Path("/store-tool"))
        failed = json.loads((destination / "latest-receipt.json").read_bytes())
        self.assertFalse(failed["replay_verified"])
        self.assertIsNone(failed["replay_verified_at_unix"])
        self.assertEqual(failed["replay_error"], "ledger_replay_failed")
        self.assertEqual(list(self.root.glob(".mfenx-replay-*")), [])
        self.assertEqual(sentinel.read_bytes(), b"preserved")
        self.assertEqual(backup.digest(archive), source["sha256"])

    def test_receiver_replay_checks_remote_commitments_and_rejects_legacy_claim(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=self.fake_store):
            created = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")
        source = created["receipt"]
        source["validators"]["validator-1"]["height"] += 1
        destination = self.root / "received"
        destination.mkdir(mode=0o700)
        archive = destination / source["archive"]
        archive.write_bytes((self.backups / source["archive"]).read_bytes())
        archive.chmod(0o600)
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive_latest.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)), \
                patch.object(policy, "run_store", side_effect=self.fake_store):
            with self.assertRaisesRegex(ValueError, "commitments differ"):
                receive_latest.receive_latest("validator-host", destination, store_tool=Path("/store-tool"))
        self.assertFalse(json.loads((destination / "latest-receipt.json").read_bytes())["replay_verified"])
        self.assertEqual(list(self.root.glob(".mfenx-replay-*")), [])
        with self.assertRaisesRegex(ValueError, "SQLite"):
            receive_latest.verify_archive(archive, {**source, "storage_mode": "json"}, Path("/store-tool"), destination)

    def test_failed_new_replay_cannot_displace_three_retained_backups(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=self.fake_store):
            source = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")["receipt"]
        content = (self.backups / source["archive"]).read_bytes()
        destination = self.root / "received"
        destination.mkdir(mode=0o700)
        retained = []
        for index in range(3):
            path = destination / f"ledger-2020010{index + 1}T000000.000000Z.tar"
            path.write_bytes(content)
            path.chmod(0o600)
            retained.append(path)
        policy.atomic_json(destination / "latest-receipt.json", {
            "archive": retained[-1].name, "sha256": source["sha256"], "replay_verified": True})
        process = self.local_ssh_process(content)
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive.subprocess, "Popen", return_value=process), \
                patch.object(receive_latest.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)), \
                patch.object(policy, "run_store", side_effect=ValueError("bad replay")):
            with self.assertRaisesRegex(ValueError, "bad replay"):
                receive_latest.receive_latest("validator-host", destination, store_tool=Path("/store-tool"))
        self.assertEqual(set(destination.glob("ledger-*.tar")), set(retained))
        self.assertTrue(all(backup.digest(path) == source["sha256"] for path in retained))
        failed = json.loads((destination / "latest-receipt.json").read_bytes())
        self.assertFalse(failed["replay_verified"])
        self.assertFalse(failed["archive_retained"])
        self.assertEqual(list(self.root.glob(".mfenx-replay-*")), [])

    def test_receiver_refreshes_backup_age_after_replay(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=self.fake_store):
            source = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")["receipt"]
        destination = self.root / "received"
        destination.mkdir(mode=0o700)
        archive = destination / source["archive"]
        archive.write_bytes((self.backups / source["archive"]).read_bytes())
        archive.chmod(0o600)
        clock = [source["completed_at_unix"] + 1]
        def replay(*_args):
            clock[0] += 3600
            return source["validators"]
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive_latest, "verify_archive", side_effect=replay), \
                patch.object(receive_latest.time, "time", side_effect=lambda: clock[0]):
            result = receive_latest.receive_latest("validator-host", destination, store_tool=Path("/store-tool"))
        self.assertEqual(result["source_backup_age_seconds"], 3601)
        self.assertEqual(result["checked_at_unix"], clock[0])
        self.assertEqual(result["warning"], "source_backup_stale")

    def test_latest_receiver_transfers_valid_archive_and_skips_identical_repeat(self):
        created = backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        source = created["receipt"]
        destination = self.root / "received"
        destination.mkdir(mode=0o700)
        for index in range(3):
            old = destination / f"ledger-2020010{index + 1}T000000.000000Z.tar"
            old.write_bytes(b"older archive")
            old.chmod(0o600)
        content = (self.backups / source["archive"]).read_bytes()
        process = self.local_ssh_process(content)
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive.subprocess, "Popen", return_value=process), \
                patch.object(receive.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)):
            result = receive_latest.receive_latest("validator-host", destination)
        self.assertFalse(result["already_present"])
        self.assertFalse(result["replay_verified"])
        self.assertEqual(len(list(destination.glob("ledger-*.tar"))), 3)
        self.assertEqual(backup.digest(destination / source["archive"]), source["sha256"])
        with patch.object(receive_latest, "fetch_receipt", return_value=source), patch.object(receive, "receive") as transfer:
            repeated = receive_latest.receive_latest("validator-host", destination)
            transfer.assert_not_called()
        self.assertTrue(repeated["already_present"])
        self.assertEqual(repeated["received_at_unix"], result["received_at_unix"])
        self.assertEqual(json.loads((destination / "latest-receipt.json").read_bytes())["source_backup"], source)

    def test_latest_receiver_rejects_changed_stream_without_publication(self):
        source = backup.create_backup(self.state, self.backups, Path("/unused"), "json")["receipt"]
        destination = self.root / "received"
        process = self.local_ssh_process(b"changed archive")
        with patch.object(receive_latest, "fetch_receipt", return_value=source), \
                patch.object(receive.subprocess, "Popen", return_value=process), \
                patch.object(receive.shutil, "disk_usage", return_value=SimpleNamespace(free=8 * policy.GIB)):
            with self.assertRaisesRegex(ValueError, "mismatched"):
                receive_latest.receive_latest("validator-host", destination)
        self.assertFalse((destination / source["archive"]).exists())
        self.assertFalse((destination / "latest-receipt.json").exists())
        self.assertEqual(list(destination.glob(".receiving-*")), [])

    def test_latest_receiver_rejects_changed_existing_archive_and_symlink_destination(self):
        source = backup.create_backup(self.state, self.backups, Path("/unused"), "json")["receipt"]
        destination = self.root / "received"
        destination.mkdir(mode=0o700)
        path = destination / source["archive"]
        path.write_bytes(b"x" * source["bytes"])
        path.chmod(0o600)
        with patch.object(receive_latest, "fetch_receipt", return_value=source), patch.object(receive, "receive") as transfer:
            with self.assertRaisesRegex(ValueError, "differs"):
                receive_latest.receive_latest("validator-host", destination)
            transfer.assert_not_called()
        alias = self.root / "alias"
        alias.symlink_to(destination, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "symlink"):
            receive_latest.prepare_destination(alias / "child")
        self.assertFalse((destination / "child").exists())

    def test_invalid_snapshot_identity_is_rejected_by_cli_wrapper(self):
        executable = self.root / "fake-store"
        value = policy.legacy_metadata(ledger(1))
        value["chain_id"] = 177155
        executable.write_text("#!/usr/bin/python3\nprint(" + repr(json.dumps(value)) + ")\n")
        executable.chmod(0o700)
        with self.assertRaisesRegex(ValueError, "identity"):
            policy.run_store(executable, "inspect", self.root / "unused")

    def test_cli_output_is_bounded(self):
        executable = self.root / "fake-store"
        executable.write_text("#!/usr/bin/python3\nprint('x' * 100000)\n")
        executable.chmod(0o700)
        with self.assertRaisesRegex(ValueError, "output limit"):
            policy.run_store(executable, "inspect", self.root / "unused")

    def test_cli_passes_explicit_allocation_instead_of_inheriting_default(self):
        executable = self.root / "fake-store"
        metadata = {**policy.legacy_metadata(ledger(1)), "head_valid": True}
        executable.write_text("#!/usr/bin/python3\nimport sys\n"
                              "assert sys.argv[sys.argv.index('--max-bytes') + 1] == '536870912'\n"
                              "print(" + repr(json.dumps(metadata)) + ")\n")
        executable.chmod(0o700)
        self.assertEqual(policy.run_store(executable, "inspect", self.root / "unused"), metadata)

    def test_receiver_rejects_remote_option_and_path_injection(self):
        with patch.object(receive.subprocess, "Popen") as process:
            with self.assertRaises(ValueError):
                receive.receive("-oProxyCommand=bad", "ledger-20261019T000000.000000Z.tar", "a" * 64, self.root / "received")
            with self.assertRaises(ValueError):
                receive.receive("root@example.invalid", "../../secret", "a" * 64, self.root / "received")
            process.assert_not_called()

    def test_rotation_and_legacy_restore(self):
        for _ in range(4):
            result = backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        self.assertEqual(len(list(self.backups.glob("ledger-*.tar"))), 3)
        output = self.root / "recovered"
        prepared = recovery.prepare_restore(self.backups / result["backup"], output,
                                            Path("/unused"), result["sha256"])
        self.assertFalse(prepared["activated"])
        self.assertTrue((output / "RECOVERY-NOT-ACTIVATED.json").is_file())
        with self.assertRaises(ValueError):
            recovery.prepare_restore(self.backups / result["backup"], output, Path("/unused"))

    def test_wrong_archive_hash_and_member_traversal_rejected(self):
        result = backup.create_backup(self.state, self.backups, Path("/unused"), "json")
        with self.assertRaises(ValueError):
            recovery.prepare_restore(self.backups / result["backup"], self.root / "bad-hash", Path("/unused"), "0" * 64)
        malicious = self.root / "malicious.tar"
        with tarfile.open(malicious, "w") as archive:
            info = tarfile.TarInfo("../../outside")
            info.size = 1
            archive.addfile(info, io.BytesIO(b"x"))
        with self.assertRaises(ValueError):
            recovery.prepare_restore(malicious, self.root / "bad-path", Path("/unused"))
        self.assertFalse((self.root / "bad-path").exists())

    def test_sqlite_restore_requires_full_verification(self):
        self.add_databases()
        with patch.object(policy, "run_store", side_effect=self.fake_store):
            result = backup.create_backup(self.state, self.backups, Path("/unused"), "sqlite")
        with patch.object(policy, "run_store", side_effect=self.fake_store) as cli:
            prepared = recovery.prepare_restore(self.backups / result["backup"], self.root / "restore-db", Path("/unused"))
        self.assertEqual(cli.call_count, 3)
        self.assertTrue(all(call.args[1] == "verify" for call in cli.call_args_list))
        self.assertFalse(prepared["activated"])

    def test_growth_warns_before_capacity(self):
        self.add_databases()
        previous = status.observation(self.state, self.backups, "sqlite", now=1000)
        path = self.state / "validator-1" / policy.DATABASE_NAME
        with path.open("wb") as stream:
            stream.truncate(policy.MAX_DATABASE_MAIN_BYTES - policy.MIB)
        current = status.observation(self.state, self.backups, "sqlite", previous, now=1600)
        self.assertGreater(current["growth_bytes_per_second"], 0)
        self.assertLess(current["estimated_seconds_to_boundary"], 7 * 86400)
        self.assertIsNotNone(current["warning"])

    def test_wal_checkpoint_cycles_do_not_predict_persistent_growth(self):
        self.add_databases()
        previous = status.observation(self.state, self.backups, "sqlite", now=1000)
        wal = self.state / "validator-1" / (policy.DATABASE_NAME + "-wal")
        with wal.open("wb") as stream:
            stream.truncate(512 * 1024)
        current = status.observation(self.state, self.backups, "sqlite", previous, now=1300)
        self.assertEqual(current["growth_bytes_per_second"], 0)
        self.assertEqual(current["wal_usage_bytes"]["validator-1"], 512 * 1024)
        self.assertIsNone(current["estimated_seconds_to_boundary"])
        wal.write_bytes(b"")
        later = status.observation(self.state, self.backups, "sqlite", current, now=1600)
        self.assertEqual(later["growth_bytes_per_second"], 0)
        self.assertEqual(later["wal_usage_bytes"]["validator-1"], 0)
        self.assertIsNone(later["estimated_seconds_to_boundary"])

    def test_growth_history_is_bounded_and_requires_a_multiminute_window(self):
        self.add_databases()
        current = None
        for now in range(1000, 2001, 5):
            current = status.observation(self.state, self.backups, "sqlite", current, now=now)
            self.assertLessEqual(len(current["growth_samples"]), status.MAX_GROWTH_SAMPLES)
            self.assertTrue(all(now - item["sampled_at_unix"] <= 900 for item in current["growth_samples"]))
            if now < 1300:
                self.assertIsNone(current["growth_bytes_per_second"])
        self.assertGreaterEqual(current["growth_window_seconds"], 300)
        self.assertLessEqual(current["growth_window_seconds"], 900)
        after_gap = status.observation(self.state, self.backups, "sqlite", current, now=3000)
        self.assertIsNone(after_gap["growth_bytes_per_second"])
        self.assertEqual(len(after_gap["growth_samples"]), 1)

    def test_cadence_uses_configuration(self):
        service = gateway.Service.__new__(gateway.Service)
        service.manifest = {"identity": {}, "topology": {}, "runtime": {"client": "test"}}
        with patch.object(gateway, "EMPTY_BLOCK_SECONDS", 12):
            self.assertEqual(service.make_status([], time.time())["empty_block_interval_seconds"], 12)

    def test_storage_allocation_does_not_expand_rpc_body_or_batch_admission(self):
        service = SimpleNamespace(
            admit=lambda *args: True, admission_lock=threading.Lock(),
            byte_bucket=SimpleNamespace(take=lambda count: True),
            admit_work=Mock(return_value=True), rpc_lock=threading.Lock(), nodes=[{}],
            snapshot=lambda: {"status": "operational"},
            upstream=Mock(side_effect=lambda node, request: {
                "jsonrpc": "2.0", "id": request["id"], "result": hex(policy.CHAIN_ID)}))
        server = gateway.Server(("127.0.0.1", 0), service)
        worker = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.01})
        worker.start()
        def post(body):
            connection = HTTPConnection("127.0.0.1", server.server_port, timeout=3)
            try:
                connection.request("POST", "/", body, {"Content-Type": "application/json"})
                response = connection.getresponse()
                return response.status, json.loads(response.read())
            finally:
                connection.close()
        try:
            request = {"jsonrpc": "2.0", "id": 1, "method": "eth_chainId", "params": []}
            code, result = post(json.dumps([request] * 8).encode())
            self.assertEqual(code, 200)
            self.assertEqual(len(result), 8)
            self.assertEqual(service.upstream.call_count, 8)
            service.admit_work.assert_called_once_with(7, 0)
            service.upstream.reset_mock()
            service.admit_work.reset_mock()
            self.assertEqual(post(json.dumps([request] * 9).encode())[0], 400)
            self.assertEqual(post(b" " * (131072 + 1))[0], 413)
            service.upstream.assert_not_called()
            service.admit_work.assert_not_called()
        finally:
            server.shutdown()
            worker.join(timeout=3)
            server.server_close()


if __name__ == "__main__":
    unittest.main()
