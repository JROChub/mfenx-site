#!/usr/bin/env python3
"""Read-only admission guard for the existing MFENX host.

No network requests, writes, deletions, service changes, or provider API calls.
Run as the dedicated root oneshot so all private state directories are visible.
Nonzero exit means the owning unit must stop mfenx-native.target, not restart it.
The existing separate egress watchdog must also stop Caddy on a cap failure.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import sys
import time

import policy

STATE_ROOT = Path("/var/lib/mfenx-native")
BACKUP_ROOT = Path("/var/lib/mfenx-native-backups")
TC_COMMAND = ("/usr/sbin/tc", "-j", "-r", "qdisc", "show", "dev", "eth0")
TC_OUTPUT_LIMIT = 16384
TC_TIMEOUT = 3
MIN_FREE_BYTES = 2 * 1024**3
MAX_STATE_BYTES = 64 * 1024**2
MAX_BACKUP_BYTES = 20 * 1024**2
MAX_LEDGER_BYTES = 1572864
MAX_ENTRIES = 1024
MAX_DEPTH = 6
ROOT_UID = 0
EXPECTED_DIRECTORIES = {"validator-1", "validator-2", "validator-3", "gateway"}


class GuardError(Exception):
    def __init__(self, check, reason):
        self.check, self.reason = check, reason
        super().__init__(reason)


def read_tc():
    """Bound both subprocess time and stdout; never emit command diagnostics."""
    process = None
    try:
        process = subprocess.Popen(TC_COMMAND, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"})
        raw = bytearray()
        deadline = time.monotonic() + TC_TIMEOUT
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise GuardError("cap", "tc_timeout")
                ready = selector.select(remaining)
                if not ready:
                    raise GuardError("cap", "tc_timeout")
                chunk = os.read(process.stdout.fileno(), min(4096, TC_OUTPUT_LIMIT + 1 - len(raw)))
                if not chunk:
                    break
                raw.extend(chunk)
                if len(raw) > TC_OUTPUT_LIMIT:
                    raise GuardError("cap", "tc_output_limit")
        if process.wait(timeout=max(0.01, deadline - time.monotonic())) != 0:
            raise GuardError("cap", "tc_failed")
        return bytes(raw)
    except (OSError, subprocess.SubprocessError):
        raise GuardError("cap", "tc_unavailable") from None
    finally:
        if process is not None:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=1)
            if process.stdout is not None:
                process.stdout.close()


def check_cap(raw):
    def pairs(values):
        output = {}
        for key, value in values:
            if key in output:
                raise ValueError()
            output[key] = value
        return output
    def invalid_number(_value):
        raise ValueError()
    try:
        if len(raw) > TC_OUTPUT_LIMIT:
            raise ValueError()
        values = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_number)
        if not isinstance(values, list) or len(values) > 16 or any(not isinstance(value, dict) for value in values):
            raise ValueError()
        roots = [value for value in values if value.get("root") is True]
        if len(roots) != 1:
            raise ValueError()
        root = roots[0]
        if root.get("kind") != "tbf" or root.get("handle") != "c0de:":
            raise ValueError()
        options = root["options"]
        for name, expected in (("rate", 64000), ("burst", 8192), ("limit", 16384)):
            if type(options[name]) is not int or options[name] != expected:
                raise ValueError()
    except (ValueError, TypeError, KeyError, RecursionError):
        raise GuardError("cap", "cap_missing_or_changed") from None
    return 64000


def open_directory(path, check, private=False):
    """Reject symlink ancestors, broad/unexpected types, and writable roots."""
    path = Path(path)
    if not path.is_absolute() or path == Path("/") or ".." in path.parts:
        raise GuardError(check, "invalid_root")
    for ancestor in (*reversed(path.parents), path):
        metadata = ancestor.lstat()
        if not stat.S_ISDIR(metadata.st_mode):
            raise GuardError(check, "unsafe_root")
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    metadata = os.fstat(descriptor)
    forbidden = 0o077 if private else 0o022
    if metadata.st_uid != ROOT_UID or stat.S_IMODE(metadata.st_mode) & forbidden:
        os.close(descriptor)
        raise GuardError(check, "unsafe_root_permissions")
    return descriptor, metadata


def scan_tree(descriptor, device, limit, check, require_ledgers=False, storage_mode="json"):
    """Only directory entries/stat metadata are read, never file contents."""
    used = entries = 0
    ledgers = {name: 0 for name in EXPECTED_DIRECTORIES if name.startswith("validator-")}
    databases = {name: 0 for name in ledgers}
    database_sizes = {}
    top_names = set()

    def walk(current, depth, owner):
        nonlocal used, entries
        if depth > MAX_DEPTH:
            raise GuardError(check, "depth_limit")
        with os.scandir(current) as listing:
            for entry in listing:
                entries += 1
                if entries > MAX_ENTRIES:
                    raise GuardError(check, "entry_limit")
                try:
                    metadata = entry.stat(follow_symlinks=False)
                except FileNotFoundError:
                    # Atomic-write temporary files can disappear during traversal.
                    continue
                if metadata.st_dev != device:
                    raise GuardError(check, "unexpected_filesystem")
                if depth == 0:
                    top_names.add(entry.name)
                    if require_ledgers and not stat.S_ISDIR(metadata.st_mode):
                        raise GuardError(check, "missing_or_unexpected_state")
                if stat.S_ISDIR(metadata.st_mode):
                    used += metadata.st_blocks * 512
                    if used > limit:
                        raise GuardError(check, "footprint_limit")
                    try:
                        child = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=current)
                    except FileNotFoundError:
                        continue
                    try:
                        if os.fstat(child).st_dev != device:
                            raise GuardError(check, "unexpected_filesystem")
                        walk(child, depth + 1, entry.name if depth == 0 else owner)
                    finally:
                        os.close(child)
                elif stat.S_ISREG(metadata.st_mode):
                    if metadata.st_nlink != 1:
                        raise GuardError(check, "hardlink_not_allowed")
                    if check == "backups" and (metadata.st_uid != ROOT_UID or stat.S_IMODE(metadata.st_mode) & 0o077):
                        raise GuardError(check, "unsafe_backup_permissions")
                    used += max(metadata.st_size, metadata.st_blocks * 512)
                    if used > limit:
                        raise GuardError(check, "footprint_limit")
                    if require_ledgers and entry.name == "native_chain_state.json":
                        if depth != 1 or owner not in ledgers or not 0 < metadata.st_size <= MAX_LEDGER_BYTES:
                            raise GuardError(check, "ledger_size_or_location")
                        ledgers[owner] += 1
                    if require_ledgers and entry.name in (
                            policy.DATABASE_NAME, policy.DATABASE_NAME + "-wal", policy.DATABASE_NAME + "-shm"):
                        cap = {policy.DATABASE_NAME: policy.MAX_DATABASE_MAIN_BYTES,
                               policy.DATABASE_NAME + "-wal": policy.MAX_WAL_BYTES,
                               policy.DATABASE_NAME + "-shm": policy.MAX_SHM_BYTES}[entry.name]
                        if depth != 1 or owner not in ledgers or metadata.st_size > cap:
                            raise GuardError(check, "database_size_or_location")
                        database_sizes.setdefault(owner, {})[entry.name] = metadata.st_size
                        if entry.name == policy.DATABASE_NAME:
                            if metadata.st_size == 0:
                                raise GuardError(check, "empty_database")
                            databases[owner] += 1
                else:
                    raise GuardError(check, "special_file_or_symlink")

    walk(descriptor, 0, None)
    if require_ledgers and (top_names != EXPECTED_DIRECTORIES or any(count != 1 for count in ledgers.values())):
        raise GuardError(check, "missing_or_unexpected_state")
    if require_ledgers and storage_mode == "sqlite" and any(count != 1 for count in databases.values()):
        raise GuardError(check, "missing_sqlite_database")
    if any(sum(files.values()) > policy.MAX_DATABASE_BYTES for files in database_sizes.values()):
        raise GuardError(check, "database_total_limit")
    return {"bytes": used, "entries": entries, **({"databases": database_sizes} if require_ledgers else {})}


def check_storage(state_root=STATE_ROOT, backup_root=BACKUP_ROOT, storage_mode="json"):
    if storage_mode not in ("json", "sqlite"):
        raise GuardError("storage", "invalid_storage_mode")
    configured_budget = os.environ.get("MFENX_NATIVE_MAX_DATABASE_BYTES")
    if storage_mode == "sqlite" and configured_budget not in (None, str(policy.MAX_DATABASE_BYTES)):
        raise GuardError("storage", "database_budget_differs_from_operations_policy")
    descriptors = []
    try:
        state, state_stat = open_directory(state_root, "state")
        descriptors.append(state)
        backup, backup_stat = open_directory(backup_root, "backups", private=True)
        descriptors.append(backup)
        if state_stat.st_dev != backup_stat.st_dev:
            raise GuardError("storage", "unexpected_filesystem")
        filesystem = os.fstatvfs(state)
        free = filesystem.f_bavail * filesystem.f_frsize
        if free < MIN_FREE_BYTES:
            raise GuardError("storage", "disk_reserve")
        state_limit = policy.MAX_STATE_BYTES if storage_mode == "sqlite" else MAX_STATE_BYTES
        backup_limit = policy.MAX_BACKUP_BYTES if storage_mode == "sqlite" else MAX_BACKUP_BYTES
        state_usage = scan_tree(state, state_stat.st_dev, state_limit, "state", require_ledgers=True, storage_mode=storage_mode)
        backup_usage = scan_tree(backup, backup_stat.st_dev, backup_limit, "backups")
        return {"free_bytes": free, "state": state_usage, "backups": backup_usage,
                "storage_mode": storage_mode, "state_limit_bytes": state_limit,
                "backup_limit_bytes": backup_limit, "reserve_bytes": MIN_FREE_BYTES,
                "database_main_limit_bytes": policy.MAX_DATABASE_MAIN_BYTES,
                "database_total_limit_bytes": policy.MAX_DATABASE_BYTES,
                "wal_limit_bytes": policy.MAX_WAL_BYTES}
    except OSError:
        raise GuardError("storage", "unavailable_or_changed") from None
    finally:
        for descriptor in descriptors:
            os.close(descriptor)


def main():
    if len(sys.argv) != 1:
        print('{"ok":false,"check":"invocation","reason":"no_arguments_allowed"}')
        return 1
    try:
        rate = check_cap(read_tc())
        result = check_storage(storage_mode=os.environ.get("MFENX_NATIVE_STORAGE", "json"))
        print(json.dumps({"ok": True, "cap_bytes_per_second": rate, **result}, separators=(",", ":")))
        return 0
    except GuardError as error:
        print(json.dumps({"ok": False, "check": error.check, "reason": error.reason}, separators=(",", ":")))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
