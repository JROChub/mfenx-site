#!/usr/bin/env python3
"""Bounded loopback edge for the separately identified MFENX native history."""
from __future__ import annotations

import argparse
from collections import Counter, OrderedDict, deque
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from http.client import HTTPConnection, HTTPException
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import socket
from socketserver import ThreadingMixIn
import threading
import tempfile
import time

CHAIN_ID = 2026092601
HISTORY_ID = "mfenx-native-2026-09-27"
HOST = "license.mfenx.com"
PUBLIC_URL = "https://license.mfenx.com/network/2026/"
INTERVAL = 15
MAX_BODY = 131072
MAX_RESPONSE = 131072
MAX_BATCH = 8
MAX_RAW_TRANSACTION = 50 * 1024
MAX_CALLDATA = 49152
EXECUTION_PROFILE = "mfenx-evm-cancun-fee-free-v1"
HASH = re.compile(r"0x[0-9a-f]{64}\Z")
ADDRESS = re.compile(r"0x[0-9a-fA-F]{40}\Z")
QUANTITY = re.compile(r"0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,15})\Z")


def utc(timestamp=None):
    return datetime.fromtimestamp(time.time() if timestamp is None else timestamp, timezone.utc).isoformat().replace("+00:00", "Z")


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def decode(raw):
    def invalid_constant(_value):
        raise ValueError("nonfinite JSON number")
    def finite_float(value):
        result = float(value)
        if not math.isfinite(result):
            raise ValueError("nonfinite JSON number")
        return result
    result = json.loads(raw, object_pairs_hook=no_duplicates, parse_constant=invalid_constant, parse_float=finite_float)
    pending = [(result, 0)]
    while pending:
        value, depth = pending.pop()
        if depth > 32:
            raise ValueError("JSON nesting exceeds the limit")
        if isinstance(value, dict):
            pending.extend((item, depth + 1) for item in value.values())
        elif isinstance(value, list):
            pending.extend((item, depth + 1) for item in value)
    return result


def encode(value):
    return json.dumps(value, separators=(",", ":"), sort_keys=True, allow_nan=False).encode()


def integer(value, low=0, high=2**53 - 1):
    return type(value) is int and low <= value <= high


def atomic_json(path, value):
    descriptor, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(encode(value))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temporary.exists():
            temporary.unlink()


class Bucket:
    def __init__(self, rate, burst):
        self.rate, self.burst = rate, burst
        self.tokens, self.updated = burst, time.monotonic()

    def take(self, amount=1):
        now = time.monotonic()
        self.tokens = min(self.burst, self.tokens + (now - self.updated) * self.rate)
        self.updated = now
        if self.tokens < amount:
            return False
        self.tokens -= amount
        return True


def validate_rpc(value):
    if not isinstance(value, dict) or set(value) != {"jsonrpc", "id", "method", "params"}:
        raise ValueError("One complete JSON-RPC request is required; batches and notifications are not supported.")
    if value["jsonrpc"] != "2.0" or not (integer(value["id"]) or isinstance(value["id"], str) and len(value["id"]) <= 64):
        raise ValueError("Invalid JSON-RPC version or identifier.")
    method, params = value["method"], value["params"]
    if not isinstance(method, str) or not isinstance(params, list):
        raise ValueError("Invalid method or parameters.")
    no_args = {"web3_clientVersion", "net_version", "eth_chainId", "eth_syncing", "eth_blockNumber", "eth_gasPrice", "eth_maxPriorityFeePerGas", "eth_accounts", "eth_coinbase", "rpc_modules", "mfenx_getExecutionProfile"}
    def is_hash(item):
        return isinstance(item, str) and HASH.fullmatch(item) is not None
    def block(item):
        return isinstance(item, str) and (item in {"latest", "earliest", "finalized", "safe", "pending"} or QUANTITY.fullmatch(item) is not None)
    def address(item):
        return isinstance(item, str) and ADDRESS.fullmatch(item) is not None
    def quantity(item, digits=32):
        return isinstance(item, str) and re.fullmatch(r"0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0," + str(digits - 1) + r"})", item) is not None
    def transaction(item):
        if not isinstance(item, dict) or len(item) > 14:
            return False
        for key, entry in item.items():
            if key in {"from", "to"}:
                if not address(entry) and not (key == "to" and entry is None):
                    return False
            elif key in {"gas", "gasPrice", "maxFeePerGas", "maxPriorityFeePerGas", "value", "nonce", "chainId", "type"}:
                if not quantity(entry, 64):
                    return False
            elif key in {"data", "input"}:
                if not isinstance(entry, str) or len(entry) > 2 + MAX_CALLDATA * 2 or re.fullmatch(r"0x(?:[0-9a-fA-F]{2})*", entry) is None:
                    return False
            elif key == "accessList":
                if not isinstance(entry, list) or len(entry) > 16:
                    return False
                for access in entry:
                    if not isinstance(access, dict) or set(access) != {"address", "storageKeys"} or not address(access["address"]):
                        return False
                    keys = access["storageKeys"]
                    if not isinstance(keys, list) or len(keys) > 64 or not all(is_hash(slot) for slot in keys):
                        return False
            else:
                return False
        return True
    if method in no_args:
        valid = not params
    elif method in {"eth_getBalance", "eth_getTransactionCount", "eth_getCode"}:
        valid = len(params) in {1, 2} and address(params[0]) and (len(params) == 1 or block(params[1]))
    elif method in {"eth_estimateGas", "eth_call"}:
        valid = len(params) in {1, 2} and transaction(params[0]) and (len(params) == 1 or block(params[1]))
    elif method == "eth_getStorageAt":
        valid = len(params) == 3 and address(params[0]) and quantity(params[1], 64) and block(params[2])
    elif method == "eth_feeHistory":
        count = params[0] if params else None
        valid_count = integer(count, 1, 64) or quantity(count, 2) and 1 <= int(count, 16) <= 64
        valid = len(params) in {2, 3} and valid_count and block(params[1])
        if valid and len(params) == 3:
            percentiles = params[2]
            valid = isinstance(percentiles, list) and len(percentiles) <= 16 and all(type(p) in {int, float} and 0 <= p <= 100 and math.isfinite(p) for p in percentiles)
            if valid:
                valid = all(a <= b for a, b in zip(percentiles, percentiles[1:]))
    elif method == "eth_getLogs":
        valid = len(params) == 1 and isinstance(params[0], dict) and set(params[0]) <= {"fromBlock", "toBlock", "blockHash", "address", "topics"}
        if valid:
            filters = params[0]
            valid = not ("blockHash" in filters and ("fromBlock" in filters or "toBlock" in filters))
            for key in ("fromBlock", "toBlock"):
                valid = valid and (key not in filters or block(filters[key]))
            valid = valid and ("blockHash" not in filters or is_hash(filters["blockHash"]))
            if "address" in filters:
                addresses = filters["address"] if isinstance(filters["address"], list) else [filters["address"]]
                valid = valid and len(addresses) <= 16 and all(address(a) for a in addresses)
            if "topics" in filters:
                topics = filters["topics"]
                valid = valid and isinstance(topics, list) and len(topics) <= 4
                if valid:
                    for topic in topics:
                        alternatives = topic if isinstance(topic, list) else [topic]
                        valid = valid and len(alternatives) <= 16 and all(t is None or is_hash(t) for t in alternatives)
    elif method == "eth_sendRawTransaction":
        valid = len(params) == 1 and isinstance(params[0], str) and 6 <= len(params[0]) <= 2 + MAX_RAW_TRANSACTION * 2 and re.fullmatch(r"0x02(?:[0-9a-fA-F]{2})+", params[0]) is not None
    elif method == "eth_getBlockByNumber":
        valid = len(params) == 2 and block(params[0]) and type(params[1]) is bool
    elif method == "eth_getBlockByHash":
        valid = len(params) == 2 and is_hash(params[0]) and type(params[1]) is bool
    elif method in {"eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockTransactionCountByHash"}:
        valid = len(params) == 1 and is_hash(params[0])
    elif method == "eth_getBlockTransactionCountByNumber":
        valid = len(params) == 1 and block(params[0])
    else:
        raise LookupError("Method is not available on this validator endpoint.")
    if not valid:
        raise ValueError("Invalid or unsupported parameters.")
    return value


class Service:
    def __init__(self, config, state_dir):
        self.manifest = config["manifest"]
        self.nodes = config["nodes"]
        identity = self.manifest["identity"]
        mode = self.manifest.get("public_rpc_mode")
        submission = self.manifest.get("transaction_submission")
        if (mode, submission) not in {("native_transfers", "public_signed_native"), ("evm_contracts", "public_signed_evm")}:
            raise ValueError("Validator capabilities must match the published manifest")
        self.execution = self.manifest.get("execution") if mode == "evm_contracts" else None
        if mode == "evm_contracts" and (not isinstance(self.execution, dict) or self.execution.get("profile") != EXECUTION_PROFILE or not integer(self.execution.get("activation_height"), 1) or self.execution.get("validator_replay") is not True):
            raise ValueError("A pinned validator execution profile is required")
        if identity["chain_id"] != CHAIN_ID or identity["history_id"] != HISTORY_ID or not HASH.fullmatch(identity["genesis_hash"]):
            raise ValueError("Refusing an unexpected network identity")
        if len(self.nodes) != 3 or len({n["node_id"] for n in self.nodes}) != 3:
            raise ValueError("Three distinct validator records are required")
        for field in ("peer_id", "public_key", "rpc_port"):
            if len({n[field] for n in self.nodes}) != 3:
                raise ValueError("Validator identities and endpoints must be distinct")
        topology = self.manifest["topology"]
        if any(topology.get(key) != value for key, value in {"validator_count": 3, "quorum": 2, "host_count": 1, "failure_domain_count": 1}.items()) or not isinstance(topology.get("regions"), list) or len(topology["regions"]) != 1:
            raise ValueError("Invalid single-host topology")
        for node in self.nodes:
            if not integer(node["rpc_port"], 1024, 65535):
                raise ValueError("Invalid loopback validator configuration")
        self.state_dir = Path(state_dir)
        self.lock = threading.Lock()
        self.rpc_lock = threading.Lock()
        self.admission_lock = threading.Lock()
        self.request_bucket = Bucket(8, 16)
        self.rpc_bucket = Bucket(4, 16)
        self.transaction_bucket = Bucket(0.2, 4)
        self.byte_bucket = Bucket(8192, MAX_RESPONSE + 512)
        self.clients = OrderedDict()
        self.samples = deque(maxlen=5761)
        self.persisted_at = 0
        self.status = self.make_status([], time.time())
        self.load_samples()

    def load_samples(self):
        path = self.state_dir / "observations.json"
        if not path.exists():
            return
        if path.stat().st_size > 262144:
            raise ValueError("Oversized observations file")
        rows = decode(path.read_bytes())
        if not isinstance(rows, list) or len(rows) > 5761:
            raise ValueError("Invalid observations")
        previous = 0
        for row in rows:
            if not isinstance(row, list) or len(row) != 2 or not integer(row[0]) or type(row[1]) is not bool or row[0] <= previous:
                raise ValueError("Invalid observation record")
            previous = row[0]
            if time.time() - 86400 <= row[0] <= time.time():
                self.samples.append(row)

    def admit(self, client, rpc=False):
        with self.admission_lock:
            try:
                client = str(ipaddress.ip_address(client))
            except ValueError:
                return False
            if client not in self.clients:
                if len(self.clients) >= 512:
                    self.clients.popitem(last=False)
                self.clients[client] = Bucket(2, 16)
            self.clients.move_to_end(client)
            return self.request_bucket.take() and self.clients[client].take() and (not rpc or self.rpc_bucket.take())

    def admit_work(self, extra_requests, writes):
        # Reserve the complete batch before forwarding any write. Request and
        # egress limits remain bounded; signatures and state validation stay in
        # the original consensus runtime, never in an unauthenticated relay.
        with self.admission_lock:
            if not self.rpc_bucket.take(extra_requests):
                return False
            return self.transaction_bucket.take(writes)

    def upstream(self, node, request):
        connection = HTTPConnection("127.0.0.1", node["rpc_port"], timeout=2)
        try:
            connection.request("POST", "/", body=encode(request), headers={"Content-Type": "application/json"})
            response = connection.getresponse()
            raw = response.read(MAX_RESPONSE + 1)
            if len(raw) > MAX_RESPONSE or response.status != 200:
                raise ValueError("Invalid upstream response size or status")
            result = decode(raw)
            if not isinstance(result, dict) or result.get("jsonrpc") != "2.0" or type(result.get("id")) is not type(request["id"]) or result.get("id") != request["id"] or (("result" in result) == ("error" in result)):
                raise ValueError("Invalid upstream envelope")
            return result
        finally:
            connection.close()

    def probe(self, node):
        row = {"node_id": node["node_id"], "peer_id": node["peer_id"], "healthy": False, "height": None, "tip_hash": None, "genesis_hash": None, "admission": "unavailable"}
        try:
            def call(method, params):
                response = self.upstream(node, {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
                return response["result"]
            if call("eth_chainId", []) != hex(CHAIN_ID):
                return row
            if self.execution is not None:
                profile = call("mfenx_getExecutionProfile", [])
                if profile.get("profile") != self.execution["profile"] or profile.get("activationHeight") != hex(self.execution["activation_height"]) or profile.get("validatorReplay") is not True:
                    return row
            genesis = call("eth_getBlockByNumber", ["0x0", False])
            if genesis["hash"] != self.manifest["identity"]["genesis_hash"]:
                return row
            admission = call("mfenx_getAdmissionStatus", [])
            if not isinstance(admission, dict) or admission.get("schema") != "mfenx.native-admission-status.v1" or admission.get("chain_id") != CHAIN_ID or admission.get("genesis_hash") != genesis["hash"] or admission.get("validator_public_key") != node["public_key"] or not integer(admission.get("block_height")):
                return row
            tip = call("eth_getBlockByNumber", [hex(admission["block_height"]), False])
            if not HASH.fullmatch(tip["hash"]) or not QUANTITY.fullmatch(tip["number"]):
                return row
            height, timestamp = int(tip["number"], 16), int(tip["timestamp"], 16)
            if not integer(height) or not integer(timestamp, 0, int(time.time()) + 30):
                return row
            if height != admission["block_height"] or tip["hash"] != admission.get("block_hash"):
                return row
            recent = timestamp > 0 and time.time() - timestamp <= 86490
            row.update(healthy=admission.get("admission") == "open" and recent, height=height, tip_hash=tip["hash"], genesis_hash=genesis["hash"], admission=admission.get("admission"), last_finalized_at=utc(timestamp) if timestamp else None)
        except (OSError, ValueError, KeyError, TypeError, OverflowError, RecursionError, HTTPException):
            pass
        return row

    def make_status(self, rows, sampled_at):
        healthy = [row for row in rows if row["healthy"]]
        counts = Counter((row["height"], row["tip_hash"]) for row in healthy)
        common, count = counts.most_common(1)[0] if counts else ((None, None), 0)
        agreement = count >= 2
        state = "operational" if len(healthy) == 3 and count == 3 else "degraded" if healthy else "unavailable" if rows else "starting"
        if state == "operational" and (common[0] == 0 or any(row["last_finalized_at"] is None for row in healthy)):
            state = "starting"
        samples = getattr(self, "samples", [])
        observed = sum(min(INTERVAL, b[0] - a[0]) for a, b in zip(samples, list(samples)[1:]) if 0 < b[0] - a[0] <= INTERVAL * 2)
        successes = sum(row[1] for row in samples)
        return {"schema": "mfenx.network-status.v1", "generated_at": utc(), "sampled_at": utc(sampled_at), "identity": self.manifest["identity"], "topology": self.manifest["topology"], "status": state, "rpc": {"reachable": state == "operational", "url": PUBLIC_URL}, "validators_healthy": len(healthy), "validators": rows, "quorum_agreement": agreement, "block_height": common[0] if agreement else None, "tip_hash": common[1] if agreement else None, "last_finalized_at": next((row["last_finalized_at"] for row in healthy if row["height"] == common[0]), None), "empty_block_interval_seconds": 86400, "client": self.manifest["runtime"]["client"], "enrollment": {"observers": False, "validators": False}, "availability": {"window_seconds": 86400, "observed_seconds": observed, "sample_count": len(samples), "successful_samples": successes, "percent": 100 * successes / len(samples) if samples else None}, "reliability_campaign": {"status": "not_started"}}

    def sample(self):
        rows = [self.probe(node) for node in self.nodes]
        now = int(time.time())
        status = self.make_status(rows, now)
        if not self.samples or now > self.samples[-1][0]:
            self.samples.append([now, status["status"] == "operational"])
        while self.samples and self.samples[0][0] < now - 86400:
            self.samples.popleft()
        status = self.make_status(rows, now)
        try:
            if now - self.persisted_at >= 60:
                atomic_json(self.state_dir / "observations.json", list(self.samples))
                self.persisted_at = now
        except OSError:
            status["status"] = "degraded"
            status["rpc"]["reachable"] = False
            status["observation_storage"] = "unavailable"
        with self.lock:
            self.status = status

    def snapshot(self):
        with self.lock:
            result = dict(self.status)
        age = time.time() - datetime.fromisoformat(result["sampled_at"].replace("Z", "+00:00")).timestamp()
        if age > 45 or age < -5:
            result.update(status="unavailable", validators_healthy=0, quorum_agreement=False, block_height=None, tip_hash=None, last_finalized_at=None, rpc={"reachable": False, "url": PUBLIC_URL}, validators=[])
        result["generated_at"] = utc()
        return result

    def run_sampler(self):
        while True:
            started = time.monotonic()
            try:
                self.sample()
            except Exception:
                # No request data or validator key material enters logs.
                print("network observation failed", flush=True)
            time.sleep(max(1, INTERVAL - (time.monotonic() - started)))


class Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    request_queue_size = 8
    allow_reuse_address = True

    def __init__(self, address, service):
        self.service = service
        self.slots = threading.BoundedSemaphore(4)
        super().__init__(address, Handler)

    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        # Do not retain user IP addresses or request contents in server logs.
        print("network edge request failed", flush=True)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    server_version = "MFENX"
    sys_version = ""

    def setup(self):
        self.request.settimeout(3)
        super().setup()

    def log_message(self, _format, *_args):
        pass

    def send_error(self, code, message=None, explain=None):
        # Parser errors may precede headers. Never reflect attacker-controlled
        # request lines or bypass the response budget on an error path.
        self.server.service.admit(self.client_address[0])
        self.send_json(code, {"error": "Invalid or unsupported HTTP request."}, getattr(self, "command", None) == "HEAD")

    def send_json(self, status, value, head=False):
        raw = encode(value)
        with self.server.service.admission_lock:
            allowed = len(raw) <= MAX_RESPONSE and self.server.service.byte_bucket.take(len(raw) + 512)
        if not allowed:
            self.close_connection = True
            return
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Connection", "close")
        # Public queries and signed transactions never forward HTTP credentials.
        # CORS is not an admission control: non-browser clients can omit Origin.
        # Resource limits and the method allowlist apply equally to all callers.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "300")
        if status == 429:
            self.send_header("Retry-After", "15")
        self.end_headers()
        if not head:
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError, socket.timeout):
                pass
        self.close_connection = True

    def boundary(self, rpc=False):
        client = self.headers.get("X-MFENX-Client-IP", self.client_address[0])
        if not self.server.service.admit(client, rpc):
            self.send_json(429, {"error": "Request budget exceeded; retry later."})
            return False
        if len(self.headers.get_all("Host", [])) != 1 or self.headers.get("Host") not in {HOST, f"127.0.0.1:{self.server.server_port}"}:
            self.send_json(421, {"error": "Unrecognized host."})
            return False
        return True

    def do_OPTIONS(self):
        if self.boundary():
            self.send_json(200, {"methods": ["GET", "HEAD", "POST"]})

    def do_HEAD(self):
        self.do_GET(head=True)

    def do_GET(self, head=False):
        if not self.boundary():
            return
        service = self.server.service
        if self.path in {"/network-status.json", "/healthz"}:
            value = service.snapshot()
            self.send_json(200 if self.path != "/healthz" or value["status"] == "operational" else 503, value, head)
        elif self.path in {"/", "/manifest.json", "/network-manifest.json"}:
            self.send_json(200, service.manifest, head)
        elif self.path.startswith("/observer-"):
            self.send_json(503, {"error": "Enrollment is not available for this network history.", "history_id": HISTORY_ID}, head)
        else:
            self.send_json(404, {"error": "Not found."}, head)

    def do_POST(self):
        if not self.boundary(rpc=True):
            return
        if self.path != "/":
            self.send_json(503 if self.path.startswith("/observer-") else 404, {"error": "Endpoint is not available."})
            return
        lengths = self.headers.get_all("Content-Length", [])
        if self.headers.get_all("Transfer-Encoding") or len(lengths) != 1 or len(lengths[0]) > 6 or not lengths[0].isascii() or not lengths[0].isdigit():
            self.send_json(400, {"error": "One fixed content length is required."})
            return
        length = int(lengths[0])
        if not 0 < length <= MAX_BODY:
            self.send_json(413, {"error": "Request exceeds the body limit."})
            return
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            self.send_json(415, {"error": "Use application/json."})
            return
        identifier = None
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("Incomplete request.")
            parsed = decode(raw)
            if isinstance(parsed, dict) and (integer(parsed.get("id")) or isinstance(parsed.get("id"), str) and len(parsed["id"]) <= 64):
                identifier = parsed["id"]
            batch = isinstance(parsed, list)
            if batch and not 1 <= len(parsed) <= MAX_BATCH:
                raise ValueError("Batch exceeds the request limit.")
            requests = parsed if batch else [parsed]
            validated, results = [], []
            for item in requests:
                request_id = item.get("id") if isinstance(item, dict) else None
                request_id = request_id if integer(request_id) or isinstance(request_id, str) and len(request_id) <= 64 else None
                try:
                    validated.append(validate_rpc(item))
                    results.append(None)
                except LookupError:
                    validated.append(None)
                    results.append({"jsonrpc": "2.0", "id": request_id, "error": {"code": -32601, "message": "Method is not available."}})
                except (ValueError, TypeError):
                    validated.append(None)
                    results.append({"jsonrpc": "2.0", "id": request_id, "error": {"code": -32600, "message": "Invalid request."}})
            identifier = requests[0].get("id") if not batch and isinstance(requests[0], dict) else None
        except (ValueError, TypeError, RecursionError, socket.timeout):
            self.send_json(400, {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request."}})
            return
        service = self.server.service
        writes = sum(item is not None and item["method"] == "eth_sendRawTransaction" for item in validated)
        if not service.admit_work(len(requests) - 1, writes):
            self.send_json(429, {"error": "RPC work budget exceeded; retry later."})
            return
        if all(item is None for item in validated):
            self.send_json(200, results if batch else results[0])
            return
        if service.snapshot()["status"] != "operational":
            self.send_json(503, {"jsonrpc": "2.0", "id": identifier, "error": {"code": -32000, "message": "Network is not ready."}})
            return
        # A wallet commonly starts several reads simultaneously. Bound the
        # queue by the four HTTP workers and a short deadline, while retaining
        # one upstream request at a time and the existing request/byte budgets.
        if not service.rpc_lock.acquire(timeout=0.25):
            self.send_json(429, {"error": "RPC is busy; retry later."})
            return
        try:
            for index, request in enumerate(validated):
                if request is None:
                    continue
                try:
                    results[index] = service.upstream(service.nodes[0], request)
                except (OSError, ValueError, KeyError, TypeError, RecursionError, HTTPException):
                    # A signed transaction may already have been admitted. Never
                    # retry it automatically on another validator or hide that
                    # uncertainty; the sender can query its deterministic hash.
                    results[index] = {"jsonrpc": "2.0", "id": request["id"], "error": {"code": -32000, "message": "Validator response unavailable; query transaction status before resubmitting."}}
                    if not batch:
                        self.send_json(502, results[index])
                        return
            self.send_json(200, results if batch else results[0])
        except (OSError, ValueError, KeyError, TypeError, RecursionError, HTTPException):
            self.send_json(502, {"jsonrpc": "2.0", "id": identifier, "error": {"code": -32000, "message": "Validator is unavailable."}})
        finally:
            service.rpc_lock.release()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--state-dir", required=True, type=Path)
    parser.add_argument("--port", type=int, default=8093)
    args = parser.parse_args()
    if not args.state_dir.is_dir() or args.config.stat().st_size > 65536:
        raise SystemExit("Invalid configuration/state location")
    service = Service(decode(args.config.read_bytes()), args.state_dir)
    server = Server(("127.0.0.1", args.port), service)
    threading.Thread(target=service.run_sampler, daemon=True).start()
    server.serve_forever(poll_interval=0.5)


if __name__ == "__main__":
    main()
