#!/usr/bin/env python3
"""Bounded atomic snapshots; never rewrite or truncate the active ledger."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile

STATE = Path('/var/lib/mfenx-native')
BACKUP = Path('/var/lib/mfenx-native-backups')
CONFIG = Path('/etc/mfenx-native/2026-09-27')
GENESIS = '0x3b0b36b6acdcc5f0d7a1e38dd6621c58a9546a0e1a98cb58911b7646a0de5e8e'
MAX_STATE = 1572864

def add(archive, name, content):
    info = tarfile.TarInfo(name)
    info.size = len(content)
    info.mode = 0o600
    archive.addfile(info, io.BytesIO(content))

def main():
    if os.geteuid() != 0 or BACKUP.is_symlink() or BACKUP.stat().st_mode & 0o077:
        raise SystemExit('Invalid backup identity or directory')
    policy = json.loads((CONFIG / 'native-validators.json').read_bytes())
    validators = sorted(policy['allowlist'])
    if len(validators) != 3 or len(set(validators)) != 3:
        raise SystemExit('Invalid validator configuration')
    descriptor, temporary = tempfile.mkstemp(prefix='.ledger-', dir=BACKUP)
    records = []
    try:
        with os.fdopen(descriptor, 'wb') as output:
            with tarfile.open(fileobj=output, mode='w') as archive:
                for index in range(1, 4):
                    path = STATE / f'validator-{index}' / 'native_chain_state.json'
                    # Native persistence atomically replaces this file. The open
                    # descriptor sees one complete version even during finality.
                    with path.open('rb') as stream:
                        content = stream.read(MAX_STATE + 1)
                    if not content or len(content) > MAX_STATE:
                        raise ValueError('Invalid ledger size')
                    state = json.loads(content)
                    if state['schema'] != 'mfenx.powerhouse.native-chain-state.v1' or state['chain_id'] != 2026092601 or state['quorum'] != 2 or sorted(state['validators']) != validators or state['genesis_accounts'] != {} or state['blocks'][0]['proposal']['hash'] != GENESIS:
                        raise ValueError('Unexpected history in backup')
                    tip = state['blocks'][-1]['proposal']
                    name = f'validator-{index}/native_chain_state.json'
                    records.append({'name': name, 'sha256': hashlib.sha256(content).hexdigest(), 'height': tip['number'], 'hash': tip['hash']})
                    add(archive, name, content)
                    del state, content
                stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
                add(archive, 'snapshot.json', json.dumps({'schema': 'mfenx.native-snapshot.v1', 'created_at': stamp, 'ledgers': records}).encode())
                add(archive, 'gateway.json', (CONFIG / 'gateway.json').read_bytes())
            output.flush()
            os.fsync(output.fileno())
        destination = BACKUP / ('ledger-' + stamp + '.tar')
        os.replace(temporary, destination)
        snapshots = sorted(BACKUP.glob('ledger-*.tar'))
        for old in snapshots[:-3]:
            if old.is_symlink() or not old.is_file() or old.parent != BACKUP:
                raise ValueError('Unexpected backup rotation target')
            old.unlink()
        directory = os.open(BACKUP, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        print(json.dumps({'backup': destination.name, 'ledgers': records}))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

if __name__ == '__main__':
    main()
