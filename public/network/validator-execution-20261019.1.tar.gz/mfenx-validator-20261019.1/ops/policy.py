"""Bounded operating policy shared by the native ledger maintenance tools."""
from __future__ import annotations

import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import time

MIB = 1024**2
GIB = 1024**3
CHAIN_ID = 2026092601
GENESIS = "0x3b0b36b6acdcc5f0d7a1e38dd6621c58a9546a0e1a98cb58911b7646a0de5e8e"
STATE_ROOT = Path("/var/lib/mfenx-native")
BACKUP_ROOT = Path("/var/lib/mfenx-native-backups")
STORE_TOOL = Path("/opt/mfenx-native/current/native-store-tool")
LEGACY_NAME = "native_chain_state.json"
DATABASE_NAME = "native_chain_state.sqlite3"
MAX_LEGACY_BYTES = 1572864
MAX_DATABASE_BYTES = 512 * MIB
# NativeStore reserves a second image and framing inside its total budget.
# Keep this integer formula aligned with native_store.rs max_page_count.
MAX_DATABASE_MAIN_BYTES = ((MAX_DATABASE_BYTES - MIB) // 100 * 49) // 4096 * 4096
MAX_WAL_BYTES = 32 * MIB
MAX_SHM_BYTES = MIB
MAX_STATE_BYTES = GIB
MAX_BACKUP_BYTES = 4 * GIB
MIN_FREE_BYTES = 2 * GIB
# Standalone snapshots contain the main image, not reserved WAL/SHM capacity.
MAX_ARCHIVE_BYTES = 3 * MAX_DATABASE_MAIN_BYTES + 8 * MIB
RETAIN_BACKUPS = 3
VALIDATORS = ("validator-1", "validator-2", "validator-3")


def regular_file(path, maximum, private=False):
    metadata = Path(path).lstat()
    if (not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1
            or not 0 < metadata.st_size <= maximum
            or (private and stat.S_IMODE(metadata.st_mode) & 0o077)):
        raise ValueError("Invalid regular file or size")
    return metadata


def run_store(tool, command, database, output=None, timeout=180):
    """Invoke the Rust SQLite implementation without opening a live DB in Python.

    Stdout, runtime and retained diagnostics are bounded. Never log command
    stderr: errors can include paths or untrusted stored values.
    """
    tool = Path(tool)
    if not tool.is_absolute():
        raise ValueError("Store tool must be an absolute path")
    argv = [str(tool), command, "--database", str(database),
            "--max-bytes", str(MAX_DATABASE_BYTES), "--json"]
    if output is not None:
        argv += ["--output", str(output)]
    process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL,
                               env={"PATH": "/usr/bin:/bin", "LC_ALL": "C",
                                    "MFENX_NATIVE_MAX_DATABASE_BYTES": str(MAX_DATABASE_BYTES)})
    data = bytearray()
    deadline = time.monotonic() + timeout
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selector.select(remaining):
                    raise ValueError("Store command timeout")
                chunk = os.read(process.stdout.fileno(), 4096)
                if not chunk:
                    break
                data.extend(chunk)
                if len(data) > 65536:
                    raise ValueError("Store command output limit")
        if process.wait(timeout=max(0.01, deadline - time.monotonic())) != 0:
            raise ValueError("Store command failed")
        result = json.loads(data)
        validate_metadata(result, require_integrity=command != "inspect")
        return result
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        process.stdout.close()


def validate_metadata(value, require_integrity=True):
    if (not isinstance(value, dict) or not isinstance(value.get("schema"), str)
            or value.get("chain_id") != CHAIN_ID or value.get("genesis_hash") != GENESIS
            or value.get("quorum") != 2 or value.get("validator_count") != 3
            or type(value.get("height")) is not int or value["height"] < 0):
        raise ValueError("Unexpected ledger identity or integrity")
    if require_integrity is True:
        if value.get("integrity_ok") is not True or value.get("integrity_checked") is not True:
            raise ValueError("Ledger integrity was not verified")
    elif require_integrity is False and (value.get("head_valid") is not True or value.get("integrity_checked") is not False):
        raise ValueError("Routine inspection must identify its limited validation scope")
    for key in ("block_hash", "state_root"):
        digest = value.get(key)
        if (not isinstance(digest, str) or len(digest) != 66 or not digest.startswith("0x")
                or any(c not in "0123456789abcdef" for c in digest[2:])):
            raise ValueError("Invalid ledger commitment")


def legacy_metadata(content):
    if not 0 < len(content) <= MAX_LEGACY_BYTES:
        raise ValueError("Legacy ledger exceeds its original limit")
    value = json.loads(content)
    validators = value.get("validators", [])
    blocks = value.get("blocks", [])
    if (value.get("schema") != "mfenx.powerhouse.native-chain-state.v1"
            or value.get("chain_id") != CHAIN_ID or value.get("quorum") != 2
            or len(validators) != 3 or len(set(validators)) != 3
            or value.get("genesis_accounts") != {} or not blocks
            or blocks[0]["proposal"]["hash"] != GENESIS):
        raise ValueError("Unexpected legacy ledger identity")
    tip = blocks[-1]["proposal"]
    result = {"schema": "mfenx.native-legacy-observation.v1", "chain_id": CHAIN_ID,
              "genesis_hash": GENESIS, "height": tip["number"], "block_hash": tip["hash"],
              "state_root": tip["state_root"], "quorum": 2, "validator_count": 3,
              "integrity_ok": False, "integrity_checked": False, "head_valid": False,
              "identity_checked": True, "validation": "JSON identity and structure only; no signature or replay verification"}
    validate_metadata(result, require_integrity=None)
    return result


def fsync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def atomic_json(path, value, mode=0o600):
    import tempfile
    descriptor, temporary = tempfile.mkstemp(prefix=".status-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(json.dumps(value, sort_keys=True, allow_nan=False).encode() + b"\n")
            stream.flush()
            os.fchmod(stream.fileno(), mode)
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        fsync_directory(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
