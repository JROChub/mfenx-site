#!/usr/bin/env python3
"""Deterministic progress-monitor regressions; no network access or real sleeps."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import check_live_progress as progress


class Clock:
    def __init__(self):
        self.elapsed = 0.0

    def now(self):
        return 1792386000 + self.elapsed

    def monotonic(self):
        return self.elapsed

    def sleep(self, seconds):
        self.elapsed += seconds


class Network:
    def __init__(self, clock):
        self.clock = clock
        self.stalled = False
        self.race = False
        self.wrong_hash = False
        self.wrong_genesis = False
        self.fake_counter = False
        self.rpc_error = False
        self.stale = False
        self.calls = []

    def height(self, url):
        step = 0 if self.stalled else int(self.clock.elapsed // 12)
        return 100 + step + (1 if self.race and url == progress.RPC_URLS[0] else 0)

    def hash(self, number):
        return progress.GENESIS_HASH if number == 0 else "0x" + format(number, "064x")

    def block(self, number, url):
        h = self.hash(100 if self.fake_counter and number >= 100 else number)
        if self.wrong_hash and url == progress.RPC_URLS[1] and number > 0:
            h = "0x" + "fa" * 32
        if self.wrong_genesis and number == 0:
            h = "0x" + "fb" * 32
        return {"number": hex(number), "hash": h, "parentHash": self.hash(max(0, number - 1)),
                "timestamp": hex(1792386000 - (200 if self.stale else 12) + (number - 100) * 12)}

    def __call__(self, url, payload=None):
        self.calls.append((url, payload))
        identity = {"chain_id": progress.CHAIN_ID, "genesis_hash": progress.GENESIS_HASH,
                    "history_id": progress.HISTORY_ID}
        if url == progress.MANIFEST_URL:
            return {"schema": "mfenx.network-manifest.v1", "identity": identity,
                    "rpc": list(progress.RPC_URLS), "limits": {"empty_block_interval_seconds": 12},
                    "topology": {"quorum": 2, "validator_count": 3},
                    "validators": [{"node_id": f"validator-{n}"} for n in range(1, 4)]}
        if url == progress.STATUS_URL:
            height = self.height(progress.RPC_URLS[1])
            finalized = 1792386000 - (200 if self.stale else 12) + (height - 100) * 12
            return {"schema": "mfenx.network-status.v1", "identity": identity,
                    "empty_block_interval_seconds": 12, "block_height": height,
                    "tip_hash": self.hash(height), "quorum_agreement": True,
                    "generated_at": progress.utc(self.clock.now()), "sampled_at": progress.utc(self.clock.now()),
                    "last_finalized_at": progress.utc(finalized),
                    "validators": [{"node_id": f"validator-{n}", "healthy": True,
                                    "height": height, "tip_hash": self.hash(height),
                                    "genesis_hash": progress.GENESIS_HASH} for n in range(1, 4)]}
        method = payload["method"]
        if self.rpc_error and method == "eth_blockNumber":
            return {"jsonrpc": "2.0", "id": 1, "error": {"code": -32000, "message": "unavailable"}}
        if method == "eth_chainId":
            value = hex(progress.CHAIN_ID)
        elif method == "eth_blockNumber":
            value = hex(self.height(url))
        elif method == "eth_getBlockByNumber":
            value = self.block(int(payload["params"][0], 16), url)
        else:
            raise AssertionError("Unexpected method: " + method)
        return {"jsonrpc": "2.0", "id": 1, "result": value}


class ProgressTests(unittest.TestCase):
    def run_case(self, **changes):
        clock = Clock()
        network = Network(clock)
        for key, value in changes.items():
            setattr(network, key, value)
        report = progress.run_monitor(network, clock=clock.now, monotonic=clock.monotonic, sleep=clock.sleep)
        return report, network

    def test_healthy_advance_is_real_and_read_only(self):
        report, network = self.run_case()
        self.assertTrue(report["ok"], report)
        self.assertEqual(len(report["samples"]), 4)
        self.assertEqual(set(report["height_advances"].values()), {3})
        self.assertTrue(all(sample["status_tip_endpoints_checked"] == 2 for sample in report["samples"]))
        self.assertEqual({payload["method"] for _, payload in network.calls if payload},
                         {"eth_chainId", "eth_blockNumber", "eth_getBlockByNumber"})

    def test_different_latest_heights_compare_the_same_height(self):
        report, _ = self.run_case(race=True)
        self.assertTrue(report["ok"], report)
        for sample in report["samples"]:
            self.assertEqual(sample["rpc"][progress.RPC_URLS[0]]["height"], sample["common_height"] + 1)

    def test_stalled_height_fails(self):
        report, _ = self.run_case(stalled=True)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "stalled_height")

    def test_status_ahead_of_rpc_is_checked_when_that_height_becomes_available(self):
        clock = Clock()
        network = Network(clock)

        def fetch(url, payload=None):
            value = network(url, payload)
            if url == progress.STATUS_URL:
                value["block_height"] += 1
                value["tip_hash"] = network.hash(value["block_height"])
                value["last_finalized_at"] = progress.utc(clock.now())
                for validator in value["validators"]:
                    validator["height"] = value["block_height"]
                    validator["tip_hash"] = value["tip_hash"]
            return value

        report = progress.run_monitor(fetch, clock=clock.now, monotonic=clock.monotonic, sleep=clock.sleep)
        self.assertTrue(report["ok"], report)
        self.assertEqual(report["samples"][0]["status_tip_endpoints_checked"], 2)
        self.assertEqual(report["samples"][-1]["status_tip_endpoints_checked"], 0)

    def test_advancing_counter_without_new_blocks_fails(self):
        report, _ = self.run_case(fake_counter=True)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "counter_without_block")

    def test_same_height_fork_fails(self):
        report, _ = self.run_case(wrong_hash=True)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "endpoint_fork")

    def test_genesis_mismatch_fails(self):
        report, _ = self.run_case(wrong_genesis=True)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "identity_mismatch")

    def test_rpc_error_is_not_a_stalled_or_successful_result(self):
        report, _ = self.run_case(rpc_error=True)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "rpc_method_error")

    def test_old_finalized_timestamp_fails(self):
        report, _ = self.run_case(stale=True)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "stale_timestamp")

    def test_strict_rpc_envelope_and_quantities(self):
        for value in (None, {}, {"jsonrpc": "2.0", "id": True, "result": "0x1"},
                      {"jsonrpc": "2.0", "id": 2, "result": "0x1"}):
            with self.subTest(value=value), self.assertRaises(progress.CheckError):
                progress.rpc(lambda *_: value, progress.RPC_URLS[0], "eth_blockNumber", [])
        for value in (True, 12, "12", "0x01", "0x10000000000000000"):
            with self.subTest(value=value), self.assertRaises(progress.CheckError):
                progress.quantity(value, "height")

    def test_json_bounds_duplicates_and_nonfinite_values(self):
        for raw in (b" " * (progress.MAX_BODY + 1), b'{"x":1,"x":2}', b'{"x":NaN}',
                    b'{"x":1e999}', b"[" * 34 + b"0" + b"]" * 34):
            with self.subTest(raw=raw[:40]), self.assertRaises(progress.CheckError):
                progress.decode(raw)

    def test_configuration_is_bounded_before_network_calls(self):
        for duration, interval in ((0, 12), (36, 0), (3601, 12), (3600, 1), (float("nan"), 12)):
            with self.subTest(duration=duration, interval=interval):
                report = progress.run_monitor(lambda *_: self.fail("Unexpected request"),
                                              duration=duration, interval=interval)
                self.assertFalse(report["ok"])
                self.assertEqual(report["errors"][0]["code"], "invalid_configuration")
                json.dumps(report, allow_nan=False)

    def test_one_stalled_endpoint_cannot_be_hidden_by_the_other(self):
        clock = Clock()
        network = Network(clock)

        def fetch(url, payload=None):
            if url == progress.RPC_URLS[1] and payload and payload["method"] == "eth_blockNumber":
                return {"jsonrpc": "2.0", "id": 1, "result": "0x64"}
            return network(url, payload)

        report = progress.run_monitor(fetch, clock=clock.now, monotonic=clock.monotonic, sleep=clock.sleep)
        self.assertFalse(report["ok"])
        self.assertEqual(report["errors"][0]["code"], "stalled_height")
        self.assertEqual(report["height_advances"][progress.RPC_URLS[0]], 3)
        self.assertEqual(report["height_advances"][progress.RPC_URLS[1]], 0)

    def test_status_mismatch_and_unmatched_quorum_fail(self):
        for failure, expected in (("status_hash", "status_tip_mismatch"), ("quorum", "status_quorum"),
                                  ("chain", "identity_mismatch")):
            with self.subTest(failure=failure):
                clock = Clock()
                network = Network(clock)

                def fetch(url, payload=None):
                    value = network(url, payload)
                    if url == progress.STATUS_URL:
                        if failure == "status_hash":
                            value["tip_hash"] = "0x" + "fc" * 32
                            for validator in value["validators"]:
                                validator["tip_hash"] = value["tip_hash"]
                        elif failure == "quorum":
                            value["validators"][0]["healthy"] = False
                            value["validators"][1]["healthy"] = False
                    if failure == "chain" and payload and payload["method"] == "eth_chainId":
                        value["result"] = "0x1"
                    return value

                report = progress.run_monitor(fetch, clock=clock.now, monotonic=clock.monotonic, sleep=clock.sleep)
                self.assertFalse(report["ok"])
                self.assertEqual(report["errors"][0]["code"], expected)

    def test_fetcher_paces_requests_and_rejects_oversized_responses(self):
        clock = Clock()

        class Response:
            def __init__(self, data, advertised=None):
                self.data = data
                self.headers = {} if advertised is None else {"Content-Length": advertised}

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read1(self, count):
                result, self.data = self.data[:count], self.data[count:]
                return result

        fetcher = progress.Fetcher()
        with patch.object(progress.time, "monotonic", clock.monotonic), patch.object(progress.time, "sleep", clock.sleep):
            with patch.object(fetcher.opener, "open", side_effect=[Response(b"{}"), Response(b"{}")]):
                fetcher(progress.MANIFEST_URL)
                fetcher(progress.STATUS_URL)
                self.assertGreaterEqual(clock.elapsed, 0.35)
            for response in (Response(b"", str(progress.MAX_BODY + 1)),
                             Response(b" " * (progress.MAX_BODY + 1))):
                with patch.object(fetcher.opener, "open", return_value=response), self.assertRaises(progress.CheckError) as error:
                    fetcher(progress.STATUS_URL)
                self.assertEqual(error.exception.code, "response_too_large")
            response = Response(b"{}")

            def late_eof(_count):
                clock.sleep(fetcher.timeout + 1)
                return b""

            with patch.object(fetcher.opener, "open", return_value=response), \
                    patch.object(response, "read1", side_effect=late_eof), \
                    self.assertRaises(progress.CheckError) as error:
                fetcher(progress.STATUS_URL)
            self.assertEqual(error.exception.code, "request_timeout")

    def test_cli_saves_failure_evidence_and_exits_nonzero(self):
        clock = Clock()
        network = Network(clock)
        network.stalled = True
        failed = progress.run_monitor(network, clock=clock.now, monotonic=clock.monotonic, sleep=clock.sleep)
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "evidence.json"
            with patch.object(progress, "run_monitor", return_value=copy.deepcopy(failed)), patch("builtins.print"):
                self.assertEqual(progress.main(["--output", str(output)]), 1)
            self.assertEqual(json.loads(output.read_bytes()), failed)
            self.assertEqual(list(Path(directory).iterdir()), [output])


if __name__ == "__main__":
    unittest.main()
