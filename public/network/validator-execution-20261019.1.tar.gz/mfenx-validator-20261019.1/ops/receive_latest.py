#!/usr/bin/env python3
"""Receive the archive named by the remote backup receipt using existing SSH.

The remote reads are limited to latest.json and the validated archive name.
This command installs no timer and does not inspect authentication material.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import selectors
import shlex
import shutil
import stat
import subprocess
import tarfile
import tempfile
import time

import backup
import policy
import receive
import recovery


def fetch_receipt(host, timeout=30, identity_file=None):
    command = "sudo -n /usr/bin/cat -- " + shlex.quote(str(policy.BACKUP_ROOT / "latest.json"))
    process = subprocess.Popen(receive.ssh_argv(host, command, identity_file),
                               stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    data = bytearray()
    deadline = time.monotonic() + timeout
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selector.select(remaining):
                    raise ValueError("SSH receipt read timed out")
                chunk = os.read(process.stdout.fileno(), min(4096, backup.MAX_RECEIPT_BYTES + 1 - len(data)))
                if not chunk:
                    break
                data.extend(chunk)
                if len(data) > backup.MAX_RECEIPT_BYTES:
                    raise ValueError("Remote receipt exceeds size limit")
        if process.wait(timeout=max(0.01, deadline - time.monotonic())) != 0:
            raise ValueError("Remote receipt read failed")
        return backup.decode_receipt(data)
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        process.stdout.close()


def prepare_destination(destination):
    destination = destination.absolute()
    if ".." in destination.parts or destination == Path("/"):
        raise ValueError("Invalid local destination")
    for path in (*reversed(destination.parents), destination):
        try:
            metadata = path.lstat()
        except FileNotFoundError:
            continue
        if not stat.S_ISDIR(metadata.st_mode):
            raise ValueError("Local destination has a symlink or non-directory ancestor")
    destination.mkdir(mode=0o700, parents=True, exist_ok=True)
    metadata = destination.lstat()
    if metadata.st_uid != os.geteuid() or stat.S_IMODE(metadata.st_mode) & 0o077:
        raise ValueError("Destination must be a private owned directory")
    return destination


def retained_archives(destination):
    archives, total = [], 0
    with os.scandir(destination) as entries:
        for count, entry in enumerate(entries, 1):
            if count > 1024:
                raise ValueError("Local destination entry limit")
            if not entry.name.startswith("ledger-"):
                continue
            if re.fullmatch(backup.ARCHIVE_PATTERN, entry.name) is None:
                raise ValueError("Invalid retained archive name")
            path = destination / entry.name
            metadata = policy.regular_file(path, policy.MAX_ARCHIVE_BYTES, private=True)
            if metadata.st_uid != os.geteuid():
                raise ValueError("Retained archive has unexpected ownership")
            total += metadata.st_size
            if total > policy.MAX_BACKUP_BYTES:
                raise ValueError("Local archive budget exceeded")
            archives.append(path)
    return sorted(archives), total


def verify_archive(archive, source, tool, destination):
    if source["storage_mode"] != "sqlite":
        raise ValueError("Full receiver replay requires a SQLite snapshot")
    if shutil.disk_usage(destination.parent).free < policy.MAX_ARCHIVE_BYTES + policy.GIB:
        raise ValueError("Insufficient local replay workspace and reserve")
    # TemporaryDirectory creates a new private sibling. Recovery only creates
    # children beneath it; cleanup cannot select a preexisting user directory.
    with tempfile.TemporaryDirectory(prefix=".mfenx-replay-", dir=destination.parent) as temporary:
        restored = recovery.prepare_restore(archive, Path(temporary) / "restore", tool,
                                            expected_sha256=source["sha256"])
        if restored.get("activated") is not False or restored.get("storage_mode") != "sqlite":
            raise ValueError("Unexpected replay verification result")
        records = restored.get("ledgers", [])
        expected = {f"{node}/{policy.DATABASE_NAME}" for node in policy.VALIDATORS}
        if len(records) != 3 or {record["name"] for record in records} != expected:
            raise ValueError("Incomplete replay verification")
        verified = {}
        for record in records:
            node = record["name"].split("/", 1)[0]
            metadata = record["ledger"]
            policy.validate_metadata(metadata, require_integrity=True)
            for key in ("chain_id", "genesis_hash", "height", "block_hash", "state_root", "quorum", "validator_count"):
                if metadata[key] != source["validators"][node][key]:
                    raise ValueError("Replayed commitments differ from backup receipt")
            verified[node] = metadata
        return verified


def refresh_observation(result, source):
    checked = time.time()
    age = max(0, checked - source["completed_at_unix"])
    result.update(checked_at_unix=checked, source_backup_age_seconds=age,
                  warning="source_backup_stale" if age > backup.BACKUP_STALE_SECONDS else None)


def receive_latest(host, destination, timeout=21600, identity_file=None, store_tool=None):
    if store_tool is not None:
        store_tool = Path(store_tool)
        if not store_tool.is_absolute():
            raise ValueError("Store tool must be an absolute path")
    source = fetch_receipt(host, identity_file=identity_file)
    # Revalidate at the orchestration boundary, including substituted readers.
    backup.validate_receipt(source)
    now = time.time()
    if source["completed_at_unix"] > now + 60:
        raise ValueError("Remote receipt completion time is in the future")
    destination = prepare_destination(destination)
    descriptor = os.open(destination / ".receive.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        metadata = os.fstat(descriptor)
        if (not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1
                or metadata.st_uid != os.geteuid() or stat.S_IMODE(metadata.st_mode) & 0o077):
            raise ValueError("Unsafe local receiver lock")
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        archives, used = retained_archives(destination)
        archive = source["archive"]
        if archives and archive < archives[-1].name:
            raise ValueError("Remote backup receipt is older than the latest retained archive")
        final = destination / archive
        if final.exists() or final.is_symlink():
            metadata = policy.regular_file(final, policy.MAX_ARCHIVE_BYTES, private=True)
            if metadata.st_size != source["bytes"] or backup.digest(final, source["bytes"]) != source["sha256"]:
                raise ValueError("Existing archive differs from remote receipt")
            result = {"archive": archive, "bytes": metadata.st_size, "sha256": source["sha256"],
                      "received_at_unix": None, "already_present": True, "replay_verified": False}
            previous = destination / "latest-receipt.json"
            if previous.exists():
                policy.regular_file(previous, 65536, private=True)
                value = json.loads(previous.read_bytes())
                if (isinstance(value, dict) and value.get("archive") == archive
                        and value.get("sha256") == source["sha256"]):
                    result["received_at_unix"] = value.get("received_at_unix")
        else:
            if used + source["bytes"] > policy.MAX_BACKUP_BYTES:
                raise ValueError("Insufficient bounded local archive workspace")
            result = receive.receive(host, archive, source["sha256"], destination, timeout=timeout,
                                     identity_file=identity_file, defer_completion=True)
            result["already_present"] = False
            if result["bytes"] != source["bytes"]:
                raise ValueError("Transferred archive size differs from remote receipt")
        result["source_backup"] = source
        refresh_observation(result, source)
        if store_tool is not None:
            # Do not leave a previous success claim visible if a fresh replay
            # fails, even when this archive was already retained locally.
            result.update(replay_verified=False, replay_verified_at_unix=None,
                          replay_attempted_at_unix=time.time())
            policy.atomic_json(destination / "latest-receipt.json", result)
            try:
                verified = verify_archive(final, source, store_tool, destination)
            except (OSError, ValueError, KeyError, TypeError, RecursionError, tarfile.TarError, subprocess.SubprocessError):
                result["replay_error"] = "ledger_replay_failed"
                result["archive_retained"] = result["already_present"]
                refresh_observation(result, source)
                try:
                    policy.atomic_json(destination / "latest-receipt.json", result)
                finally:
                    if not result["already_present"]:
                        # Only this invocation's newly published archive is
                        # removed; known-good retained archives are untouched.
                        final.unlink()
                        policy.fsync_directory(destination)
                raise
            result.update(replay_verified=True, replay_verified_at_unix=time.time(),
                          verified_validators=verified)
            refresh_observation(result, source)
        # A failed atomic receipt update leaves the previous receipt intact;
        # an already verified archive can be recognized on the next invocation.
        policy.atomic_json(destination / "latest-receipt.json", result)
        archives, _ = retained_archives(destination)
        for old in archives[:-policy.RETAIN_BACKUPS]:
            old.unlink()
        policy.fsync_directory(destination)
        return result
    finally:
        os.close(descriptor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=21600)
    parser.add_argument("--identity-file", type=Path)
    parser.add_argument("--store-tool", type=Path)
    args = parser.parse_args()
    try:
        if not 1 <= args.timeout <= 21600:
            raise ValueError("Invalid archive transfer timeout")
        print(json.dumps(receive_latest(args.host, args.destination, args.timeout,
                                        identity_file=args.identity_file, store_tool=args.store_tool),
                         sort_keys=True, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError, OverflowError, RecursionError, tarfile.TarError, subprocess.SubprocessError):
        print('{"ok":false,"reason":"latest_archive_receive_failed"}')
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
