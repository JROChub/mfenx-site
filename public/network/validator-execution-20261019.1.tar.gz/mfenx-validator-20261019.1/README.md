MFENX validator runtime, release 20261019.1

This source distribution corresponds to the MFENX native validator and its
SQLite maintenance CLI. The Cargo package is `mfenx-validator` 0.1.0, with
`publish = false`; the library retains the `power_house` name. Runtime releases
are identified by the dated release number, source-archive digest and executable
digests. They are separate from the published Power House crate releases.

The basis is the published `validator-execution-20261008.3.tar.gz` archive
(SHA-256 `5da858924e47e1d376d6729f1b6e4d9fc659bd308039f45566e7547d26034db6`).
Its [Power House README](ops/legacy/power-house-README-0.4.0.md) is retained
unchanged as historical documentation. The imported archive omitted conformance
fixtures referenced by its tests; their restored, unmodified release provenance
is recorded in [conformance-fixture-source.json](ops/conformance-fixture-source.json).

State and execution

SQLite transactions bind finalized blocks, execution-state checkpoints, the
current head, pending proposals and durable vote locks. The resident block cache
is bounded; older blocks remain addressable in the database. Historical execution
starts from a verified checkpoint and rejects work beyond its replay bound.
Database failures are reported as errors rather than unknown blocks. Startup
validates the retained head and signer state; complete integrity and execution
replay are explicit maintenance operations.

Migration preserves chain ID `2026092601`, genesis
`0x3b0b36b6acdcc5f0d7a1e38dd6621c58a9546a0e1a98cb58911b7646a0de5e8e`,
validator identities, finalized commitments and signer locks. The execution
profile remains `mfenx-evm-cancun-fee-free-v1`, using REVM 43.0.3 from activation
height 14. The storage migration does not change these execution rules.

Build and verification

The selected production feature graph is the default `memory` feature plus
`net`. The recorded build uses Rust 1.93.1 and bundled SQLite 3.53.2:

```sh
CARGO_BUILD_JOBS=1 cargo build --release --locked --features net --bins
CARGO_BUILD_JOBS=1 cargo test --release --locked --features net --lib --bins --tests --no-fail-fast
python3 -B -m unittest discover -s ops -p 'test_*.py' -v
```

The operational integration test additionally requires captured legacy ledgers
and the built CLI. [The operating procedure](ops/README.md) specifies those
inputs, constrained cluster tests, offline migration, consistent backup, replay
verification and activation. The dependency assessment records both selected and
optional feature scopes in [dependency-audit.json](ops/dependency-audit.json);
optional proof backends are not covered by the production test command above.

Operating limits

The configured empty-block interval is twelve seconds. Three validator processes
and one gateway share a single host and a 96 MiB, 20% CPU, 64-task boundary.
Finalization requires two of the three validator identities. A missing scheduled
leader can stall progress until it returns; this release adds no leader-change
protocol or independent host failure tolerance.

The selected allocation is 512 MiB per validator, including journal headroom;
the SQLite main-file ceiling is 262,549,504 bytes. History is not pruned when the
ceiling is reached: admission closes. [The capacity record](ops/capacity-report.json)
separates measured sizes from illustrative growth projections and accounts for
backup workspace and the disk reserve. Retention is finite, and transaction
traffic can consume it substantially faster than empty-block production.

Backups contain sequential consistent snapshots with individual commitments;
they contain no signing keys. Recovery prepares and verifies a new directory
without activating a signer. Once SQLite has recorded a proposal, vote or new
finalized block, the retained JSON must not be used to restart an older signer.

License: [AGPL-3.0-only](LICENSE).
