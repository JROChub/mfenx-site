#![cfg(feature = "net")]
#![allow(missing_docs)]

//! Quorum-finalized native transfers exposed through the wallet RPC adapter.

use crate::net::evm::{self, BlockContext, EvmAccount, EvmBlockExecution, EvmChainState};

use crate::net::{
    decode_public_key_base64, encode_public_key_base64, encode_signature_base64,
    verify_signature_base64, StakeRegistry,
};
use base64::{engine::general_purpose::STANDARD as BASE64, Engine as _};
use blake2::digest::{consts::U32, Digest as BlakeDigest};
use ed25519_dalek::{Signer, SigningKey};
use k256::ecdsa::{RecoveryId, Signature, VerifyingKey};
use rlp::{Rlp, RlpStream};
use serde::{Deserialize, Serialize};
use sha3::Keccak256;
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::{Read, Write},
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc,
    },
    time::{SystemTime, UNIX_EPOCH},
};
use tokio::sync::{oneshot, RwLock};

type Blake2b256 = blake2::Blake2b<U32>;

pub const NATIVE_CHAIN_TOPIC: &str = "mfenx/powerhouse/native-chain/v1";
pub const NATIVE_DECIMAL_FACTOR: u128 = 1_000_000_000_000_000_000;
pub const NATIVE_GAS_LIMIT: u64 = 21_000;
pub const NATIVE_GAS_PRICE: u64 = 0;
const STATE_SCHEMA: &str = "mfenx.powerhouse.native-chain-state.v1";
const MESSAGE_SCHEMA: &str = "mfenx.powerhouse.native-chain-message.v1";
const MAX_BLOCK_TRANSACTIONS: usize = 256;
const MAX_FUTURE_SECONDS: u64 = 30;
const EMPTY_BLOCK_MIN_SECONDS: u64 = 12;
static BROADCAST_SEQUENCE: AtomicU64 = AtomicU64::new(0);

#[derive(Debug, Clone)]
struct ResourceLimits {
    empty_block_seconds: u64,
    pending_transactions: Option<usize>,
    orphan_blocks: Option<usize>,
    state_bytes: Option<usize>,
}

impl ResourceLimits {
    fn from_env() -> Result<Self, String> {
        Ok(Self {
            empty_block_seconds: read_positive_limit("MFENX_NATIVE_EMPTY_BLOCK_SECONDS")?
                .map(|value| value as u64)
                .unwrap_or(EMPTY_BLOCK_MIN_SECONDS),
            pending_transactions: read_positive_limit("MFENX_NATIVE_MAX_PENDING")?,
            orphan_blocks: read_positive_limit("MFENX_NATIVE_MAX_ORPHAN_BLOCKS")?,
            state_bytes: read_positive_limit("MFENX_NATIVE_MAX_STATE_BYTES")?,
        })
    }
}

fn read_positive_limit(name: &str) -> Result<Option<usize>, String> {
    match std::env::var(name) {
        Ok(value) => value
            .parse::<usize>()
            .ok()
            .filter(|value| *value > 0)
            .map(Some)
            .ok_or_else(|| format!("{name} must be a positive integer")),
        Err(std::env::VarError::NotPresent) => Ok(None),
        Err(_) => Err(format!("{name} must contain a valid integer")),
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NativeTransaction {
    pub hash: String,
    pub raw: String,
    pub from: String,
    pub to: String,
    pub nonce: u64,
    pub value_wei: String,
    pub value_units: u64,
    pub gas_limit: u64,
    pub max_fee_per_gas: String,
    pub max_priority_fee_per_gas: String,
    pub input: String,
    pub y_parity: u8,
    pub r: String,
    pub s: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct NativeAccount {
    pub balance: u64,
    pub nonce: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NativeBlockProposal {
    pub chain_id: u64,
    pub number: u64,
    pub parent_hash: String,
    pub timestamp: u64,
    pub proposer: String,
    pub transactions: Vec<NativeTransaction>,
    pub state_root: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub evm: Option<EvmBlockExecution>,
    pub hash: String,
    pub signature: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NativeBlockVote {
    pub block_hash: String,
    pub block_number: u64,
    pub validator: String,
    pub signature: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct FinalizedNativeBlock {
    pub proposal: NativeBlockProposal,
    pub votes: Vec<NativeBlockVote>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeChainTip {
    pub height: u64,
    pub hash: String,
    pub observed_at: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeChainSyncRequest {
    pub from_height: u64,
    pub request_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeChainSyncResponse {
    pub request_id: String,
    pub block: FinalizedNativeBlock,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeChainState {
    pub schema: String,
    pub chain_id: u64,
    pub validators: Vec<String>,
    pub quorum: usize,
    pub genesis_accounts: BTreeMap<String, NativeAccount>,
    pub accounts: BTreeMap<String, NativeAccount>,
    /// Post-activation authoritative balances, nonces, bytecode and storage.
    /// Legacy accounts remain the exact native state at the transition.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub evm: Option<EvmChainState>,
    pub blocks: Vec<FinalizedNativeBlock>,
    #[serde(default)]
    pub votes_cast: BTreeMap<u64, String>,
    /// The exact next-height proposal, retained before publishing or voting.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pending_proposal: Option<NativeBlockProposal>,
    /// Process-local admission health; never part of persisted consensus state.
    #[serde(skip)]
    pub admission: NativeAdmissionStatus,
}

#[derive(Debug, Clone, Default)]
pub struct NativeAdmissionStatus {
    pub blocked_reason: Option<String>,
    pub max_state_bytes: Option<usize>,
    pub validator_public_key: String,
}

pub type SharedNativeChainState = Arc<RwLock<NativeChainState>>;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", content = "payload", rename_all = "snake_case")]
pub enum NativeChainMessagePayload {
    Transaction(NativeTransaction),
    Proposal(NativeBlockProposal),
    Vote(NativeBlockVote),
    Finalized(FinalizedNativeBlock),
    Tip(NativeChainTip),
    SyncRequest(NativeChainSyncRequest),
    SyncResponse(NativeChainSyncResponse),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeChainMessage {
    pub schema: String,
    pub payload: NativeChainMessagePayload,
    /// Transport identity only: excluded from block hashes and vote signatures.
    /// A retry must not be suppressed by gossipsub's payload-based deduplication.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub broadcast_id: Option<String>,
}

impl NativeChainMessage {
    pub fn new(payload: NativeChainMessagePayload) -> Self {
        Self {
            schema: MESSAGE_SCHEMA.to_string(),
            payload,
            broadcast_id: Some(format!(
                "{}-{}",
                now_nanos(),
                BROADCAST_SEQUENCE.fetch_add(1, Ordering::Relaxed)
            )),
        }
    }

    pub fn validate_schema(&self) -> Result<(), String> {
        if self.schema != MESSAGE_SCHEMA {
            return Err(format!("unsupported native-chain schema: {}", self.schema));
        }
        if self.broadcast_id.as_ref().is_some_and(|id| id.len() > 96) {
            return Err("native-chain broadcast ID is too long".to_string());
        }
        Ok(())
    }
}

#[derive(Debug)]
pub struct NativeChainCommand {
    pub transaction: NativeTransaction,
    pub response: oneshot::Sender<Result<String, String>>,
}

pub struct NativeChainRuntime {
    pub state: SharedNativeChainState,
    state_path: PathBuf,
    validators: Vec<String>,
    quorum: usize,
    local_validator: String,
    pending: BTreeMap<String, NativeTransaction>,
    proposals: BTreeMap<String, NativeBlockProposal>,
    votes: BTreeMap<String, BTreeMap<String, NativeBlockVote>>,
    orphan_votes: BTreeMap<String, BTreeMap<String, NativeBlockVote>>,
    voted_heights: BTreeMap<u64, String>,
    limits: ResourceLimits,
    persistence_error: Option<String>,
}

impl NativeChainRuntime {
    pub async fn new(
        state: SharedNativeChainState,
        state_path: PathBuf,
        mut validators: Vec<String>,
        quorum: usize,
        signing: &SigningKey,
    ) -> Result<Self, String> {
        let limits = ResourceLimits::from_env()?;
        validators.sort();
        validators.dedup();
        if validators.is_empty() {
            return Err("native chain requires at least one validator".to_string());
        }
        if quorum == 0 || quorum > validators.len() {
            return Err(format!(
                "native chain quorum {quorum} is invalid for {} validators",
                validators.len()
            ));
        }
        if quorum.saturating_mul(2) <= validators.len() {
            return Err(format!(
                "native chain quorum {quorum} must be a strict majority of {} validators",
                validators.len()
            ));
        }
        let (voted_heights, proposals) = {
            let current = state.read().await;
            current.validate()?;
            if current.validators != validators || current.quorum != quorum {
                return Err(
                    "native chain validator configuration does not match persisted genesis"
                        .to_string(),
                );
            }
            let proposals = current
                .pending_proposal
                .iter()
                .map(|proposal| (proposal.hash.clone(), proposal.clone()))
                .collect();
            (current.votes_cast.clone(), proposals)
        };
        {
            let mut current = state.write().await;
            current.admission.max_state_bytes = limits.state_bytes;
            current.admission.validator_public_key =
                encode_public_key_base64(&signing.verifying_key());
            if limits.state_bytes.is_some() {
                write_admission_status(&state_path, "open", None, &current)?;
            }
        }
        Ok(Self {
            state,
            state_path,
            validators,
            quorum,
            local_validator: encode_public_key_base64(&signing.verifying_key()),
            pending: BTreeMap::new(),
            proposals,
            votes: BTreeMap::new(),
            orphan_votes: BTreeMap::new(),
            voted_heights,
            limits,
            persistence_error: None,
        })
    }

    pub async fn accept_transaction(&mut self, tx: NativeTransaction) -> Result<bool, String> {
        self.require_writable()?;
        if self.pending.contains_key(&tx.hash) {
            return Ok(false);
        }
        let state = self.state.read().await;
        if state.transaction(&tx.hash).is_some() {
            return Ok(false);
        }
        if self
            .limits
            .pending_transactions
            .is_some_and(|limit| self.pending.len() >= limit)
        {
            return Err(
                "native transaction admission capacity reached; retry after finality".into(),
            );
        }
        if state.evm_active(state.latest_number().saturating_add(1)) {
            let mut working = state.evm.clone().expect("active EVM state");
            let context = state.execution_context(
                state.latest_number().saturating_add(1),
                now_secs().max(state.latest_timestamp().saturating_add(1)),
            );
            let mut gas = 0u64;
            let mut bytes = 0usize;
            let mut pending = self.pending.values().collect::<Vec<_>>();
            pending.sort_by(|a, b| (&a.from, a.nonce, &a.hash).cmp(&(&b.from, b.nonce, &b.hash)));
            for pending in pending {
                if pending.gas_limit > evm::BLOCK_GAS_LIMIT - gas {
                    continue;
                }
                if let Ok((next, receipt)) = working.execute(&context, pending) {
                    let size = evm_payload_bytes(pending, &receipt)?;
                    if size > evm::MAX_BLOCK_PAYLOAD_BYTES - bytes {
                        continue;
                    }
                    bytes += size;
                    gas += receipt.gas_used;
                    working = next;
                }
            }
            if tx.gas_limit > evm::BLOCK_GAS_LIMIT - gas {
                return Err("pending block gas capacity reached; retry after finality".into());
            }
            let (_, receipt) = working.execute(&context, &tx)?;
            if evm_payload_bytes(&tx, &receipt)? > evm::MAX_BLOCK_PAYLOAD_BYTES - bytes {
                return Err("pending block byte capacity reached; retry after finality".into());
            }
            drop(state);
            self.pending.insert(tx.hash.clone(), tx);
            return Ok(true);
        }
        validate_transaction(&state, &tx)?;
        let mut expected = state.account(&tx.from).nonce;
        let pending_nonces = self
            .pending
            .values()
            .filter(|item| item.from == tx.from)
            .map(|item| item.nonce)
            .collect::<BTreeSet<_>>();
        while pending_nonces.contains(&expected) {
            expected = expected.saturating_add(1);
        }
        if tx.nonce != expected {
            return Err(format!(
                "nonce mismatch: expected {expected}, received {}",
                tx.nonce
            ));
        }
        drop(state);
        self.pending.insert(tx.hash.clone(), tx);
        Ok(true)
    }

    pub async fn propose(
        &mut self,
        signing: &SigningKey,
    ) -> Result<Option<NativeBlockProposal>, String> {
        self.require_writable()?;
        let state = self.state.read().await;
        let number = state.latest_number().saturating_add(1);
        if expected_leader(&self.validators, number) != self.local_validator {
            return Ok(None);
        }
        // Retry the durable proposal even when its transactions were lost from
        // the process-local mempool or the heartbeat interval has not elapsed.
        if let Some(existing) = state.pending_proposal.as_ref() {
            return Ok(Some(existing.clone()));
        }
        if state.votes_cast.contains_key(&number) {
            return Err("locked proposal is unavailable; refusing to sign a replacement".into());
        }
        let now = now_secs();
        let empty_heartbeat = self.pending.is_empty();
        if empty_heartbeat
            && state
                .latest_timestamp()
                .saturating_add(self.limits.empty_block_seconds)
                > now
        {
            return Ok(None);
        }
        let mut transactions = Vec::new();
        let mut working = state.accounts.clone();
        let timestamp = now.max(state.latest_timestamp().saturating_add(1));
        let context = state.execution_context(number, timestamp);
        let mut contracts = state.evm.clone();
        let mut execution = state.evm_active(number).then(|| EvmBlockExecution {
            profile: evm::PROFILE.into(),
            activation_height: contracts.as_ref().unwrap().activation_height,
            gas_used: 0,
            receipts: Vec::new(),
        });
        let mut execution_bytes = 0usize;
        let mut pending = self.pending.values().collect::<Vec<_>>();
        pending.sort_by(|a, b| (&a.from, a.nonce, &a.hash).cmp(&(&b.from, b.nonce, &b.hash)));
        for tx in pending {
            if transactions.len() >= MAX_BLOCK_TRANSACTIONS {
                break;
            }
            if let Some(execution) = &mut execution {
                if tx.gas_limit > evm::BLOCK_GAS_LIMIT - execution.gas_used {
                    continue;
                }
                if let Ok((next, receipt)) = contracts.as_ref().unwrap().execute(&context, tx) {
                    let size = evm_payload_bytes(tx, &receipt)?;
                    if size > evm::MAX_BLOCK_PAYLOAD_BYTES - execution_bytes {
                        continue;
                    }
                    execution_bytes += size;
                    execution.gas_used += receipt.gas_used;
                    execution.receipts.push(receipt);
                    contracts = Some(next);
                    transactions.push(tx.clone());
                }
            } else if apply_transaction_to_accounts(state.chain_id, &mut working, tx).is_ok() {
                transactions.push(tx.clone());
            }
        }
        if !empty_heartbeat && transactions.is_empty() {
            return Ok(None);
        }
        let state_root = if execution.is_some() {
            contracts.as_ref().unwrap().root()
        } else {
            accounts_root(&working)
        };
        let mut proposal = NativeBlockProposal {
            chain_id: state.chain_id,
            number,
            parent_hash: state.latest_hash().to_string(),
            timestamp,
            proposer: self.local_validator.clone(),
            transactions,
            state_root,
            evm: execution,
            hash: String::new(),
            signature: String::new(),
        };
        proposal.hash = block_hash(&proposal);
        proposal.signature = sign_block_hash(signing, &proposal.hash);
        let mut next = state.clone();
        next.pending_proposal = Some(proposal.clone());
        drop(state);
        {
            let mut state = self.state.write().await;
            if let Err(error) =
                save_state_atomic_limited(&self.state_path, &next, self.limits.state_bytes)
            {
                self.persistence_error = Some(error.clone());
                state.admission.blocked_reason = Some(error.clone());
                let _ = write_admission_status(&self.state_path, "blocked", Some(&error), &state);
                return Err(error);
            }
            *state = next;
        }
        self.proposals
            .insert(proposal.hash.clone(), proposal.clone());
        Ok(Some(proposal))
    }

    pub async fn handle_message(
        &mut self,
        message: NativeChainMessage,
        signing: &SigningKey,
    ) -> Result<Vec<NativeChainMessage>, String> {
        message.validate_schema()?;
        match message.payload {
            NativeChainMessagePayload::Transaction(tx) => {
                self.accept_transaction(tx).await?;
                Ok(Vec::new())
            }
            NativeChainMessagePayload::Proposal(proposal) => {
                self.handle_proposal(proposal, signing).await
            }
            NativeChainMessagePayload::Vote(vote) => self.handle_vote(vote).await,
            NativeChainMessagePayload::Finalized(block) => {
                self.finalize(block).await?;
                Ok(Vec::new())
            }
            NativeChainMessagePayload::Tip(tip) => self.handle_tip(tip).await,
            NativeChainMessagePayload::SyncRequest(request) => {
                self.handle_sync_request(request).await
            }
            NativeChainMessagePayload::SyncResponse(response) => {
                self.handle_sync_response(response).await
            }
        }
    }

    pub async fn tip_message(&self) -> NativeChainMessage {
        let state = self.state.read().await;
        NativeChainMessage::new(NativeChainMessagePayload::Tip(NativeChainTip {
            height: state.latest_number(),
            hash: state.latest_hash().to_string(),
            observed_at: now_secs(),
        }))
    }

    async fn handle_tip(&self, tip: NativeChainTip) -> Result<Vec<NativeChainMessage>, String> {
        if !is_hash(&tip.hash) {
            return Err("native chain tip contains an invalid hash".to_string());
        }
        let state = self.state.read().await;
        if tip.height == state.latest_number() && tip.hash != state.latest_hash() {
            return Err("native chain tip conflicts at the finalized height".to_string());
        }
        if tip.height <= state.latest_number() {
            return Ok(Vec::new());
        }
        Ok(vec![
            self.sync_request(state.latest_number().saturating_add(1))
        ])
    }

    async fn handle_sync_request(
        &self,
        request: NativeChainSyncRequest,
    ) -> Result<Vec<NativeChainMessage>, String> {
        if request.request_id.len() > 256 {
            return Err("native chain sync request ID is too long".to_string());
        }
        let state = self.state.read().await;
        let Some(block) = state.block_by_number(request.from_height) else {
            return Ok(Vec::new());
        };
        Ok(vec![NativeChainMessage::new(
            NativeChainMessagePayload::SyncResponse(NativeChainSyncResponse {
                request_id: request.request_id,
                block: block.clone(),
            }),
        )])
    }

    async fn handle_sync_response(
        &mut self,
        response: NativeChainSyncResponse,
    ) -> Result<Vec<NativeChainMessage>, String> {
        if response.request_id.len() > 256 {
            return Err("native chain sync response ID is too long".to_string());
        }
        let number = response.block.proposal.number;
        self.finalize(response.block).await?;
        let latest = self.state.read().await.latest_number();
        if number < latest {
            return Ok(Vec::new());
        }
        Ok(vec![self.sync_request(latest.saturating_add(1))])
    }

    fn sync_request(&self, from_height: u64) -> NativeChainMessage {
        NativeChainMessage::new(NativeChainMessagePayload::SyncRequest(
            NativeChainSyncRequest {
                from_height,
                request_id: format!("{}:{from_height}:{}", self.local_validator, now_nanos()),
            },
        ))
    }

    async fn handle_proposal(
        &mut self,
        proposal: NativeBlockProposal,
        signing: &SigningKey,
    ) -> Result<Vec<NativeChainMessage>, String> {
        self.require_writable()?;
        {
            let state = self.state.read().await;
            if proposal.number <= state.latest_number() {
                if state
                    .block_by_number(proposal.number)
                    .map(|block| block.proposal.hash == proposal.hash)
                    .unwrap_or(false)
                {
                    return Ok(Vec::new());
                }
                return Err("conflicting stale proposal".to_string());
            }
            validate_proposal(&state, &proposal, &self.validators)?;
            if state
                .pending_proposal
                .as_ref()
                .is_some_and(|pending| pending.hash != proposal.hash)
            {
                return Err("refusing to replace the durable pending proposal".into());
            }
        }
        if let Some(previous) = self.voted_heights.get(&proposal.number) {
            if previous != &proposal.hash {
                return Err(format!(
                    "refusing conflicting proposal at height {}",
                    proposal.number
                ));
            }
        }
        self.proposals
            .insert(proposal.hash.clone(), proposal.clone());
        if let Some(orphaned) = self.orphan_votes.remove(&proposal.hash) {
            let votes = self.votes.entry(proposal.hash.clone()).or_default();
            for vote in orphaned.into_values() {
                validate_vote(&vote, &proposal, &self.validators)?;
                votes.insert(vote.validator.clone(), vote);
            }
        }
        if !self.validators.contains(&self.local_validator) {
            return Ok(Vec::new());
        }
        {
            let mut state = self.state.write().await;
            if let Some(previous) = state.votes_cast.get(&proposal.number) {
                if previous != &proposal.hash {
                    return Err(format!(
                        "persistent vote lock rejects conflicting proposal at height {}",
                        proposal.number
                    ));
                }
            }
            // Repeating an already durable vote does not rewrite the ledger.
            // Older state files may have a lock without the proposal itself;
            // only an independently validated matching proposal can fill it in.
            if !state.votes_cast.contains_key(&proposal.number) || state.pending_proposal.is_none()
            {
                let mut next = state.clone();
                next.votes_cast
                    .insert(proposal.number, proposal.hash.clone());
                next.pending_proposal = Some(proposal.clone());
                if let Err(error) =
                    save_state_atomic_limited(&self.state_path, &next, self.limits.state_bytes)
                {
                    self.persistence_error = Some(error.clone());
                    state.admission.blocked_reason = Some(error.clone());
                    let _ =
                        write_admission_status(&self.state_path, "blocked", Some(&error), &state);
                    return Err(error);
                }
                *state = next;
            }
        }
        let vote = NativeBlockVote {
            block_hash: proposal.hash.clone(),
            block_number: proposal.number,
            validator: self.local_validator.clone(),
            signature: sign_vote(signing, &proposal.hash, proposal.number),
        };
        println!(
            "QSYS|mod=NATIVE_CHAIN|evt=VOTE|height={}|hash={}|validator={}",
            proposal.number, proposal.hash, self.local_validator
        );
        self.voted_heights
            .insert(proposal.number, proposal.hash.clone());
        self.votes
            .entry(proposal.hash)
            .or_default()
            .insert(vote.validator.clone(), vote.clone());
        Ok(vec![NativeChainMessage::new(
            NativeChainMessagePayload::Vote(vote),
        )])
    }

    async fn handle_vote(
        &mut self,
        vote: NativeBlockVote,
    ) -> Result<Vec<NativeChainMessage>, String> {
        let proposal = self.proposals.get(&vote.block_hash).cloned();
        let Some(proposal) = proposal else {
            {
                let state = self.state.read().await;
                if vote.block_number <= state.latest_number() {
                    return Ok(Vec::new());
                }
            }
            validate_vote_envelope(&vote, &self.validators)?;
            if !self.orphan_votes.contains_key(&vote.block_hash)
                && self
                    .limits
                    .orphan_blocks
                    .is_some_and(|limit| self.orphan_votes.len() >= limit)
            {
                return Err("native orphan-vote capacity reached".into());
            }
            self.orphan_votes
                .entry(vote.block_hash.clone())
                .or_default()
                .insert(vote.validator.clone(), vote);
            return Ok(Vec::new());
        };
        validate_vote(&vote, &proposal, &self.validators)?;
        let votes = self.votes.entry(vote.block_hash.clone()).or_default();
        votes.insert(vote.validator.clone(), vote);
        println!(
            "QSYS|mod=NATIVE_CHAIN|evt=VOTE_OBSERVED|height={}|hash={}|votes={}/{}",
            proposal.number,
            proposal.hash,
            votes.len(),
            self.quorum
        );
        if votes.len() < self.quorum {
            return Ok(Vec::new());
        }
        let finalized = FinalizedNativeBlock {
            proposal,
            votes: votes.values().cloned().collect(),
        };
        self.finalize(finalized.clone()).await?;
        Ok(vec![NativeChainMessage::new(
            NativeChainMessagePayload::Finalized(finalized),
        )])
    }

    async fn finalize(&mut self, block: FinalizedNativeBlock) -> Result<(), String> {
        self.require_writable()?;
        let mut state = self.state.write().await;
        if block.proposal.number <= state.latest_number() {
            if state
                .blocks
                .iter()
                .any(|existing| existing.proposal.hash == block.proposal.hash)
            {
                return Ok(());
            }
            return Err("conflicting finalized block below current height".to_string());
        }
        validate_finalized(&state, &block, &self.validators, self.quorum)?;
        let transition = execute_transition(&state, &block.proposal)?;
        let mut next = state.clone();
        next.accounts = transition.accounts;
        next.evm = transition.evm;
        next.blocks.push(block.clone());
        next.votes_cast
            .retain(|number, _| *number > block.proposal.number);
        next.pending_proposal = None;
        if let Err(error) =
            save_state_atomic_limited(&self.state_path, &next, self.limits.state_bytes)
        {
            self.persistence_error = Some(error.clone());
            state.admission.blocked_reason = Some(error.clone());
            let _ = write_admission_status(&self.state_path, "blocked", Some(&error), &state);
            return Err(error);
        }
        *state = next;
        drop(state);

        for tx in &block.proposal.transactions {
            self.pending.remove(&tx.hash);
        }
        let height = block.proposal.number;
        self.proposals
            .retain(|_, proposal| proposal.number > height);
        self.votes
            .retain(|hash, _| self.proposals.contains_key(hash));
        self.orphan_votes
            .retain(|_, votes| votes.values().any(|vote| vote.block_number > height));
        self.voted_heights.retain(|number, _| *number > height);
        Ok(())
    }

    fn require_writable(&self) -> Result<(), String> {
        match &self.persistence_error {
            Some(error) => Err(format!(
                "native admission blocked pending operator recovery: {error}"
            )),
            None => Ok(()),
        }
    }
}

impl NativeChainState {
    pub fn load_or_initialize(
        path: &Path,
        chain_id: u64,
        registry_path: Option<&Path>,
        mut validators: Vec<String>,
        quorum: usize,
    ) -> Result<Self, String> {
        validators.sort();
        validators.dedup();
        if validators.is_empty()
            || quorum == 0
            || quorum > validators.len()
            || quorum.saturating_mul(2) <= validators.len()
        {
            return Err("native chain requires a strict-majority validator quorum".to_string());
        }
        if path.exists() {
            let limit = read_positive_limit("MFENX_NATIVE_MAX_STATE_BYTES")?;
            let bytes = if let Some(limit) = limit {
                let mut bytes = Vec::new();
                fs::File::open(path)
                    .map_err(|err| err.to_string())?
                    .take((limit as u64).saturating_add(1))
                    .read_to_end(&mut bytes)
                    .map_err(|err| err.to_string())?;
                if bytes.len() > limit {
                    return Err(format!(
                        "native state exceeds configured {limit}-byte limit"
                    ));
                }
                bytes
            } else {
                fs::read(path).map_err(|err| err.to_string())?
            };
            let mut state: Self = serde_json::from_slice(&bytes).map_err(|err| err.to_string())?;
            state.validate()?;
            if state.chain_id != chain_id {
                return Err(format!(
                    "native chain ID mismatch: state={} configured={chain_id}",
                    state.chain_id
                ));
            }
            if state.validators != validators || state.quorum != quorum {
                return Err(
                    "configured validator set or quorum differs from native-chain genesis"
                        .to_string(),
                );
            }
            if let Some(height) = read_positive_limit("MFENX_EVM_ACTIVATION_HEIGHT")? {
                if let Some(existing) = &state.evm {
                    if existing.activation_height != height as u64 {
                        return Err(
                            "configured EVM activation conflicts with persisted upgrade".into()
                        );
                    }
                } else {
                    state.enable_evm(height as u64)?;
                    save_state_atomic(path, &state)?;
                }
            }
            return Ok(state);
        }

        let mut accounts = BTreeMap::new();
        if let Some(registry_path) = registry_path {
            let registry = StakeRegistry::load(registry_path)?;
            for (key, account) in registry.accounts() {
                if let Some(address) = registry_key_to_evm_address(key) {
                    let entry = accounts
                        .entry(address)
                        .or_insert_with(NativeAccount::default);
                    entry.balance = entry.balance.saturating_add(account.balance);
                }
            }
        }
        let genesis = genesis_block(chain_id, &accounts, &validators, quorum);
        let mut state = Self {
            schema: STATE_SCHEMA.to_string(),
            chain_id,
            validators,
            quorum,
            genesis_accounts: accounts.clone(),
            accounts,
            evm: None,
            blocks: vec![genesis],
            votes_cast: BTreeMap::new(),
            pending_proposal: None,
            admission: NativeAdmissionStatus::default(),
        };
        if let Some(height) = read_positive_limit("MFENX_EVM_ACTIVATION_HEIGHT")? {
            state.enable_evm(height as u64)?;
        }
        save_state_atomic(path, &state)?;
        Ok(state)
    }

    pub fn validate(&self) -> Result<(), String> {
        if self.schema != STATE_SCHEMA {
            return Err(format!(
                "unsupported native chain state schema: {}",
                self.schema
            ));
        }
        if self.blocks.is_empty() {
            return Err("native chain state has no genesis block".to_string());
        }
        if self.blocks[0].proposal.number != 0 {
            return Err("native chain genesis block number must be zero".to_string());
        }
        if self.validators.is_empty()
            || self.quorum == 0
            || self.quorum > self.validators.len()
            || self.quorum.saturating_mul(2) <= self.validators.len()
        {
            return Err("native chain validator quorum is invalid".to_string());
        }
        if self.blocks[0]
            != genesis_block(
                self.chain_id,
                &self.genesis_accounts,
                &self.validators,
                self.quorum,
            )
        {
            return Err("native chain genesis commitment is corrupt".to_string());
        }
        if let Some(contracts) = &self.evm {
            contracts.validate_encoding()?;
        }
        let mut replay = Self {
            schema: self.schema.clone(),
            chain_id: self.chain_id,
            validators: self.validators.clone(),
            quorum: self.quorum,
            genesis_accounts: self.genesis_accounts.clone(),
            accounts: self.genesis_accounts.clone(),
            evm: self
                .evm
                .as_ref()
                .map(|e| EvmChainState::from_native(e.activation_height, &self.genesis_accounts)),
            blocks: vec![self.blocks[0].clone()],
            votes_cast: BTreeMap::new(),
            pending_proposal: None,
            admission: NativeAdmissionStatus::default(),
        };
        for block in self.blocks.iter().skip(1) {
            validate_finalized(&replay, block, &self.validators, self.quorum)?;
            let transition = execute_transition(&replay, &block.proposal)?;
            replay.accounts = transition.accounts;
            replay.evm = transition.evm;
            replay.blocks.push(block.clone());
        }
        if replay.accounts != self.accounts {
            return Err("native chain account state does not match replayed blocks".to_string());
        }
        if replay.evm != self.evm {
            return Err("EVM code, storage or account state does not match replayed blocks".into());
        }
        for (number, hash) in &self.votes_cast {
            if *number != self.latest_number().saturating_add(1) || !is_hash(hash) {
                return Err("invalid persisted next-height vote lock".into());
            }
        }
        if let Some(proposal) = &self.pending_proposal {
            validate_proposal(self, proposal, &self.validators)?;
            if self
                .votes_cast
                .get(&proposal.number)
                .is_some_and(|hash| hash != &proposal.hash)
            {
                return Err("pending proposal conflicts with the persisted vote lock".into());
            }
        }
        Ok(())
    }

    /// Set an explicit future fork without modifying genesis or finalized history.
    pub fn enable_evm(&mut self, activation_height: u64) -> Result<(), String> {
        self.validate()?;
        if self.evm.is_some()
            || activation_height <= self.latest_number()
            || self.pending_proposal.is_some()
            || !self.votes_cast.is_empty()
        {
            return Err("EVM activation requires an unlocked future height".into());
        }
        self.evm = Some(EvmChainState::from_native(
            activation_height,
            &self.accounts,
        ));
        self.validate()
    }

    pub fn evm_active(&self, number: u64) -> bool {
        self.evm
            .as_ref()
            .is_some_and(|e| number >= e.activation_height)
    }

    pub fn execution_context(&self, number: u64, timestamp: u64) -> BlockContext {
        let start = number.saturating_sub(256);
        BlockContext {
            chain_id: self.chain_id,
            number,
            timestamp,
            ancestors: self
                .blocks
                .iter()
                .filter(|b| b.proposal.number >= start && b.proposal.number < number)
                .map(|b| (b.proposal.number, b.proposal.hash.clone()))
                .collect(),
        }
    }

    /// Reconstruct typed historical contract state, not HDF5/JSON file bytes.
    pub fn evm_at(&self, number: u64) -> Result<EvmChainState, String> {
        if number > self.latest_number() {
            return Err(format!("block {number} has not been finalized"));
        }
        let height = self
            .evm
            .as_ref()
            .ok_or("EVM upgrade is not configured")?
            .activation_height;
        if number == self.latest_number() {
            return Ok(self.evm.clone().unwrap());
        }
        let mut replay = Self {
            schema: self.schema.clone(),
            chain_id: self.chain_id,
            validators: self.validators.clone(),
            quorum: self.quorum,
            genesis_accounts: self.genesis_accounts.clone(),
            accounts: self.genesis_accounts.clone(),
            evm: Some(EvmChainState::from_native(height, &self.genesis_accounts)),
            blocks: vec![self.blocks[0].clone()],
            votes_cast: BTreeMap::new(),
            pending_proposal: None,
            admission: NativeAdmissionStatus::default(),
        };
        for block in self.blocks.iter().skip(1).take(number as usize) {
            let transition = execute_transition(&replay, &block.proposal)?;
            replay.accounts = transition.accounts;
            replay.evm = transition.evm;
            replay.blocks.push(block.clone());
        }
        Ok(replay.evm.unwrap())
    }

    pub fn evm_account_at(&self, address: &str, number: u64) -> Result<EvmAccount, String> {
        let address = normalize_evm_address(address).ok_or("invalid address format")?;
        Ok(self.evm_at(number)?.account(&address))
    }

    pub fn account(&self, address: &str) -> NativeAccount {
        normalize_evm_address(address)
            .and_then(|normalized| self.accounts.get(&normalized).cloned())
            .unwrap_or_default()
    }

    pub fn account_at(&self, address: &str, number: u64) -> Result<NativeAccount, String> {
        if self.evm_active(number) {
            return Err(
                "post-upgrade accounts require the full-width evm_account_at interface".into(),
            );
        }
        if number > self.latest_number() {
            return Err(format!("block {number} has not been finalized"));
        }
        let normalized =
            normalize_evm_address(address).ok_or_else(|| "invalid address format".to_string())?;
        let mut accounts = self.genesis_accounts.clone();
        for block in self.blocks.iter().skip(1).take(number as usize) {
            for tx in &block.proposal.transactions {
                apply_transaction_to_accounts(self.chain_id, &mut accounts, tx)?;
            }
        }
        Ok(accounts.get(&normalized).cloned().unwrap_or_default())
    }

    pub fn latest_block(&self) -> &FinalizedNativeBlock {
        self.blocks.last().expect("validated state has genesis")
    }

    pub fn latest_number(&self) -> u64 {
        self.latest_block().proposal.number
    }

    pub fn latest_hash(&self) -> &str {
        &self.latest_block().proposal.hash
    }

    pub fn latest_timestamp(&self) -> u64 {
        self.latest_block().proposal.timestamp
    }

    pub fn block_by_number(&self, number: u64) -> Option<&FinalizedNativeBlock> {
        self.blocks.get(number as usize)
    }

    pub fn block_by_hash(&self, hash: &str) -> Option<&FinalizedNativeBlock> {
        self.blocks
            .iter()
            .find(|block| block.proposal.hash.eq_ignore_ascii_case(hash))
    }

    pub fn transaction(
        &self,
        hash: &str,
    ) -> Option<(&FinalizedNativeBlock, usize, &NativeTransaction)> {
        self.blocks.iter().find_map(|block| {
            block
                .proposal
                .transactions
                .iter()
                .enumerate()
                .find(|(_, tx)| tx.hash.eq_ignore_ascii_case(hash))
                .map(|(index, tx)| (block, index, tx))
        })
    }
}

pub fn decode_eip1559_transaction(
    raw: &[u8],
    expected_chain_id: u64,
) -> Result<NativeTransaction, String> {
    if raw.first().copied() != Some(0x02) {
        return Err("only EIP-1559 type 0x02 transactions are supported".to_string());
    }
    let rlp = Rlp::new(&raw[1..]);
    if !rlp.is_list() || rlp.item_count().map_err(|err| err.to_string())? != 12 {
        return Err("invalid EIP-1559 RLP payload".to_string());
    }
    let chain_id = rlp_u64(&rlp, 0)?;
    if chain_id != expected_chain_id {
        return Err(format!(
            "chainId mismatch: transaction={chain_id} configured={expected_chain_id}"
        ));
    }
    let nonce = rlp_u64(&rlp, 1)?;
    let max_priority_fee_per_gas = rlp_u128(&rlp, 2)?;
    let max_fee_per_gas = rlp_u128(&rlp, 3)?;
    let gas_limit = rlp_u64(&rlp, 4)?;
    if gas_limit < NATIVE_GAS_LIMIT {
        return Err(format!("gas limit must be at least {NATIVE_GAS_LIMIT}"));
    }
    let to_bytes = rlp_data(&rlp, 5)?;
    if to_bytes.len() != 20 {
        return Err("contract creation is not supported".to_string());
    }
    let value_wei = rlp_u128(&rlp, 6)?;
    let value_units = wei_to_native_units(value_wei)?;
    let input_bytes = rlp_data(&rlp, 7)?;
    if !input_bytes.is_empty() {
        return Err("contract calldata is not supported".to_string());
    }
    let access_list_item = rlp.at(8).map_err(|err| err.to_string())?;
    if !access_list_item.is_list() {
        return Err("EIP-1559 access list must be an RLP list".to_string());
    }
    let access_list = access_list_item.as_raw().to_vec();
    let y_parity = rlp_u64(&rlp, 9)?;
    if y_parity > 1 {
        return Err("invalid signature recovery parity".to_string());
    }
    let r32 = left_pad_32(rlp_data(&rlp, 10)?)?;
    let s32 = left_pad_32(rlp_data(&rlp, 11)?)?;

    let mut stream = RlpStream::new_list(9);
    stream.append(&chain_id);
    stream.append(&nonce);
    stream.append(&max_priority_fee_per_gas);
    stream.append(&max_fee_per_gas);
    stream.append(&gas_limit);
    stream.append(&to_bytes);
    stream.append(&value_wei);
    stream.append(&input_bytes);
    stream.append_raw(&access_list, 1);
    let encoded = stream.out();
    let mut signing_payload = Vec::with_capacity(encoded.len() + 1);
    signing_payload.push(0x02);
    signing_payload.extend_from_slice(encoded.as_ref());
    let sighash = keccak256(&signing_payload);
    let signature = Signature::from_scalars(r32, s32).map_err(|err| err.to_string())?;
    if signature.normalize_s().is_some() {
        return Err("signature must use canonical low-S form".to_string());
    }
    let recovery_id =
        RecoveryId::from_byte(y_parity as u8).ok_or_else(|| "invalid recovery ID".to_string())?;
    let verifying = VerifyingKey::recover_from_prehash(&sighash, &signature, recovery_id)
        .map_err(|err| format!("signature recovery failed: {err}"))?;
    let encoded_public = verifying.to_encoded_point(false);
    let public = encoded_public.as_bytes();
    if public.len() != 65 {
        return Err("invalid recovered public key".to_string());
    }
    let address_hash = keccak256(&public[1..]);

    Ok(NativeTransaction {
        hash: format!("0x{}", hex::encode(keccak256(raw))),
        raw: format!("0x{}", hex::encode(raw)),
        from: format!("0x{}", hex::encode(&address_hash[12..])),
        to: format!("0x{}", hex::encode(to_bytes)),
        nonce,
        value_wei: to_quantity_u128(value_wei),
        value_units,
        gas_limit,
        max_fee_per_gas: to_quantity_u128(max_fee_per_gas),
        max_priority_fee_per_gas: to_quantity_u128(max_priority_fee_per_gas),
        input: "0x".to_string(),
        y_parity: y_parity as u8,
        r: format!("0x{}", hex::encode(r32)),
        s: format!("0x{}", hex::encode(s32)),
    })
}

pub fn decode_hex_prefixed(input: &str) -> Result<Vec<u8>, String> {
    let raw = input
        .trim()
        .strip_prefix("0x")
        .or_else(|| input.trim().strip_prefix("0X"))
        .ok_or_else(|| "hex payload must start with 0x".to_string())?;
    hex::decode(raw).map_err(|err| format!("invalid hex payload: {err}"))
}

pub fn normalize_evm_address(value: &str) -> Option<String> {
    let trimmed = value.trim();
    let raw = trimmed
        .strip_prefix("0x")
        .or_else(|| trimmed.strip_prefix("0X"))?;
    if raw.len() != 40 || !raw.chars().all(|ch| ch.is_ascii_hexdigit()) {
        return None;
    }
    Some(format!("0x{}", raw.to_ascii_lowercase()))
}

pub fn to_quantity_u64(value: u64) -> String {
    format!("0x{value:x}")
}

pub fn to_quantity_u128(value: u128) -> String {
    format!("0x{value:x}")
}

fn validate_transaction(state: &NativeChainState, tx: &NativeTransaction) -> Result<(), String> {
    let raw = decode_hex_prefixed(&tx.raw)?;
    let decoded = decode_eip1559_transaction(&raw, state.chain_id)?;
    if &decoded != tx {
        return Err("transaction fields do not match signed raw payload".to_string());
    }
    let sender = state.account(&tx.from);
    if sender.nonce != tx.nonce {
        return Err(format!(
            "nonce mismatch: expected {}, received {}",
            sender.nonce, tx.nonce
        ));
    }
    if sender.balance < tx.value_units {
        return Err("insufficient native balance".to_string());
    }
    Ok(())
}

fn apply_transaction_to_accounts(
    chain_id: u64,
    accounts: &mut BTreeMap<String, NativeAccount>,
    tx: &NativeTransaction,
) -> Result<(), String> {
    let raw = decode_hex_prefixed(&tx.raw)?;
    if decode_eip1559_transaction(&raw, chain_id)? != *tx {
        return Err("transaction fields do not match signed raw payload".to_string());
    }
    let from = normalize_evm_address(&tx.from).ok_or_else(|| "invalid sender".to_string())?;
    let to = normalize_evm_address(&tx.to).ok_or_else(|| "invalid recipient".to_string())?;
    let sender = accounts.entry(from.clone()).or_default();
    if sender.nonce != tx.nonce {
        return Err(format!(
            "nonce mismatch: expected {}, received {}",
            sender.nonce, tx.nonce
        ));
    }
    if sender.balance < tx.value_units {
        return Err("insufficient native balance".to_string());
    }
    sender.balance -= tx.value_units;
    sender.nonce = sender.nonce.saturating_add(1);
    let recipient = accounts.entry(to).or_default();
    recipient.balance = recipient.balance.saturating_add(tx.value_units);
    Ok(())
}

fn validate_proposal(
    state: &NativeChainState,
    proposal: &NativeBlockProposal,
    validators: &[String],
) -> Result<(), String> {
    if proposal.chain_id != state.chain_id
        || proposal.number != state.latest_number().saturating_add(1)
        || proposal.parent_hash != state.latest_hash()
    {
        return Err("proposal does not extend the finalized tip".to_string());
    }
    if proposal.transactions.len() > MAX_BLOCK_TRANSACTIONS {
        return Err("proposal transaction count is invalid".to_string());
    }
    if proposal.timestamp <= state.latest_timestamp()
        || proposal.timestamp > now_secs().saturating_add(MAX_FUTURE_SECONDS)
    {
        return Err("proposal timestamp is outside the accepted range".to_string());
    }
    if expected_leader(validators, proposal.number) != proposal.proposer {
        return Err("proposal was not signed by the expected leader".to_string());
    }
    if block_hash(proposal) != proposal.hash {
        return Err("proposal hash mismatch".to_string());
    }
    verify_signature_base64(
        &proposal.proposer,
        block_signing_payload(&proposal.hash).as_bytes(),
        &proposal.signature,
    )
    .map_err(|err| format!("invalid proposer signature: {err}"))?;

    let mut hashes = BTreeSet::new();
    for tx in &proposal.transactions {
        if !hashes.insert(tx.hash.clone()) {
            return Err("proposal contains duplicate transactions".to_string());
        }
    }
    let transition = execute_transition(state, proposal)?;
    if transition.root != proposal.state_root || transition.execution != proposal.evm {
        return Err("proposal state root does not match transaction execution".to_string());
    }
    Ok(())
}

struct Transition {
    accounts: BTreeMap<String, NativeAccount>,
    evm: Option<EvmChainState>,
    execution: Option<EvmBlockExecution>,
    root: String,
}

fn evm_payload_bytes(tx: &NativeTransaction, receipt: &evm::EvmReceipt) -> Result<usize, String> {
    let tx_bytes = serde_json::to_vec(tx).map_err(|e| e.to_string())?.len();
    let receipt_bytes = serde_json::to_vec(receipt)
        .map_err(|e| e.to_string())?
        .len();
    tx_bytes
        .checked_add(receipt_bytes)
        .ok_or_else(|| "execution byte overflow".into())
}

fn execute_transition(
    state: &NativeChainState,
    proposal: &NativeBlockProposal,
) -> Result<Transition, String> {
    let mut accounts = state.accounts.clone();
    if !state.evm_active(proposal.number) {
        if proposal.evm.is_some() {
            return Err("EVM execution precedes its configured activation".into());
        }
        for tx in &proposal.transactions {
            apply_transaction_to_accounts(state.chain_id, &mut accounts, tx)?;
        }
        return Ok(Transition {
            root: accounts_root(&accounts),
            evm: state
                .evm
                .as_ref()
                .map(|e| EvmChainState::from_native(e.activation_height, &accounts)),
            accounts,
            execution: None,
        });
    }
    let mut contracts = state.evm.clone().unwrap();
    let context = state.execution_context(proposal.number, proposal.timestamp);
    let mut execution = EvmBlockExecution {
        profile: evm::PROFILE.into(),
        activation_height: contracts.activation_height,
        gas_used: 0,
        receipts: Vec::new(),
    };
    let mut execution_bytes = 0usize;
    for tx in &proposal.transactions {
        if tx.gas_limit > evm::BLOCK_GAS_LIMIT - execution.gas_used {
            return Err("block exceeds its available EVM gas".into());
        }
        let (next, receipt) = contracts.execute(&context, tx)?;
        let size = evm_payload_bytes(tx, &receipt)?;
        if size > evm::MAX_BLOCK_PAYLOAD_BYTES - execution_bytes {
            return Err("block exceeds its EVM payload byte budget".into());
        }
        execution_bytes += size;
        execution.gas_used = execution
            .gas_used
            .checked_add(receipt.gas_used)
            .ok_or("block gas overflow")?;
        execution.receipts.push(receipt);
        contracts = next;
    }
    Ok(Transition {
        accounts,
        root: contracts.root(),
        evm: Some(contracts),
        execution: Some(execution),
    })
}

fn validate_vote(
    vote: &NativeBlockVote,
    proposal: &NativeBlockProposal,
    validators: &[String],
) -> Result<(), String> {
    if vote.block_hash != proposal.hash || vote.block_number != proposal.number {
        return Err("vote does not match proposal".to_string());
    }
    validate_vote_envelope(vote, validators)
}

fn validate_vote_envelope(vote: &NativeBlockVote, validators: &[String]) -> Result<(), String> {
    if !validators.contains(&vote.validator) {
        return Err("vote signer is not a validator".to_string());
    }
    if !is_hash(&vote.block_hash) {
        return Err("vote contains an invalid block hash".to_string());
    }
    verify_signature_base64(
        &vote.validator,
        vote_signing_payload(&vote.block_hash, vote.block_number).as_bytes(),
        &vote.signature,
    )
    .map_err(|err| format!("invalid block vote: {err}"))
}

fn is_hash(value: &str) -> bool {
    value.len() == 66
        && value.starts_with("0x")
        && value[2..]
            .chars()
            .all(|character| character.is_ascii_hexdigit())
}

fn validate_finalized(
    state: &NativeChainState,
    block: &FinalizedNativeBlock,
    validators: &[String],
    quorum: usize,
) -> Result<(), String> {
    validate_proposal(state, &block.proposal, validators)?;
    let mut signers = BTreeSet::new();
    for vote in &block.votes {
        validate_vote(vote, &block.proposal, validators)?;
        signers.insert(vote.validator.clone());
    }
    if signers.len() < quorum {
        return Err(format!(
            "quorum certificate has {} distinct votes; {quorum} required",
            signers.len()
        ));
    }
    Ok(())
}

fn genesis_block(
    chain_id: u64,
    accounts: &BTreeMap<String, NativeAccount>,
    validators: &[String],
    quorum: usize,
) -> FinalizedNativeBlock {
    let mut hasher = Blake2b256::new();
    hasher.update(b"mfenx-native-genesis-v1");
    hasher.update(chain_id.to_be_bytes());
    hasher.update(accounts_root(accounts).as_bytes());
    hasher.update(serde_json::to_vec(validators).expect("validators serialize"));
    hasher.update(quorum.to_be_bytes());
    let hash: [u8; 32] = hasher.finalize().into();
    FinalizedNativeBlock {
        proposal: NativeBlockProposal {
            chain_id,
            number: 0,
            parent_hash: format!("0x{}", "00".repeat(32)),
            timestamp: 0,
            proposer: "genesis".to_string(),
            transactions: Vec::new(),
            state_root: accounts_root(accounts),
            evm: None,
            hash: format!("0x{}", hex::encode(hash)),
            signature: String::new(),
        },
        votes: Vec::new(),
    }
}

fn block_hash(proposal: &NativeBlockProposal) -> String {
    let mut hasher = Blake2b256::new();
    if let Some(execution) = &proposal.evm {
        hasher.update(b"mfenx-evm-block-v1");
        hasher.update(serde_json::to_vec(execution).expect("EVM block execution serializes"));
    } else {
        hasher.update(b"mfenx-native-block-v1");
    }
    hasher.update(proposal.chain_id.to_be_bytes());
    hasher.update(proposal.number.to_be_bytes());
    hasher.update(proposal.parent_hash.as_bytes());
    hasher.update(proposal.timestamp.to_be_bytes());
    hasher.update(proposal.proposer.as_bytes());
    hasher.update(proposal.state_root.as_bytes());
    for tx in &proposal.transactions {
        hasher.update(tx.hash.as_bytes());
    }
    let digest: [u8; 32] = hasher.finalize().into();
    format!("0x{}", hex::encode(digest))
}

fn accounts_root(accounts: &BTreeMap<String, NativeAccount>) -> String {
    let mut hasher = Blake2b256::new();
    hasher.update(b"mfenx-native-state-root-v1");
    hasher.update(serde_json::to_vec(accounts).expect("native accounts serialize"));
    let digest: [u8; 32] = hasher.finalize().into();
    format!("0x{}", hex::encode(digest))
}

fn expected_leader(validators: &[String], number: u64) -> String {
    validators[((number.saturating_sub(1)) as usize) % validators.len()].clone()
}

fn sign_block_hash(signing: &SigningKey, hash: &str) -> String {
    encode_signature_base64(&signing.sign(block_signing_payload(hash).as_bytes()))
}

fn sign_vote(signing: &SigningKey, hash: &str, number: u64) -> String {
    encode_signature_base64(&signing.sign(vote_signing_payload(hash, number).as_bytes()))
}

fn block_signing_payload(hash: &str) -> String {
    format!("mfenx-native-block-signature-v1:{hash}")
}

fn vote_signing_payload(hash: &str, number: u64) -> String {
    format!("mfenx-native-block-vote-v1:{number}:{hash}")
}

fn save_state_atomic(path: &Path, state: &NativeChainState) -> Result<(), String> {
    save_state_atomic_limited(
        path,
        state,
        read_positive_limit("MFENX_NATIVE_MAX_STATE_BYTES")?,
    )
}

fn serialize_state_limited(
    state: &NativeChainState,
    limit: Option<usize>,
) -> Result<Vec<u8>, String> {
    struct LimitedBytes {
        bytes: Vec<u8>,
        limit: usize,
    }
    impl Write for LimitedBytes {
        fn write(&mut self, data: &[u8]) -> std::io::Result<usize> {
            if data.len() > self.limit.saturating_sub(self.bytes.len()) {
                return Err(std::io::Error::other(
                    "native persistent-state byte budget reached",
                ));
            }
            self.bytes.extend_from_slice(data);
            Ok(data.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    let mut output = LimitedBytes {
        bytes: Vec::new(),
        limit: limit.unwrap_or(usize::MAX),
    };
    serde_json::to_writer_pretty(&mut output, state).map_err(|err| err.to_string())?;
    Ok(output.bytes)
}

fn write_admission_status(
    path: &Path,
    admission: &str,
    reason: Option<&str>,
    state: &NativeChainState,
) -> Result<(), String> {
    let status = path.with_file_name("native_admission_status.json");
    let temporary = status.with_extension(format!("tmp-{}-{}", std::process::id(), now_nanos()));
    let payload = serde_json::json!({
        "schema": "mfenx.native-admission-status.v1", "admission": admission,
        "reason": reason, "max_state_bytes": state.admission.max_state_bytes,
        "updated_at_unix": now_secs(), "chain_id": state.chain_id,
        "genesis_hash": state.blocks[0].proposal.hash,
        "validator_public_key": state.admission.validator_public_key
    });
    let result = (|| {
        let mut file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)
            .map_err(|err| err.to_string())?;
        file.write_all(&serde_json::to_vec(&payload).map_err(|err| err.to_string())?)
            .map_err(|err| err.to_string())?;
        file.sync_all().map_err(|err| err.to_string())?;
        fs::rename(&temporary, &status).map_err(|err| err.to_string())
    })();
    if result.is_err() {
        let _ = fs::remove_file(temporary);
    }
    result
}

fn save_state_atomic_limited(
    path: &Path,
    state: &NativeChainState,
    limit: Option<usize>,
) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|err| err.to_string())?;
    }
    let bytes = serialize_state_limited(state, limit)?;
    let temp = path.with_extension(format!("tmp-{}-{}", std::process::id(), now_nanos()));
    let result = (|| -> Result<(), String> {
        let mut file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temp)
            .map_err(|err| err.to_string())?;
        file.write_all(&bytes).map_err(|err| err.to_string())?;
        file.sync_all().map_err(|err| err.to_string())?;
        fs::rename(&temp, path).map_err(|err| err.to_string())?;
        if let Some(parent) = path.parent() {
            fs::File::open(parent)
                .and_then(|directory| directory.sync_all())
                .map_err(|err| err.to_string())?;
        }
        Ok(())
    })();
    if result.is_err() {
        let _ = fs::remove_file(temp);
    }
    result
}

fn registry_key_to_evm_address(key: &str) -> Option<String> {
    if let Some(address) = normalize_evm_address(key) {
        return Some(address);
    }
    let public = BASE64.decode(key).ok()?;
    let _ = decode_public_key_base64(key).ok()?;
    let mut hasher = Blake2b256::new();
    hasher.update(b"mfenx-migration-address-v1");
    hasher.update(public);
    let digest: [u8; 32] = hasher.finalize().into();
    Some(format!("0x{}", hex::encode(&digest[12..])))
}

fn wei_to_native_units(value: u128) -> Result<u64, String> {
    if !value.is_multiple_of(NATIVE_DECIMAL_FACTOR) {
        return Err("value must be aligned to whole native tokens".to_string());
    }
    u64::try_from(value / NATIVE_DECIMAL_FACTOR)
        .map_err(|_| "native transfer value exceeds u64 capacity".to_string())
}

fn rlp_data<'a>(rlp: &'a Rlp<'a>, index: usize) -> Result<&'a [u8], String> {
    rlp.at(index)
        .map_err(|err| err.to_string())?
        .data()
        .map_err(|err| err.to_string())
}

fn rlp_u64(rlp: &Rlp<'_>, index: usize) -> Result<u64, String> {
    let bytes = rlp_data(rlp, index)?;
    if bytes.len() > 8 {
        return Err("RLP integer exceeds u64".to_string());
    }
    Ok(bytes
        .iter()
        .fold(0u64, |value, byte| (value << 8) | u64::from(*byte)))
}

fn rlp_u128(rlp: &Rlp<'_>, index: usize) -> Result<u128, String> {
    let bytes = rlp_data(rlp, index)?;
    if bytes.len() > 16 {
        return Err("RLP integer exceeds u128".to_string());
    }
    Ok(bytes
        .iter()
        .fold(0u128, |value, byte| (value << 8) | u128::from(*byte)))
}

fn left_pad_32(bytes: &[u8]) -> Result<[u8; 32], String> {
    if bytes.len() > 32 {
        return Err("signature scalar exceeds 32 bytes".to_string());
    }
    let mut output = [0u8; 32];
    output[32 - bytes.len()..].copy_from_slice(bytes);
    Ok(output)
}

fn keccak256(data: &[u8]) -> [u8; 32] {
    let mut hasher = Keccak256::new();
    hasher.update(data);
    hasher.finalize().into()
}

fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn now_nanos() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos()
}

#[cfg(test)]
pub(crate) fn signed_test_transfer(
    secret: [u8; 32],
    chain_id: u64,
    nonce: u64,
    to: [u8; 20],
    units: u64,
) -> NativeTransaction {
    use k256::ecdsa::SigningKey as SecpSigningKey;

    let signing = SecpSigningKey::from_bytes((&secret).into()).unwrap();
    let value = u128::from(units) * NATIVE_DECIMAL_FACTOR;
    let mut unsigned = RlpStream::new_list(9);
    unsigned.append(&chain_id);
    unsigned.append(&nonce);
    unsigned.append(&100_000_000u64);
    unsigned.append(&NATIVE_GAS_PRICE);
    unsigned.append(&NATIVE_GAS_LIMIT);
    unsigned.append(&to.as_slice());
    unsigned.append(&value);
    unsigned.append(&&[][..]);
    unsigned.begin_list(0);
    let encoded = unsigned.out();
    let mut payload = vec![0x02];
    payload.extend_from_slice(&encoded);
    let digest = keccak256(&payload);
    let (signature, recovery) = signing.sign_prehash_recoverable(&digest).unwrap();

    let mut signed = RlpStream::new_list(12);
    signed.append(&chain_id);
    signed.append(&nonce);
    signed.append(&100_000_000u64);
    signed.append(&NATIVE_GAS_PRICE);
    signed.append(&NATIVE_GAS_LIMIT);
    signed.append(&to.as_slice());
    signed.append(&value);
    signed.append(&&[][..]);
    signed.begin_list(0);
    signed.append(&u8::from(recovery));
    signed.append(&signature.r().to_bytes().as_slice());
    signed.append(&signature.s().to_bytes().as_slice());
    let mut raw = vec![0x02];
    raw.extend_from_slice(&signed.out());
    decode_eip1559_transaction(&raw, chain_id).unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::net::{load_or_derive_keypair, Ed25519KeySource};

    fn validator(seed: &str) -> crate::net::KeyMaterial {
        load_or_derive_keypair(&Ed25519KeySource::Seed(seed.to_string())).unwrap()
    }

    #[tokio::test]
    async fn evm_quorum_replays_contracts_and_rejects_forged_execution() {
        let (_directory, keys, mut runtimes) = liveness_cluster().await;
        for runtime in &mut runtimes {
            runtime.state.write().await.enable_evm(1).unwrap();
        }
        let leader = runtimes
            .iter()
            .position(|r| r.local_validator == expected_leader(&r.validators, 1))
            .unwrap();
        // CREATE stores a STOP runtime. No native token is minted or required.
        let tx = evm::signed_test_transaction(
            0,
            &[],
            &hex::decode("6001600c60003960016000f300").unwrap(),
            0,
            100_000,
        );
        for runtime in &mut runtimes {
            runtime.accept_transaction(tx.clone()).await.unwrap();
        }
        let proposal = runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .unwrap()
            .unwrap();
        assert!(proposal.evm.as_ref().unwrap().receipts[0].success);
        let mut forged = proposal.clone();
        forged.evm.as_mut().unwrap().receipts[0].gas_used += 1;
        forged.hash = block_hash(&forged);
        forged.signature = sign_block_hash(&keys[leader].signing, &forged.hash);
        for runtime in &runtimes {
            assert!(
                validate_proposal(&*runtime.state.read().await, &forged, &runtime.validators)
                    .is_err()
            );
        }
        let mut votes = Vec::new();
        for (index, runtime) in runtimes.iter_mut().enumerate() {
            let messages = runtime
                .handle_message(
                    NativeChainMessage::new(NativeChainMessagePayload::Proposal(proposal.clone())),
                    &keys[index].signing,
                )
                .await
                .unwrap();
            if let NativeChainMessagePayload::Vote(vote) = messages[0].payload.clone() {
                votes.push(vote);
            }
        }
        let block = FinalizedNativeBlock { proposal, votes };
        for (index, runtime) in runtimes.iter_mut().enumerate() {
            runtime
                .handle_message(
                    NativeChainMessage::new(NativeChainMessagePayload::Finalized(block.clone())),
                    &keys[index].signing,
                )
                .await
                .unwrap();
            let state = runtime.state.read().await;
            state.validate().unwrap();
            assert!(state.evm_active(1));
            assert_eq!(state.evm.as_ref().unwrap().account(&tx.from).nonce, 1);
            let address = block.proposal.evm.as_ref().unwrap().receipts[0]
                .contract_address
                .as_ref()
                .unwrap();
            assert_eq!(state.evm.as_ref().unwrap().account(address).code, "0x00");
            assert_eq!(state.evm_at(0).unwrap().account(address).code, "0x");
            let mut corrupt = state.clone();
            corrupt
                .evm
                .as_mut()
                .unwrap()
                .accounts
                .get_mut(address)
                .unwrap()
                .code = "0x01".into();
            assert!(corrupt.validate().is_err());
            let mut wrong_activation = state.clone();
            wrong_activation.evm.as_mut().unwrap().activation_height = 2;
            assert!(wrong_activation.validate().is_err());
            assert!(runtime.state_path.exists());
        }
        for (index, runtime) in runtimes.iter_mut().enumerate() {
            *runtime = restart(runtime, &keys[index].signing).await;
            runtime.state.read().await.validate().unwrap();
        }
    }

    #[test]
    fn activation_preserves_native_genesis_and_requires_unlocked_future_height() {
        let directory = TestDirectory::new();
        let key = validator("evm-activation");
        let mut state = NativeChainState::load_or_initialize(
            &directory.path().join("state.json"),
            2026092601,
            None,
            vec![encode_public_key_base64(&key.verifying)],
            1,
        )
        .unwrap();
        let genesis = state.blocks[0].clone();
        assert!(state.enable_evm(0).is_err());
        state.enable_evm(2).unwrap();
        assert_eq!(state.blocks[0], genesis);
        assert!(!state.evm_active(1));
        assert!(state.evm_active(2));
        assert!(state.enable_evm(3).is_err());
        state.validate().unwrap();
    }

    struct TestDirectory(PathBuf);

    impl TestDirectory {
        fn new() -> Self {
            let path = std::env::temp_dir().join(format!(
                "native-budget-{}-{}",
                std::process::id(),
                now_nanos()
            ));
            fs::create_dir(&path).unwrap();
            Self(path)
        }

        fn path(&self) -> &Path {
            &self.0
        }
    }

    impl Drop for TestDirectory {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    #[test]
    fn state_budget_preserves_encoding_and_existing_file() {
        let temporary = TestDirectory::new();
        let path = temporary.path().join("state.json");
        let key = validator("bounded-state-test");
        let state = NativeChainState::load_or_initialize(
            &path,
            2026092601,
            None,
            vec![encode_public_key_base64(&key.verifying)],
            1,
        )
        .unwrap();
        let original = fs::read(&path).unwrap();
        assert_eq!(original, serde_json::to_vec_pretty(&state).unwrap());
        assert_eq!(
            serialize_state_limited(&state, Some(original.len())).unwrap(),
            original
        );
        assert!(save_state_atomic_limited(&path, &state, Some(original.len() - 1)).is_err());
        assert_eq!(fs::read(&path).unwrap(), original);
        assert_eq!(fs::read_dir(temporary.path()).unwrap().count(), 1);
    }

    #[tokio::test]
    async fn authenticated_orphan_votes_obey_capacity() {
        let temporary = TestDirectory::new();
        let path = temporary.path().join("state.json");
        let key = validator("bounded-orphan-test");
        let public = encode_public_key_base64(&key.verifying);
        let state =
            NativeChainState::load_or_initialize(&path, 2026092601, None, vec![public.clone()], 1)
                .unwrap();
        let mut runtime = NativeChainRuntime::new(
            Arc::new(RwLock::new(state)),
            path,
            vec![public.clone()],
            1,
            &key.signing,
        )
        .await
        .unwrap();
        runtime.limits.orphan_blocks = Some(1);
        for (index, byte) in ["11", "22"].iter().enumerate() {
            let hash = format!("0x{}", byte.repeat(32));
            let vote = NativeBlockVote {
                block_hash: hash.clone(),
                block_number: 1,
                validator: public.clone(),
                signature: sign_vote(&key.signing, &hash, 1),
            };
            let result = runtime.handle_vote(vote).await;
            if index == 0 {
                assert!(result.is_ok());
            } else {
                assert!(result.unwrap_err().contains("capacity reached"));
            }
        }
        assert_eq!(runtime.orphan_votes.len(), 1);
    }

    async fn liveness_cluster() -> (
        TestDirectory,
        Vec<crate::net::KeyMaterial>,
        Vec<NativeChainRuntime>,
    ) {
        let directory = TestDirectory::new();
        let mut keys = vec![
            validator("retry-a"),
            validator("retry-b"),
            validator("retry-c"),
        ];
        keys.sort_by_key(|key| encode_public_key_base64(&key.verifying));
        let ids = keys
            .iter()
            .map(|key| encode_public_key_base64(&key.verifying))
            .collect::<Vec<_>>();
        let mut runtimes = Vec::new();
        for (index, key) in keys.iter().enumerate() {
            let path = directory.path().join(format!("state-{index}.json"));
            let state =
                NativeChainState::load_or_initialize(&path, 2026092601, None, ids.clone(), 2)
                    .unwrap();
            runtimes.push(
                NativeChainRuntime::new(
                    Arc::new(RwLock::new(state)),
                    path,
                    ids.clone(),
                    2,
                    &key.signing,
                )
                .await
                .unwrap(),
            );
        }
        (directory, keys, runtimes)
    }

    async fn restart(runtime: &NativeChainRuntime, key: &SigningKey) -> NativeChainRuntime {
        let state = NativeChainState::load_or_initialize(
            &runtime.state_path,
            2026092601,
            None,
            runtime.validators.clone(),
            2,
        )
        .unwrap();
        NativeChainRuntime::new(
            Arc::new(RwLock::new(state)),
            runtime.state_path.clone(),
            runtime.validators.clone(),
            2,
            key,
        )
        .await
        .unwrap()
    }

    #[tokio::test]
    async fn dropped_first_votes_retry_identically_and_finalize_after_restart() {
        let (_directory, keys, mut runtimes) = liveness_cluster().await;
        let leader = runtimes
            .iter()
            .position(|runtime| runtime.local_validator == expected_leader(&runtime.validators, 1))
            .unwrap();
        let proposal = runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .unwrap()
            .unwrap();
        let genesis = runtimes[0].state.read().await.latest_hash().to_string();
        let mut first_votes = Vec::new();
        for (runtime, key) in runtimes.iter_mut().zip(&keys) {
            let messages = runtime
                .handle_proposal(proposal.clone(), &key.signing)
                .await
                .unwrap();
            assert_eq!(messages.len(), 1);
            let NativeChainMessagePayload::Vote(vote) = messages[0].payload.clone() else {
                panic!("expected vote")
            };
            first_votes.push(vote);
        }
        // Every initial message is discarded, then every process is restarted.
        for (runtime, key) in runtimes.iter_mut().zip(&keys) {
            *runtime = restart(runtime, &key.signing).await;
        }
        assert_eq!(
            runtimes[leader]
                .propose(&keys[leader].signing)
                .await
                .unwrap(),
            Some(proposal.clone())
        );
        let mut retries = Vec::new();
        for (index, (runtime, key)) in runtimes.iter_mut().zip(&keys).enumerate() {
            let before = fs::read(&runtime.state_path).unwrap();
            for _ in 0..20 {
                let messages = runtime
                    .handle_proposal(proposal.clone(), &key.signing)
                    .await
                    .unwrap();
                let NativeChainMessagePayload::Vote(vote) = messages[0].payload.clone() else {
                    panic!("expected vote")
                };
                assert_eq!(vote, first_votes[index]);
            }
            assert_eq!(fs::read(&runtime.state_path).unwrap(), before);
            retries.push(first_votes[index].clone());
        }
        for runtime in &mut runtimes {
            for vote in &retries {
                runtime.handle_vote(vote.clone()).await.unwrap();
            }
            let state = runtime.state.read().await;
            assert_eq!(state.latest_number(), 1);
            assert_eq!(state.latest_hash(), proposal.hash);
            assert_eq!(state.blocks[0].proposal.hash, genesis);
            assert!(state.votes_cast.is_empty());
            assert!(state.pending_proposal.is_none());
            state.validate().unwrap();
        }
    }

    #[tokio::test]
    async fn leader_persists_proposal_before_first_publication() {
        let (_directory, keys, mut runtimes) = liveness_cluster().await;
        let leader = runtimes
            .iter()
            .position(|runtime| runtime.local_validator == expected_leader(&runtime.validators, 1))
            .unwrap();
        let proposal = runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .unwrap()
            .unwrap();
        assert!(runtimes[leader].state.read().await.votes_cast.is_empty());
        runtimes[leader] = restart(&runtimes[leader], &keys[leader].signing).await;
        assert_eq!(
            runtimes[leader]
                .propose(&keys[leader].signing)
                .await
                .unwrap(),
            Some(proposal)
        );
    }

    #[tokio::test]
    async fn legacy_vote_lock_recovers_only_the_original_proposal() {
        let (_directory, keys, mut runtimes) = liveness_cluster().await;
        let leader = runtimes
            .iter()
            .position(|runtime| runtime.local_validator == expected_leader(&runtime.validators, 1))
            .unwrap();
        let proposal = runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .unwrap()
            .unwrap();
        runtimes[leader]
            .handle_proposal(proposal.clone(), &keys[leader].signing)
            .await
            .unwrap();
        {
            let mut state = runtimes[leader].state.write().await;
            state.pending_proposal = None;
            save_state_atomic(&runtimes[leader].state_path, &state).unwrap();
        }
        runtimes[leader] = restart(&runtimes[leader], &keys[leader].signing).await;
        let before = fs::read(&runtimes[leader].state_path).unwrap();
        assert!(runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .unwrap_err()
            .contains("refusing to sign"));
        let mut conflicting = proposal.clone();
        conflicting.timestamp += 1;
        conflicting.hash = block_hash(&conflicting);
        conflicting.signature = sign_block_hash(&keys[leader].signing, &conflicting.hash);
        assert!(runtimes[leader]
            .handle_proposal(conflicting, &keys[leader].signing)
            .await
            .is_err());
        assert_eq!(fs::read(&runtimes[leader].state_path).unwrap(), before);
        assert_eq!(
            runtimes[leader]
                .handle_proposal(proposal.clone(), &keys[leader].signing)
                .await
                .unwrap()
                .len(),
            1
        );
        assert_eq!(
            runtimes[leader].state.read().await.votes_cast.get(&1),
            Some(&proposal.hash)
        );
        assert_eq!(
            runtimes[leader].state.read().await.pending_proposal,
            Some(proposal)
        );
    }

    #[tokio::test]
    async fn pending_proposal_storage_failure_never_exposes_a_proposal() {
        let (_directory, keys, mut runtimes) = liveness_cluster().await;
        let leader = runtimes
            .iter()
            .position(|runtime| runtime.local_validator == expected_leader(&runtime.validators, 1))
            .unwrap();
        let before = fs::read(&runtimes[leader].state_path).unwrap();
        runtimes[leader].limits.state_bytes = Some(before.len());
        assert!(runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .is_err());
        assert_eq!(fs::read(&runtimes[leader].state_path).unwrap(), before);
        assert!(runtimes[leader]
            .state
            .read()
            .await
            .pending_proposal
            .is_none());
        assert!(runtimes[leader].proposals.is_empty());
        assert!(runtimes[leader].require_writable().is_err());
    }

    #[tokio::test]
    async fn corrupt_pending_proposal_or_vote_lock_is_rejected() {
        let (_directory, keys, mut runtimes) = liveness_cluster().await;
        let leader = runtimes
            .iter()
            .position(|runtime| runtime.local_validator == expected_leader(&runtime.validators, 1))
            .unwrap();
        let proposal = runtimes[leader]
            .propose(&keys[leader].signing)
            .await
            .unwrap()
            .unwrap();
        let mut state = runtimes[leader].state.read().await.clone();
        state.pending_proposal.as_mut().unwrap().signature = "invalid".into();
        assert!(state.validate().is_err());
        state.pending_proposal = Some(proposal);
        state.votes_cast.insert(1, format!("0x{}", "11".repeat(32)));
        assert!(state.validate().is_err());
        state.pending_proposal = None;
        state.votes_cast.clear();
        state.votes_cast.insert(2, format!("0x{}", "11".repeat(32)));
        assert!(state.validate().is_err());
    }

    #[test]
    fn retransmission_changes_only_transport_identity_and_reads_legacy_envelopes() {
        let payload = NativeChainMessagePayload::Tip(NativeChainTip {
            height: 0,
            hash: format!("0x{}", "00".repeat(32)),
            observed_at: 0,
        });
        let first = NativeChainMessage::new(payload.clone());
        let mut second = NativeChainMessage::new(payload);
        assert_ne!(
            serde_json::to_vec(&first).unwrap(),
            serde_json::to_vec(&second).unwrap()
        );
        assert_eq!(
            serde_json::to_value(&first.payload).unwrap(),
            serde_json::to_value(&second.payload).unwrap()
        );
        let mut legacy = serde_json::to_value(first).unwrap();
        legacy.as_object_mut().unwrap().remove("broadcast_id");
        serde_json::from_value::<NativeChainMessage>(legacy)
            .unwrap()
            .validate_schema()
            .unwrap();
        second.broadcast_id = Some("x".repeat(97));
        assert!(second.validate_schema().is_err());
    }

    #[tokio::test]
    async fn replicas_apply_identical_quorum_finalized_block() {
        let chain_id = 177155;
        let tx = signed_test_transfer([7u8; 32], chain_id, 0, [9u8; 20], 2);
        let validators = [validator("a"), validator("b"), validator("c")];
        let validator_ids = validators
            .iter()
            .map(|key| encode_public_key_base64(&key.verifying))
            .collect::<Vec<_>>();
        let mut accounts = BTreeMap::new();
        accounts.insert(
            tx.from.clone(),
            NativeAccount {
                balance: 5,
                nonce: 0,
            },
        );
        let base = NativeChainState {
            schema: STATE_SCHEMA.to_string(),
            chain_id,
            validators: validator_ids.clone(),
            quorum: 2,
            genesis_accounts: accounts.clone(),
            accounts: accounts.clone(),
            evm: None,
            blocks: vec![genesis_block(chain_id, &accounts, &validator_ids, 2)],
            votes_cast: BTreeMap::new(),
            pending_proposal: None,
            admission: NativeAdmissionStatus::default(),
        };
        let root = std::env::temp_dir().join(format!("native_chain_test_{}", now_nanos()));
        fs::create_dir_all(&root).unwrap();
        let mut runtimes = Vec::new();
        for (index, key) in validators.iter().enumerate() {
            let state = Arc::new(RwLock::new(base.clone()));
            runtimes.push(
                NativeChainRuntime::new(
                    state,
                    root.join(format!("state-{index}.json")),
                    validator_ids.clone(),
                    2,
                    &key.signing,
                )
                .await
                .unwrap(),
            );
        }
        for runtime in &mut runtimes {
            runtime.accept_transaction(tx.clone()).await.unwrap();
        }
        let proposal = runtimes[0]
            .propose(&validators[0].signing)
            .await
            .unwrap()
            .unwrap();
        let mut votes = Vec::new();
        for index in 0..2 {
            let messages = runtimes[index]
                .handle_message(
                    NativeChainMessage::new(NativeChainMessagePayload::Proposal(proposal.clone())),
                    &validators[index].signing,
                )
                .await
                .unwrap();
            if let NativeChainMessagePayload::Vote(vote) = messages[0].payload.clone() {
                votes.push(vote);
            }
        }
        let finalized = FinalizedNativeBlock { proposal, votes };
        for runtime in runtimes.iter_mut().take(2) {
            runtime
                .handle_message(
                    NativeChainMessage::new(NativeChainMessagePayload::Finalized(
                        finalized.clone(),
                    )),
                    &validators[0].signing,
                )
                .await
                .unwrap();
        }
        let tip = runtimes[0].tip_message().await;
        let requests = runtimes[2]
            .handle_message(tip, &validators[2].signing)
            .await
            .unwrap();
        let mut responses = Vec::new();
        for request in requests {
            responses.extend(
                runtimes[0]
                    .handle_message(request, &validators[0].signing)
                    .await
                    .unwrap(),
            );
        }
        for response in responses {
            runtimes[2]
                .handle_message(response, &validators[2].signing)
                .await
                .unwrap();
        }
        let hashes = futures::future::join_all(
            runtimes
                .iter()
                .map(|runtime| async { runtime.state.read().await.latest_hash().to_string() }),
        )
        .await;
        assert!(hashes.windows(2).all(|pair| pair[0] == pair[1]));
        for runtime in &runtimes {
            let state = runtime.state.read().await;
            assert_eq!(state.account(&tx.from).balance, 3);
            assert_eq!(state.account(&tx.to).balance, 2);
            assert_eq!(state.account(&tx.from).nonce, 1);
        }
        fs::remove_dir_all(root).unwrap();
    }

    #[tokio::test]
    async fn empty_heartbeat_blocks_finalize_without_changing_accounts() {
        let chain_id = 177155;
        let validator = validator("heartbeat");
        let validator_ids = vec![encode_public_key_base64(&validator.verifying)];
        let mut accounts = BTreeMap::new();
        accounts.insert(
            "0x20463165245573078cfd3c5d67fd643fe8c7745e".to_string(),
            NativeAccount {
                balance: 1_000_000,
                nonce: 0,
            },
        );
        let base = NativeChainState {
            schema: STATE_SCHEMA.to_string(),
            chain_id,
            validators: validator_ids.clone(),
            quorum: 1,
            genesis_accounts: accounts.clone(),
            accounts: accounts.clone(),
            evm: None,
            blocks: vec![genesis_block(chain_id, &accounts, &validator_ids, 1)],
            votes_cast: BTreeMap::new(),
            pending_proposal: None,
            admission: NativeAdmissionStatus::default(),
        };
        let root = std::env::temp_dir().join(format!("native_chain_heartbeat_{}", now_nanos()));
        fs::create_dir_all(&root).unwrap();
        let state = Arc::new(RwLock::new(base));
        let mut runtime = NativeChainRuntime::new(
            state.clone(),
            root.join("state.json"),
            validator_ids,
            1,
            &validator.signing,
        )
        .await
        .unwrap();

        let proposal = runtime
            .propose(&validator.signing)
            .await
            .unwrap()
            .expect("genesis-idle chain should produce a heartbeat block");
        assert!(proposal.transactions.is_empty());
        let messages = runtime
            .handle_message(
                NativeChainMessage::new(NativeChainMessagePayload::Proposal(proposal)),
                &validator.signing,
            )
            .await
            .unwrap();
        for message in messages {
            runtime
                .handle_message(message, &validator.signing)
                .await
                .unwrap();
        }

        let finalized = state.read().await;
        assert_eq!(finalized.latest_number(), 1);
        assert_eq!(finalized.accounts, accounts);
        assert_eq!(finalized.latest_block().proposal.transactions.len(), 0);
        finalized.validate().unwrap();
        drop(finalized);
        assert!(runtime.propose(&validator.signing).await.unwrap().is_none());
        fs::remove_dir_all(root).unwrap();
    }
}
