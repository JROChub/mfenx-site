//! MFENX's explicitly activated, gas-metered, fee-free Cancun execution profile.
//!
//! REVM executes the bytecode. MFENX validators independently reproduce state,
//! receipts and logs before signing a block. Historical native blocks are not
//! reinterpreted. State commitments remain MFENX commitments, not Ethereum MPTs.

use super::native_chain::{
    decode_hex_prefixed, normalize_evm_address, NativeAccount, NativeTransaction,
    NATIVE_DECIMAL_FACTOR,
};
use k256::ecdsa::{RecoveryId, Signature, VerifyingKey};
use revm::{
    bytecode::Bytecode,
    context::{BlockEnv, CfgEnv, Context, TxEnv},
    context_interface::{
        result::{ExecutionResult, Output},
        transaction::{AccessList, AccessListItem},
    },
    database::{AccountState, InMemoryDB},
    primitives::{hardfork::SpecId, Address, TxKind, B256, U256},
    state::AccountInfo,
    ExecuteCommitEvm, ExecuteEvm, MainBuilder, MainContext,
};
use rlp::{Rlp, RlpStream};
use serde::{Deserialize, Serialize};
use sha3::{Digest, Keccak256};
use std::{collections::BTreeMap, str::FromStr};

/// Consensus identifier for the bounded, fee-free Cancun execution rules.
pub const PROFILE: &str = "mfenx-evm-cancun-fee-free-v1";
/// Maximum transaction and aggregate block gas.
pub const BLOCK_GAS_LIMIT: u64 = 3_000_000;
/// Maximum encoded signed transaction length.
pub const MAX_RAW_TRANSACTION_BYTES: usize = 50 * 1024;
/// Maximum creation bytecode or call input length.
pub const MAX_CALLDATA_BYTES: usize = 49_152;
/// Per-interpreter linear-memory ceiling, independent of transaction gas.
pub const VM_MEMORY_LIMIT: u64 = 4 * 1024 * 1024;
/// Maximum canonical serialized contract-state size.
pub const MAX_CONTRACT_STATE_BYTES: usize = 1024 * 1024;
/// Maximum canonical serialized receipt size.
pub const MAX_RECEIPT_BYTES: usize = 64 * 1024;
/// Aggregate canonical transaction and receipt bytes per EVM block. The margin
/// below the gossip limit also accommodates headers, signatures and sync wraps.
pub const MAX_BLOCK_PAYLOAD_BYTES: usize = 240 * 1024;

/// Persisted account with a full-width wei balance and nonzero storage slots.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EvmAccount {
    /// Minimal hexadecimal unsigned 256-bit wei balance.
    pub balance: String,
    /// Next permitted transaction nonce.
    pub nonce: u64,
    /// Hexadecimal deployed runtime bytecode.
    pub code: String,
    /// Sorted, fixed-width hexadecimal keys and nonzero values.
    pub storage: BTreeMap<String, String>,
}

impl Default for EvmAccount {
    fn default() -> Self {
        Self {
            balance: "0x0".into(),
            nonce: 0,
            code: "0x".into(),
            storage: BTreeMap::new(),
        }
    }
}

/// Canonical contract state, bound to the agreed activation block.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EvmChainState {
    /// First height whose transitions use this execution profile.
    pub activation_height: u64,
    /// Sorted nonempty account records.
    pub accounts: BTreeMap<String, EvmAccount>,
}

/// A committed EVM log; reverted executions never contribute logs.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EvmLog {
    /// Emitting contract address.
    pub address: String,
    /// Ordered 32-byte indexed topics.
    pub topics: Vec<String>,
    /// Hexadecimal unindexed log bytes.
    pub data: String,
}

/// Deterministically replayed execution outcome for one signed transaction.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EvmReceipt {
    /// Keccak-256 identity of the signed transaction bytes.
    pub transaction_hash: String,
    /// True only when execution completes without revert or halt.
    pub success: bool,
    /// Actual gas consumed after Cancun refund accounting.
    pub gas_used: u64,
    /// Successful top-level CREATE address, when applicable.
    pub contract_address: Option<String>,
    /// Committed logs in execution order.
    pub logs: Vec<EvmLog>,
}

/// Execution metadata included in the quorum-signed block commitment.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EvmBlockExecution {
    /// Exact consensus execution-profile identifier.
    pub profile: String,
    /// Agreed first EVM block height.
    pub activation_height: u64,
    /// Sum of actual transaction gas usage.
    pub gas_used: u64,
    /// One receipt per block transaction, in the same order.
    pub receipts: Vec<EvmReceipt>,
}

/// Deterministic block inputs supplied identically to every validator.
#[derive(Debug, Clone)]
pub struct BlockContext {
    /// Replay-protected transaction chain identifier.
    pub chain_id: u64,
    /// Height of the block being executed or simulated.
    pub number: u64,
    /// Agreed block timestamp in seconds.
    pub timestamp: u64,
    /// At most 256 preceding finalized block heights and hashes.
    pub ancestors: Vec<(u64, String)>,
}

impl EvmChainState {
    /// Lift legacy whole-token balances into exact wei without changing supply.
    pub fn from_native(activation_height: u64, accounts: &BTreeMap<String, NativeAccount>) -> Self {
        Self {
            activation_height,
            accounts: accounts
                .iter()
                .filter(|(_, a)| a.balance != 0 || a.nonce != 0)
                .map(|(address, a)| {
                    (
                        address.clone(),
                        EvmAccount {
                            balance: quantity(
                                U256::from(a.balance) * U256::from(NATIVE_DECIMAL_FACTOR),
                            ),
                            nonce: a.nonce,
                            ..EvmAccount::default()
                        },
                    )
                })
                .collect(),
        }
    }

    /// Return an account, using the EVM empty-account representation if absent.
    pub fn account(&self, address: &str) -> EvmAccount {
        self.accounts.get(address).cloned().unwrap_or_default()
    }

    /// Compute MFENX's domain-separated canonical state commitment.
    pub fn root(&self) -> String {
        commitment(b"mfenx-evm-contract-state-v1", self)
    }

    /// Reject noncanonical encodings and contract-state capacity violations.
    pub fn validate_encoding(&self) -> Result<(), String> {
        if self.activation_height == 0 {
            return Err("EVM activation must follow native genesis".into());
        }
        for (address, account) in &self.accounts {
            if normalize_evm_address(address).as_ref() != Some(address) {
                return Err("noncanonical EVM account address".into());
            }
            if quantity(parse_quantity(&account.balance)?) != account.balance {
                return Err("noncanonical EVM balance".into());
            }
            let code = decode_hex_prefixed(&account.code)?;
            if code.len() > 24_576 || format!("0x{}", hex::encode(&code)) != account.code {
                return Err("invalid persisted EVM code".into());
            }
            for (key, value) in &account.storage {
                if word(parse_quantity(key)?) != *key
                    || word(parse_quantity(value)?) != *value
                    || parse_quantity(value)?.is_zero()
                {
                    return Err("noncanonical EVM storage".into());
                }
            }
        }
        let size = serde_json::to_vec(self).map_err(|e| e.to_string())?.len();
        if size > MAX_CONTRACT_STATE_BYTES {
            return Err("EVM contract-state capacity reached".into());
        }
        Ok(())
    }

    fn database(&self, block: &BlockContext) -> Result<InMemoryDB, String> {
        let mut db = InMemoryDB::default();
        for (address, account) in &self.accounts {
            let address = Address::from_str(address).map_err(|e| e.to_string())?;
            let code = Bytecode::new_raw(decode_hex_prefixed(&account.code)?.into());
            db.insert_account_info(
                address,
                AccountInfo {
                    balance: parse_quantity(&account.balance)?,
                    nonce: account.nonce,
                    code_hash: code.hash_slow(),
                    code: Some(code),
                    ..AccountInfo::default()
                },
            );
            for (key, value) in &account.storage {
                db.insert_account_storage(address, parse_quantity(key)?, parse_quantity(value)?)
                    .map_err(|e| e.to_string())?;
            }
        }
        for (number, hash) in &block.ancestors {
            db.cache.block_hashes.insert(
                U256::from(*number),
                B256::from_str(hash).map_err(|e| e.to_string())?,
            );
        }
        Ok(db)
    }

    fn import_database(&self, db: &InMemoryDB) -> Result<Self, String> {
        let mut accounts = BTreeMap::new();
        for (address, account) in &db.cache.accounts {
            if account.account_state == AccountState::NotExisting {
                continue;
            }
            let code = db
                .cache
                .contracts
                .get(&account.info.code_hash)
                .map(|b| b.original_bytes())
                .unwrap_or_default();
            if account.info.balance.is_zero() && account.info.nonce == 0 && code.is_empty() {
                continue;
            }
            accounts.insert(
                format!("{address:#x}"),
                EvmAccount {
                    balance: quantity(account.info.balance),
                    nonce: account.info.nonce,
                    code: format!("0x{}", hex::encode(code)),
                    storage: account
                        .storage
                        .iter()
                        .filter(|(_, value)| !value.is_zero())
                        .map(|(key, value)| (word(*key), word(*value)))
                        .collect(),
                },
            );
        }
        let next = Self {
            activation_height: self.activation_height,
            accounts,
        };
        next.validate_encoding()?;
        Ok(next)
    }

    /// Execute a signed transaction atomically. REVERT/HALT commit only the
    /// EVM's prescribed nonce and fee effects, never reverted storage or logs.
    pub fn execute(
        &self,
        block: &BlockContext,
        transaction: &NativeTransaction,
    ) -> Result<(Self, EvmReceipt), String> {
        let decoded = decode_transaction(&decode_hex_prefixed(&transaction.raw)?, block.chain_id)?;
        if decoded != *transaction {
            return Err("transaction fields do not match signed raw payload".into());
        }
        let mut db = self.database(block)?;
        let tx = transaction_env(transaction, block.chain_id)?;
        let result = {
            let context = Context::mainnet()
                .with_cfg(configuration(block, false))
                .with_block(block_environment(block))
                .with_db(&mut db);
            context
                .build_mainnet()
                .transact_commit(tx)
                .map_err(|e| format!("EVM transaction rejected: {e}"))?
        };
        let receipt = receipt(transaction.hash.clone(), &result);
        if serde_json::to_vec(&receipt)
            .map_err(|e| e.to_string())?
            .len()
            > MAX_RECEIPT_BYTES
        {
            return Err("EVM receipt capacity reached".into());
        }
        Ok((self.import_database(&db)?, receipt))
    }

    /// Simulation discards the state transition and never changes the ledger.
    pub fn simulate(&self, block: &BlockContext, tx: TxEnv) -> Result<ExecutionResult, String> {
        if tx.gas_limit > BLOCK_GAS_LIMIT || tx.data.len() > MAX_CALLDATA_BYTES {
            return Err("EVM simulation resource limit exceeded".into());
        }
        let mut db = self.database(block)?;
        let context = Context::mainnet()
            .with_cfg(configuration(block, true))
            .with_block(block_environment(block))
            .with_db(&mut db);
        context
            .build_mainnet()
            .transact(tx)
            .map(|r| r.result)
            .map_err(|e| format!("EVM simulation rejected: {e}"))
    }
}

fn configuration(block: &BlockContext, simulation: bool) -> CfgEnv {
    let mut cfg = CfgEnv::new_with_spec(SpecId::CANCUN).with_chain_id(block.chain_id);
    cfg.memory_limit = VM_MEMORY_LIMIT;
    cfg.disable_nonce_check = simulation;
    cfg.disable_eip3607 = simulation;
    cfg
}

fn block_environment(block: &BlockContext) -> BlockEnv {
    let parent = block
        .ancestors
        .last()
        .and_then(|(_, h)| B256::from_str(h).ok())
        .unwrap_or_default();
    BlockEnv {
        number: U256::from(block.number),
        timestamp: U256::from(block.timestamp),
        gas_limit: BLOCK_GAS_LIMIT,
        basefee: 0,
        beneficiary: Address::ZERO,
        prevrandao: Some(parent),
        ..BlockEnv::default()
    }
}

fn receipt(hash: String, result: &ExecutionResult) -> EvmReceipt {
    let contract_address = match result {
        ExecutionResult::Success {
            output: Output::Create(_, address),
            ..
        } => address.map(|a| format!("{a:#x}")),
        _ => None,
    };
    EvmReceipt {
        transaction_hash: hash,
        success: result.is_success(),
        gas_used: result.tx_gas_used(),
        contract_address,
        // Some execution APIs retain pre-revert trace logs. Only successful
        // transactions may publish committed receipt logs or bloom bits.
        logs: (if result.is_success() {
            result.logs()
        } else {
            &[]
        })
        .iter()
        .map(|log| EvmLog {
            address: format!("{:#x}", log.address),
            topics: log
                .data
                .topics()
                .iter()
                .map(|t| format!("{t:#x}"))
                .collect(),
            data: format!("0x{}", hex::encode(&log.data.data)),
        })
        .collect(),
    }
}

fn transaction_env(tx: &NativeTransaction, chain_id: u64) -> Result<TxEnv, String> {
    let raw = decode_hex_prefixed(&tx.raw)?;
    let rlp = Rlp::new(&raw[1..]);
    Ok(TxEnv {
        tx_type: 2,
        caller: Address::from_str(&tx.from).map_err(|e| e.to_string())?,
        gas_limit: tx.gas_limit,
        gas_price: 0,
        gas_priority_fee: Some(0),
        kind: if tx.to == "0x" {
            TxKind::Create
        } else {
            TxKind::Call(Address::from_str(&tx.to).map_err(|e| e.to_string())?)
        },
        value: parse_quantity(&tx.value_wei)?,
        data: decode_hex_prefixed(&tx.input)?.into(),
        nonce: tx.nonce,
        chain_id: Some(chain_id),
        access_list: access_list(&rlp.at(8).map_err(|e| e.to_string())?)?,
        ..TxEnv::default()
    })
}

/// Recover the signed access list for RPC presentation, including legacy
/// native transactions whose execution predates the EVM activation.
pub fn transaction_access_list(tx: &NativeTransaction) -> Result<AccessList, String> {
    let raw = decode_hex_prefixed(&tx.raw)?;
    if raw.first() != Some(&2) {
        return Err("invalid typed transaction".into());
    }
    access_list(&Rlp::new(&raw[1..]).at(8).map_err(|e| e.to_string())?)
}

/// Decode canonical signed EIP-1559 transactions, including CREATE and calldata.
pub fn decode_transaction(raw: &[u8], chain_id: u64) -> Result<NativeTransaction, String> {
    if raw.len() > MAX_RAW_TRANSACTION_BYTES {
        return Err("signed transaction exceeds byte limit".into());
    }
    if raw.first() != Some(&2) {
        return Err("only EIP-1559 type 0x02 transactions are supported".into());
    }
    let rlp = Rlp::new(&raw[1..]);
    let info = rlp.payload_info().map_err(|e| e.to_string())?;
    if info.total() != raw.len() - 1
        || !rlp.is_list()
        || rlp.item_count().map_err(|e| e.to_string())? != 12
    {
        return Err("invalid canonical EIP-1559 RLP payload".into());
    }
    let read_u64 = |index| -> Result<u64, String> {
        let number = unsigned(&rlp, index, 8)?;
        Ok(number
            .iter()
            .fold(0u64, |n, byte| (n << 8) | u64::from(*byte)))
    };
    let actual_chain = read_u64(0)?;
    if actual_chain != chain_id {
        return Err(format!(
            "chainId mismatch: transaction={actual_chain} configured={chain_id}"
        ));
    }
    let nonce = read_u64(1)?;
    if nonce == u64::MAX {
        return Err("transaction nonce is exhausted".into());
    }
    if !unsigned(&rlp, 2, 16)?.is_empty() || !unsigned(&rlp, 3, 16)?.is_empty() {
        return Err("MFENX's fee-free profile requires zero fee and priority fee".into());
    }
    let gas_limit = read_u64(4)?;
    if !(21_000..=BLOCK_GAS_LIMIT).contains(&gas_limit) {
        return Err("transaction gas limit is outside the execution profile".into());
    }
    let to = rlp
        .at(5)
        .map_err(|e| e.to_string())?
        .data()
        .map_err(|e| e.to_string())?;
    if !to.is_empty() && to.len() != 20 {
        return Err("recipient must be an address or empty for contract creation".into());
    }
    let value = U256::from_be_slice(unsigned(&rlp, 6, 32)?);
    let data = rlp
        .at(7)
        .map_err(|e| e.to_string())?
        .data()
        .map_err(|e| e.to_string())?;
    if data.len() > MAX_CALLDATA_BYTES {
        return Err("transaction calldata exceeds byte limit".into());
    }
    let access = access_list(&rlp.at(8).map_err(|e| e.to_string())?)?;
    let y = read_u64(9)?;
    if y > 1 {
        return Err("invalid signature recovery parity".into());
    }
    let r = scalar(unsigned(&rlp, 10, 32)?);
    let s = scalar(unsigned(&rlp, 11, 32)?);
    // Re-encode every field, including nested lists. RLP iterators can stop at
    // malformed trailing data, so field-count checks alone are insufficient.
    let mut canonical = RlpStream::new_list(12);
    for i in 0..8 {
        canonical.append(
            &rlp.at(i)
                .map_err(|e| e.to_string())?
                .data()
                .map_err(|e| e.to_string())?,
        );
    }
    canonical.begin_list(access.0.len());
    for entry in &access.0 {
        canonical.begin_list(2);
        canonical.append(&entry.address.as_slice());
        canonical.begin_list(entry.storage_keys.len());
        for key in &entry.storage_keys {
            canonical.append(&key.as_slice());
        }
    }
    for i in 9..12 {
        canonical.append(
            &rlp.at(i)
                .map_err(|e| e.to_string())?
                .data()
                .map_err(|e| e.to_string())?,
        );
    }
    if canonical.out().as_ref() != &raw[1..] {
        return Err("noncanonical nested EIP-1559 RLP payload".into());
    }
    let signature = Signature::from_scalars(r, s).map_err(|e| e.to_string())?;
    if signature.normalize_s().is_some() {
        return Err("signature must use canonical low-S form".into());
    }
    let mut unsigned_payload = RlpStream::new_list(9);
    for i in 0..9 {
        unsigned_payload.append_raw(rlp.at(i).map_err(|e| e.to_string())?.as_raw(), 1);
    }
    let mut signing = vec![2];
    signing.extend_from_slice(&unsigned_payload.out());
    let key = VerifyingKey::recover_from_prehash(
        &digest(&signing),
        &signature,
        RecoveryId::from_byte(y as u8).ok_or("invalid parity")?,
    )
    .map_err(|e| format!("signature recovery failed: {e}"))?;
    let public = key.to_encoded_point(false);
    let address = digest(&public.as_bytes()[1..]);
    Ok(NativeTransaction {
        hash: format!("0x{}", hex::encode(digest(raw))),
        raw: format!("0x{}", hex::encode(raw)),
        from: format!("0x{}", hex::encode(&address[12..])),
        to: format!("0x{}", hex::encode(to)),
        nonce,
        value_wei: quantity(value),
        value_units: 0,
        gas_limit,
        max_fee_per_gas: "0x0".into(),
        max_priority_fee_per_gas: "0x0".into(),
        input: format!("0x{}", hex::encode(data)),
        y_parity: y as u8,
        r: format!("0x{}", hex::encode(r)),
        s: format!("0x{}", hex::encode(s)),
    })
}

fn unsigned<'a>(rlp: &Rlp<'a>, index: usize, size: usize) -> Result<&'a [u8], String> {
    let bytes = rlp
        .at(index)
        .map_err(|e| e.to_string())?
        .data()
        .map_err(|e| e.to_string())?;
    if bytes.len() > size || bytes.first() == Some(&0) {
        return Err("noncanonical or oversized RLP integer".into());
    }
    Ok(bytes)
}

fn scalar(bytes: &[u8]) -> [u8; 32] {
    let mut value = [0; 32];
    value[32 - bytes.len()..].copy_from_slice(bytes);
    value
}

fn access_list(rlp: &Rlp<'_>) -> Result<AccessList, String> {
    if !rlp.is_list() {
        return Err("access list must be an RLP list".into());
    }
    let mut entries = Vec::new();
    for entry in rlp.iter() {
        if !entry.is_list() || entry.item_count().map_err(|e| e.to_string())? != 2 {
            return Err("invalid access-list entry".into());
        }
        let address = entry
            .at(0)
            .map_err(|e| e.to_string())?
            .data()
            .map_err(|e| e.to_string())?;
        if address.len() != 20 {
            return Err("invalid access-list address".into());
        }
        let list = entry.at(1).map_err(|e| e.to_string())?;
        if !list.is_list() {
            return Err("access-list keys must be a list".into());
        }
        let mut keys = Vec::new();
        for key in list.iter() {
            let data = key.data().map_err(|e| e.to_string())?;
            if data.len() != 32 {
                return Err("access-list keys must be 32 bytes".into());
            }
            keys.push(B256::from_slice(data));
        }
        entries.push(AccessListItem {
            address: Address::from_slice(address),
            storage_keys: keys,
        });
    }
    Ok(AccessList(entries))
}

/// Parse a hexadecimal unsigned 256-bit quantity or fixed-width storage word.
pub fn parse_quantity(value: &str) -> Result<U256, String> {
    let digits = value
        .strip_prefix("0x")
        .ok_or("quantity must start with 0x")?;
    if digits.is_empty() || digits.len() > 64 || !digits.chars().all(|ch| ch.is_ascii_hexdigit()) {
        return Err("invalid 256-bit quantity".into());
    }
    U256::from_str_radix(digits, 16).map_err(|e| e.to_string())
}

/// Encode an unsigned 256-bit value as a minimal JSON-RPC quantity.
pub fn quantity(value: U256) -> String {
    format!("{value:#x}")
}
/// Encode an unsigned 256-bit value as a fixed 32-byte storage word.
pub fn word(value: U256) -> String {
    format!("0x{}", hex::encode(value.to_be_bytes::<32>()))
}
/// Compute Ethereum Keccak-256, not standardized SHA3-256.
pub fn digest(bytes: &[u8]) -> [u8; 32] {
    Keccak256::digest(bytes).into()
}
/// Hash a domain prefix and deterministic canonical serialized execution data.
pub fn commitment<T: Serialize>(domain: &[u8], data: &T) -> String {
    let mut hash = Keccak256::new();
    hash.update(domain);
    hash.update(serde_json::to_vec(data).expect("canonical EVM data serializes"));
    format!("0x{}", hex::encode(hash.finalize()))
}

/// Construct the standard 2048-bit Ethereum bloom from canonical executed logs.
pub fn logs_bloom(logs: &[EvmLog]) -> String {
    let mut bloom = [0u8; 256];
    for log in logs {
        for value in std::iter::once(&log.address).chain(log.topics.iter()) {
            let hash = digest(&decode_hex_prefixed(value).expect("executed log is canonical"));
            for pair in hash[..6].chunks_exact(2) {
                let bit = ((usize::from(pair[0]) << 8) | usize::from(pair[1])) & 2047;
                bloom[255 - bit / 8] |= 1 << (bit % 8);
            }
        }
    }
    format!("0x{}", hex::encode(bloom))
}

#[cfg(test)]
pub(crate) fn signed_test_transaction(
    nonce: u64,
    to: &[u8],
    data: &[u8],
    value: u128,
    gas: u64,
) -> NativeTransaction {
    let key = k256::ecdsa::SigningKey::from_slice(&[7; 32]).unwrap();
    let mut fields = RlpStream::new_list(9);
    fields
        .append(&2026092601u64)
        .append(&nonce)
        .append(&0u64)
        .append(&0u64)
        .append(&gas)
        .append(&to)
        .append(&value)
        .append(&data);
    fields.begin_list(0);
    let encoded = fields.out();
    let mut payload = vec![2];
    payload.extend_from_slice(&encoded);
    let (signature, recovery) = key.sign_prehash_recoverable(&digest(&payload)).unwrap();
    let mut signed = RlpStream::new_list(12);
    let fields = Rlp::new(&encoded);
    for i in 0..9 {
        signed.append_raw(fields.at(i).unwrap().as_raw(), 1);
    }
    signed.append(&u8::from(recovery));
    for scalar in [signature.r().to_bytes(), signature.s().to_bytes()] {
        let first = scalar.iter().position(|b| *b != 0).unwrap_or(scalar.len());
        signed.append(&&scalar[first..]);
    }
    let mut raw = vec![2];
    raw.extend_from_slice(&signed.out());
    decode_transaction(&raw, 2026092601).unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn block() -> BlockContext {
        BlockContext {
            chain_id: 2026092601,
            number: 1,
            timestamp: 100,
            ancestors: vec![(0, format!("0x{}", "ab".repeat(32)))],
        }
    }

    fn empty() -> EvmChainState {
        EvmChainState::from_native(1, &BTreeMap::new())
    }

    pub(crate) fn init_code(runtime: &[u8]) -> Vec<u8> {
        let length = u16::try_from(runtime.len()).unwrap().to_be_bytes();
        let mut code = vec![
            0x61, length[0], length[1], 0x61, 0, 15, 0x60, 0, 0x39, 0x61, length[0], length[1],
            0x60, 0, 0xf3,
        ];
        code.extend_from_slice(runtime);
        code
    }

    fn deploy(runtime: &[u8]) -> (EvmChainState, String, String) {
        let tx = signed_test_transaction(0, &[], &init_code(runtime), 0, 500_000);
        let (state, receipt) = empty().execute(&block(), &tx).unwrap();
        assert!(receipt.success);
        (state, receipt.contract_address.unwrap(), tx.from)
    }

    #[test]
    fn create_storage_and_read_only_simulation_are_exact() {
        let runtime = hex::decode("60003560005560005460005260206000f3").unwrap();
        let (state, address, sender) = deploy(&runtime);
        assert_eq!(
            state.account(&address).code,
            format!("0x{}", hex::encode(&runtime))
        );
        let to = decode_hex_prefixed(&address).unwrap();
        let data = U256::from(42).to_be_bytes::<32>();
        let tx = signed_test_transaction(1, &to, &data, 0, 100_000);
        let root = state.root();
        let result = state
            .simulate(&block(), transaction_env(&tx, block().chain_id).unwrap())
            .unwrap();
        assert!(result.is_success());
        assert_eq!(state.root(), root);
        let (next, receipt) = state.execute(&block(), &tx).unwrap();
        assert!(receipt.success && receipt.gas_used > 21_000 && receipt.gas_used < tx.gas_limit);
        assert_eq!(
            next.account(&address).storage[&word(U256::ZERO)],
            word(U256::from(42))
        );
        assert_eq!(next.account(&sender).nonce, 2);
        assert_ne!(next.root(), root);
        let restored: EvmChainState =
            serde_json::from_slice(&serde_json::to_vec(&next).unwrap()).unwrap();
        restored.validate_encoding().unwrap();
        assert_eq!(restored.root(), next.root());
    }

    #[test]
    fn revert_and_out_of_gas_consume_nonce_without_committing_storage() {
        for runtime in ["602a60005560006000a060006000fd", "5b600056", "fe"] {
            let (state, address, sender) = deploy(&hex::decode(runtime).unwrap());
            let tx =
                signed_test_transaction(1, &decode_hex_prefixed(&address).unwrap(), &[], 0, 50_000);
            let (next, receipt) = state.execute(&block(), &tx).unwrap();
            assert!(!receipt.success);
            assert!(receipt.logs.is_empty());
            assert!(next.account(&address).storage.is_empty());
            assert_eq!(next.account(&sender).nonce, 2);
            assert!(receipt.gas_used <= tx.gas_limit);
            assert!(next.execute(&block(), &tx).is_err());
        }
    }

    #[test]
    fn fractional_wei_transfers_preserve_total_balance() {
        let tx = signed_test_transaction(0, &[9; 20], &[], 1, 21_000);
        let mut native = BTreeMap::new();
        native.insert(
            tx.from.clone(),
            NativeAccount {
                balance: 1,
                nonce: 0,
            },
        );
        let state = EvmChainState::from_native(1, &native);
        let (next, receipt) = state.execute(&block(), &tx).unwrap();
        assert!(receipt.success);
        assert_eq!(
            parse_quantity(&next.account(&tx.from).balance).unwrap(),
            U256::from(NATIVE_DECIMAL_FACTOR - 1)
        );
        assert_eq!(next.account(&tx.to).balance, "0x1");
        assert_eq!(receipt.gas_used, 21_000);
        assert!(empty().execute(&block(), &tx).is_err());
    }

    #[test]
    fn logs_and_zero_slot_removal_follow_committed_execution() {
        let (state, address, _) = deploy(&hex::decode("6000358060005560005260206000a000").unwrap());
        let to = decode_hex_prefixed(&address).unwrap();
        let tx = signed_test_transaction(1, &to, &U256::from(42).to_be_bytes::<32>(), 0, 100_000);
        let (state, receipt) = state.execute(&block(), &tx).unwrap();
        assert_eq!(receipt.logs.len(), 1);
        assert_eq!(receipt.logs[0].address, address);
        assert_eq!(receipt.logs[0].data, word(U256::from(42)));
        assert_ne!(logs_bloom(&receipt.logs), format!("0x{}", "00".repeat(256)));
        let tx = signed_test_transaction(2, &to, &[0; 32], 0, 100_000);
        let (state, _) = state.execute(&block(), &tx).unwrap();
        assert!(state.account(&address).storage.is_empty());
    }

    #[test]
    fn mutated_signed_fields_and_wrong_nonce_are_rejected_atomically() {
        let tx = signed_test_transaction(0, &[9; 20], &[], 0, 21_000);
        let mut mutation = tx.clone();
        mutation.value_wei = "0x1".into();
        let state = empty();
        assert!(state.execute(&block(), &mutation).is_err());
        assert!(state
            .execute(
                &block(),
                &signed_test_transaction(1, &[9; 20], &[], 0, 21_000)
            )
            .is_err());
        assert!(state.accounts.is_empty());
    }

    #[test]
    fn malformed_and_noncanonical_transactions_never_panic() {
        let tx = signed_test_transaction(0, &[9; 20], &[], 0, 21_000);
        let raw = decode_hex_prefixed(&tx.raw).unwrap();
        for n in 0..raw.len() {
            assert!(decode_transaction(&raw[..n], 2026092601).is_err());
        }
        let mut extended = raw.clone();
        extended.push(0);
        assert!(decode_transaction(&extended, 2026092601).is_err());
        assert!(decode_transaction(&raw, 177155).is_err());
        let fields = Rlp::new(&raw[1..]);
        for field in [0, 1, 2, 3, 4, 6, 9, 10, 11] {
            let mut noncanonical = RlpStream::new_list(12);
            for index in 0..12 {
                if index == field {
                    let mut value = vec![0];
                    value.extend_from_slice(fields.at(index).unwrap().data().unwrap());
                    noncanonical.append(&value);
                } else {
                    noncanonical.append_raw(fields.at(index).unwrap().as_raw(), 1);
                }
            }
            let mut bytes = vec![2];
            bytes.extend_from_slice(&noncanonical.out());
            assert!(decode_transaction(&bytes, 2026092601).is_err());
        }
        assert!(decode_transaction(&vec![2; MAX_RAW_TRANSACTION_BYTES + 1], 2026092601).is_err());
    }

    #[test]
    fn canonical_state_rejects_zero_slots_and_oversized_code() {
        let mut state = empty();
        let address = format!("0x{}", "09".repeat(20));
        let mut account = EvmAccount::default();
        account.storage.insert(word(U256::ZERO), word(U256::ZERO));
        state.accounts.insert(address.clone(), account);
        assert!(state.validate_encoding().is_err());
        let account = state.accounts.get_mut(&address).unwrap();
        account.storage.clear();
        account.code = format!("0x{}", "00".repeat(24_577));
        assert!(state.validate_encoding().is_err());
    }

    #[test]
    fn cancun_selfdestruct_does_not_erase_preexisting_contract() {
        let mut runtime = vec![0x73];
        runtime.extend_from_slice(&[9; 20]);
        runtime.push(0xff);
        let (state, address, _) = deploy(&runtime);
        let tx =
            signed_test_transaction(1, &decode_hex_prefixed(&address).unwrap(), &[], 0, 100_000);
        let (next, receipt) = state.execute(&block(), &tx).unwrap();
        assert!(receipt.success);
        assert_eq!(next.account(&address).code, state.account(&address).code);
    }
}
