//! Contract RPC methods. Expensive reads use one bounded blocking worker,
//! leaving the asynchronous consensus and network I/O tasks available.
use super::{
    parse_block_tag, required_string, to_quantity_u64, EvmRpcConfig, JsonRpcRequest, RpcError,
};
use crate::net::{
    evm::{self, EvmLog},
    native_chain::{
        decode_hex_prefixed, normalize_evm_address, FinalizedNativeBlock, NativeChainState,
        NativeTransaction,
    },
};
use revm::{
    context::TxEnv,
    context_interface::{
        result::ExecutionResult,
        transaction::{AccessList, AccessListItem},
    },
    primitives::{Address, TxKind, B256, U256},
};
use serde_json::{json, Value};
use std::str::FromStr;

pub(super) async fn handle(
    request: &JsonRpcRequest,
    cfg: &EvmRpcConfig,
) -> Option<Result<Value, RpcError>> {
    if !matches!(
        request.method.as_str(),
        "eth_call"
            | "eth_estimateGas"
            | "eth_getCode"
            | "eth_getStorageAt"
            | "eth_getLogs"
            | "eth_getBalance"
            | "eth_getTransactionCount"
            | "eth_feeHistory"
            | "mfenx_getExecutionProfile"
    ) {
        return None;
    }
    if request.method == "mfenx_getExecutionProfile" {
        let state = cfg.state.read().await;
        return Some(Ok(json!({
            "profile": state.evm.as_ref().map(|_| evm::PROFILE),
            "activationHeight": state.evm.as_ref().map(|e| to_quantity_u64(e.activation_height)),
            "active": state.evm_active(state.latest_number()),
            "acceptingTransactions": state.evm_active(state.latest_number().saturating_add(1)),
            "backend": "revm", "backendVersion": "43.0.3",
            "gasLimit": to_quantity_u64(evm::BLOCK_GAS_LIMIT), "effectiveGasPrice": "0x0",
            "stateCommitment": "mfenx-evm-contract-state-v1",
            "validatorReplay": true,
        })));
    }
    let permit = match cfg.execution_slots.clone().try_acquire_owned() {
        Ok(permit) => permit,
        Err(_) => {
            return Some(Err(RpcError {
                code: -32005,
                message: "contract RPC busy; retry after current request".into(),
                data: None,
            }))
        }
    };
    // Reserve before cloning history: rejected concurrent calls cannot amplify
    // memory by each holding an independent ledger snapshot.
    let state = {
        let state = cfg.state.read().await;
        state.evm.as_ref()?;
        state.clone()
    };
    let request = request.clone();
    Some(
        tokio::task::spawn_blocking(move || {
            let _permit = permit;
            handle_snapshot(&request, &state)
        })
        .await
        .unwrap_or_else(|e| {
            Err(RpcError::internal(format!(
                "contract RPC worker failed: {e}"
            )))
        }),
    )
}

fn requested_block(params: &Value, index: usize, latest: u64) -> Result<u64, RpcError> {
    let items = params
        .as_array()
        .ok_or_else(|| RpcError::invalid_params("params must be an array"))?;
    let tag = match items.get(index) {
        None => "latest",
        Some(value) => value
            .as_str()
            .ok_or_else(|| RpcError::invalid_params("block tag must be a string"))?,
    };
    parse_block_tag(tag, latest)
}

fn handle_snapshot(request: &JsonRpcRequest, state: &NativeChainState) -> Result<Value, RpcError> {
    let latest = state.latest_number();
    match request.method.as_str() {
        "eth_getCode" | "eth_getBalance" | "eth_getTransactionCount" => {
            let address = required_string(&request.params, 0, "address")?;
            let number = requested_block(&request.params, 1, latest)?;
            let account = state
                .evm_account_at(&address, number)
                .map_err(RpcError::invalid_params)?;
            Ok(match request.method.as_str() {
                "eth_getCode" => json!(account.code),
                "eth_getBalance" => json!(account.balance),
                _ => json!(to_quantity_u64(account.nonce)),
            })
        }
        "eth_getStorageAt" => {
            let address = required_string(&request.params, 0, "address")?;
            let slot = required_string(&request.params, 1, "storage position")?;
            let slot = evm::word(evm::parse_quantity(&slot).map_err(RpcError::invalid_params)?);
            let number = requested_block(&request.params, 2, latest)?;
            let account = state
                .evm_account_at(&address, number)
                .map_err(RpcError::invalid_params)?;
            Ok(json!(account
                .storage
                .get(&slot)
                .cloned()
                .unwrap_or_else(|| evm::word(U256::ZERO))))
        }
        "eth_call" | "eth_estimateGas" => {
            let number = requested_block(&request.params, 1, latest)?;
            let contracts = state.evm_at(number).map_err(RpcError::invalid_params)?;
            let block = state
                .block_by_number(number)
                .ok_or_else(|| RpcError::invalid_params("block is not finalized"))?;
            let context = state.execution_context(number, block.proposal.timestamp);
            let tx = call_transaction(&request.params, state.chain_id, &contracts)?;
            let result = contracts
                .simulate(&context, tx.clone())
                .map_err(RpcError::internal)?;
            let output = successful_output(&result)?;
            if request.method == "eth_call" {
                return Ok(json!(output));
            }
            // A conservative estimate is accepted only after execution succeeds
            // at that exact limit. The upper bound already succeeded above.
            let limit = result
                .tx_gas_used()
                .saturating_add(result.tx_gas_used() / 5)
                .saturating_add(21_000)
                .min(tx.gas_limit);
            let mut candidate = tx.clone();
            candidate.gas_limit = limit;
            let accepted = contracts
                .simulate(&context, candidate)
                .is_ok_and(|r| r.is_success());
            Ok(json!(to_quantity_u64(if accepted {
                limit
            } else {
                tx.gas_limit
            })))
        }
        "eth_getLogs" => get_logs(&request.params, state),
        "eth_feeHistory" => fee_history(&request.params, state),
        _ => Err(RpcError::method_not_found(&request.method)),
    }
}

fn successful_output(result: &ExecutionResult) -> Result<String, RpcError> {
    match result {
        ExecutionResult::Success { output, .. } => Ok(format!("0x{}", hex::encode(output.data()))),
        ExecutionResult::Revert { output, .. } => Err(RpcError {
            code: 3,
            message: "execution reverted".into(),
            data: Some(json!(format!("0x{}", hex::encode(output)))),
        }),
        ExecutionResult::Halt { reason, .. } => {
            Err(RpcError::internal(format!("execution halted: {reason:?}")))
        }
    }
}

fn call_transaction(
    params: &Value,
    chain_id: u64,
    contracts: &evm::EvmChainState,
) -> Result<TxEnv, RpcError> {
    let call = params
        .as_array()
        .and_then(|p| p.first())
        .and_then(Value::as_object)
        .ok_or_else(|| RpcError::invalid_params("expected a transaction object"))?;
    for field in ["gasPrice", "maxFeePerGas", "maxPriorityFeePerGas"] {
        if let Some(value) = call.get(field) {
            let value = value
                .as_str()
                .ok_or_else(|| RpcError::invalid_params("fee must be a hex quantity"))?;
            if !evm::parse_quantity(value)
                .map_err(RpcError::invalid_params)?
                .is_zero()
            {
                return Err(RpcError::invalid_params(
                    "MFENX's fee-free profile requires zero fees",
                ));
            }
        }
    }
    if let Some(value) = call.get("type") {
        if value.as_str() != Some("0x2") {
            return Err(RpcError::invalid_params("only type 0x02 is supported"));
        }
    }
    if call.contains_key("authorizationList") || call.contains_key("blobVersionedHashes") {
        return Err(RpcError::invalid_params(
            "authorization/blob transactions are not supported",
        ));
    }
    let from = match call.get("from") {
        Some(value) => normalize_evm_address(value.as_str().unwrap_or(""))
            .ok_or_else(|| RpcError::invalid_params("invalid from address"))?,
        None => format!("{:#x}", Address::ZERO),
    };
    let kind = match call.get("to") {
        Some(Value::Null) | None => TxKind::Create,
        Some(value) => TxKind::Call(
            Address::from_str(value.as_str().unwrap_or(""))
                .map_err(|_| RpcError::invalid_params("invalid to address"))?,
        ),
    };
    if call.get("data").is_some()
        && call.get("input").is_some()
        && call.get("data") != call.get("input")
    {
        return Err(RpcError::invalid_params("data and input disagree"));
    }
    let data = match call.get("data").or_else(|| call.get("input")) {
        Some(value) => decode_hex_prefixed(
            value
                .as_str()
                .ok_or_else(|| RpcError::invalid_params("data must be hex bytes"))?,
        )
        .map_err(RpcError::invalid_params)?,
        None => Vec::new(),
    };
    if data.len() > evm::MAX_CALLDATA_BYTES {
        return Err(RpcError::invalid_params("calldata exceeds byte limit"));
    }
    let quantity = |name: &str, default: U256| -> Result<U256, RpcError> {
        match call.get(name) {
            None => Ok(default),
            Some(value) => evm::parse_quantity(
                value
                    .as_str()
                    .ok_or_else(|| RpcError::invalid_params("expected a hex quantity"))?,
            )
            .map_err(RpcError::invalid_params),
        }
    };
    let gas_limit = u64::try_from(quantity("gas", U256::from(evm::BLOCK_GAS_LIMIT))?)
        .map_err(|_| RpcError::invalid_params("gas exceeds u64"))?;
    if !(21_000..=evm::BLOCK_GAS_LIMIT).contains(&gas_limit) {
        return Err(RpcError::invalid_params(
            "gas is outside the execution profile",
        ));
    }
    if quantity("chainId", U256::from(chain_id))? != U256::from(chain_id) {
        return Err(RpcError::invalid_params("chainId mismatch"));
    }
    let mut access = Vec::new();
    if let Some(list) = call.get("accessList") {
        for item in list
            .as_array()
            .ok_or_else(|| RpcError::invalid_params("accessList must be an array"))?
        {
            let address =
                Address::from_str(item.get("address").and_then(Value::as_str).unwrap_or(""))
                    .map_err(|_| RpcError::invalid_params("invalid access-list address"))?;
            let keys = item
                .get("storageKeys")
                .and_then(Value::as_array)
                .ok_or_else(|| RpcError::invalid_params("invalid storageKeys"))?;
            let storage_keys = keys
                .iter()
                .map(|value| {
                    B256::from_str(value.as_str().unwrap_or(""))
                        .map_err(|_| RpcError::invalid_params("storage key must be 32 bytes"))
                })
                .collect::<Result<Vec<_>, _>>()?;
            access.push(AccessListItem {
                address,
                storage_keys,
            });
        }
    }
    Ok(TxEnv {
        tx_type: 2,
        caller: Address::from_str(&from).map_err(|_| RpcError::invalid_params("invalid caller"))?,
        kind,
        value: quantity("value", U256::ZERO)?,
        gas_limit,
        gas_price: 0,
        gas_priority_fee: Some(0),
        nonce: u64::try_from(quantity(
            "nonce",
            U256::from(contracts.account(&from).nonce),
        )?)
        .map_err(|_| RpcError::invalid_params("nonce exceeds u64"))?,
        data: data.into(),
        access_list: AccessList(access),
        chain_id: Some(chain_id),
        ..TxEnv::default()
    })
}

pub(super) fn receipt_rpc(
    block: &FinalizedNativeBlock,
    index: usize,
    tx: &NativeTransaction,
) -> Value {
    let execution = block.proposal.evm.as_ref().expect("EVM receipt block");
    let receipt = &execution.receipts[index];
    let previous = execution.receipts.iter().take(index);
    let offset = previous.clone().map(|r| r.logs.len()).sum::<usize>();
    let gas = previous.map(|r| r.gas_used).sum::<u64>() + receipt.gas_used;
    json!({
        "transactionHash": tx.hash, "transactionIndex": to_quantity_u64(index as u64),
        "blockHash": block.proposal.hash, "blockNumber": to_quantity_u64(block.proposal.number),
        "from": tx.from, "to": if tx.to == "0x" { Value::Null } else { json!(tx.to) },
        "cumulativeGasUsed": to_quantity_u64(gas), "gasUsed": to_quantity_u64(receipt.gas_used),
        "effectiveGasPrice": "0x0", "contractAddress": receipt.contract_address,
        "logs": receipt.logs.iter().enumerate().map(|(i, log)| log_rpc(block, index, offset + i, tx, log)).collect::<Vec<_>>(),
        "logsBloom": evm::logs_bloom(&receipt.logs), "type": "0x2",
        "status": if receipt.success { "0x1" } else { "0x0" },
    })
}

fn log_rpc(
    block: &FinalizedNativeBlock,
    index: usize,
    log_index: usize,
    tx: &NativeTransaction,
    log: &EvmLog,
) -> Value {
    json!({ "address": log.address, "topics": log.topics, "data": log.data, "removed": false,
        "blockHash": block.proposal.hash, "blockNumber": to_quantity_u64(block.proposal.number),
        "transactionHash": tx.hash, "transactionIndex": to_quantity_u64(index as u64), "logIndex": to_quantity_u64(log_index as u64) })
}

fn get_logs(params: &Value, state: &NativeChainState) -> Result<Value, RpcError> {
    let filter = params
        .as_array()
        .and_then(|p| p.first())
        .and_then(Value::as_object)
        .ok_or_else(|| RpcError::invalid_params("expected a log filter"))?;
    let latest = state.latest_number();
    let (from, to) = if let Some(hash) = filter.get("blockHash") {
        if filter.contains_key("fromBlock") || filter.contains_key("toBlock") {
            return Err(RpcError::invalid_params(
                "blockHash cannot be combined with a range",
            ));
        }
        let hash = hash
            .as_str()
            .ok_or_else(|| RpcError::invalid_params("invalid block hash"))?;
        B256::from_str(hash).map_err(|_| RpcError::invalid_params("invalid block hash"))?;
        let block = state
            .block_by_hash(hash)
            .ok_or_else(|| RpcError::internal("unknown block hash"))?;
        (block.proposal.number, block.proposal.number)
    } else {
        let tag = |name: &str| -> Result<u64, RpcError> {
            let value = filter
                .get(name)
                .map(|v| {
                    v.as_str()
                        .ok_or_else(|| RpcError::invalid_params("invalid block tag"))
                })
                .transpose()?
                .unwrap_or("latest");
            parse_block_tag(value, latest)
        };
        (tag("fromBlock")?, tag("toBlock")?)
    };
    if from > to || to > latest {
        return Err(RpcError::invalid_params("invalid finalized log range"));
    }
    if to - from >= 128 {
        return Err(RpcError {
            code: -32005,
            message: "log range exceeds 128 blocks".into(),
            data: None,
        });
    }
    let addresses = match filter.get("address") {
        None => Vec::new(),
        Some(Value::String(s)) => vec![normalize_evm_address(s)
            .ok_or_else(|| RpcError::invalid_params("invalid log address"))?],
        Some(Value::Array(a)) => a
            .iter()
            .map(|v| {
                normalize_evm_address(v.as_str().unwrap_or(""))
                    .ok_or_else(|| RpcError::invalid_params("invalid log address"))
            })
            .collect::<Result<Vec<_>, _>>()?,
        _ => return Err(RpcError::invalid_params("invalid log address filter")),
    };
    let topic = |v: &Value| -> Result<String, RpcError> {
        B256::from_str(v.as_str().unwrap_or(""))
            .map(|v| format!("{v:#x}"))
            .map_err(|_| RpcError::invalid_params("topic must be 32 bytes"))
    };
    let topics = match filter.get("topics") {
        None => Vec::new(),
        Some(Value::Array(a)) if a.len() <= 4 => a
            .iter()
            .map(|v| match v {
                Value::Null => Ok(None),
                Value::Array(a) if a.iter().any(Value::is_null) => Ok(None),
                Value::Array(a) => a.iter().map(topic).collect::<Result<Vec<_>, _>>().map(Some),
                _ => topic(v).map(|t| Some(vec![t])),
            })
            .collect::<Result<Vec<_>, _>>()?,
        _ => {
            return Err(RpcError::invalid_params(
                "topics must contain at most four positions",
            ))
        }
    };
    let mut result = Vec::new();
    for block in &state.blocks[from as usize..=to as usize] {
        if let Some(execution) = &block.proposal.evm {
            let mut offset = 0usize;
            for (index, receipt) in execution.receipts.iter().enumerate() {
                for (i, log) in receipt.logs.iter().enumerate() {
                    let address_matches = addresses.is_empty() || addresses.contains(&log.address);
                    let topic_matches = log.topics.len() >= topics.len()
                        && topics.iter().enumerate().all(|(i, options)| {
                            options.as_ref().is_none_or(|a| a.contains(&log.topics[i]))
                        });
                    if address_matches && topic_matches {
                        result.push(log_rpc(
                            block,
                            index,
                            offset + i,
                            &block.proposal.transactions[index],
                            log,
                        ));
                        if result.len() > 256 {
                            return Err(RpcError {
                                code: -32005,
                                message: "log result exceeds 256 records; narrow the filter".into(),
                                data: None,
                            });
                        }
                    }
                }
                offset += receipt.logs.len();
            }
        }
    }
    Ok(json!(result))
}

fn fee_history(params: &Value, state: &NativeChainState) -> Result<Value, RpcError> {
    let value = params
        .as_array()
        .and_then(|p| p.first())
        .ok_or_else(|| RpcError::invalid_params("missing block count"))?;
    let count = match value {
        Value::String(count) => {
            u64::try_from(evm::parse_quantity(count).map_err(RpcError::invalid_params)?)
                .map_err(|_| RpcError::invalid_params("block count exceeds u64"))?
        }
        Value::Number(count) => count
            .as_u64()
            .ok_or_else(|| RpcError::invalid_params("block count must be unsigned"))?,
        _ => return Err(RpcError::invalid_params("invalid block count")),
    };
    if !(1..=64).contains(&count) {
        return Err(RpcError::invalid_params(
            "block count must be between 1 and 64",
        ));
    }
    let newest = requested_block(params, 1, state.latest_number())?;
    if newest > state.latest_number() {
        return Err(RpcError::invalid_params("newest block is not finalized"));
    }
    let percentiles = params
        .as_array()
        .and_then(|p| p.get(2))
        .map(|v| {
            v.as_array()
                .ok_or_else(|| RpcError::invalid_params("reward percentiles must be an array"))
        })
        .transpose()?;
    let mut previous = 0.0;
    if let Some(values) = percentiles {
        for value in values {
            let value = value
                .as_f64()
                .filter(|v| v.is_finite() && (0.0..=100.0).contains(v))
                .ok_or_else(|| RpcError::invalid_params("invalid reward percentile"))?;
            if value < previous {
                return Err(RpcError::invalid_params(
                    "reward percentiles must be sorted",
                ));
            }
            previous = value;
        }
    }
    let count = count.min(newest + 1);
    let oldest = newest + 1 - count;
    let ratios = state.blocks[oldest as usize..=newest as usize]
        .iter()
        .map(|b| {
            b.proposal
                .evm
                .as_ref()
                .map(|e| e.gas_used as f64 / evm::BLOCK_GAS_LIMIT as f64)
                .unwrap_or(b.proposal.transactions.len() as f64 * 21_000.0 / 30_000_000.0)
        })
        .collect::<Vec<_>>();
    Ok(
        json!({ "oldestBlock": to_quantity_u64(oldest), "baseFeePerGas": vec!["0x0"; count as usize + 1],
        "gasUsedRatio": ratios, "reward": vec![vec!["0x0"; percentiles.map_or(0, Vec::len)]; count as usize] }),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn contracts() -> evm::EvmChainState {
        evm::EvmChainState::from_native(1, &std::collections::BTreeMap::new())
    }

    #[test]
    fn contract_call_parameters_are_typed_and_replay_protected() {
        let state = contracts();
        let address = format!("0x{}", "09".repeat(20));
        for call in [
            json!({"to": address, "gas": "0x0"}),
            json!({"to": address, "chainId": "0x1"}),
            json!({"to": address, "gasPrice": "0x1"}),
            json!({"to": address, "data": "0x00", "input": "0x01"}),
            json!({"to": address, "value": "0x"}),
            json!({"to": address, "blobVersionedHashes": []}),
            json!({"to": address, "accessList": [{"address": address, "storageKeys": ["0x0"]}]}),
        ] {
            assert!(call_transaction(&json!([call]), 2026092601, &state).is_err());
        }
        let tx = call_transaction(
            &json!([{"to": null, "data": "0x00", "value": "0x0"}]),
            2026092601,
            &state,
        )
        .unwrap();
        assert_eq!(tx.kind, TxKind::Create);
        assert_eq!(tx.gas_limit, evm::BLOCK_GAS_LIMIT);
        assert_eq!(tx.chain_id, Some(2026092601));
        let tx = call_transaction(
            &json!([{"to": address, "accessList": [{"address": address,
            "storageKeys": [format!("0x{}", "00".repeat(32))]}]}]),
            2026092601,
            &state,
        )
        .unwrap();
        assert_eq!(tx.access_list.0.len(), 1);
        assert_eq!(tx.access_list.0[0].storage_keys.len(), 1);
    }

    #[test]
    fn invalid_block_tags_are_not_silently_treated_as_latest() {
        for value in [Value::Null, json!(false), json!(100), json!({})] {
            assert!(requested_block(&json!(["0x00", value]), 1, 13).is_err());
        }
        assert_eq!(
            requested_block(&json!(["0x00", "earliest"]), 1, 13).unwrap(),
            0
        );
        assert_eq!(requested_block(&json!(["0x00"]), 1, 13).unwrap(), 13);
    }

    #[test]
    fn revert_data_preserves_standard_rpc_error_envelope() {
        let result = ExecutionResult::Revert {
            gas: Default::default(),
            logs: Vec::new(),
            output: vec![0xde, 0xad].into(),
        };
        let error = successful_output(&result).unwrap_err();
        assert_eq!(error.code, 3);
        assert_eq!(error.data.unwrap(), json!("0xdead"));
    }
}
