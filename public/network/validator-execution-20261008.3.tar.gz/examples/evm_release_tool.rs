//! File-backed operator transaction signer for the MFENX execution profile.
use k256::ecdsa::SigningKey;
use power_house::net::{evm, native_chain::decode_hex_prefixed};
use rlp::{Rlp, RlpStream};
use serde::Deserialize;
use std::{env, fs};

#[derive(Deserialize)]
struct Request {
    nonce: u64,
    to: Option<String>,
    data: String,
    gas: u64,
    #[serde(default)]
    value: Option<String>,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args().collect();
    if args.len() != 5 {
        return Err("usage: evm_release_tool KEYFILE CHAIN sign REQUEST.json".into());
    }
    let signing = SigningKey::from_slice(&fs::read(&args[1])?)?;
    let chain: u64 = args[2].parse()?;
    // Argument four is an explicit operation, so accidental invocations fail closed.
    if args[3] != "sign" {
        return Err("operation must be sign".into());
    }
    let request: Request = serde_json::from_slice(&fs::read(&args[4])?)?;
    let to = request
        .to
        .map(|s| decode_hex_prefixed(&s))
        .transpose()
        .map_err(std::io::Error::other)?
        .unwrap_or_default();
    let data = decode_hex_prefixed(&request.data).map_err(std::io::Error::other)?;
    let value = evm::parse_quantity(request.value.as_deref().unwrap_or("0x0"))
        .map_err(std::io::Error::other)?;
    let bytes = value.to_be_bytes::<32>();
    let first = bytes.iter().position(|b| *b != 0).unwrap_or(bytes.len());
    let mut unsigned = RlpStream::new_list(9);
    unsigned
        .append(&chain)
        .append(&request.nonce)
        .append(&0u64)
        .append(&0u64)
        .append(&request.gas)
        .append(&to)
        .append(&&bytes[first..])
        .append(&data);
    unsigned.begin_list(0);
    let encoded = unsigned.out();
    let mut payload = vec![2];
    payload.extend_from_slice(&encoded);
    let (signature, recovery) = signing.sign_prehash_recoverable(&evm::digest(&payload))?;
    let fields = Rlp::new(&encoded);
    let mut signed = RlpStream::new_list(12);
    for index in 0..9 {
        signed.append_raw(fields.at(index)?.as_raw(), 1);
    }
    signed.append(&u8::from(recovery));
    for scalar in [signature.r().to_bytes(), signature.s().to_bytes()] {
        let first = scalar.iter().position(|b| *b != 0).unwrap_or(scalar.len());
        signed.append(&&scalar[first..]);
    }
    let mut raw = vec![2];
    raw.extend_from_slice(&signed.out());
    let transaction = evm::decode_transaction(&raw, chain).map_err(std::io::Error::other)?;
    println!("{}", serde_json::to_string(&transaction)?);
    Ok(())
}
