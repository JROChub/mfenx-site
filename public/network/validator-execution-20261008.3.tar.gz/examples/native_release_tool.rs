//! Private operator acceptance helper. Not part of the deployed network binary.
use k256::ecdsa::SigningKey;
use power_house::net::native_chain::{decode_eip1559_transaction, NativeChainState};
use rlp::RlpStream;
use sha3::{Digest, Keccak256};
use std::{env, fs};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = env::args().collect();
    if args.get(1).map(String::as_str) == Some("plan-state") && args.len() == 5 {
        let mut state: NativeChainState = serde_json::from_slice(&fs::read(&args[2])?)?;
        state
            .enable_evm(args[3].parse()?)
            .map_err(std::io::Error::other)?;
        fs::write(&args[4], serde_json::to_vec_pretty(&state)?)?;
        println!(
            "{}",
            serde_json::json!({"height": state.latest_number(), "tip": state.latest_hash(),
            "activation_height": state.evm.as_ref().unwrap().activation_height,
            "state_root": state.evm.as_ref().unwrap().root()})
        );
        return Ok(());
    }
    if args.get(1).map(String::as_str) == Some("validate-state") && args.len() == 3 {
        let state: NativeChainState = serde_json::from_slice(&fs::read(&args[2])?)?;
        state.validate().map_err(std::io::Error::other)?;
        println!(
            "{}",
            serde_json::json!({"chain_id": state.chain_id,
            "height": state.latest_number(), "tip": state.latest_hash(),
            "genesis_hash": state.blocks[0].proposal.hash,
            "validators": state.validators.len(), "quorum": state.quorum,
            "execution_profile": state.evm.as_ref().map(|_| power_house::net::evm::PROFILE),
            "activation_height": state.evm.as_ref().map(|s| s.activation_height),
            "contract_state_root": state.evm.as_ref().map(|s| s.root())})
        );
        return Ok(());
    }
    if args.get(1).map(String::as_str) != Some("sign-transfers") || args.len() != 5 {
        return Err(
            "usage: native_release_tool validate-state FILE | sign-transfers KEYFILE CHAIN COUNT"
                .into(),
        );
    }
    let secret = fs::read(&args[2])?;
    let signing = SigningKey::from_slice(&secret)?;
    let chain_id: u64 = args[3].parse()?;
    let count: u64 = args[4].parse()?;
    let mut transactions = Vec::new();
    for nonce in 0..count {
        let mut unsigned = RlpStream::new_list(9);
        unsigned
            .append(&chain_id)
            .append(&nonce)
            .append(&0u64)
            .append(&0u64)
            .append(&21_000u64)
            .append(&[9u8; 20].as_slice())
            .append(&1_000_000_000_000_000_000u128)
            .append(&&[][..]);
        unsigned.begin_list(0);
        let mut payload = vec![2];
        payload.extend_from_slice(&unsigned.out());
        let digest: [u8; 32] = Keccak256::digest(&payload).into();
        let (signature, recovery) = signing.sign_prehash_recoverable(&digest)?;
        let mut signed = RlpStream::new_list(12);
        signed
            .append(&chain_id)
            .append(&nonce)
            .append(&0u64)
            .append(&0u64)
            .append(&21_000u64)
            .append(&[9u8; 20].as_slice())
            .append(&1_000_000_000_000_000_000u128)
            .append(&&[][..]);
        signed.begin_list(0);
        signed
            .append(&u8::from(recovery))
            .append(&signature.r().to_bytes().as_slice())
            .append(&signature.s().to_bytes().as_slice());
        let mut raw = vec![2];
        raw.extend_from_slice(&signed.out());
        transactions
            .push(decode_eip1559_transaction(&raw, chain_id).map_err(std::io::Error::other)?);
    }
    println!("{}", serde_json::to_string(&transactions)?);
    Ok(())
}
