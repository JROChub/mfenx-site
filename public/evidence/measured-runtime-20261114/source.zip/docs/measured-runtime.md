Measured runtime references

Gate 1.1.0rc4 adds an explicit encrypted-policy v2 path for a self-contained
TDX EFI RAM-root workload. This is a reference implementation with tested
parsing, policy enforcement and measured boot. Confidential model execution
remains unqualified on the inspected allocations: the broker denied the key
because the platform did not satisfy the required firmware baseline. Neither
CPU nor GPU protected model inference is represented as completed.

Compatibility and scope

Encrypted-policy v1 retains its exact Initdata requirement. The v2 policy adds
`attestation_profile`, selecting `tdx-efi-ram-cpu/v1` or
`tdx-efi-ram-nvidia/v1`. The CPU selection requires the existing owned-byte CPU
inference profile; the NVIDIA selection requires its existing CUDA12 profile
and both authenticated CPU and GPU submodules. Unknown profiles and mismatched
runtime selections reject. Selecting the CPU profile does not qualify GPU
execution. Receipt v1 signatures, model identities, PHA canonicalization and
Rootprint identities are unchanged.

The v2 path deliberately does not supply a fictitious launch-time MRCONFIGID.
Instead, the authenticated quote must identify the complete approved EFI image,
kernel, command line and initial filesystem through their measured boot
transcripts. Only independently approved references can authorize that path.
The old Initdata path cannot accept a boot reference as a substitute.

Reference format and authority

`BootReference.from_bytes` accepts a bounded, independently SHA-256-pinned
`mfenx/tdx-efi-ram-reference/v1` object. Its fields are:

| Field | Required meaning |
| --- | --- |
| `attestation_profile` | Exact explicit CPU or NVIDIA profile |
| `encrypted_policy_sha256` | Approved complete encrypted policy |
| `minimum_tcb_evaluation_number` | Protected minimum Intel appraisal-data counter; positive integer |
| `quote` | Exact `mr_td`, `mr_config_id`, `xfam`, and `rtmr_0` through `rtmr_3` values |
| `image_authenticode_sha384` | Approved loaded EFI image measurement |
| `kernel_authenticode_sha384` | Approved loaded kernel PE measurement |
| `gpt_sha384` | Approved measured partition-table event |
| `command_line_sha384` | SHA-384 of the measured UTF-16LE command line including its terminating NUL |
| `initrd_sha384` | SHA-384 of the complete initial filesystem byte stream |

The parser recomputes the complete RTMR1 and RTMR2 digest-extension sequences;
it rejects inconsistent artifact references and requires RTMR3 to remain zero
for this profile. Firmware and its configuration still require independent
approval. Copying measurements from an unreviewed guest is not approval.
Authenticode measurement is distinct from a raw-file distribution hash.

The generated attestation rule requires Intel-native evidence, debug disabled,
matching references, unexpired collateral, both `tcb_status` and
`tcb_status_current` equal to `UpToDate`, and the protected minimum appraisal
counter. The resource rule independently checks those TCB fields, the exact
model-key resource and the selected submodule count. It uses the broker's clock
to enforce a positive remaining policy lifetime of at most 300 seconds. The
existing guest-side policy check and serving lease remain required. A key
already delivered cannot be retracted by subsequently denying new requests.

The observed counter floor is 22. It is an explicit deployment-policy choice,
not a timeless assertion that counter 22 will always be sufficient. Update the
floor and approved references through protected authority as vendor recovery
requirements change. A fresh signature or recent collateral issue date does not
by itself establish that the selected appraisal channel contains the required
recovery baseline.

Image construction

`integrations/measured_boot/build_probe.py` builds GRUB with an embedded kernel,
initial filesystem and locked configuration. Trusted runtime-tree inputs become
part of those measured bytes. The RAM-root bootstrap does not mount the model
source disk or activate its swap. Its optional diagnostic interface returns
hardware evidence; the alternative SSH interface accepts only an explicitly
embedded operator public key and generates its host key inside the guest.
The trusted operator and build environment remain within the workload's trust
boundary. The builder never embeds a model key or release-authority private key
on the caller's behalf. Review every supplied runtime-tree file before building.

The bounded CCEL parser replays all four SHA-384 registers and requires the
complete independently specified executable and kernel-input transcripts. Event
labels alone are insufficient: an attacker can relabel an event without changing
its extended digest. Extra, missing or reordered executable measurements deny.
The reference implementation does not attempt to authorize every possible UEFI
boot sequence or claim a universal event-log verifier.

The inspected firmware was independently identified as Ubuntu
`ovmf_2025.02-8ubuntu3_all.deb`, package SHA-256
`498438a464ca4f110dd5e92bfd810bc501fdb5482d4e094af603776caf33a485`.
The archive signature and package-index hash were verified. The measured
`OVMF.fd` identity was reproduced using virtee/tdx-measure revision
`08fc6201b576e8f19a16252125f416d8203a93a3` and matched the authenticated MRTD.
Package identity is not a security review or qualification of that firmware.
UEFI vulnerability applicability remains part of deployment commissioning.

Observed enforcement

On 14 November 2026 a tenant-built EFI image actually booted on a Voltage TDX
allocation. A subsequent image contained the pinned CPU runtime, native client,
encrypted model and policy. Its MRTD, MRCONFIGID, XFAM and all four RTMR values
matched the independently supplied references. Native appraisal identified its
executables and configuration; the model-key request still failed because the
platform hardware appraisal was contraindicated with `OutOfDate` TCB status.
No protected model inference or model-key delivery was recorded as successful.

The separate Python evaluator initially used Intel's standard channel, which
returned appraisal number 20 and `UpToDate`. Evaluating the same quote using
Intel-signed early-channel number 22 reproduced `OutOfDate`, consistent with the
native verifier. The early appraisal included TDX module and platform advisories.
These channels are different policy inputs; the discrepancy was not resolved by
ignoring the newer one. Remediation requires a platform whose fresh appraisal
meets the protected floor and required security status, followed by complete
key-release, decryption, inference, revocation and recovery testing.

Regression evidence

The CPU/compatibility selection executes 99 tests, including retained model
loading, Receipt v1, lineage, bundle acquisition and the measured-boot tests.
Thirteen separately selected local Trustee tests exercise the actual TLS,
signed-token, Rego and recipient-bound resource implementation. Synthetic EAR
controls prove policy behavior, not vendor authenticity or confidential
execution. The local rules reject stale appraisal counters, out-of-date status,
expired collateral, debug mode, altered registers and invalid policy windows.
The retained hardware observations separately establish real boot and denial.

References

- [Pinned native verifier collateral policy](https://github.com/confidential-containers/trustee/blob/512fed65642015b849f38fb13bfdec7806639987/deps/verifier/src/intel_dcap/mod.rs)
- [Intel TCB recovery requirements](https://github.com/intel/Intel-affected-processor-list)
- [Intel TDX module advisory INTEL-SA-01436](https://www.intel.com/content/www/us/en/security-center/advisory/intel-sa-01436.html)
- [Intel ACTM advisory INTEL-SA-01439](https://www.intel.com/content/www/us/en/security-center/advisory/intel-sa-01439.html)
- [Ubuntu snapshot used for firmware identity](https://snapshot.ubuntu.com/ubuntu/20251010T000000Z/)
