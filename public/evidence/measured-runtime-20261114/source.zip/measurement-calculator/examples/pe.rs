fn main() -> anyhow::Result<()> { for f in std::env::args().skip(1) { let data=std::fs::read(&f)?; println!("{} {}",f,hex::encode(tdx_measure::research_pe_hash(&data)?)); } Ok(()) }
