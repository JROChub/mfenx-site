"""Assemble independently pinned encrypted-deployment policy and launch data."""
import argparse
import json
from pathlib import Path

from mfenx_gate.admission import AdmissionPolicy
from mfenx_gate.encrypted import Descriptor, EncryptedPolicy
from mfenx_gate.receipt import ReceiptError, canonical, read_regular, sha256
from mfenx_gate.trustee_policy import resource_policy


def prepare(args):
    inner=read_regular(args.admission_policy)
    AdmissionPolicy.from_bytes(inner,expected_sha256=args.approved_admission_sha256)
    raw=read_regular(args.descriptor)
    descriptor=Descriptor.from_bytes(raw,expected_sha256=args.approved_descriptor_sha256)
    ca=read_regular(args.broker_ca,64*1024)
    if sha256(ca)!=args.approved_broker_ca_sha256:
        raise ReceiptError("broker CA does not match independent approval")
    document={"schema":"mfenx/encrypted-admission-policy/v1", "admission":json.loads(inner),
              "descriptor_sha256":descriptor.digest, "broker_url":args.broker_url,
              "broker_ca_sha256":args.approved_broker_ca_sha256,
              "trustee_client_sha256":args.approved_trustee_client_sha256}
    raw=canonical(document);policy=EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))
    rego=resource_policy(policy,descriptor,cpu_tee=args.cpu_tee)
    outputs={"policy.json":raw,"initdata.toml":policy.init_data.encode("ascii"),
             "resource-policy.rego":rego.encode("ascii")}
    report={"schema":"mfenx/encrypted-policy-build/v1", "policy_sha256":policy.digest,
            "initdata_raw_sha256":sha256(outputs['initdata.toml']),
            "resource_policy_sha256":sha256(outputs['resource-policy.rego']),
            "resource":descriptor.context['resource'],"hardware_qualified":False}
    outputs['build.json']=json.dumps(report,indent=2).encode()+b'\n'
    args.output.mkdir(mode=0o700)
    for name,data in outputs.items():
        with (args.output/name).open('xb') as handle:handle.write(data)
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['admission-policy','descriptor','broker-ca','output']:
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ['approved-admission-sha256','approved-descriptor-sha256','approved-broker-ca-sha256',
                 'approved-trustee-client-sha256','broker-url']:
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--cpu-tee',choices=['tdx','snp'],required=True)
    args=parser.parse_args()
    try:print(json.dumps(prepare(args),sort_keys=True))
    except (ReceiptError,OSError) as exc:parser.exit(2,str(exc)+'\n')
