"""Single-deployment HTTP transport over the existing admitted serving handle.

Operator configuration and the process/kernel are trusted. Use behind a trusted
TLS proxy. This transport does not provide confidential execution, fleet quotas
or a multi-tenant control plane. No client can select model paths or trust roots.
"""
from __future__ import annotations

import argparse
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import re
import resource
import signal
import stat
import select
import subprocess
import sys
import time

from mfenx_gate.admission import AdmissionPolicy, PolicyAuthority, ServingSession, admit_model
from mfenx_gate.receipt import ReceiptError, read_regular


_WATCHDOG = """import os,select,signal,sys,time
fd=int(sys.argv[1]);deadline=int(sys.argv[2])
signal.pidfd_send_signal(fd,0)
sys.stdout.buffer.write(b'R');sys.stdout.buffer.flush()
ready=select.select([sys.stdin.buffer],[],[],max(0,(deadline-time.monotonic_ns())/1e9))[0]
if not ready:
 try:signal.pidfd_send_signal(fd,signal.SIGKILL)
 except ProcessLookupError:pass
"""


class Deadline:
    """Independent Linux watchdog: native code cannot suppress it by holding the GIL."""
    def __init__(self, seconds):
        self.end = time.monotonic_ns() + int(seconds * 1_000_000_000)
        self.child = None

    def __enter__(self):
        try:
            descriptor = os.pidfd_open(os.getpid(), 0)
        except (AttributeError, OSError) as error:
            raise ReceiptError('Linux pidfd deadline supervision is unavailable') from error
        try:
            self.child = subprocess.Popen([sys.executable, '-I', '-c', _WATCHDOG, str(descriptor), str(self.end)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                env={'PATH':os.defpath,'LANG':'C.UTF-8'}, close_fds=True,
                pass_fds=(descriptor,), start_new_session=True)
            remaining = max(0, (self.end-time.monotonic_ns())/1e9)
            ready = select.select([self.child.stdout], [], [], min(remaining, 5))[0]
            if not ready or self.child.stdout.read(1) != b'R':
                self._cancel()
                raise ReceiptError('Independent deadline supervisor failed to start')
            self.child.stdout.close()
        finally:
            os.close(descriptor)
        return self

    def check(self):
        if time.monotonic_ns() >= self.end:
            os.kill(os.getpid(), signal.SIGKILL)

    def _cancel(self):
        if self.child is not None:
            if self.child.stdin and not self.child.stdin.closed:
                try:self.child.stdin.close()
                except BrokenPipeError:pass
            try:self.child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.child.kill();self.child.wait(timeout=1)
            if self.child.stdout and not self.child.stdout.closed:self.child.stdout.close()

    def __exit__(self, *_):
        self.check()
        self._cancel()


def token_from_path(path):
    metadata = path.lstat()
    if (not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.geteuid()
            or metadata.st_mode & 0o077):
        raise ReceiptError('Access token requires an owner-only regular file')
    token = read_regular(path, 256).decode('ascii').strip()
    if re.fullmatch(r'[A-Za-z0-9_-]{43,128}', token) is None:
        raise ReceiptError('Use a cryptographically random access token of at least 32 bytes')
    return token


def input_document(raw):
    depth = 0
    quoted = escaped = False
    for byte in raw:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
        elif byte in (91, 123):
            depth += 1
            if depth > 128:
                raise ValueError('input nesting limit')
        elif byte in (93, 125):
            depth -= 1
    def unique(items):
        result = {}
        for name, value in items:
            if name in result:
                raise ValueError('duplicate input key')
            result[name] = value
        return result
    def reject(_):
        raise ValueError('nonfinite input number')
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject)


def serve(args):
    import numpy as np
    if not 1 <= args.request_seconds <= 120 or not 1 <= args.startup_seconds <= 180:
        raise ReceiptError('Unsupported gateway deadline')
    token = token_from_path(args.access_token_file)
    with Deadline(args.startup_seconds):
        evidence = dict(receipt=read_regular(args.receipt), trusted_public_key=read_regular(args.trusted_public_key, 4096),
                        lineage=input_document(read_regular(args.lineage, 1024*1024)) if args.lineage else None,
                        execution_proof=read_regular(args.execution_proof, 4*1024*1024) if args.execution_proof else None,
                        proof_verifier=args.proof_verifier)
        encrypted_arguments = [args.encrypted_descriptor, args.trustee_client, args.broker_ca]
        if any(encrypted_arguments):
            if not all(encrypted_arguments):
                raise ReceiptError('Encrypted loading requires descriptor, Trustee client and broker CA')
            from mfenx_gate.encrypted import EncryptedPolicy, admit_encrypted_model
            encrypted_policy = EncryptedPolicy.from_bytes(read_regular(args.policy),
                                                          expected_sha256=args.expected_policy_sha256)
            policy = encrypted_policy.admission
            authority = PolicyAuthority(policy, state_path=args.state)
            model = admit_encrypted_model(**evidence, ciphertext=args.model,
                descriptor=read_regular(args.encrypted_descriptor), policy=encrypted_policy,
                trustee_client=args.trustee_client, broker_ca=args.broker_ca)
        else:
            policy = AdmissionPolicy.from_bytes(read_regular(args.policy), expected_sha256=args.expected_policy_sha256)
            authority = PolicyAuthority(policy, state_path=args.state)
            model = admit_model(**evidence, model=args.model, policy=policy)
        session = ServingSession(model, authority)
        # Metadata belongs to the already admitted runtime object; no path is reopened.
        specifications = {item.name:item for item in session._session.get_inputs()}
        if not specifications or any(item.type != 'tensor(float)' for item in specifications.values()):
            session.close()
            raise ReceiptError('This transport supports dense Float32 model inputs only')

    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.0'
        server_version = 'MFENX Gate'
        sys_version = ''

        def setup(self):
            super().setup()
            self.connection.settimeout(3)

        def log_message(self, *_):
            pass

        def respond(self, status, document):
            raw = json.dumps(document, allow_nan=False, separators=(',', ':')).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            self.respond(404, {'error':'unknown operation'})

        def do_POST(self):
            if self.path != '/v1/infer':
                return self.respond(404, {'error':'unknown operation'})
            authorization = self.headers.get_all('Authorization', [])
            authenticated = False
            if len(authorization) == 1:
                try:
                    authenticated = hmac.compare_digest(authorization[0].encode('ascii'), ('Bearer ' + token).encode('ascii'))
                except UnicodeEncodeError:
                    pass
            if not authenticated:
                return self.respond(401, {'error':'authorization required'})
            lengths = self.headers.get_all('Content-Length', [])
            if self.headers.get('Transfer-Encoding') or len(lengths) != 1 or not re.fullmatch(r'[1-9][0-9]{0,5}', lengths[0]):
                return self.respond(400, {'error':'bounded content length required'})
            length = int(lengths[0])
            if length > 65536:
                return self.respond(413, {'error':'request exceeds 64 KiB'})
            if self.headers.get('Content-Type', '').split(';',1)[0] != 'application/json':
                return self.respond(415, {'error':'JSON required'})
            try:
                raw = self.rfile.read(length)
                if len(raw) != length:
                    raise ValueError('incomplete request')
                document = input_document(raw)
                if type(document) is not dict or set(document) != {'inputs'} or type(document['inputs']) is not dict:
                    raise ValueError('wrong request fields')
                if set(document['inputs']) != set(specifications):
                    raise ValueError('wrong input names')
                inputs = {}
                for name, value in document['inputs'].items():
                    array = np.asarray(value, dtype=np.float32)
                    shape = specifications[name].shape
                    if (array.ndim != len(shape) or array.nbytes > 1024*1024 or not np.isfinite(array).all()
                            or any((type(expected) is int and actual != expected) or actual > 65536
                                   for actual,expected in zip(array.shape,shape))):
                        raise ValueError('unsupported input shape or values')
                    inputs[name] = array
            except (ValueError, TypeError, OverflowError, RecursionError, ReceiptError, OSError):
                return self.respond(400, {'error':'invalid inference inputs'})
            try:
                with Deadline(args.request_seconds) as deadline:
                    outputs = session.run(inputs)
                    if sum(item.nbytes for item in outputs) > 256*1024:
                        session.close()
                        raise ReceiptError('output exceeds transport limit')
                    result = {'outputs':[item.tolist() for item in outputs], 'model_sha256':model.artifact_digest,
                              'receipt_sha256':model.receipt_digest, 'policy_sha256':policy.digest,
                              'execution_proof_sha256':model.execution_proof_sha256,
                              'distribution_sha256':model.distribution_sha256,
                              'output_devices':list(session.last_output_devices)}
                    deadline.check()
                    self.respond(200, result)
            except ReceiptError:
                self.respond(503, {'error':'deployment requires readmission'})
            except (ValueError, RuntimeError):
                session.close()
                self.respond(503, {'error':'inference unavailable'})
            except (BrokenPipeError, ConnectionResetError):
                # A disconnected client receives no output; an in-flight native call
                # may finish. The whole-process wall deadline remains enforced.
                pass

    class Server(HTTPServer):
        request_queue_size = 4
        allow_reuse_address = False

    server = None
    try:
        server = Server((args.host, args.port), Handler)
        print(json.dumps({'listening':True, 'port':server.server_port,
                          'scope':policy.scope, 'runtime_profile':policy.runtime_profile}), flush=True)
        server.serve_forever(poll_interval=0.2)
    finally:
        if server is not None:
            server.server_close()
        try:
            session.close()
        except ReceiptError:
            pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['receipt','trusted-public-key','model','policy','state','access-token-file']:
        parser.add_argument('--'+name, type=Path, required=True)
    for name in ['execution-proof','proof-verifier','lineage','encrypted-descriptor','trustee-client','broker-ca']:
        parser.add_argument('--'+name, type=Path)
    parser.add_argument('--expected-policy-sha256', required=True)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--request-seconds', type=int, default=30)
    parser.add_argument('--startup-seconds', type=int, default=45)
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    def stop(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
    try:
        serve(args)
    except KeyboardInterrupt:
        return 0
    except (ReceiptError, OSError, ValueError, RuntimeError):
        print(json.dumps({'listening':False,'error':'admission or runtime initialization denied'}), flush=True)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
