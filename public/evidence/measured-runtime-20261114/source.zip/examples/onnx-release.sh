#!/usr/bin/env bash
# source candidate dataset approved-contract approved-digest key issuer receipt
set -euo pipefail
if [ "$#" -ne 8 ]; then
  printf '%s\n' 'Usage: bash onnx-release.sh SOURCE CANDIDATE DATASET CONTRACT APPROVED_SHA256 PRIVATE_KEY ISSUER RECEIPT' >&2
  exit 2
fi
mfenx-gate admit-onnx --source="$1" --candidate="$2" --dataset="$3" \
  --contract="$4" --expected-contract-sha256="$5" --private-key="$6" \
  --issuer="$7" --output="$8"
