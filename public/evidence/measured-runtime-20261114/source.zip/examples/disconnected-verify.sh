#!/usr/bin/env bash
# Install first from the separately verified local wheelhouse, with --no-index.
set -euo pipefail
if [ "$#" -ne 3 ]; then
  printf '%s\n' 'Usage: bash disconnected-verify.sh RECEIPT TRUSTED_PUBLIC_KEY MODEL' >&2
  exit 2
fi
mfenx-gate verify --trusted-public-key="$2" --model="$3" -- "$1"
