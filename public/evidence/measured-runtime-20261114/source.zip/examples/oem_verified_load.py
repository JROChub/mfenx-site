"""Verify immutable bytes and pass those exact bytes to the application's loader."""
from pathlib import Path
from typing import Callable, TypeVar

from mfenx_gate.receipt import read_regular, verify_receipt

T = TypeVar("T")


def verify_and_load(receipt: Path, trusted_key: Path, model: Path,
                    approved_contract_sha256: str, loader: Callable[[bytes], T]) -> T:
    # The loader never reopens the original path after verification.
    payload = read_regular(model, maximum=64 * 1024 * 1024)
    verify_receipt(read_regular(receipt), read_regular(trusted_key, 4096),
                   artifact_bytes=payload, expected_contract_digest=approved_contract_sha256)
    return loader(payload)


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("receipt", type=Path)
    p.add_argument("trusted_key", type=Path)
    p.add_argument("model", type=Path)
    p.add_argument("approved_contract_sha256")
    args = p.parse_args()
    def load_onnx(payload):
        import onnxruntime
        return onnxruntime.InferenceSession(payload, providers=["CPUExecutionProvider"])
    session = verify_and_load(args.receipt, args.trusted_key, args.model,
                              args.approved_contract_sha256, load_onnx)
    print("Verified exact model bytes loaded; inference has not been evaluated by this example.")
