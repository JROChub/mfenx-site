"""Prepare ciphertext distribution; keep the separately provisioned key private."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import stat

from mfenx_gate.admission import MAX_MODEL_BYTES
from mfenx_gate.encrypted import Descriptor, encrypt_model
from mfenx_gate.receipt import ReceiptError, read_regular, sha256


def prepare(*, model, receipt, trusted_public_key, distribution, key_file):
    distribution, key_file = Path(distribution), Path(key_file)
    if key_file.resolve().is_relative_to(distribution.resolve()):
        raise ReceiptError("key must be outside the distribution directory")
    metadata = key_file.parent.lstat()
    if (not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != os.geteuid()
            or metadata.st_mode & 0o077):
        raise ReceiptError("key destination requires an owner-only directory")
    package = encrypt_model(read_regular(Path(model), MAX_MODEL_BYTES),
        receipt=read_regular(Path(receipt)), trusted_public_key=read_regular(Path(trusted_public_key), 4096))
    descriptor = Descriptor.from_bytes(package.descriptor, expected_sha256=sha256(package.descriptor))
    report = {"schema":"mfenx/encrypted-distribution-build/v1", "descriptor_sha256":descriptor.digest,
              "ciphertext_sha256":descriptor.ciphertext_sha256,
              "model_sha256":descriptor.context["model_sha256"],
              "receipt_sha256":descriptor.context["receipt_sha256"],
              "resource":descriptor.context["resource"], "algorithm":"AES-256-GCM"}
    created, directory_created = [], False
    try:
        distribution.mkdir(mode=0o700)
        directory_created = True
        for path, data in [(key_file, package.key), (distribution/"descriptor.json", package.descriptor),
                           (distribution/"model.enc", package.ciphertext),
                           (distribution/"build.json", json.dumps(report, indent=2).encode()+b"\n")]:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            created.append(path)
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
        for path in [distribution, key_file.parent, distribution.parent]:
            fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
    except BaseException:
        for path in reversed(created):
            path.unlink(missing_ok=True)
        if directory_created:
            distribution.rmdir()
        raise
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ["model", "receipt", "trusted-public-key", "distribution", "key-file"]:
        parser.add_argument("--"+name, type=Path, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(prepare(**vars(args)), sort_keys=True))
    except (ReceiptError, OSError) as error:
        parser.exit(2, "Encrypted distribution denied: "+str(error)+"\n")


if __name__ == "__main__":
    main()
