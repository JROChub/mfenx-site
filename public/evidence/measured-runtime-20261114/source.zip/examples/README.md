# Five local integrations

Install the pinned Gate wheel from the release manifest first. The scripts do
not install arbitrary dependencies or make network requests. Keep issuer keys,
trust roots and approved policy digests in protected configuration rather than
candidate-controlled branches.

1. `bash onnx-release.sh SOURCE CANDIDATE DATASET CONTRACT APPROVED_SHA256 PRIVATE_KEY ISSUER RECEIPT`
   executes the approved finite ONNX contract and issues only on PASS. CKODMK
   0.5.1 production dependencies are required. Never run untrusted model
   evaluation in a privileged CI job containing production secrets.
2. `bash safetensors-integrity.sh MODEL PRIVATE_KEY ISSUER RECEIPT` inspects and
   signs one unsharded Safetensors checkpoint. It does not test behavior.
3. `model-gate-action/action.yml` is a composite action for an already installed
   `mfenx-gate 1.0.0`. Place it in a protected integration repository and refer to
   an immutable commit in consumer workflows. It verifies, never executes,
   candidate models. It uses no third-party actions and requests no credentials.
   Do not source the action, trust key or approved digest from an untrusted PR.
4. `python oem_verified_load.py RECEIPT TRUSTED_KEY MODEL APPROVED_SHA256` passes
   the exact immutable verified bytes to ONNX Runtime, avoiding a verify/reopen
   race. It authenticates issuer-attested approval; inference is not replayed.
   Loading hostile signed models still requires a suitable isolation boundary.
5. `bash disconnected-verify.sh RECEIPT TRUSTED_KEY MODEL` performs local
   verification after installing the release wheelhouse with `--no-index`.
   It neither contacts a license server nor uploads files. This example omits
   an expected policy digest; its output says `contractStatus: NOT_CHECKED`.

The examples do not grant OEM issuance rights or replace a deployment's trust
policy. Free verification rights are specified in `VERIFIER-TERMS.txt`.

Single-deployment serving transport

`serving_gateway.py` consumes the existing admitted handle, deployment policy
and durable authority. It binds its HTTP listener only after admission and
loading finish. Client requests contain Float32 inputs, never model paths,
release keys or deployment policy. A separate owner-only, randomly generated
32-byte access token gates the inference route. Run behind a trusted TLS proxy;
this is a single-deployment integration, not a multi-tenant organization API.

The process serializes requests, bounds JSON acquisition, rejects duplicate
keys, nonfinite values and nesting beyond 128 levels, and validates input names/shapes
before inference. Startup and inference use independent Linux pidfd watchdog processes. They
terminate an overdue gateway with SIGKILL even when a native call holds the
Python GIL. Returned output is also checked against the deadline before writing. This does not
promise hardware erasure or instant cancellation of already-running kernels.
The runtime arena setting is not a total GPU-memory or fleet-wide quota.

Protected operator arguments are `--receipt`, `--trusted-public-key`, `--model`,
`--policy`, `--expected-policy-sha256`, `--state` and `--access-token-file`.
Optional `--execution-proof` and `--proof-verifier` require the existing v2
policy. The default listener is loopback port 8000. `--host 0.0.0.0` is for a
trusted TLS proxy with access controls, not an unauthenticated public service.
Run the script with isolated Python startup from the qualified environment.
Changing policy epochs or revocations in the existing durable authority denies
subsequent requests; restart requires current independently approved evidence.

`tests/test_serving_gateway.py` observes actual HTTP outputs after pathname
replacement, denial before runtime calls, rejection before listening, durable
revocation, native-loop process termination and approved recovery. Its keys and
models are synthetic test fixtures, not production approvals.
