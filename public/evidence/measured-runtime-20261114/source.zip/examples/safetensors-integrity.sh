#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 4 ]; then
  printf '%s\n' 'Usage: bash safetensors-integrity.sh MODEL PRIVATE_KEY ISSUER RECEIPT' >&2
  exit 2
fi
mfenx-gate issue-integrity --model="$1" --private-key="$2" --issuer="$3" --output="$4"
