"""Bounded single-inference worker for the software-only CPU admission profile."""
from __future__ import annotations

import argparse
import base64
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import signal
import tempfile
import threading
import time

_WORKERS = threading.BoundedSemaphore(2)


def run_isolated(request: dict, *, memory_mb: int = 2048, cpu_seconds: int = 30,
                 wall_seconds: int = 45) -> dict:
    """Run verification, model parsing, loading and one inference in one child.

    rlimits bound address space and CPU, not cgroup aggregate memory. The child
    inherits no cloud credentials. This is resource isolation, not a hostile-host
    confidentiality or syscall sandbox. Caller concurrency must also be bounded.
    """
    from .receipt import ReceiptError
    for value, low, high in [(memory_mb, 256, 8192), (cpu_seconds, 1, 120), (wall_seconds, 1, 180)]:
        if type(value) is not int or not low <= value <= high:
            raise ReceiptError("unsupported worker resource limit")
    raw = json.dumps(request, allow_nan=False, ensure_ascii=True).encode("ascii")
    if len(raw) > 1024 * 1024:
        raise ReceiptError("worker request exceeds byte limit")
    env = {"PATH": os.defpath, "PYTHONPATH": str(Path(__file__).resolve().parents[1]),
           "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
           "PYTHONNOUSERSITE": "1"}
    command = [sys.executable, "-P", "-m", "mfenx_gate.worker", "--memory-mb", str(memory_mb),
               "--cpu-seconds", str(cpu_seconds)]
    if not _WORKERS.acquire(blocking=False):
        raise ReceiptError("concurrent admission worker limit reached")
    try:
        with tempfile.TemporaryFile() as output:
            with subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output,
                                  stderr=subprocess.DEVNULL, env=env, start_new_session=True) as child:
                try:
                    child.communicate(raw, timeout=wall_seconds)
                except subprocess.TimeoutExpired as exc:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.communicate()
                    raise ReceiptError("admission worker exceeded wall deadline and was terminated") from exc
                except BaseException:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.communicate()
                    raise
                output.seek(0)
                response = output.read(1024 * 1024 + 1)
                if child.returncode or len(response) > 1024 * 1024:
                    raise ReceiptError("admission worker rejected or exceeded a resource limit")
    finally:
        _WORKERS.release()
    try:
        value = json.loads(response)
        if value.get("schema") != "mfenx/isolated-inference-result/v1":
            raise ValueError("wrong result")
        return value
    except (ValueError, TypeError, AttributeError) as exc:
        raise ReceiptError("invalid worker result") from exc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--memory-mb", type=int, required=True)
    parser.add_argument("--cpu-seconds", type=int, required=True)
    args = parser.parse_args()
    if not 256 <= args.memory_mb <= 8192 or not 1 <= args.cpu_seconds <= 120:
        return 2
    started = time.monotonic()
    resource.setrlimit(resource.RLIMIT_AS, (args.memory_mb * 1024**2,) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (args.cpu_seconds,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (2 * 1024 * 1024,) * 2)
    resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
    from .admission import AdmissionPolicy, PolicyAuthority, ServingSession, admit_model, RUNTIME_PROFILE
    from .receipt import read_regular, ReceiptError
    try:
        raw = sys.stdin.buffer.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ReceiptError("oversized worker request")
        request = json.loads(raw)
        required = {"receipt", "trusted_key", "model", "policy", "policy_sha256", "state", "inputs"}
        if set(request) not in (required, required | {"lineage"}):
            raise ReceiptError("unsupported worker request")
        policy_raw = read_regular(Path(request["policy"]))
        policy = AdmissionPolicy.from_bytes(policy_raw, expected_sha256=request["policy_sha256"])
        if policy.runtime_profile != RUNTIME_PROFILE:
            raise ReceiptError("this address-space supervisor is qualified only for the CPU profile")
        authority = PolicyAuthority(policy, state_path=Path(request["state"]))
        lineage = None
        if request.get("lineage") is not None:
            def unique(items):
                result = {}
                for key, value in items:
                    if key in result:
                        raise ReceiptError("duplicate lineage key")
                    result[key] = value
                return result
            lineage = json.loads(read_regular(Path(request["lineage"]), 1024 * 1024), object_pairs_hook=unique)
        model = admit_model(receipt=read_regular(Path(request["receipt"])),
                            trusted_public_key=read_regular(Path(request["trusted_key"]), 4096),
                            model=Path(request["model"]), policy=policy, lineage=lineage)
        import numpy as np
        if type(request["inputs"]) is not dict or not 1 <= len(request["inputs"]) <= 8:
            raise ReceiptError("unsupported inference inputs")
        inputs = {name: np.asarray(value, dtype=np.float32) for name, value in request["inputs"].items()}
        if sum(v.nbytes for v in inputs.values()) > 1024 * 1024 or any(not np.isfinite(v).all() for v in inputs.values()):
            raise ReceiptError("invalid or oversized inference input")
        with ServingSession(model, authority) as session:
            outputs = session.run(inputs)
        if sum(v.nbytes for v in outputs) > 256 * 1024:
            raise ReceiptError("inference output exceeds worker result limit")
        result = {"schema": "mfenx/isolated-inference-result/v1", "model_sha256": model.artifact_digest,
                  "receipt_sha256": model.receipt_digest, "policy_sha256": policy.digest,
                  "runtime_profile": "onnx-cpu-owned-bytes/v1", "replay_status": "NOT_PERFORMED",
                  "outputs": [v.tolist() for v in outputs],
                  "resources": {"address_space_limit_bytes": args.memory_mb * 1024**2,
                                "cpu_limit_seconds": args.cpu_seconds,
                                "peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                                "elapsed_ms": round((time.monotonic() - started) * 1000)}}
        encoded = json.dumps(result, allow_nan=False).encode()
        if len(encoded) > 1024 * 1024:
            raise ReceiptError("oversized encoded inference output")
        sys.stdout.buffer.write(encoded)
        return 0
    except Exception:
        # No private paths, input data, runtime diagnostics or credentials in the result.
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
