"""Bounded Linux invocation of an independently approved upstream Trustee client."""
from __future__ import annotations

import base64
import fcntl
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading

from .receipt import ReceiptError, read_regular, sha256
from .execution import _sealed_verifier

_LIMIT = threading.BoundedSemaphore(2)
_LAUNCHER = """import ctypes,os,resource,signal,sys
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
libc=ctypes.CDLL(None,use_errno=True)
libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
libc.prctl.restype=ctypes.c_int
if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:raise OSError(ctypes.get_errno(),'parent-death supervision unavailable')
if os.getppid()!=int(sys.argv[1]):os.kill(os.getpid(),signal.SIGKILL)
signal.signal(signal.SIGXFSZ,signal.SIG_DFL)
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,)*2)
resource.setrlimit(resource.RLIMIT_CPU,(30,)*2)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
resource.setrlimit(resource.RLIMIT_FSIZE,(4096,4096))
resource.setrlimit(resource.RLIMIT_NOFILE,(128,128))
os.execve('/proc/self/fd/'+sys.argv[2],['kbs-client']+sys.argv[3:],os.environ)
"""


def retrieve_key(policy, *, resource: str, client: Path, ca: Path) -> bytes:
    """Upstream performs fresh attestation and recipient-bound resource delivery.

    Only this exact command is permitted: no cached token, supplied recipient
    private key, sample-attester selector or arbitrary command-line arguments.
    No key response is written to disk or included in an exception or log.
    """
    from .encrypted import EncryptedPolicy, RESOURCE
    if (type(policy) is not EncryptedPolicy or type(resource) is not str
            or not RESOURCE.fullmatch(resource) or sys.platform != "linux"):
        raise ReceiptError("unsupported encrypted key-delivery request")
    if not _LIMIT.acquire(blocking=False):
        raise ReceiptError("concurrent key-delivery limit reached")
    descriptors = []
    try:
        binary = _sealed_verifier(client, policy.trustee_client_sha256)
        descriptors.append(binary)
        certificate = read_regular(ca, 64*1024)
        if sha256(certificate) != policy.broker_ca_sha256:
            raise ReceiptError("broker certificate does not match protected policy")
        cert_fd = os.memfd_create("mfenx-broker-ca", os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING)
        descriptors.append(cert_fd)
        view = memoryview(certificate)
        while view:
            count = os.write(cert_fd, view)
            if count <= 0:
                raise ReceiptError("certificate acquisition did not progress")
            view = view[count:]
        seals = fcntl.F_SEAL_WRITE | fcntl.F_SEAL_GROW | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_SEAL
        fcntl.fcntl(cert_fd, fcntl.F_ADD_SEALS, seals)
        if fcntl.fcntl(cert_fd, fcntl.F_GET_SEALS) & seals != seals:
            raise ReceiptError("certificate snapshot was not sealed")
        response = os.memfd_create("mfenx-kbs-response", os.MFD_CLOEXEC)
        descriptors.append(response)
        command = [sys.executable, "-I", "-c", _LAUNCHER, str(os.getpid()), str(binary),
                   "--url", policy.broker_url, "--cert-file", "/proc/self/fd/"+str(cert_fd),
                   "get-resource", "--path", resource]
        if policy.init_data is not None:
            command.extend(["--init-data",policy.init_data])
        # Proxy variables, caller import paths, admin tokens and cached recipient
        # credentials must not enter the attestation/key-delivery subprocess.
        env = {"PATH":os.defpath, "LANG":"C.UTF-8", "RUST_LOG":"off"}
        with tempfile.TemporaryDirectory(prefix="mfenx-kbs-") as directory:
            with subprocess.Popen(command, pass_fds=(binary, cert_fd), stdin=subprocess.DEVNULL,
                    stdout=response, stderr=subprocess.DEVNULL, env=env, cwd=directory,
                    start_new_session=True) as child:
                try:
                    child.wait(timeout=45)
                except BaseException:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait()
                    raise
            raw = os.pread(response, 4097, 0)
            if child.returncode or len(raw) != 45 or raw[-1:] != b"\n":
                raise ReceiptError("Trustee denied key delivery or returned an invalid response")
            key = base64.b64decode(raw[:-1], validate=True)
            if len(key) != 32 or base64.b64encode(key)+b"\n" != raw:
                raise ReceiptError("Trustee did not return the approved 256-bit key format")
            return key
    except ReceiptError:
        raise
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        raise ReceiptError("attestation-bound key delivery failed") from exc
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)
        _LIMIT.release()
