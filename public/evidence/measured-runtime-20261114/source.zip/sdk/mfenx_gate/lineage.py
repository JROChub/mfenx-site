"""Application-level release lineage using the existing Power House Python SDK.

The graph records authenticated release relationships. It is not a proof that a
transformation was correctly implemented or that inference was executed.
"""
import copy
import base64
from datetime import timedelta
import json

from .receipt import ReceiptError, read_regular, sha256, timestamp, verify_receipt

PROFILE = "mfenx/model-release-lineage/v1"


def create_release_lineage(*, receipt: bytes, trusted_public_key: bytes, model,
                           approved_contract: str, transformation: str = "root",
                           parent_graph=None, parent_branch=None, expected_parent_replay=None):
    from power_house import create_artifact, new_rootprint, fork, replay_rootprint, verify_rootprint
    result = verify_receipt(receipt, trusted_public_key, artifact_bytes=read_regular(model, 64 * 1024 * 1024),
                            expected_contract_digest=approved_contract)
    statement = result["receipt"]["statement"]
    if statement["profile"] != "onnx-finite-evaluation/v1":
        raise ReceiptError("this lineage profile requires finite ONNX release evidence")
    public = {"model_sha256": statement["artifact"]["sha256"], "model_bytes": statement["artifact"]["bytes"],
              "receipt_sha256": sha256(receipt), "issuer_sha256": sha256(trusted_public_key),
              "contract_sha256": approved_contract, "report_sha256": statement["evaluation"]["report_sha256"],
              "parent_model_sha256": statement["parent_sha256"], "transformation": transformation}
    artifact = create_artifact({"producer": "mfenx-gate"}, PROFILE, public,
                                {"receipt_base64": base64.b64encode(receipt).decode("ascii")})
    if parent_graph is None:
        if parent_branch is not None or expected_parent_replay is not None or transformation != "root":
            raise ReceiptError("a lineage root cannot declare an unbound parent or transformation")
        return new_rootprint("release", artifact)
    verify_rootprint(parent_graph)
    if replay_rootprint(parent_graph)["state_fingerprint"] != expected_parent_replay:
        raise ReceiptError("parent lineage does not match independent replay approval")
    parent = parent_graph["branches"].get(parent_branch)
    if (not parent or transformation == "root"
            or parent["artifact"]["embedded_proof"]["protocol"] != PROFILE
            or parent["artifact"]["embedded_proof"]["public_inputs"]["model_sha256"] != statement["parent_sha256"]):
        raise ReceiptError("release does not continue the approved parent model")
    graph = copy.deepcopy(parent_graph)
    fork(graph, parent_branch, "release-derivative", artifact)
    return graph


def verify_release_lineage(graph, *, trusted_public_key: bytes, expected_root: str,
                           expected_leaf: str, expected_replay: str, receipt_sha256: str,
                           allowed_transformations: tuple[str, ...]):
    from power_house import replay_rootprint, verify_rootprint
    verify_rootprint(graph)
    if (graph["root_branch"] != expected_root or len(graph["branches"]) > 64
            or replay_rootprint(graph)["state_fingerprint"] != expected_replay):
        raise ReceiptError("lineage root or replay state is not independently approved")
    if expected_leaf not in graph["branches"]:
        raise ReceiptError("required lineage branch is missing")
    for branch in sorted(graph["branches"].values(), key=lambda b: b["sequence"]):
        proof = branch["artifact"]["embedded_proof"]
        if proof["protocol"] != PROFILE or set(proof["proof"]) != {"receipt_base64"}:
            raise ReceiptError("unsupported model lineage evidence")
        raw = base64.b64decode(proof["proof"]["receipt_base64"], validate=True)
        # Historical authentication uses the signed issue time. Current validity
        # is independently enforced on the leaf receipt by deployment admission.
        from .receipt import parse
        parsed = parse(raw)
        issued = timestamp(parsed["statement"]["issued_at"])
        result = verify_receipt(raw, trusted_public_key, now=issued + timedelta(microseconds=1))
        s = result["receipt"]["statement"]
        if s["profile"] != "onnx-finite-evaluation/v1":
            raise ReceiptError("lineage requires finite evaluation evidence")
        p = proof["public_inputs"]
        if p != {"model_sha256": s["artifact"]["sha256"], "model_bytes": s["artifact"]["bytes"],
                 "receipt_sha256": sha256(raw), "issuer_sha256": sha256(trusted_public_key),
                 "contract_sha256": s["contract_sha256"], "report_sha256": s["evaluation"]["report_sha256"],
                 "parent_model_sha256": s["parent_sha256"], "transformation": p.get("transformation")}:
            raise ReceiptError("lineage differs from authenticated release evidence")
        parents = branch["parents"]
        if not parents:
            if p["transformation"] != "root":
                raise ReceiptError("lineage root has an invalid transformation")
        elif (len(parents) != 1 or p["transformation"] not in allowed_transformations
              or p["parent_model_sha256"] != graph["branches"][parents[0]]["artifact"]["embedded_proof"]["public_inputs"]["model_sha256"]):
            raise ReceiptError("unauthorized transformation, merge or parent continuity")
    leaf = graph["branches"][expected_leaf]["artifact"]["embedded_proof"]["public_inputs"]
    if leaf["receipt_sha256"] != receipt_sha256:
        raise ReceiptError("lineage is for a different release receipt")
    return {"profile": PROFILE, "root_branch": expected_root, "leaf_branch": expected_leaf,
            "replay_fingerprint": expected_replay, "transformation_execution": "NOT_PROVED"}
