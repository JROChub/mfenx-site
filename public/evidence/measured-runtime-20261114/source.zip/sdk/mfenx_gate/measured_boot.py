"""Independently supplied references for the versioned TDX EFI RAM profile.

Reference parsing is not reference approval or hardware verification. The
expected digest must come from protected deployment configuration. Trustee's
native TDX verifier authenticates hardware evidence before these rules run.
"""
from dataclasses import dataclass
import hashlib
import re

from .receipt import ReceiptError, parse, canonical, sha256, _digest

CPU_PROFILE = 'tdx-efi-ram-cpu/v1'
GPU_PROFILE = 'tdx-efi-ram-nvidia/v1'
PROFILES = (CPU_PROFILE, GPU_PROFILE)
REFERENCE_SCHEMA = 'mfenx/tdx-efi-ram-reference/v1'
_SHA384 = re.compile(r'sha384:[0-9a-f]{96}\Z')
_QUOTE_FIELDS = ('mr_td','mr_config_id','xfam','rtmr_0','rtmr_1','rtmr_2','rtmr_3')


def _sha384(value):
    if type(value) is not str or not _SHA384.fullmatch(value):
        raise ReceiptError('invalid SHA-384 boot reference')
    return bytes.fromhex(value[7:])


def _extend(digests):
    state = bytes(48)
    for digest in digests:
        state = hashlib.sha384(state+digest).digest()
    return state.hex()


@dataclass(frozen=True)
class BootReference:
    digest: str
    profile: str
    policy_sha256: str
    quote: tuple
    minimum_tcb_evaluation_number: int

    @classmethod
    def from_bytes(cls, raw: bytes, *, expected_sha256: str):
        _digest(expected_sha256)
        if type(raw) is not bytes or not 0 < len(raw) <= 65536 or sha256(raw) != expected_sha256:
            raise ReceiptError('boot reference does not match independent approval')
        p = parse(raw)
        fields = {'schema','attestation_profile','encrypted_policy_sha256','quote',
                  'image_authenticode_sha384','kernel_authenticode_sha384',
                  'gpt_sha384','command_line_sha384','initrd_sha384',
                  'minimum_tcb_evaluation_number'}
        if (type(p) is not dict or set(p) != fields or p['schema'] != REFERENCE_SCHEMA
                or p['attestation_profile'] not in PROFILES):
            raise ReceiptError('unsupported measured boot reference')
        _digest(p['encrypted_policy_sha256'])
        minimum = p['minimum_tcb_evaluation_number']
        if type(minimum) is not int or not 1 <= minimum <= 2**53-1:
            raise ReceiptError('invalid minimum TCB evaluation number')
        q = p['quote']
        if type(q) is not dict or set(q) != set(_QUOTE_FIELDS):
            raise ReceiptError('incomplete TDX reference')
        for name in _QUOTE_FIELDS:
            size = 16 if name == 'xfam' else 96
            if type(q[name]) is not str or not re.fullmatch('[0-9a-f]{'+str(size)+'}',q[name]):
                raise ReceiptError('invalid TDX reference value')
        h = lambda b: hashlib.sha384(b).digest()
        image = _sha384(p['image_authenticode_sha384'])
        kernel = _sha384(p['kernel_authenticode_sha384'])
        expected_rtmr1 = _extend([h(b'Calling EFI Application from Boot Option'),h(bytes(4)),
            _sha384(p['gpt_sha384']),image,kernel,h(b'Exit Boot Services Invocation'),
            h(b'Exit Boot Services Returned with Success')])
        expected_rtmr2 = _extend([_sha384(p['command_line_sha384']),_sha384(p['initrd_sha384'])])
        if q['rtmr_1'] != expected_rtmr1 or q['rtmr_2'] != expected_rtmr2 or q['rtmr_3'] != '0'*96:
            raise ReceiptError('TDX references do not match the approved boot artifacts')
        return cls(expected_sha256,p['attestation_profile'],p['encrypted_policy_sha256'],
                   tuple((name,q[name]) for name in _QUOTE_FIELDS),minimum)

    def attestation_policy(self):
        """Install only on the independently operated, profile-specific broker."""
        q = dict(self.quote)
        body = '\n'.join('    input.tdx.quote.body.'+name+' == '+canonical(value).decode()
                         for name,value in self.quote)
        return f'''package policy
import rego.v1
default hardware := 97
default executables := 33
default configuration := 36
reference_matches if {{
{body}
    input.tdx.td_attributes.debug == false
}}
hardware := 2 if {{
    input.tdx.quote.header.tee_type == "81000000"
    input.tdx.quote.header.vendor_id == "939a7233f79c4ca9940a0db3957f0607"
    input.tdx.quote.body.mr_td == "{q['mr_td']}"
    input.tdx.tcb_status == "UpToDate"
    input.tdx.tcb_status_current == "UpToDate"
    input.tdx.tcb_eval_num >= {self.minimum_tcb_evaluation_number}
    input.tdx.collateral_expiration_status == "0"
}}
executables := 3 if {{ reference_matches }}
configuration := 2 if {{ reference_matches }}
trust_claims := {{"hardware":hardware,"executables":executables,
                 "configuration":configuration,"file-system":0,
                 "instance-identity":0,"runtime-opaque":0,
                 "storage-opaque":0,"sourced-data":0}}
'''
