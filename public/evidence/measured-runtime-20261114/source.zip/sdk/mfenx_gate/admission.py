"""Software admission for explicitly selected Receipt v1 ONNX runtime profiles.

The verifier, deployment configuration, Python process and kernel are trusted.
This module provides neither confidential execution nor a hardware boundary.
"""
from __future__ import annotations

from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import sqlite3
import threading
import time
import uuid

from .receipt import ReceiptError, canonical, parse, read_regular, sha256, timestamp, verify_receipt

POLICY_SCHEMA = "mfenx/admission-policy/v1"
PROOF_POLICY_SCHEMA = "mfenx/admission-policy/v2"
RUNTIME_PROFILE = "onnx-cpu-owned-bytes/v1"
CUDA_RUNTIME_PROFILE = "onnx-cuda12-owned-bytes/v1"
MAX_MODEL_BYTES = 64 * 1024 * 1024
RUNTIME_CONFIG = {"providers": ["CPUExecutionProvider"], "intra_op_threads": 1,
                  "inter_op_threads": 1, "graph_optimization": "disabled"}
CUDA_PROVIDER_OPTIONS = {"device_id": "0", "gpu_mem_limit": str(2 * 1024**3),
                         "do_copy_in_default_stream": "1", "use_tf32": "0",
                         "cudnn_conv_algo_search": "DEFAULT",
                         "cudnn_conv_use_max_workspace": "0"}
CUDA_RUNTIME_CONFIG = {"providers": ["CUDAExecutionProvider"], "intra_op_threads": 1,
                       "inter_op_threads": 1, "graph_optimization": "disabled",
                       "disable_cpu_ep_fallback": True, "output_device": "cuda:0",
                       "cuda_library_preload": "onnxruntime-default",
                       "provider_options": CUDA_PROVIDER_OPTIONS}


def runtime_config(profile: str) -> dict:
    if profile == RUNTIME_PROFILE:
        return RUNTIME_CONFIG
    if profile == CUDA_RUNTIME_PROFILE:
        return CUDA_RUNTIME_CONFIG
    raise ReceiptError("unsupported inference runtime profile")


def _file_digest(path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def runtime_identity(profile: str = RUNTIME_PROFILE) -> dict:
    """Observed runtime identity for independent deployment qualification."""
    import onnxruntime as ort
    from onnxruntime.capi import onnxruntime_pybind11_state as native
    observed = {"version": ort.__version__, "native_sha256": _file_digest(native.__file__),
                "config_sha256": sha256(canonical(runtime_config(profile)))}
    if profile == CUDA_RUNTIME_PROFILE:
        if "CUDAExecutionProvider" not in ort.get_available_providers():
            raise ReceiptError("required CUDA execution provider is unavailable")
        provider = Path(native.__file__).parent / "libonnxruntime_providers_cuda.so"
        if not provider.is_file():
            raise ReceiptError("qualified Linux CUDA provider library is missing")
        observed["provider_sha256"] = _file_digest(provider)
    return observed


@dataclass(frozen=True)
class AdmissionPolicy:
    """Protected, independently pinned deployment policy; not candidate metadata."""
    digest: str
    scope: str
    epoch: int
    minimum_sequence: int
    expires_at: datetime
    runtime_version: str
    runtime_sha256: str
    maximum_model_bytes: int
    maximum_lease_seconds: int
    approved_releases: tuple[tuple[str, int], ...]
    revoked_receipts: tuple[str, ...]
    revoked_issuers: tuple[str, ...]
    contract_sha256: str
    issuer_sha256: str
    required_lineage: tuple | None
    runtime_profile: str = RUNTIME_PROFILE
    runtime_provider_sha256: str | None = None
    runtime_config_sha256: str = sha256(canonical(RUNTIME_CONFIG))

    execution_requirement: object | None = None

    @classmethod
    def from_bytes(cls, raw: bytes, *, expected_sha256: str) -> AdmissionPolicy:
        if sha256(raw) != expected_sha256:
            raise ReceiptError("deployment policy does not match independent pin")
        p = parse(raw)
        fields = {"schema", "scope", "epoch", "minimum_sequence", "expires_at",
                  "runtime_profile", "runtime_version", "maximum_model_bytes",
                  "runtime_sha256", "runtime_config_sha256",
                  "maximum_lease_seconds", "approved_releases", "revoked_receipts",
                  "revoked_issuers", "contract_sha256", "issuer_sha256",
                  "required_assurance"}
        if type(p) is not dict or p.get("schema") not in (POLICY_SCHEMA, PROOF_POLICY_SCHEMA):
            raise ReceiptError("unsupported deployment policy")
        if p["schema"] == PROOF_POLICY_SCHEMA:
            fields = fields | {"execution_proof"}
        profile = p.get("runtime_profile")
        if profile == CUDA_RUNTIME_PROFILE:
            fields = fields | {"runtime_provider_sha256"}
        if set(p) not in (fields, fields | {"lineage"}):
            raise ReceiptError("unsupported deployment policy fields")
        if profile not in (RUNTIME_PROFILE, CUDA_RUNTIME_PROFILE) or p["required_assurance"] != "issuer-attested-finite-evaluation":
            raise ReceiptError("unqualified runtime or assurance profile")
        for name, maximum in [("epoch", 2**53-1), ("minimum_sequence", 2**53-1),
                              ("maximum_model_bytes", MAX_MODEL_BYTES), ("maximum_lease_seconds", 300)]:
            if type(p[name]) is not int or not 1 <= p[name] <= maximum:
                raise ReceiptError(f"invalid policy {name}")
        if (type(p["scope"]) is not str or not p["scope"]
                or type(p["runtime_version"]) is not str or not p["runtime_version"]):
            raise ReceiptError("policy scope and runtime version are required")
        def digest(value):
            from .receipt import DIGEST
            if type(value) is not str or not DIGEST.fullmatch(value):
                raise ReceiptError("invalid policy digest")
            return value
        if (p["runtime_config_sha256"] != sha256(canonical(runtime_config(profile)))
                or type(p["approved_releases"]) is not list):
            raise ReceiptError("unsupported runtime configuration or release list")
        releases = []
        for item in p["approved_releases"]:
            if type(item) is not dict or set(item) != {"receipt_sha256", "sequence"}:
                raise ReceiptError("invalid approved release")
            if type(item["sequence"]) is not int or not 1 <= item["sequence"] <= 2**53-1:
                raise ReceiptError("invalid release sequence")
            releases.append((digest(item["receipt_sha256"]), item["sequence"]))
        if not releases or len({v[0] for v in releases}) != len(releases):
            raise ReceiptError("missing or duplicate releases")
        for name in ("revoked_receipts", "revoked_issuers"):
            if type(p[name]) is not list:
                raise ReceiptError("invalid revocation list")
            for value in p[name]:
                digest(value)
            if len(set(p[name])) != len(p[name]):
                raise ReceiptError("duplicate revocation entry")
        lineage = p.get("lineage")
        if lineage is not None:
            if (type(lineage) is not dict or set(lineage) != {"root_branch", "leaf_branch", "replay_fingerprint", "allowed_transformations"}
                    or type(lineage["allowed_transformations"]) is not list
                    or any(type(v) is not str or not v or v == "root" for v in lineage["allowed_transformations"])):
                raise ReceiptError("unsupported lineage policy")
            lineage = (digest(lineage["root_branch"]), digest(lineage["leaf_branch"]),
                       digest(lineage["replay_fingerprint"]), tuple(lineage["allowed_transformations"]))
        execution = None
        if p["schema"] == PROOF_POLICY_SCHEMA:
            from .execution import ExecutionRequirement
            execution = ExecutionRequirement.from_dict(p["execution_proof"])
        return cls(expected_sha256, p["scope"], p["epoch"], p["minimum_sequence"],
                   timestamp(p["expires_at"]), p["runtime_version"], digest(p["runtime_sha256"]), p["maximum_model_bytes"],
                   p["maximum_lease_seconds"], tuple(releases), tuple(p["revoked_receipts"]),
                   tuple(p["revoked_issuers"]), digest(p["contract_sha256"]), digest(p["issuer_sha256"]), lineage,
                   profile, digest(p["runtime_provider_sha256"]) if profile == CUDA_RUNTIME_PROFILE else None,
                   p["runtime_config_sha256"], execution)

    def authorize(self, receipt_digest: str, issuer_digest: str, *, now: datetime) -> int:
        if now.tzinfo is None or not 0 < (self.expires_at - now).total_seconds() <= 300:
            raise ReceiptError("deployment policy expired or exceeds the five-minute authorization window")
        if issuer_digest != self.issuer_sha256 or issuer_digest in self.revoked_issuers:
            raise ReceiptError("issuer is not authorized by deployment policy")
        if receipt_digest in self.revoked_receipts:
            raise ReceiptError("release revoked")
        releases = dict(self.approved_releases)
        sequence = releases.get(receipt_digest, 0)
        if sequence < self.minimum_sequence:
            raise ReceiptError("release is unapproved or below the rollback floor")
        return sequence


class PolicyAuthority:
    """In-process authority with monotonic updates and per-call revocation.

    Supply state_path for durable epoch/rollback floors. The caller protects the
    database and its parent directory. Without it, state is process-local only.
    """
    def __init__(self, policy: AdmissionPolicy, *, state_path: Path | None = None):
        self._policy = policy
        self._lock = threading.RLock()
        self._available = True
        self._state_path = state_path
        if state_path is not None:
            self._persist(policy, reopening=True)

    def _persist(self, policy, *, reopening=False):
        # This database is protected operator state, never part of a model bundle.
        import os
        import stat
        path = self._state_path
        flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(path, flags, 0o600)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077 or info.st_uid != os.getuid():
                raise ReceiptError("policy state requires an owner-only regular file")
        finally:
            os.close(fd)
        with closing(sqlite3.connect(path)) as db, db:
            db.execute("PRAGMA synchronous=FULL")
            db.execute("BEGIN IMMEDIATE")
            db.execute("CREATE TABLE IF NOT EXISTS admission_floor(scope TEXT PRIMARY KEY, epoch INTEGER, floor INTEGER, digest TEXT)")
            self._clock_floor(db)
            prior = db.execute("SELECT epoch,floor,digest FROM admission_floor WHERE scope=?", (policy.scope,)).fetchone()
            if prior and (policy.epoch < prior[0] or policy.minimum_sequence < prior[1]
                          or (policy.epoch == prior[0] and (policy.digest != prior[2] or not reopening))):
                raise ReceiptError("durable policy epoch or rollback floor regressed")
            db.execute("INSERT OR REPLACE INTO admission_floor VALUES(?,?,?,?)",
                       (policy.scope, policy.epoch, policy.minimum_sequence, policy.digest))

    def _clock_floor(self, db):
        db.execute("CREATE TABLE IF NOT EXISTS admission_clock(scope TEXT PRIMARY KEY, observed REAL)")
        now = time.time()
        prior = db.execute("SELECT observed FROM admission_clock WHERE scope=?", (self._policy.scope,)).fetchone()
        if prior and now + 1 < prior[0]:
            raise ReceiptError("wall clock regressed against durable observation")
        db.execute("INSERT OR REPLACE INTO admission_clock VALUES(?,?)",
                   (self._policy.scope, max(now, prior[0] if prior else now)))

    def install(self, policy: AdmissionPolicy) -> None:
        with self._lock:
            current = self._policy
            if (policy.scope != current.scope or policy.epoch <= current.epoch
                    or policy.minimum_sequence < current.minimum_sequence):
                raise ReceiptError("policy scope, epoch or rollback floor regressed")
            if self._state_path is not None:
                self._persist(policy)
            self._policy = policy

    def unavailable(self) -> None:
        with self._lock:
            self._available = False

    def current(self) -> AdmissionPolicy:
        with self._lock:
            if not self._available:
                raise ReceiptError("policy authority unavailable")
            if self._state_path is not None:
                try:
                    with closing(sqlite3.connect(self._state_path)) as db, db:
                        self._clock_floor(db)
                        row = db.execute("SELECT epoch,floor,digest FROM admission_floor WHERE scope=?",
                                         (self._policy.scope,)).fetchone()
                    if row != (self._policy.epoch, self._policy.minimum_sequence, self._policy.digest):
                        raise ReceiptError("durable authority advanced; readmission required")
                except sqlite3.Error as exc:
                    raise ReceiptError("durable policy authority unavailable") from exc
            return self._policy

    def record(self, session_id, model, event):
        if self._state_path is None:
            return
        try:
            with closing(sqlite3.connect(self._state_path)) as db, db:
                db.execute("CREATE TABLE IF NOT EXISTS admission_audit(sequence INTEGER PRIMARY KEY AUTOINCREMENT, session TEXT, scope TEXT, policy TEXT, model TEXT, receipt TEXT, event TEXT, observed REAL)")
                db.execute("INSERT INTO admission_audit(session,scope,policy,model,receipt,event,observed) VALUES(?,?,?,?,?,?,?)",
                           (session_id, model.scope, model.policy_digest, model.artifact_digest,
                            model.receipt_digest, event, time.time()))
                if model.execution_proof_sha256 is not None:
                    db.execute("CREATE TABLE IF NOT EXISTS admission_execution_evidence(session TEXT PRIMARY KEY, proof TEXT NOT NULL)")
                    db.execute("INSERT OR IGNORE INTO admission_execution_evidence(session,proof) VALUES(?,?)",
                               (session_id, model.execution_proof_sha256))
                    if db.execute("SELECT proof FROM admission_execution_evidence WHERE session=?", (session_id,)).fetchone() != (model.execution_proof_sha256,):
                        raise ReceiptError("conflicting execution evidence for serving session")
                if model.distribution_sha256 is not None:
                    db.execute("CREATE TABLE IF NOT EXISTS admission_distribution_evidence(session TEXT PRIMARY KEY, distribution TEXT NOT NULL)")
                    db.execute("INSERT OR IGNORE INTO admission_distribution_evidence VALUES(?,?)",
                               (session_id, model.distribution_sha256))
                    if db.execute("SELECT distribution FROM admission_distribution_evidence WHERE session=?", (session_id,)).fetchone() != (model.distribution_sha256,):
                        raise ReceiptError("conflicting distribution evidence for serving session")
        except sqlite3.Error as exc:
            raise ReceiptError("durable activation audit unavailable") from exc


_ADMITTED = object()


class VerifiedModel:
    """Owned immutable ONNX bytes, constructed only after policy admission.

    Python access control is not isolation from malicious code in this process.
    The loader never receives the original candidate path.
    """
    __slots__ = ("__payload", "receipt_digest", "issuer_digest", "artifact_digest",
                 "policy_digest", "epoch", "scope", "sequence", "expires_at", "runtime_version",
                 "runtime_profile", "runtime_sha256", "runtime_provider_sha256", "runtime_config_sha256",
                 "execution_proof_sha256", "distribution_sha256")

    def __init__(self, token, payload, result, raw, policy, sequence, execution_proof_sha256=None):
        if token is not _ADMITTED:
            raise ReceiptError("models must be constructed by admission")
        self.__payload = payload
        self.distribution_sha256 = None
        self.execution_proof_sha256 = execution_proof_sha256
        self.receipt_digest = sha256(raw)
        self.issuer_digest = result["receipt"]["issuer"]["key_id"]
        self.artifact_digest = result["receipt"]["statement"]["artifact"]["sha256"]
        self.policy_digest = policy.digest
        self.epoch, self.scope, self.sequence = policy.epoch, policy.scope, sequence
        self.expires_at = timestamp(result["receipt"]["statement"]["expires_at"])
        self.runtime_version = policy.runtime_version
        self.runtime_profile = policy.runtime_profile
        self.runtime_sha256 = policy.runtime_sha256
        self.runtime_provider_sha256 = policy.runtime_provider_sha256
        self.runtime_config_sha256 = policy.runtime_config_sha256

    def _load_cpu(self):
        # Compatibility entry point; the runtime is selected only by admitted policy.
        return self._load_approved()

    def _load_approved(self):
        import onnxruntime as ort
        observed = runtime_identity(self.runtime_profile)
        if (observed["version"] != self.runtime_version or observed["native_sha256"] != self.runtime_sha256
                or observed.get("provider_sha256") != self.runtime_provider_sha256
                or observed["config_sha256"] != self.runtime_config_sha256):
            raise ReceiptError("inference runtime does not match approved version")
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        options.inter_op_num_threads = 1
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        if self.runtime_profile == RUNTIME_PROFILE:
            return ort.InferenceSession(self.__payload, sess_options=options,
                                        providers=["CPUExecutionProvider"])
        if self.runtime_profile != CUDA_RUNTIME_PROFILE:
            raise ReceiptError("unsupported admitted runtime")
        ort.preload_dlls(cuda=True, cudnn=True, msvc=False)
        options.add_session_config_entry("session.disable_cpu_ep_fallback", "1")
        session = ort.InferenceSession(self.__payload, sess_options=options,
                                      providers=[("CUDAExecutionProvider", dict(CUDA_PROVIDER_OPTIONS))])
        session.disable_fallback()
        registered = session.get_providers()
        # ORT may retain CPU EP registration even when placement on it is disabled.
        # The native initialization flag and the unsupported-operator regression
        # enforce this boundary; the registration list alone does not establish it.
        if (not registered or registered[0] != "CUDAExecutionProvider"
                or any(provider not in ("CUDAExecutionProvider", "CPUExecutionProvider") for provider in registered)
                or session.get_session_options().get_session_config_entry("session.disable_cpu_ep_fallback") != "1"):
            raise ReceiptError("CUDA profile requires native CPU fallback prohibition")
        return session


def admit_model(*, receipt: bytes, trusted_public_key: bytes, model: Path | None = None,
                model_bytes: bytes | None = None,
                policy: AdmissionPolicy, now: datetime | None = None, lineage=None,
                execution_proof: bytes | None = None, proof_verifier: Path | None = None) -> VerifiedModel:
    now = now or datetime.now(timezone.utc)
    if (model is None) == (model_bytes is None):
        raise ReceiptError("supply exactly one model path or owned immutable model buffer")
    # Authenticate and authorize before acquiring or parsing a potentially large model.
    result = verify_receipt(receipt, trusted_public_key,
                            expected_contract_digest=policy.contract_sha256, now=now)
    if result["receipt"]["statement"]["profile"] != "onnx-finite-evaluation/v1":
        raise ReceiptError("integrity-only evidence cannot authorize behavioral admission")
    sequence = policy.authorize(sha256(receipt), sha256(trusted_public_key), now=now)
    if policy.required_lineage is not None:
        if lineage is None:
            raise ReceiptError("required model lineage is missing")
        from .lineage import verify_release_lineage
        root, leaf, replay, transformations = policy.required_lineage
        verify_release_lineage(lineage, trusted_public_key=trusted_public_key,
                               expected_root=root, expected_leaf=leaf, expected_replay=replay,
                               receipt_sha256=sha256(receipt), allowed_transformations=transformations)
    observed = runtime_identity(policy.runtime_profile)
    if (observed["version"] != policy.runtime_version or observed["native_sha256"] != policy.runtime_sha256
            or observed.get("provider_sha256") != policy.runtime_provider_sha256
            or observed["config_sha256"] != policy.runtime_config_sha256):
        raise ReceiptError("native runtime identity does not match approved policy")
    statement = result["receipt"]["statement"]
    if statement["artifact"]["bytes"] > policy.maximum_model_bytes:
        raise ReceiptError("model exceeds deployment policy limit")
    if model_bytes is not None:
        if type(model_bytes) is not bytes or not 0 < len(model_bytes) <= policy.maximum_model_bytes:
            raise ReceiptError("model buffer must contain bounded immutable bytes")
        payload = model_bytes
    else:
        payload = read_regular(model, policy.maximum_model_bytes)
    result = verify_receipt(receipt, trusted_public_key, artifact_bytes=payload,
                            expected_contract_digest=policy.contract_sha256, now=now)
    execution_identity = None
    if policy.execution_requirement is not None:
        if execution_proof is None or proof_verifier is None:
            raise ReceiptError("required execution proof or protected verifier is missing")
        from .execution import verify_execution_proof
        execution_identity = verify_execution_proof(
            execution_proof, policy.execution_requirement,
            model_sha256=statement["artifact"]["sha256"], verifier=proof_verifier)
    elif execution_proof is not None:
        raise ReceiptError("execution evidence requires an explicit v2 proof policy")
    # Parsing sees only authenticated retained bytes. External data is not admitted.
    import onnx
    parsed = onnx.load_model_from_string(payload)
    def graph(g):
        sparse = [t for value in g.sparse_initializer for t in (value.values, value.indices)]
        for tensor in list(g.initializer) + sparse:
            if tensor.external_data or tensor.data_location == onnx.TensorProto.EXTERNAL:
                raise ReceiptError("external ONNX tensor dependencies are not admitted")
        for node in g.node:
            if node.domain not in ("", "ai.onnx"):
                raise ReceiptError("custom ONNX operator domains are not admitted")
            for attribute in node.attribute:
                tensors = list(attribute.tensors)
                sparse_attributes = list(attribute.sparse_tensors)
                if attribute.HasField("sparse_tensor"):
                    sparse_attributes.append(attribute.sparse_tensor)
                tensors.extend(t for value in sparse_attributes for t in (value.values, value.indices))
                if attribute.HasField("t"):
                    tensors.append(attribute.t)
                for tensor in tensors:
                    if tensor.external_data or tensor.data_location == onnx.TensorProto.EXTERNAL:
                        raise ReceiptError("external ONNX attribute tensors are not admitted")
                if attribute.HasField("g"):
                    graph(attribute.g)
                for child in attribute.graphs:
                    graph(child)
    if parsed.functions or parsed.training_info:
        raise ReceiptError("ONNX functions and training extensions are not admitted")
    graph(parsed.graph)
    onnx.checker.check_model(parsed)
    return VerifiedModel(_ADMITTED, payload, result, receipt, policy, sequence, execution_identity)


class ServingSession:
    """Approved runtime entry with retained bytes and per-call policy checks.

    Calls are serialized with close. Revocation denies subsequent calls; a call
    already executing is allowed to finish. A process supervisor is needed to
    terminate a stuck native kernel. No arbitrary loader callback is accepted.
    """
    def __init__(self, model: VerifiedModel, authority: PolicyAuthority):
        if type(model) is not VerifiedModel:
            raise ReceiptError("a verified model is required")
        self._lock = threading.RLock()
        self._model, self._authority = model, authority
        self._session_id = uuid.uuid4().hex
        self.last_output_devices = ()
        self.state = "POLICY_AUTHORIZED"
        self._started = time.monotonic()
        policy = self._check()
        self._lease = policy.maximum_lease_seconds
        try:
            self._session = model._load_cpu()
            self.state = "MODEL_LOADED"
            self._check()
            authority.record(self._session_id, model, "activation")
            self.state = "SERVING_ACTIVE"
        except BaseException:
            self.state = "TERMINATED"
            self._session = None
            self._model = None
            raise

    def _check(self):
        policy = self._authority.current()
        now = datetime.now(timezone.utc)
        if (policy.digest != self._model.policy_digest or policy.epoch != self._model.epoch
                or now >= self._model.expires_at):
            raise ReceiptError("activation is stale; readmission required")
        policy.authorize(self._model.receipt_digest, self._model.issuer_digest, now=now)
        if time.monotonic() - self._started >= getattr(self, "_lease", policy.maximum_lease_seconds):
            raise ReceiptError("serving lease expired")
        return policy

    def run(self, inputs):
        with self._lock:
            if self.state != "SERVING_ACTIVE":
                raise ReceiptError("serving is inactive")
            try:
                self._check()
            except ReceiptError:
                self.close()
                raise
            try:
                self._authority.record(self._session_id, self._model, "inference-started")
                if self._model.runtime_profile == CUDA_RUNTIME_PROFILE:
                    binding = self._session.io_binding()
                    for name, value in inputs.items():
                        binding.bind_cpu_input(name, value)
                    for output in self._session.get_outputs():
                        binding.bind_output(output.name, "cuda", 0)
                    binding.synchronize_inputs()
                    self._session.run_with_iobinding(binding)
                    binding.synchronize_outputs()
                    devices = tuple(value.device_name().lower() for value in binding.get_outputs())
                    if not devices or any(device != "cuda" for device in devices):
                        raise ReceiptError("CUDA profile did not produce device-resident outputs")
                    self.last_output_devices = devices
                    result = binding.copy_outputs_to_cpu()
                else:
                    result = self._session.run(None, inputs)
                self._authority.record(self._session_id, self._model, "inference-completed")
                return result
            except BaseException:
                self.close()
                raise

    def close(self):
        with self._lock:
            model = self._model
            self.state = "TERMINATED"
            self._session = None
            self._model = None
            if model is not None:
                self._authority.record(self._session_id, model, "termination")

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
