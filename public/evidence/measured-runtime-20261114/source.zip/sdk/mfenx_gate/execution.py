"""Policy binding for a bounded SFCS fixed-model evaluation statement.

Linux software admission trusts the kernel, Python process, provisioned verifier
and its dynamic libraries. This module does not attest to GPU execution.
"""
from __future__ import annotations
from dataclasses import dataclass
import base64
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import threading

from .receipt import DIGEST, ReceiptError, sha256

_LIMIT = threading.BoundedSemaphore(2)
MAX_PROOF_BYTES = 8 * 1024**2


@dataclass(frozen=True)
class ExecutionRequirement:
    image_id: str
    program_digest: str
    dataset_sha256: str
    sample_index: int
    journal_sha256: str
    verifier_sha256: str

    @classmethod
    def from_dict(cls, value):
        if sys.platform != "linux":
            raise ReceiptError("execution-proof admission requires the qualified Linux profile")
        fields = {'schema', 'image_id', 'program_digest', 'dataset_sha256',
                  'sample_index', 'journal_sha256', 'verifier_sha256'}
        if (type(value) is not dict or set(value) != fields
                or value['schema'] != 'mfenx/fixed-mlp-execution/v1'):
            raise ReceiptError('unsupported execution-proof requirement')
        for name in ['program_digest', 'dataset_sha256', 'journal_sha256', 'verifier_sha256']:
            if type(value[name]) is not str or not DIGEST.fullmatch(value[name]):
                raise ReceiptError('invalid execution-proof digest')
        image = value['image_id']
        if type(image) is not str or not DIGEST.fullmatch(image.replace('risc0:', 'sha256:', 1)) or not image.startswith('risc0:'):
            raise ReceiptError('invalid approved guest image')
        index = value['sample_index']
        if type(index) is not int or not 0 <= index < 1797:
            raise ReceiptError('invalid approved evaluation sample')
        return cls(*(value[name] for name in ['image_id', 'program_digest', 'dataset_sha256',
                                              'sample_index', 'journal_sha256', 'verifier_sha256']))


def _sealed_verifier(path, expected):
    """Acquire, seal and authenticate the actual executable consumed by exec."""
    import fcntl
    source = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    target = None
    try:
        target = os.memfd_create('mfenx-proof-verifier', os.MFD_ALLOW_SEALING | os.MFD_CLOEXEC)
        before = os.fstat(source)
        if not stat.S_ISREG(before.st_mode) or not 0 < before.st_size <= 512 * 1024**2:
            raise ReceiptError('verifier is not a bounded regular executable')
        digest, count = hashlib.sha256(), 0
        while block := os.read(source, min(1024**2, before.st_size + 1 - count)):
            count += len(block)
            if count > before.st_size:
                raise ReceiptError('verifier grew during acquisition')
            digest.update(block)
            view = memoryview(block)
            while view:
                written = os.write(target, view)
                if written <= 0:
                    raise ReceiptError('cannot acquire verifier executable')
                view = view[written:]
        after = os.fstat(source)
        if (count != before.st_size or (before.st_size, before.st_mtime_ns, before.st_ctime_ns) !=
                (after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
            raise ReceiptError('verifier changed during acquisition')
        seals = fcntl.F_SEAL_WRITE | fcntl.F_SEAL_GROW | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_SEAL
        fcntl.fcntl(target, fcntl.F_ADD_SEALS, seals)
        if fcntl.fcntl(target, fcntl.F_GET_SEALS) & seals != seals:
            raise ReceiptError('verifier executable was not sealed')
        if 'sha256:' + digest.hexdigest() != expected:
            raise ReceiptError('proof verifier does not match protected policy')
        return target
    except BaseException:
        if target is not None:
            os.close(target)
        raise
    finally:
        os.close(source)


_LAUNCHER = '''import os,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,)*2)
resource.setrlimit(resource.RLIMIT_CPU,(30,)*2)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
resource.setrlimit(resource.RLIMIT_FSIZE,(1024**2,)*2)
resource.setrlimit(resource.RLIMIT_NOFILE,(64,64))
os.execve('/proc/self/fd/'+sys.argv[1],['julian','sfcs','verify-risc0-pha',sys.argv[2]],os.environ)
'''


def verify_execution_proof(raw: bytes, requirement: ExecutionRequirement, *, model_sha256: str,
                           verifier: Path) -> str:
    if type(raw) is not bytes or not 0 < len(raw) <= MAX_PROOF_BYTES:
        raise ReceiptError('execution proof exceeds acquisition limit')
    if not _LIMIT.acquire(blocking=False):
        raise ReceiptError('concurrent execution-proof limit reached')
    binary = None
    try:
        binary = _sealed_verifier(verifier, requirement.verifier_sha256)
        with tempfile.TemporaryDirectory(prefix='mfenx-proof-') as directory, tempfile.TemporaryFile() as output:
            # Private snapshot: the candidate's original path is never passed to the verifier.
            path = Path(directory) / 'execution.pha'
            path.write_bytes(raw)
            path.chmod(0o400)
            env = {'PATH': os.defpath, 'RAYON_NUM_THREADS': '2', 'OMP_NUM_THREADS': '1',
                   'RISC0_PROVER': 'local', 'PYTHONNOUSERSITE': '1'}
            with subprocess.Popen([sys.executable, '-I', '-c', _LAUNCHER, str(binary), str(path)],
                                  pass_fds=(binary,), stdout=output, stderr=output,
                                  env=env, cwd=directory, start_new_session=True) as child:
                try:
                    child.wait(timeout=45)
                except BaseException:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait()
                    raise
            output.seek(0)
            observed = output.read(1024**2 + 1)
            if child.returncode or len(observed) > 1024**2:
                raise ReceiptError('protocol-specific execution-proof verification failed')
        # The native protocol verifier has checked duplicate keys, core identity,
        # attachment integrity, receipt validity and statement/guest consistency.
        statement = json.loads(raw)['embedded_proof']['public_inputs']
        if (statement['image_id'] != requirement.image_id
                or statement['program_digest'] != requirement.program_digest):
            raise ReceiptError('execution proof concerns an unapproved program')
        journal = base64.b64decode(statement['journal_base64'], validate=True)
        if (len(journal) != 116 or journal[:8] != b'MFXMLP01'
                or 'sha256:' + journal[8:40].hex() != model_sha256
                or 'sha256:' + journal[40:72].hex() != requirement.dataset_sha256
                or struct.unpack_from('<I', journal, 72)[0] != requirement.sample_index
                or sha256(journal) != requirement.journal_sha256):
            raise ReceiptError('verified execution statement does not match admitted model and policy')
        return sha256(raw)
    except ReceiptError:
        raise
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as exc:
        raise ReceiptError('execution-proof verification rejected') from exc
    finally:
        if binary is not None:
            os.close(binary)
        _LIMIT.release()
