"""Generate a narrowly scoped Trustee v0.22 EAR resource policy.

This policy is evaluated only after Trustee authenticates the attestation token.
CPU/GPU vendor evidence appraisal and reference enrollment remain upstream duties.
"""
import tomllib

from .encrypted import Descriptor, EncryptedPolicy
from .receipt import ReceiptError, canonical


def resource_policy(policy: EncryptedPolicy, descriptor: Descriptor, *, cpu_tee: str,
                    boot_reference=None) -> str:
    if (type(policy) is not EncryptedPolicy or type(descriptor) is not Descriptor
            or descriptor.digest != policy.descriptor_sha256 or cpu_tee not in ("tdx", "snp")):
        raise ReceiptError("resource policy requires an approved descriptor and supported CPU TEE")
    resource = canonical(descriptor.context["resource"].split("/")).decode("ascii")
    if policy.attestation_profile != 'coco-initdata/v1':
        from .measured_boot import BootReference, CPU_PROFILE, GPU_PROFILE
        if (type(boot_reference) is not BootReference or cpu_tee != 'tdx'
                or boot_reference.profile != policy.attestation_profile
                or boot_reference.policy_sha256 != policy.digest):
            raise ReceiptError('measured deployment requires an independently approved policy-bound boot reference')
        gpu = policy.attestation_profile == GPU_PROFILE
        fields = '\n'.join('    cpu["ear.veraison.annotated-evidence"].tdx.quote.body.'+
                            name+' == '+canonical(value).decode() for name,value in boot_reference.quote)
        gpu_rules = '''    gpu := input.submods.gpu0
    gpu["ear.status"] == "affirming"
    gpu["ear.trustworthiness-vector"].hardware == 2
    gpu["ear.trustworthiness-vector"].executables == 3
    gpu["ear.trustworthiness-vector"].configuration == 2
    gpu["ear.veraison.annotated-evidence"].nvidia
''' if gpu else ''
        return f'''package policy
import rego.v1
default allow := false
allow if {{
    data.plugin == "resource"
    data["resource-path"] == {resource}
    count(data.query) == 0
    now := time.now_ns()
    remaining := {int(policy.admission.expires_at.timestamp()) * 1_000_000_000} - now
    remaining > 0
    remaining <= 300000000000
    count(input.submods) == {2 if gpu else 1}
    cpu := input.submods.cpu0
    cpu["ear.status"] == "affirming"
    cpu["ear.trustworthiness-vector"].hardware == 2
    cpu["ear.trustworthiness-vector"].executables == 3
    cpu["ear.trustworthiness-vector"].configuration == 2
{fields}
    evidence := cpu["ear.veraison.annotated-evidence"].tdx
    evidence.tcb_status == "UpToDate"
    evidence.tcb_status_current == "UpToDate"
    evidence.tcb_eval_num >= {boot_reference.minimum_tcb_evaluation_number}
    evidence.collateral_expiration_status == "0"
    evidence.td_attributes.debug == false
{gpu_rules}}}
'''
    if boot_reference is not None:
        raise ReceiptError('Initdata v1 cannot be reinterpreted as measured boot authorization')
    init_data = canonical(tomllib.loads(policy.init_data)["data"]).decode("ascii")
    return f'''package policy
import rego.v1

default allow := false

allow if {{
    data.plugin == "resource"
    data["resource-path"] == {resource}
    count(data.query) == 0
    count(input.submods) == 2
    cpu := input.submods.cpu0
    gpu := input.submods.gpu0
    cpu["ear.status"] == "affirming"
    gpu["ear.status"] == "affirming"
    cpu["ear.trustworthiness-vector"].hardware == 2
    cpu["ear.trustworthiness-vector"].executables == 3
    cpu["ear.trustworthiness-vector"].configuration == 2
    gpu["ear.trustworthiness-vector"].hardware == 2
    gpu["ear.trustworthiness-vector"].executables == 3
    gpu["ear.trustworthiness-vector"].configuration == 2
    cpu["ear.veraison.annotated-evidence"].{cpu_tee}
    gpu["ear.veraison.annotated-evidence"].nvidia
    cpu["ear.veraison.annotated-evidence"].init_data_claims == {init_data}
}}
'''
