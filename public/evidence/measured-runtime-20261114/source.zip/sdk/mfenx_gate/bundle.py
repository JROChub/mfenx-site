"""Retain CKODMK's signed external inventory as sealed Linux objects.

This reuses its established envelope verifier; it never upgrades integrity-only
evidence to behavioral or serving admission. No checkpoint runtime is implied.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile

from .receipt import ReceiptError, sha256


class RetainedBundle:
    """Only declared immutable descriptors are accessible; original paths are not used."""
    def __init__(self, descriptors, envelope_digest, identity, checkpoint=None):
        self.__descriptors = descriptors
        self.envelope_sha256 = envelope_digest
        self.statement_root_id = identity.statement_root_id
        self.profile = "mfenx/retained-bundle/v1"
        self.behavioral_status = "NOT_EVALUATED"
        self.checkpoint_inventory = checkpoint

    @property
    def subjects(self):
        return tuple(sorted(self.__descriptors))

    def duplicate_descriptor(self, subject):
        if subject not in self.__descriptors:
            raise ReceiptError("undeclared bundle subject")
        # A duplicate shares offset but pread-based consumers are offset-independent.
        return os.dup(self.__descriptors[subject])

    def close(self):
        for fd in self.__descriptors.values():
            os.close(fd)
        self.__descriptors.clear()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def retain_bundle(raw: bytes, *, root: Path, trusted_public_key: bytes,
                  expected_envelope_sha256: str, max_files: int = 256,
                  max_total_bytes: int = 512 * 1024 * 1024,
                  checkpoint_format: str | None = None) -> RetainedBundle:
    if (type(raw) is not bytes or len(raw) > 8 * 1024 * 1024
            or sha256(raw) != expected_envelope_sha256):
        raise ReceiptError("bundle envelope does not match independent approval")
    if (type(max_files) is not int or not 1 <= max_files <= 256
            or type(max_total_bytes) is not int or not 1 <= max_total_bytes <= 512 * 1024 * 1024):
        raise ReceiptError("unsupported retained-bundle resource limits")
    if checkpoint_format not in (None, "safetensors"):
        raise ReceiptError("unqualified checkpoint format")
    from mfenx_ckodmk.external_envelope import verify_external_envelope
    # Bound work before invoking the existing verifier; its own parser and
    # signature checks remain authoritative for this document's interpretation.
    try:
        document = json.loads(raw)
        records = document["statement"]["artifacts"]
        if (type(records) is not list or not 1 <= len(records) <= max_files
                or any(type(r["bytes"]) is not int or r["bytes"] < 0 for r in records)
                or sum(r["bytes"] for r in records) > max_total_bytes):
            raise ReceiptError("bundle exceeds retained-object limits")
    except (KeyError, TypeError, ValueError, RecursionError) as exc:
        raise ReceiptError("invalid or oversized bundle inventory") from exc
    expected_paths = [r["path"] for r in records]
    actual_paths = []
    visited = 0
    pending = [Path(root)]
    while pending:
        base = pending.pop()
        with os.scandir(base) as entries:
            for entry in entries:
                visited += 1
                if visited > 1024:
                    raise ReceiptError("bundle tree exceeds entry budget")
                if entry.is_symlink():
                    raise ReceiptError("bundle symlinks are not admitted")
                if entry.is_dir(follow_symlinks=False):
                    pending.append(Path(entry.path))
                elif entry.is_file(follow_symlinks=False):
                    actual_paths.append(Path(entry.path).relative_to(root).as_posix())
                    if len(actual_paths) > max_files:
                        raise ReceiptError("bundle exceeds file-count budget")
                else:
                    raise ReceiptError("special objects are not admitted")
    if sorted(actual_paths) != sorted(expected_paths) or len(set(expected_paths)) != len(expected_paths):
        raise ReceiptError("bundle inventory does not cover the exact file set")
    staging = tempfile.TemporaryDirectory(prefix="mfenx-envelope-verify-")
    descriptors = {}
    directories = []
    try:
        directory_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        root_fd = os.open(root, directory_flags)
        directories.append(root_fd)
        seals = fcntl.F_SEAL_WRITE | fcntl.F_SEAL_GROW | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_SEAL
        for record in records:
            relative = record["path"]
            path = PurePosixPath(relative)
            if path.is_absolute() or path.as_posix() != relative or any(v in (".", "..") for v in path.parts):
                raise ReceiptError("noncanonical bundle path")
            opened = []
            try:
                parent = root_fd
                for component in path.parts[:-1]:
                    parent = os.open(component, directory_flags, dir_fd=parent)
                    opened.append(parent)
                source = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
                opened.append(source)
                before = os.fstat(source)
                if not stat.S_ISREG(before.st_mode) or before.st_size != record["bytes"]:
                    raise ReceiptError("bundle subject changed before acquisition")
                retained = os.memfd_create("mfenx-bundle", os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING)
                descriptors[relative] = retained
                remaining = record["bytes"]
                while remaining:
                    block = os.read(source, min(1024 * 1024, remaining))
                    if not block:
                        raise ReceiptError("bundle subject truncated")
                    remaining -= len(block)
                    view = memoryview(block)
                    while view:
                        count = os.write(retained, view)
                        if count <= 0:
                            raise ReceiptError("retained write did not progress")
                        view = view[count:]
                if os.read(source, 1):
                    raise ReceiptError("bundle subject grew")
                fcntl.fcntl(retained, fcntl.F_ADD_SEALS, seals)
                if fcntl.fcntl(retained, fcntl.F_GET_SEALS) & seals != seals:
                    raise ReceiptError("required immutable seals were not applied")
                digest = hashlib.sha256()
                offset = 0
                while block := os.pread(retained, 1024 * 1024, offset):
                    digest.update(block)
                    offset += len(block)
                if offset != record["bytes"] or "sha256:" + digest.hexdigest() != record["sha256"]:
                    raise ReceiptError("retained bundle subject identity mismatch")
            finally:
                for fd in reversed(opened):
                    os.close(fd)
        # The existing verifier reads only private bounded snapshots, not paths
        # whose producer can grow them while its streaming hash is in progress.
        staged = Path(staging.name)
        for relative, fd in descriptors.items():
            target = staged / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                offset = 0
                while block := os.pread(fd, 1024 * 1024, offset):
                    handle.write(block)
                    offset += len(block)
        identity = verify_external_envelope(raw, root=staged, trusted_public_key_der=trusted_public_key)
        checkpoint = None
        if checkpoint_format is not None:
            from mfenx_ckodmk.scale import inspect_checkpoint_tree
            checkpoint = inspect_checkpoint_tree(staged, checkpoint_format=checkpoint_format)
        return RetainedBundle(descriptors, expected_envelope_sha256, identity, checkpoint)
    except BaseException:
        for fd in descriptors.values():
            os.close(fd)
        raise
    finally:
        staging.cleanup()
        for fd in directories:
            os.close(fd)
