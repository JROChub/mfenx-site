"""Real CPU inference and adversarial software-admission boundary tests.

Ephemeral keys sign synthetic finite-evaluation statements; they are not model
quality evidence. The execution assertion observes actual ONNX Runtime output.
"""
import copy
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import tempfile
import unittest

import numpy as np
import onnx
from onnx import TensorProto, helper

from mfenx_gate.admission import (AdmissionPolicy, PolicyAuthority, ServingSession,
                                   admit_model, runtime_identity, RUNTIME_PROFILE)
from mfenx_gate.receipt import ReceiptError, generate_keypair, _sign, sha256
from mfenx_gate.worker import run_isolated


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.private, self.public = generate_keypair()
        graph = helper.make_graph([helper.make_node("Add", ["x", "bias"], ["y"])], "admission-test",
                                  [helper.make_tensor_value_info("x", TensorProto.FLOAT, [1])],
                                  [helper.make_tensor_value_info("y", TensorProto.FLOAT, [1])],
                                  [helper.make_tensor("bias", TensorProto.FLOAT, [1], [2.0])])
        model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
        model.ir_version = 8
        self.payload = model.SerializeToString()
        self.model = self.root / "model.onnx"
        self.model.write_bytes(self.payload)
        now = datetime.now(timezone.utc).replace(microsecond=0)
        utc = lambda value: value.strftime("%Y-%m-%dT%H:%M:%SZ")
        self.statement = {"id": "synthetic-test", "issued_at": utc(now-timedelta(seconds=1)),
                          "expires_at": utc(now+timedelta(hours=1)), "profile": "onnx-finite-evaluation/v1",
                          "artifact": {"format": "onnx", "sha256": sha256(self.payload), "bytes": len(self.payload)},
                          "parent_sha256": sha256(b"synthetic-parent"), "contract_sha256": sha256(b"synthetic-contract"),
                          "evaluation": {"decision": "PASS", "report_sha256": sha256(b"synthetic-test-only"),
                                         "samples": 1, "source_correct": 1, "candidate_correct": 1,
                                         "decision_changes": 0, "candidate_p95_latency_ns": 1}}
        self.receipt = _sign(self.statement, self.private, "Ephemeral test authority")
        observed = runtime_identity()
        self.p = {"schema": "mfenx/admission-policy/v1", "scope": "tenant-test/prod", "epoch": 1,
                  "minimum_sequence": 1, "expires_at": utc(now+timedelta(seconds=180)),
                  "runtime_profile": RUNTIME_PROFILE, "runtime_version": observed["version"],
                  "runtime_sha256": observed["native_sha256"], "runtime_config_sha256": observed["config_sha256"],
                  "maximum_model_bytes": 1024*1024, "maximum_lease_seconds": 60,
                  "approved_releases": [{"receipt_sha256": sha256(self.receipt), "sequence": 1}],
                  "revoked_receipts": [], "revoked_issuers": [],
                  "contract_sha256": self.statement["contract_sha256"], "issuer_sha256": sha256(self.public),
                  "required_assurance": "issuer-attested-finite-evaluation"}

    def test_versioned_proof_policy_requires_evidence_before_model_parsing(self):
        from unittest.mock import patch
        p = copy.deepcopy(self.p)
        p['schema'] = 'mfenx/admission-policy/v2'
        p['execution_proof'] = {
            'schema': 'mfenx/fixed-mlp-execution/v1', 'image_id': 'risc0:'+'0'*64,
            'program_digest': sha256(b'approved-program'), 'dataset_sha256': sha256(b'approved-data'),
            'sample_index': 0, 'journal_sha256': sha256(b'approved-journal'),
            'verifier_sha256': sha256(b'approved-patched-verifier')}
        policy = self.policy(p)
        with patch.object(onnx, 'load_model_from_string') as parser:
            with self.assertRaisesRegex(ReceiptError, 'required execution proof'):
                self.admit(policy)
            parser.assert_not_called()
        p['schema'] = 'mfenx/admission-policy/v1'
        with self.assertRaises(ReceiptError):
            self.policy(p)
        p['schema'] = 'mfenx/admission-policy/v2'
        p['execution_proof'] = None
        with self.assertRaises(ReceiptError):
            self.policy(p)
        del p['execution_proof']
        with self.assertRaises(ReceiptError):
            self.policy(p)

    def test_unrequired_proof_cannot_be_silently_treated_as_verified(self):
        with self.assertRaisesRegex(ReceiptError, 'explicit v2 proof policy'):
            admit_model(receipt=self.receipt, trusted_public_key=self.public,
                        model=self.model, policy=self.policy(), execution_proof=b'unchecked evidence')

    def policy(self, p=None):
        raw = json.dumps(self.p if p is None else p).encode()
        return AdmissionPolicy.from_bytes(raw, expected_sha256=sha256(raw))

    def admit(self, policy=None):
        return admit_model(receipt=self.receipt, trusted_public_key=self.public,
                            model=self.model, policy=policy or self.policy())

    def test_retained_model_survives_path_replacement_and_delayed_inference(self):
        admitted = self.admit()
        self.model.unlink()
        self.model.write_bytes(b"X" * len(self.payload))
        with ServingSession(admitted, PolicyAuthority(self.policy())) as session:
            for _ in range(2):
                self.assertEqual(session.run({"x": np.array([3.0], np.float32)})[0].tolist(), [5.0])
        self.assertEqual(session.state, "TERMINATED")
        with self.assertRaises(ReceiptError):
            session.run({})

    def test_changed_weight_bytes_and_same_size_replacement_reject(self):
        for payload in [self.payload[:-1]+bytes([self.payload[-1]^1]), b"x"*len(self.payload)]:
            self.model.write_bytes(payload)
            with self.assertRaises(ReceiptError):
                self.admit()

    def test_wrong_signature_policy_contract_runtime_and_release_deny(self):
        for key, value in [("contract_sha256", sha256(b"wrong")), ("issuer_sha256", sha256(b"wrong")),
                           ("runtime_version", "0.0.0"), ("runtime_sha256", sha256(b"wrong")),
                           ("minimum_sequence", 2), ("revoked_receipts", [sha256(self.receipt)]),
                           ("required_assurance", "hardware-confidential"),
                           ("runtime_profile", "cuda-unqualified")]:
            p = copy.deepcopy(self.p); p[key] = value
            with self.subTest(key=key), self.assertRaises(ReceiptError):
                self.admit(self.policy(p))
        wrong_private, _ = generate_keypair()
        self.receipt = _sign(self.statement, wrong_private, "wrong")
        with self.assertRaises(ReceiptError):
            self.admit()

    def test_revocation_epoch_and_unavailable_authority_stop_subsequent_calls(self):
        for event in ["revocation", "unavailable"]:
            authority = PolicyAuthority(self.policy())
            session = ServingSession(self.admit(), authority)
            if event == "revocation":
                p = copy.deepcopy(self.p); p["epoch"] = 2; p["revoked_receipts"] = [sha256(self.receipt)]
                authority.install(self.policy(p))
            else:
                authority.unavailable()
            with self.subTest(event=event), self.assertRaises(ReceiptError):
                session.run({"x": np.array([3.0], np.float32)})
            self.assertEqual(session.state, "TERMINATED")

    def test_durable_rollback_floor_survives_restart(self):
        path = self.root / "authority.sqlite3"
        a = PolicyAuthority(self.policy(), state_path=path)
        p = copy.deepcopy(self.p); p["epoch"] = 2; p["minimum_sequence"] = 2
        a.install(self.policy(p))
        with self.assertRaises(ReceiptError):
            PolicyAuthority(self.policy(), state_path=path)
        PolicyAuthority(self.policy(p), state_path=path)

    def test_expired_lease_does_not_execute(self):
        session = ServingSession(self.admit(), PolicyAuthority(self.policy()))
        session._started -= 100
        with self.assertRaises(ReceiptError):
            session.run({})
        self.assertEqual(session.state, "TERMINATED")

    def test_independent_policy_pin_and_duplicate_json_reject(self):
        raw = json.dumps(self.p).encode()
        with self.assertRaises(ReceiptError):
            AdmissionPolicy.from_bytes(raw, expected_sha256=sha256(b"wrong"))
        raw = raw[:-1] + b',"epoch":1}'
        with self.assertRaises(ReceiptError):
            AdmissionPolicy.from_bytes(raw, expected_sha256=sha256(raw))

    def test_runtime_configuration_cannot_drift_after_policy_authentication(self):
        from unittest.mock import patch
        from mfenx_gate.admission import RUNTIME_CONFIG
        policy = self.policy()
        with patch.dict(RUNTIME_CONFIG, {"intra_op_threads": 2}):
            with self.assertRaises(ReceiptError):
                self.admit(policy)

    def test_cuda_profile_cannot_enter_the_cpu_supervisor(self):
        from mfenx_gate.admission import CUDA_RUNTIME_PROFILE, CUDA_RUNTIME_CONFIG
        from mfenx_gate.receipt import canonical
        p = copy.deepcopy(self.p)
        p.update(runtime_profile=CUDA_RUNTIME_PROFILE,
                 runtime_config_sha256=sha256(canonical(CUDA_RUNTIME_CONFIG)))
        with self.assertRaises(ReceiptError):
            self.policy(p)
        p["runtime_provider_sha256"] = sha256(b"operator-selected-test-provider")
        self.assertEqual(self.policy(p).runtime_profile, CUDA_RUNTIME_PROFILE)
        raw = json.dumps(p).encode()
        for name, data in [("receipt.json", self.receipt), ("issuer.der", self.public), ("policy.json", raw)]:
            (self.root / name).write_bytes(data)
        state = self.root / "forbidden-gpu-state.sqlite3"
        with self.assertRaises(ReceiptError):
            run_isolated({"receipt": str(self.root / "receipt.json"),
                          "trusted_key": str(self.root / "issuer.der"), "model": str(self.model),
                          "policy": str(self.root / "policy.json"), "policy_sha256": sha256(raw),
                          "state": str(state), "inputs": {"x": [3.0]}})
        self.assertFalse(state.exists(), "CPU supervisor must reject before activation state is created")

    def test_symlink_and_fifo_never_reach_parser(self):
        actual = self.root / "actual.onnx"; self.model.rename(actual)
        self.model.symlink_to(actual)
        with self.assertRaises(ReceiptError):
            self.admit()
        self.model.unlink(); os.mkfifo(self.model)
        with self.assertRaises(ReceiptError):
            self.admit()

    def test_isolated_worker_executes_actual_model_and_rejects_replacement(self):
        (self.root/"receipt.json").write_bytes(self.receipt)
        (self.root/"issuer.der").write_bytes(self.public)
        raw = json.dumps(self.p).encode(); (self.root/"policy.json").write_bytes(raw)
        request = {"receipt": str(self.root/"receipt.json"), "trusted_key": str(self.root/"issuer.der"),
                   "model": str(self.model), "policy": str(self.root/"policy.json"),
                   "policy_sha256": sha256(raw), "state": str(self.root/"state.sqlite3"), "inputs": {"x": [3.0]}}
        from contextlib import chdir
        marker = self.root / "unexpected-worker-import"
        malicious = 'open(' + repr(str(marker)) + ',"w").write("unsafe import")\nraise RuntimeError("unsafe worker import")\n'
        package = self.root / "mfenx_gate"
        package.mkdir()
        (package / "__init__.py").write_text(malicious)
        (self.root / "resource.py").write_text(malicious)
        with chdir(self.root):
            result = run_isolated(request)
        self.assertFalse(marker.exists(), "CPU worker imported candidate-controlled code")
        self.assertEqual(result["outputs"], [[5.0]])
        self.assertEqual(result["model_sha256"], sha256(self.payload))
        self.model.write_bytes(b"X" * len(self.payload))
        with self.assertRaises(ReceiptError):
            run_isolated(request)

    def test_clock_rollback_and_cross_process_policy_update_deny(self):
        from unittest.mock import patch
        path = self.root / "state.sqlite3"
        authority = PolicyAuthority(self.policy(), state_path=path)
        with patch("mfenx_gate.admission.time.time", return_value=1):
            with self.assertRaises(ReceiptError):
                PolicyAuthority(self.policy(), state_path=path)
        session = ServingSession(self.admit(), authority)
        p = copy.deepcopy(self.p); p["epoch"] = 2
        PolicyAuthority(self.policy(p), state_path=path)
        with self.assertRaises(ReceiptError):
            session.run({})
        self.assertEqual(session.state, "TERMINATED")

    def test_audit_failure_denies_activation(self):
        from unittest.mock import patch
        authority = PolicyAuthority(self.policy(), state_path=self.root / "state.sqlite3")
        admitted = self.admit()
        with patch.object(authority, "record", side_effect=ReceiptError("audit unavailable")):
            with self.assertRaises(ReceiptError):
                ServingSession(admitted, authority)

    def test_two_actual_workers_and_resource_measurements(self):
        from concurrent.futures import ThreadPoolExecutor
        (self.root/"receipt.json").write_bytes(self.receipt)
        (self.root/"issuer.der").write_bytes(self.public)
        raw = json.dumps(self.p).encode(); (self.root/"policy.json").write_bytes(raw)
        request = {"receipt": str(self.root/"receipt.json"), "trusted_key": str(self.root/"issuer.der"),
                   "model": str(self.model), "policy": str(self.root/"policy.json"), "policy_sha256": sha256(raw),
                   "state": str(self.root/"state.sqlite3"), "inputs": {"x": [3.0]}}
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(run_isolated, [request, request]))
        for result in results:
            self.assertEqual(result["outputs"], [[5.0]])
            self.assertGreater(result["resources"]["peak_rss_kib"], 0)
            self.assertEqual(result["resources"]["address_space_limit_bytes"], 2048 * 1024**2)

    def test_supervisor_terminates_long_native_loop(self):
        body = helper.make_graph([
            helper.make_node("Identity", ["condition"], ["next_condition"]),
            helper.make_node("Identity", ["value"], ["next_value"])], "loop-body",
            [helper.make_tensor_value_info("iteration", TensorProto.INT64, []),
             helper.make_tensor_value_info("condition", TensorProto.BOOL, []),
             helper.make_tensor_value_info("value", TensorProto.FLOAT, [1])],
            [helper.make_tensor_value_info("next_condition", TensorProto.BOOL, []),
             helper.make_tensor_value_info("next_value", TensorProto.FLOAT, [1])])
        graph = helper.make_graph([helper.make_node("Loop", ["count", "condition", "x"], ["y"], body=body)],
            "deadline-test", [helper.make_tensor_value_info("x", TensorProto.FLOAT, [1])],
            [helper.make_tensor_value_info("y", TensorProto.FLOAT, [1])],
            [helper.make_tensor("count", TensorProto.INT64, [], [100000000]),
             helper.make_tensor("condition", TensorProto.BOOL, [], [True])])
        model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)]); model.ir_version = 8
        self.model.write_bytes(model.SerializeToString())
        self.statement["artifact"] = {"format": "onnx", "sha256": sha256(self.model.read_bytes()), "bytes": self.model.stat().st_size}
        self.receipt = _sign(self.statement, self.private, "Ephemeral deadline-test authority")
        self.p["approved_releases"][0]["receipt_sha256"] = sha256(self.receipt)
        (self.root/"receipt.json").write_bytes(self.receipt); (self.root/"issuer.der").write_bytes(self.public)
        raw = json.dumps(self.p).encode(); (self.root/"policy.json").write_bytes(raw)
        request = {"receipt": str(self.root/"receipt.json"), "trusted_key": str(self.root/"issuer.der"),
                   "model": str(self.model), "policy": str(self.root/"policy.json"), "policy_sha256": sha256(raw),
                   "state": str(self.root/"state.sqlite3"), "inputs": {"x": [3.0]}}
        with self.assertRaisesRegex(ReceiptError, "wall deadline"):
            run_isolated(request, wall_seconds=2)

    def test_external_dense_and_sparse_tensor_dependencies_are_rejected(self):
        for sparse in [False, True]:
            parsed = onnx.load_model_from_string(self.payload)
            if sparse:
                item = parsed.graph.sparse_initializer.add()
                item.values.name = "sparse-weights"; item.values.data_type = TensorProto.FLOAT
                item.values.dims.append(1); item.values.float_data.append(1.0)
                item.indices.data_type = TensorProto.INT64; item.indices.dims.append(1)
                item.dims.append(2); tensor = item.indices
            else:
                tensor = parsed.graph.initializer[0]
                tensor.ClearField("float_data")
            tensor.data_location = TensorProto.EXTERNAL
            value = tensor.external_data.add(); value.key = "location"; value.value = "../unapproved-weights.bin"
            raw = parsed.SerializeToString(); self.model.write_bytes(raw)
            self.statement["artifact"] = {"format": "onnx", "sha256": sha256(raw), "bytes": len(raw)}
            self.receipt = _sign(self.statement, self.private, "Ephemeral external-dependency test")
            self.p["approved_releases"][0]["receipt_sha256"] = sha256(self.receipt)
            with self.subTest(sparse=sparse), self.assertRaisesRegex(ReceiptError, "external ONNX"):
                self.admit()

    def test_mutation_during_real_file_read_is_rejected(self):
        from unittest.mock import patch
        original = os.fdopen
        model_path = self.model
        payload = self.payload
        class ChangedReader:
            def __init__(self, handle): self.handle = handle
            def __enter__(self): return self
            def __exit__(self, *args): self.handle.close()
            def fileno(self): return self.handle.fileno()
            def read(self, maximum):
                model_path.write_bytes(b"X"*len(payload))
                return self.handle.read(maximum)
        with patch("mfenx_gate.receipt.os.fdopen", side_effect=lambda fd, mode: ChangedReader(original(fd, mode))):
            with self.assertRaises(ReceiptError): self.admit()


if __name__ == "__main__":
    unittest.main()
