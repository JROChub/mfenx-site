"""Actual encrypted acquisition plus native SFCS verification; no hardware claim."""
from contextlib import closing
import copy
import json
import os
from pathlib import Path
import sqlite3
import time
import unittest
from unittest.mock import patch

import numpy as np
import onnxruntime as ort

from mfenx_gate.admission import PolicyAuthority, ServingSession
from mfenx_gate.encrypted import Descriptor, admit_encrypted_model, encrypt_model
from mfenx_gate.execution import verify_execution_proof
from mfenx_gate.receipt import ReceiptError, _sign, canonical, sha256
import test_trustee_integration as trustee_fixture

@unittest.skipUnless(os.environ.get('MFENX_ENCRYPTED_PROOF_QUALIFICATION')=='1',
                     'requires actual native SFCS verifier, generated proof and public model/data')
class EncryptedProofTests(unittest.TestCase):
    setUpClass=classmethod(trustee_fixture.TrusteeIntegrationTests.setUpClass.__func__)
    stop_server=classmethod(trustee_fixture.TrusteeIntegrationTests.stop_server.__func__)
    make_policy=trustee_fixture.TrusteeIntegrationTests.make_policy
    admin=trustee_fixture.TrusteeIntegrationTests.admin
    allow_development_sample=trustee_fixture.TrusteeIntegrationTests.allow_development_sample
    install_policy=trustee_fixture.TrusteeIntegrationTests.install_policy

    def setUp(self):
        trustee_fixture.TrusteeIntegrationTests.setUp(self)
        fixtures=Path(os.environ['MFENX_ENCRYPTED_PROOF_FIXTURES'])
        self.verifier=Path(os.environ['MFENX_ENCRYPTED_PROOF_VERIFIER'])
        self.proof=(fixtures/'execution.pha').read_bytes()
        self.payload=(fixtures/'source.onnx').read_bytes()
        dataset=(fixtures/'dataset.npz').read_bytes()
        self.assertEqual(sha256(self.payload),'sha256:efaf1bec54e8eea3d49f6ff5abef1482ca3f69775e5978772913032d75ad9ff9')
        self.assertEqual(sha256(dataset),'sha256:b281019a68b5f20f7900774fffa870f51e3a7df263407d1b73a030358710874d')
        self.assertEqual(sha256(self.verifier.read_bytes()),'sha256:504bde645d83c25dd43c3ef69fc85b4f5f18d5b500e8e0f3136f4173bda582b8')
        options=ort.SessionOptions();options.intra_op_num_threads=1;options.inter_op_num_threads=1
        options.graph_optimization_level=ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        native=ort.InferenceSession(self.payload,sess_options=options,providers=['CPUExecutionProvider'])
        self.inputs=[];decisions=[];latency=[]
        with np.load(fixtures/'dataset.npz',allow_pickle=False) as data:
            self.inputs=data['inputs'].copy();labels=data['labels'].copy()
        for row in self.inputs:
            start=time.monotonic_ns();outputs=native.run(None,{'input':row[None,:]});latency.append(time.monotonic_ns()-start)
            decisions.append(int(np.argmax(outputs[0][0])))
        correct=int(np.sum(np.asarray(decisions)==labels))
        report={'schema':'mfenx/encrypted-proof-test-evaluation/v1','samples':len(labels),'correct':correct,
                'dataset_sha256':sha256(dataset),'model_sha256':sha256(self.payload),'runtime':ort.__version__,
                'candidate_p95_latency_ns':int(np.percentile(latency,95))}
        self.statement['artifact']={'format':'onnx','sha256':sha256(self.payload),'bytes':len(self.payload)}
        self.statement['parent_sha256']=sha256(self.payload)
        self.statement['evaluation'].update(samples=len(labels),source_correct=correct,candidate_correct=correct,
            decision_changes=0,candidate_p95_latency_ns=report['candidate_p95_latency_ns'],report_sha256=sha256(canonical(report)))
        self.receipt=_sign(self.statement,self.private,'Ephemeral encrypted proof test authority')
        self.p['approved_releases']=[{'receipt_sha256':sha256(self.receipt),'sequence':1}]
        self.p['schema']='mfenx/admission-policy/v2'
        self.p['execution_proof']={'schema':'mfenx/fixed-mlp-execution/v1',
          'image_id':'risc0:392f246b67cb70cc19d07e4337b48efbf5e04cf026270c5c0e051f21f7900020',
          'program_digest':'sha256:b1ed482aa92462b48d46324eaa5017bfe6dcb9f9165faebdf65d78ad9dc62120',
          'dataset_sha256':sha256(dataset),'sample_index':0,
          'journal_sha256':'sha256:336dcb71874b27c00e9f2963020ccfdf7a9143dd4f25b31400e433f82b52bbb8',
          'verifier_sha256':sha256(self.verifier.read_bytes())}
        self.package=encrypt_model(self.payload,receipt=self.receipt,trusted_public_key=self.public)
        self.descriptor=Descriptor.from_bytes(self.package.descriptor,expected_sha256=sha256(self.package.descriptor))
        self.cipher.write_bytes(self.package.ciphertext)
        self.raw_policy['descriptor_sha256']=self.descriptor.digest;self.policy=self.make_policy()
        self.admin('resource/'+self.descriptor.context['resource'],self.package.key)

    def admit(self,proof=None):
        return admit_encrypted_model(descriptor=self.package.descriptor,ciphertext=self.cipher,receipt=self.receipt,
            trusted_public_key=self.public,policy=self.policy,trustee_client=self.client,broker_ca=self.ca,
            execution_proof=self.proof if proof is None else proof,proof_verifier=self.verifier)

    def test_real_encrypted_key_delivery_native_proof_and_retained_inference(self):
        model=self.admit();self.cipher.unlink();self.cipher.write_bytes(b'X'*len(self.package.ciphertext))
        with ServingSession(model,PolicyAuthority(self.policy.admission,state_path=self.root/'state.sqlite')) as session:
            logits=session.run({'input':self.inputs[0:1]})[0]
            self.assertEqual(int(np.argmax(logits[0])),0)
        with closing(sqlite3.connect(self.root/'state.sqlite')) as db:
            proof=db.execute('SELECT proof FROM admission_execution_evidence').fetchone()[0]
            distribution=db.execute('SELECT distribution FROM admission_distribution_evidence').fetchone()[0]
            completed=db.execute("SELECT COUNT(*) FROM admission_audit WHERE event='inference-completed'").fetchone()[0]
        self.assertEqual(proof,sha256(self.proof));self.assertEqual(distribution,model.distribution_sha256)
        self.assertEqual(completed,1)

    def test_required_proof_missing_denies_before_key_request(self):
        with patch('mfenx_gate.trustee.retrieve_key') as fetch:
            with self.assertRaisesRegex(ReceiptError,'required execution proof'):
                admit_encrypted_model(descriptor=self.package.descriptor,ciphertext=self.cipher,receipt=self.receipt,
                    trusted_public_key=self.public,policy=self.policy,trustee_client=self.client,broker_ca=self.ca)
            fetch.assert_not_called()

    def test_altered_external_receipt_is_rejected_before_model_parser(self):
        raw=json.loads(self.proof)
        # The deterministic core is retained; the protocol attachment is not.
        raw['embedded_proof']['external_proof_attachments'][0]['payload']['proof']['receipt_base64']='AA=='
        corrupted=json.dumps(raw,sort_keys=True,separators=(',',':')).encode()
        with patch('onnx.load_model_from_string') as parser, \
                patch('mfenx_gate.execution.verify_execution_proof',wraps=verify_execution_proof) as verifier:
            with self.assertRaises(ReceiptError):self.admit(corrupted)
            verifier.assert_called_once()
            parser.assert_not_called()

    def test_valid_proof_for_different_required_dataset_denies_before_parser(self):
        self.p['execution_proof']['dataset_sha256']=sha256(b'wrong required dataset')
        self.policy=self.make_policy()
        with patch('onnx.load_model_from_string') as parser:
            with self.assertRaises(ReceiptError):self.admit()
            parser.assert_not_called()

if __name__=='__main__':unittest.main()
