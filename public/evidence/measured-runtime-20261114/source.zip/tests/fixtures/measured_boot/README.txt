The retained CCEL and reference inputs originate from an actual 14 November 2026
TDX EFI boot. observation.json records register replay and transcript matching;
it explicitly does not qualify firmware or confidential model execution.
Unit tests use the retained register values as fixed inputs. They do not perform
online vendor-collateral verification and must not be described as fresh hardware
attestation. EFI, kernel and initial-filesystem measurements have distinct roles.
