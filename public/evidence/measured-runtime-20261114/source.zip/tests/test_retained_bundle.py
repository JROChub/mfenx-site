"""Reuse signed CKODMK envelopes and observe actual kernel write-seal enforcement."""
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import tempfile
import unittest

from mfenx_ckodmk.external_envelope import ArtifactInput, issue_external_envelope
from mfenx_gate.bundle import retain_bundle
from mfenx_gate.receipt import generate_keypair, sha256, ReceiptError


class BundleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root/"model").mkdir()
        (self.root/"model/shard.bin").write_bytes(b"signed-shard-contents")
        (self.root/"tokenizer.json").write_bytes(b"{}")
        self.private, self.public = generate_keypair()
        now = datetime.now(timezone.utc)
        fmt = lambda t: t.strftime("%Y-%m-%dT%H:%M:%SZ")
        self.raw = issue_external_envelope(root=self.root, artifacts=[
            ArtifactInput("model/shard.bin", "model-checkpoint-shard", "application/octet-stream"),
            ArtifactInput("tokenizer.json", "tokenizer", "application/json")],
            private_key_pem=self.private, issuer_name="Ephemeral test issuer", serial="bundle-test",
            issued_at=fmt(now-timedelta(seconds=1)), expires_at=fmt(now+timedelta(hours=1)),
            release_kind="integrity-test", subject="synthetic-test")

    def retain(self, **kwargs):
        return retain_bundle(self.raw, root=self.root, trusted_public_key=self.public,
                             expected_envelope_sha256=sha256(self.raw), **kwargs)

    def test_sealed_objects_survive_original_replacement_and_deny_writes(self):
        with self.retain() as bundle:
            (self.root/"model/shard.bin").write_bytes(b"attacker replacement")
            fd = bundle.duplicate_descriptor("model/shard.bin")
            try:
                self.assertEqual(os.pread(fd, 100, 0), b"signed-shard-contents")
                with self.assertRaises(PermissionError):
                    os.pwrite(fd, b"X", 0)
                with self.assertRaises(PermissionError):
                    os.ftruncate(fd, 0)
            finally:
                os.close(fd)
            self.assertEqual(bundle.behavioral_status, "NOT_EVALUATED")
            with self.assertRaises(ReceiptError):
                bundle.duplicate_descriptor("undeclared-plugin.so")

    def test_extra_missing_substituted_or_linked_files_reject(self):
        for kind in ["extra", "missing", "same-size", "link"]:
            with self.subTest(kind=kind):
                target = self.root/"model/shard.bin"
                if target.exists() or target.is_symlink():
                    target.unlink()
                target.write_bytes(b"signed-shard-contents")
                if kind == "extra": (self.root/"plugin.so").write_bytes(b"x")
                if kind == "missing": target.unlink()
                if kind == "same-size": target.write_bytes(b"X"*len(b"signed-shard-contents"))
                if kind == "link": target.unlink(); target.symlink_to(self.root/"tokenizer.json")
                with self.assertRaises(Exception): self.retain()
                (self.root/"plugin.so").unlink(missing_ok=True)

    def test_oversize_and_wrong_authority_reject(self):
        with self.assertRaises(ReceiptError): self.retain(max_total_bytes=1)
        _, wrong = generate_keypair()
        with self.assertRaises(Exception):
            retain_bundle(self.raw, root=self.root, trusted_public_key=wrong,
                          expected_envelope_sha256=sha256(self.raw))

    def test_signed_but_inconsistent_safetensors_index_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            header = json.dumps({"w": {"dtype": "F32", "shape": [1], "data_offsets": [0, 4]}}).encode()
            (root/"model-00001.safetensors").write_bytes(len(header).to_bytes(8, "little")+header+bytes(4))
            index = root/"model.safetensors.index.json"
            index.write_text(json.dumps({"metadata": {"total_size": 4}, "weight_map": {"w": "model-00001.safetensors"}}))
            now = datetime.now(timezone.utc)
            def issue():
                return issue_external_envelope(root=root, artifacts=[
                    ArtifactInput("model-00001.safetensors", "model-weights", "application/octet-stream"),
                    ArtifactInput(index.name, "shard-index", "application/json")],
                    private_key_pem=self.private, issuer_name="Ephemeral shard-index test", serial="shards-test",
                    issued_at=(now-timedelta(seconds=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    expires_at=(now+timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    release_kind="integrity-test", subject="synthetic-test")
            raw = issue()
            with retain_bundle(raw, root=root, trusted_public_key=self.public,
                               expected_envelope_sha256=sha256(raw), checkpoint_format="safetensors") as bundle:
                self.assertEqual(bundle.checkpoint_inventory["parameter_count"], 1)
            index.write_text(json.dumps({"metadata": {"total_size": 4}, "weight_map": {"wrong-name": "model-00001.safetensors"}}))
            raw = issue()
            with self.assertRaises(Exception):
                retain_bundle(raw, root=root, trusted_public_key=self.public,
                              expected_envelope_sha256=sha256(raw), checkpoint_format="safetensors")


if __name__ == "__main__": unittest.main()
