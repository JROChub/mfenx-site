from __future__ import annotations

import base64
import copy
from datetime import datetime, timedelta, timezone
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from unittest.mock import patch

from mfenx_gate.cli import main
from mfenx_gate.receipt import (ALGORITHM, MAX_RECEIPT, P256_ORDER, ReceiptError,
                              _sign, canonical, generate_keypair, hash_artifact,
                              parse, read_regular, sha256, verify_receipt)
from mfenx_gate.workflow import admit_onnx, issue_integrity


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.directory = Path(self.tmp.name)
        self.model = self.directory / "model.onnx"
        self.model.write_bytes(b"unit-test-model-bytes")
        self.private, self.public = generate_keypair()
        now = datetime.now(timezone.utc).replace(microsecond=0)
        self.statement = {
            "id": "test-release", "issued_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expires_at": (now + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "profile": "onnx-finite-evaluation/v1", "artifact": {
                "format": "onnx", "sha256": sha256(self.model.read_bytes()), "bytes": self.model.stat().st_size},
            "parent_sha256": sha256(b"source"), "contract_sha256": sha256(b"contract"),
            "evaluation": {"decision": "PASS", "report_sha256": sha256(b"local-report"),
                           "samples": 20, "source_correct": 18, "candidate_correct": 18,
                           "decision_changes": 0, "candidate_p95_latency_ns": 1000}}
        self.raw = _sign(self.statement, self.private, "Test issuer")

    def test_valid_attestation_is_not_replay(self):
        result = verify_receipt(self.raw, self.public)
        self.assertEqual(result["status"], "ATTESTATION_VERIFIED")
        self.assertEqual(result["artifactStatus"], "NOT_CHECKED")
        self.assertEqual(result["contractStatus"], "NOT_CHECKED")
        self.assertEqual(result["replayStatus"], "NOT_PERFORMED")

    def test_artifact_and_expected_contract(self):
        result = verify_receipt(self.raw, self.public, artifact=self.model,
                                expected_contract_digest=sha256(b"contract"))
        self.assertEqual(result["artifactStatus"], "MATCH")
        self.assertEqual(result["contractStatus"], "MATCH")

    def test_immutable_artifact_bytes_binding(self):
        payload = self.model.read_bytes()
        self.assertEqual(verify_receipt(self.raw, self.public, artifact_bytes=payload)["artifactStatus"], "MATCH")
        for arguments in ({"artifact_bytes": bytearray(payload)}, {"artifact_bytes": payload + b"wrong"},
                          {"artifact": self.model, "artifact_bytes": payload}):
            with self.subTest(arguments=arguments), self.assertRaises(ReceiptError):
                verify_receipt(self.raw, self.public, **arguments)

    def test_wrong_trust_key(self):
        with self.assertRaises(ReceiptError):
            verify_receipt(self.raw, generate_keypair()[1])

    def test_wrong_artifact(self):
        self.model.write_bytes(b"different")
        with self.assertRaises(ReceiptError):
            verify_receipt(self.raw, self.public, artifact=self.model)

    def test_wrong_contract(self):
        with self.assertRaises(ReceiptError):
            verify_receipt(self.raw, self.public, expected_contract_digest=sha256(b"wrong"))

    def test_expired_and_future(self):
        now = datetime.now(timezone.utc)
        for moment in (now - timedelta(days=1), now + timedelta(days=2)):
            with self.subTest(moment=moment), self.assertRaises(ReceiptError):
                verify_receipt(self.raw, self.public, now=moment)

    def test_mutated_bound_fields(self):
        for field in ("schema", "root_id"):
            document = parse(self.raw); document[field] += "tamper"
            with self.subTest(field=field), self.assertRaises(ReceiptError):
                verify_receipt(canonical(document), self.public)
        for field in ("name", "key_id", "algorithm"):
            document = parse(self.raw); document["issuer"][field] += "tamper"
            with self.subTest(field=field), self.assertRaises(ReceiptError):
                verify_receipt(canonical(document), self.public)
        document = parse(self.raw); document["statement"]["evaluation"]["candidate_correct"] += 1
        with self.assertRaises(ReceiptError):
            verify_receipt(canonical(document), self.public)

    def test_signature_mutations(self):
        for style in ("flip", "high_s", "zero", "oversized", "bad_base64"):
            document = parse(self.raw)
            value = bytearray(base64.b64decode(document["signature"]["value_base64"]))
            if style == "flip": value[4] ^= 1
            if style == "high_s": value[32:] = (P256_ORDER - int.from_bytes(value[32:], "big")).to_bytes(32, "big")
            if style == "zero": value[32:] = bytes(32)
            if style == "oversized": value += b"x"
            document["signature"]["value_base64"] = "???" if style == "bad_base64" else base64.b64encode(value).decode()
            with self.subTest(style=style), self.assertRaises(ReceiptError):
                verify_receipt(canonical(document), self.public)

    def test_ambiguous_json_and_limits(self):
        invalid = [b'{"schema":"x","schema":"y"}', b'{"x":1.0}', b'{"x":1e0}',
                   b'{"x":NaN}', b'{"x":9007199254740992}', b'{"x":"\\u00e9"}',
                   b"[] trailing", b" " * (MAX_RECEIPT + 1), b'[' * 40 + b'0' + b']' * 40,
                   b'{"x":' + b'9' * 5000 + b'}']
        for raw in invalid:
            with self.subTest(raw=raw[:50]), self.assertRaises((ReceiptError, ValueError)):
                parse(raw)

    def test_invalid_statement_types_and_profiles(self):
        mutations = [("profile", "unknown"), ("issued_at", "2026-02-30T00:00:00Z"),
                     ("expires_at", "2020-01-01T00:00:00Z"), ("id", "path/to/model")]
        for field, value in mutations:
            statement = copy.deepcopy(self.statement); statement[field] = value
            with self.subTest(field=field), self.assertRaises(ReceiptError):
                _sign(statement, self.private, "Test issuer")
        for value in (True, -1, 1.5, 21):
            statement = copy.deepcopy(self.statement); statement["evaluation"]["candidate_correct"] = value
            with self.subTest(value=value), self.assertRaises(ReceiptError):
                _sign(statement, self.private, "Test issuer")

    def test_no_embedded_trust_key(self):
        document = parse(self.raw); document["issuer"]["public_key"] = base64.b64encode(self.public).decode()
        with self.assertRaises(ReceiptError): verify_receipt(canonical(document), self.public)

    def test_symlinks_and_fifo(self):
        link = self.directory / "link"; link.symlink_to(self.model)
        fifo = self.directory / "fifo"; os.mkfifo(fifo)
        for path in (link, fifo, self.directory):
            with self.subTest(path=path), self.assertRaises(ReceiptError): read_regular(path)
            with self.subTest(path=path), self.assertRaises(ReceiptError): hash_artifact(path)

    def test_cli_verification_and_key_no_overwrite(self):
        receipt = self.directory / "receipt.json"; receipt.write_bytes(self.raw)
        public = self.directory / "trust.der"; public.write_bytes(self.public)
        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(main(["verify", str(receipt), "--trusted-public-key", str(public), "--model", str(self.model)]), 0)
        self.assertEqual(json.loads(output.getvalue())["artifactStatus"], "MATCH")
        private = self.directory / "new.pem"; new_public = self.directory / "new.der"
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            self.assertEqual(main(["keygen", "--private-key", str(private), "--public-key", str(new_public)]), 0)
            before = private.read_bytes()
            self.assertEqual(main(["keygen", "--private-key", str(private), "--public-key", str(new_public)]), 2)
        self.assertEqual(private.read_bytes(), before)
        self.assertEqual(private.stat().st_mode & 0o777, 0o600)

    def test_no_receipt_on_block_or_inconclusive(self):
        for decision in ("BLOCK", "INCONCLUSIVE"):
            with patch("mfenx_ckodmk.gate.runner.run_onnx_gate", return_value={"decision": decision}):
                receipt, report = admit_onnx(source=self.model, candidate=self.model, dataset=self.model,
                    contract=self.model, expected_contract_digest=sha256(b"contract"), private_key=self.private, issuer="Test")
            self.assertIsNone(receipt)
            self.assertEqual(report["decision"], decision)

    def test_single_safetensors_integrity_real_inspection(self):
        model = self.directory / "weights.safetensors"
        header = json.dumps({"weights": {"dtype": "F32", "shape": [2], "data_offsets": [0, 8]}}, separators=(",", ":")).encode()
        header += b" " * ((8 - len(header) % 8) % 8)
        model.write_bytes(len(header).to_bytes(8, "little") + header + bytes(8))
        raw, report = issue_integrity(model=model, private_key=self.private, issuer="Test")
        verified = verify_receipt(raw, self.public, artifact=model)
        self.assertEqual(verified["behavioralStatus"], "NOT_EVALUATED")
        self.assertEqual(verified["contractStatus"], "NOT_APPLICABLE")
        self.assertEqual(report["parameter_count"], 2)
        with self.assertRaises(ReceiptError):
            verify_receipt(raw, self.public, expected_contract_digest=sha256(b"contract"))

    def test_cli_block_does_not_publish_receipt(self):
        private = self.directory / "private.pem"; private.write_bytes(self.private)
        output = self.directory / "release.json"
        args = ["admit-onnx", "--source", str(self.model), "--candidate", str(self.model),
                "--dataset", str(self.model), "--contract", str(self.model),
                "--expected-contract-sha256", sha256(b"contract"), "--private-key", str(private),
                "--issuer", "Test", "--output", str(output)]
        with patch("mfenx_ckodmk.gate.runner.run_onnx_gate", return_value={"decision": "BLOCK"}), redirect_stdout(io.StringIO()):
            self.assertEqual(main(args), 3)
        self.assertFalse(output.exists())

    def test_integrity_claim_escalation_is_rejected(self):
        statement = copy.deepcopy(self.statement)
        statement["profile"] = "safetensors-integrity/v1"
        statement["artifact"]["format"] = "safetensors"
        with self.assertRaises(ReceiptError): _sign(statement, self.private, "Test")

    def test_non_p256_key_is_rejected(self):
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        wrong = ec.generate_private_key(ec.SECP384R1()).private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        with self.assertRaises(ReceiptError): _sign(self.statement, wrong, "Test")

    def test_receipt_has_no_paths_or_private_payloads(self):
        self.assertNotIn(str(self.directory).encode(), self.raw)
        self.assertNotIn(self.model.read_bytes(), self.raw)
        self.assertNotIn(b"PRIVATE KEY", self.raw)
        self.assertNotIn(b"payloads", self.raw)

    def test_checkpoint_corruption_cannot_issue(self):
        model = self.directory / "broken.safetensors"; model.write_bytes(b"broken data")
        with self.assertRaises(ValueError): issue_integrity(model=model, private_key=self.private, issuer="Test")

    def test_receipt_schema_extra_field_and_non_object(self):
        document = parse(self.raw); document["approved"] = True
        for raw in (canonical(document), b"null", b"[]", b"true", b"0"):
            with self.subTest(raw=raw[:40]), self.assertRaises(ReceiptError): verify_receipt(raw, self.public)

    def test_python_browser_interoperability_and_rejections(self):
        receipt = self.directory / "receipt.json"; receipt.write_bytes(self.raw)
        public = self.directory / "trust.der"; public.write_bytes(self.public)
        script = Path(__file__).with_name("test_receipt_browser.mjs")
        subprocess.run(["node", str(script), str(receipt), str(public), str(self.model)], check=True, capture_output=True, text=True, timeout=30)

    def test_browser_async_input_substitution_regressions(self):
        script = Path(__file__).with_name("test_receipt_review.mjs")
        subprocess.run(["node", str(script)], check=True, capture_output=True, text=True, timeout=30)


if __name__ == "__main__": unittest.main()
