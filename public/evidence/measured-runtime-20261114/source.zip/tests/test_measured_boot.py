"""Measured boot parsing and policy binding; not live attestation qualification."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import unittest

from mfenx_gate.encrypted import EncryptedPolicy, Descriptor
from mfenx_gate.measured_boot import BootReference, CPU_PROFILE, GPU_PROFILE, _extend
from mfenx_gate.receipt import ReceiptError, canonical, sha256
from mfenx_gate.trustee_policy import resource_policy
import test_admission as fixtures

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('measured_eventlog',ROOT/'integrations/measured_boot/eventlog.py')
eventlog=importlib.util.module_from_spec(spec);sys.modules[spec.name]=eventlog;spec.loader.exec_module(eventlog)

class EventLogTests(unittest.TestCase):
    def setUp(self):
        root=ROOT/'tests/fixtures/measured_boot'
        self.raw=(root/'ccel.bin').read_bytes()
        self.refs=json.loads((root/'references.json').read_text())
        for name in ['bootstrap_digest','kernel_digest','initrd_digest','approved_gpt']:
            self.refs[name]=bytes.fromhex(self.refs[name])
        self.registers=tuple(bytes.fromhex(x) for x in json.loads((root/'observation.json').read_text())['rtmr'])

    def identify(self, raw=None, refs=None):
        return eventlog.identify_bootstrap(self.raw if raw is None else raw,self.registers,**(self.refs if refs is None else refs))

    def test_retained_register_replay_and_complete_transcript(self):
        result=self.identify()
        self.assertTrue(result['bootstrap_identified'])
        self.assertFalse(result['confidential_model_execution_qualified'])
        self.assertFalse(result['firmware_configuration_authorized'])

    def test_oversized_truncated_and_bad_algorithm_declarations(self):
        bad=bytearray(self.raw);bad[62]^=1
        for raw in [self.raw+b'x'*eventlog.MAX_LOG_BYTES,self.raw[:60],bytes(bad)]:
            with self.subTest(size=len(raw)),self.assertRaises(ValueError):self.identify(raw)

    def test_mutated_measurements_cannot_replay_authenticated_registers(self):
        # First event follows the legacy specification header.
        offset=32+struct.unpack_from('<I',self.raw,28)[0]
        bad=bytearray(self.raw);bad[offset+14]^=1
        with self.assertRaises(ValueError):self.identify(bytes(bad))

    def test_relabelled_executable_cannot_hide_behind_unchanged_digests(self):
        raw=bytearray(self.raw);offset=32+struct.unpack_from('<I',raw,28)[0]
        while offset<len(raw):
            register,kind,count=struct.unpack_from('<III',raw,offset)
            if register==2 and kind==eventlog.EFI_APPLICATION:
                struct.pack_into('<I',raw,offset+4,6);break
            cursor=offset+12
            for _ in range(count):
                alg=struct.unpack_from('<H',raw,cursor)[0];cursor+=2+eventlog._ALGORITHMS[alg]
            offset=cursor+4+struct.unpack_from('<I',raw,cursor)[0]
        else:self.fail('fixture lacks executable event')
        self.assertEqual(eventlog.replay(eventlog.parse(bytes(raw))),self.registers)
        with self.assertRaisesRegex(ValueError,'transcript'):self.identify(bytes(raw))

    def test_each_wrong_independent_reference_denies(self):
        for name in self.refs:
            refs=self.refs.copy();v=refs[name]
            refs[name]=(v+' altered') if isinstance(v,str) else v[:-1]+bytes([v[-1]^1])
            with self.subTest(name=name),self.assertRaises(ValueError):self.identify(refs=refs)

    def test_nonuniform_padding_and_wrong_registers_deny(self):
        raw=self.raw[:-1]+b'X'
        with self.assertRaises(ValueError):self.identify(raw)
        registers=list(self.registers);registers[3]=b'x'*48
        with self.assertRaises(ValueError):eventlog.identify_bootstrap(self.raw,registers,**self.refs)

class ReferenceTests(unittest.TestCase):
    def setUp(self):
        h=lambda x:hashlib.sha384(x).digest()
        self.value={'schema':'mfenx/tdx-efi-ram-reference/v1','attestation_profile':CPU_PROFILE,
                    'encrypted_policy_sha256':sha256(b'policy'),
                    'minimum_tcb_evaluation_number':22}
        for field in ['image_authenticode','kernel_authenticode','gpt','command_line','initrd']:
            self.value[field+'_sha384']='sha384:'+h(field.encode()).hex()
        b=lambda name:bytes.fromhex(self.value[name+'_sha384'][7:])
        self.value['quote']={'mr_td':'01'*48,'mr_config_id':'00'*48,'xfam':'00'*8,'rtmr_0':'02'*48,
            'rtmr_1':_extend([h(b'Calling EFI Application from Boot Option'),h(bytes(4)),b('gpt'),b('image_authenticode'),b('kernel_authenticode'),h(b'Exit Boot Services Invocation'),h(b'Exit Boot Services Returned with Success')]),
            'rtmr_2':_extend([b('command_line'),b('initrd')]),'rtmr_3':'00'*48}

    def parse(self,value=None):
        raw=canonical(self.value if value is None else value)
        return BootReference.from_bytes(raw,expected_sha256=sha256(raw))

    def test_policy_binds_every_quote_field_and_native_hardware_requirements(self):
        ref=self.parse();text=ref.attestation_policy()
        for name,value in self.value['quote'].items():self.assertIn('body.'+name+' == "'+value+'"',text)
        for check in ['debug == false','tcb_status == "UpToDate"','collateral_expiration_status == "0"',
                      'tcb_status_current == "UpToDate"','tcb_eval_num >= 22']:
            self.assertIn(check,text)

    def test_all_artifact_and_register_mutations_require_reapproval(self):
        for name in [n for n in self.value if n.endswith('_sha384')]:
            value=copy.deepcopy(self.value);value[name]='sha384:'+'fa'*48
            with self.subTest(name=name),self.assertRaises(ReceiptError):self.parse(value)
        for name in ['rtmr_1','rtmr_2','rtmr_3']:
            value=copy.deepcopy(self.value);value['quote'][name]='fa'*48
            with self.subTest(name=name),self.assertRaises(ReceiptError):self.parse(value)

    def test_independent_pin_unknown_fields_and_invalid_types_fail(self):
        raw=canonical(self.value)
        with self.assertRaises(ReceiptError):BootReference.from_bytes(raw,expected_sha256=sha256(b'other'))
        for name,v in [('extra',0),('attestation_profile','unknown'),('quote',None),('gpt_sha384',True),
                       ('minimum_tcb_evaluation_number',True),('minimum_tcb_evaluation_number',0)]:
            value=copy.deepcopy(self.value);value[name]=v
            with self.subTest(name=name),self.assertRaises(ReceiptError):self.parse(value)

class ProfileTests(unittest.TestCase):
    def setUp(self):
        fixtures.AdmissionTests.setUp(self)
        from mfenx_gate.encrypted import encrypt_model
        self.package=encrypt_model(self.payload,receipt=self.receipt,trusted_public_key=self.public)
        self.value={'schema':'mfenx/encrypted-admission-policy/v2','attestation_profile':CPU_PROFILE,
            'admission':self.p,'descriptor_sha256':sha256(self.package.descriptor),
            'broker_url':'https://broker.example','broker_ca_sha256':sha256(b'ca'),
            'trustee_client_sha256':sha256(b'client')}

    def parse(self):
        raw=canonical(self.value);return EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))

    def test_cpu_profile_is_explicit_and_requires_approved_reference(self):
        p=self.parse();self.assertIsNone(p.init_data)
        d=Descriptor.from_bytes(self.package.descriptor,expected_sha256=p.descriptor_sha256)
        with self.assertRaises(ReceiptError):resource_policy(p,d,cpu_tee='tdx')
        test=ReferenceTests();test.setUp();test.value['encrypted_policy_sha256']=p.digest;ref=test.parse()
        text=resource_policy(p,d,cpu_tee='tdx',boot_reference=ref)
        self.assertIn('count(input.submods) == 1',text)
        with self.assertRaises(ReceiptError):resource_policy(p,d,cpu_tee='snp',boot_reference=ref)
        test.value['encrypted_policy_sha256']=sha256(b'other')
        with self.assertRaises(ReceiptError):resource_policy(p,d,cpu_tee='tdx',boot_reference=test.parse())

    def test_gpu_profile_cannot_use_cpu_runtime_or_silently_downgrade(self):
        self.value['attestation_profile']=GPU_PROFILE
        with self.assertRaises(ReceiptError):self.parse()
        self.value['attestation_profile']='coco-initdata/v1'
        with self.assertRaises(ReceiptError):self.parse()
        del self.value['attestation_profile']
        with self.assertRaises(ReceiptError):self.parse()

    def test_legacy_profile_retains_initdata_and_rejects_boot_reference(self):
        del self.value['attestation_profile'];self.value['schema']='mfenx/encrypted-admission-policy/v1'
        p=self.parse();self.assertIsNotNone(p.init_data)
        d=Descriptor.from_bytes(self.package.descriptor,expected_sha256=p.descriptor_sha256)
        test=ReferenceTests();test.setUp()
        with self.assertRaises(ReceiptError):resource_policy(p,d,cpu_tee='tdx',boot_reference=test.parse())
