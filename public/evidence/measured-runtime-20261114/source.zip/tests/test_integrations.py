from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class IntegrationExamples(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)
        shim = self.path / "mfenx-gate"
        shim.write_text(f"#!{sys.executable}\nfrom mfenx_gate.cli import main\nif __name__ == '__main__':\n    raise SystemExit(main())\n")
        shim.chmod(0o700)
        self.env = {**os.environ, "PATH": str(self.path) + os.pathsep + os.environ.get("PATH", "")}
        self.demo = ROOT / "demo-public"

    def run_command(self, args, **kwargs):
        return subprocess.run(args, env=self.env, capture_output=True, text=True, **kwargs)

    def test_disconnected_example_and_mutation(self):
        args = ["bash", str(ROOT / "examples/disconnected-verify.sh"), str(self.demo / "release-receipt.json"),
                str(self.demo / "issuer-public.der"), str(self.demo / "model.onnx")]
        result = self.run_command(args)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["artifactStatus"], "MATCH")
        wrong = self.path / "wrong.onnx"; wrong.write_bytes(b"wrong")
        self.assertNotEqual(self.run_command(args[:-1] + [str(wrong)]).returncode, 0)

    def test_composite_action_success_and_wrong_policy(self):
        action = (ROOT / "examples/model-gate-action/action.yml").read_text()
        block = action.split("      run: |\n", 1)[1]
        script = "\n".join(line[8:] for line in block.splitlines())
        receipt = json.loads((self.demo / "release-receipt.json").read_text())
        self.env.update(MFENX_RECEIPT=str(self.demo / "release-receipt.json"), MFENX_MODEL=str(self.demo / "model.onnx"),
            MFENX_TRUST_KEY=str(self.demo / "issuer-public.der"), MFENX_APPROVED_CONTRACT=receipt["statement"]["contract_sha256"])
        result = self.run_command(["bash", "-c", script]); self.assertEqual(result.returncode, 0, result.stderr)
        self.env["MFENX_APPROVED_CONTRACT"] = "sha256:" + "0" * 64
        self.assertNotEqual(self.run_command(["bash", "-c", script]).returncode, 0)
        self.env["MFENX_APPROVED_CONTRACT"] = receipt["statement"]["contract_sha256"]
        for field in ("MFENX_RECEIPT", "MFENX_MODEL", "MFENX_TRUST_KEY", "MFENX_APPROVED_CONTRACT"):
            original = self.env[field]; self.env[field] = "--help"
            self.assertNotEqual(self.run_command(["bash", "-c", script]).returncode, 0, field)
            self.env[field] = original
        self.assertNotIn("uses:", action)

    def test_oem_load_receives_same_immutable_bytes(self):
        spec = importlib.util.spec_from_file_location("oem_example", ROOT / "examples/oem_verified_load.py")
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        model = self.path / "model.onnx"; original = (self.demo / "model.onnx").read_bytes(); model.write_bytes(original)
        digest = json.loads((self.demo / "release-receipt.json").read_text())["statement"]["contract_sha256"]
        def loader(payload):
            model.write_bytes(b"replaced after verification")
            self.assertIs(type(payload), bytes)
            self.assertEqual(payload, original)
            return "loaded-same-bytes"
        self.assertEqual(module.verify_and_load(self.demo / "release-receipt.json", self.demo / "issuer-public.der", model, digest, loader), "loaded-same-bytes")

    def test_safetensors_issue_script(self):
        from mfenx_gate.receipt import generate_keypair, verify_receipt
        private, public = generate_keypair(); key = self.path / "issuer.pem"; key.write_bytes(private)
        model = self.path / "model.safetensors"
        header = json.dumps({"w": {"dtype": "F32", "shape": [1], "data_offsets": [0, 4]}}).encode()
        model.write_bytes(len(header).to_bytes(8, "little") + header + bytes(4))
        receipt = self.path / "integrity.json"
        result = self.run_command(["bash", str(ROOT / "examples/safetensors-integrity.sh"), str(model), str(key), "Example issuer", str(receipt)])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(verify_receipt(receipt.read_bytes(), public, artifact=model)["behavioralStatus"], "NOT_EVALUATED")

    def test_onnx_script_missing_inputs_fail_closed(self):
        result = self.run_command(["bash", str(ROOT / "examples/onnx-release.sh")])
        self.assertEqual(result.returncode, 2)

    def test_onnx_release_script_executes_retained_finite_case(self):
        from mfenx_gate.receipt import generate_keypair, sha256, verify_receipt
        case = Path(os.environ.get("MFENX_GATE_RETAINED_CASE", ROOT / "evidence/public-onnx-release"))
        if not (case / "approved-contract.json").is_file():
            self.skipTest("provide MFENX_GATE_RETAINED_CASE for full private evaluation evidence")
        private, public = generate_keypair(); key = self.path / "issuer.pem"; key.write_bytes(private)
        receipt = self.path / "evaluated-receipt.json"
        # The test is the fixture authority, not production policy approval.
        contract = self.path / "approved-contract.json"
        prepared = self.run_command([sys.executable, str(ROOT / "scripts/prepare_acceptance_contract.py"),
                                     str(case / "approved-contract.json"), str(contract)])
        self.assertEqual(prepared.returncode, 0, prepared.stderr)
        expected = sha256(contract.read_bytes())
        result = self.run_command(["bash", str(ROOT / "examples/onnx-release.sh"), str(case / "source.onnx"),
            str(case / "candidate.onnx"), str(case / "dataset.npz"), str(contract), expected,
            str(key), "Integration test issuer", str(receipt)])
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        verified = verify_receipt(receipt.read_bytes(), public, artifact=case / "candidate.onnx", expected_contract_digest=expected)
        self.assertEqual(verified["receipt"]["statement"]["evaluation"]["samples"], 1797)
        result = self.run_command(["bash", str(ROOT / "examples/onnx-release.sh"), *(str(self.path / "missing") for _ in range(8))])
        self.assertEqual(result.returncode, 2)


if __name__ == "__main__": unittest.main()
