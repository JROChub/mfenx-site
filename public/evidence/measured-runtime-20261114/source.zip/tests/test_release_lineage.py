import copy
import unittest
import test_admission as fixtures
from power_house import replay_rootprint, new_rootprint, verify_rootprint
from mfenx_gate.lineage import create_release_lineage, verify_release_lineage
from mfenx_gate.receipt import ReceiptError, _sign, sha256


class LineageTests(unittest.TestCase):
    setUp = fixtures.AdmissionTests.setUp
    policy = fixtures.AdmissionTests.policy
    admit = fixtures.AdmissionTests.admit

    def graph(self, **kwargs):
        return create_release_lineage(receipt=self.receipt, trusted_public_key=self.public,
                                      model=self.model, approved_contract=self.p["contract_sha256"], **kwargs)

    def pinned_policy(self, graph):
        p = copy.deepcopy(self.p)
        replay = replay_rootprint(graph)
        p["lineage"] = {"root_branch": graph["root_branch"], "leaf_branch": replay["tips"][0],
                         "replay_fingerprint": replay["state_fingerprint"], "allowed_transformations": ["identity"]}
        return self.policy(p)

    def test_required_lineage_is_independently_bound_before_model_loading(self):
        graph = self.graph(); policy = self.pinned_policy(graph)
        with self.assertRaises(ReceiptError): self.admit(policy)
        from mfenx_gate.admission import admit_model
        model = admit_model(receipt=self.receipt, trusted_public_key=self.public, model=self.model,
                            policy=policy, lineage=graph)
        self.assertEqual(model.artifact_digest, sha256(self.payload))

    def test_consistent_but_unapproved_root_is_denied(self):
        graph = self.graph()
        altered = copy.deepcopy(graph["branches"][graph["root_branch"]]["artifact"])
        # A fresh consistent graph with a changed label still has no deployment authority.
        other = new_rootprint("unauthorized-root", altered)
        verify_rootprint(other)
        expected = replay_rootprint(graph)
        with self.assertRaises(ReceiptError):
            verify_release_lineage(other, trusted_public_key=self.public,
                                   expected_root=graph["root_branch"], expected_leaf=expected["tips"][0],
                                   expected_replay=expected["state_fingerprint"],
                                   receipt_sha256=sha256(self.receipt), allowed_transformations=())

    def test_parent_continuity_and_transform_permission(self):
        parent = self.graph(); original = copy.deepcopy(parent)
        parent_state = replay_rootprint(parent)["state_fingerprint"]
        with self.assertRaises(ReceiptError):
            self.graph(parent_graph=parent, parent_branch=parent["root_branch"],
                       expected_parent_replay=parent_state, transformation="identity")
        self.statement["parent_sha256"] = sha256(self.payload)
        self.receipt = _sign(self.statement, self.private, "Ephemeral test authority")
        child = self.graph(parent_graph=parent, parent_branch=parent["root_branch"],
                           expected_parent_replay=parent_state, transformation="identity")
        self.assertEqual(parent, original)
        replay = replay_rootprint(child)
        args = dict(trusted_public_key=self.public, expected_root=child["root_branch"],
                    expected_leaf=replay["tips"][0], expected_replay=replay["state_fingerprint"],
                    receipt_sha256=sha256(self.receipt))
        with self.assertRaises(ReceiptError): verify_release_lineage(child, allowed_transformations=(), **args)
        checked = verify_release_lineage(child, allowed_transformations=("identity",), **args)
        self.assertEqual(checked["transformation_execution"], "NOT_PROVED")


if __name__ == "__main__": unittest.main()
