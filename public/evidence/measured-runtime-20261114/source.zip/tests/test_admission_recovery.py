"""Observed CPU serving effects during rotation, durable recovery and outages.

Ephemeral authorities and synthetic models exercise policy enforcement, not
production key custody or confidential hardware recovery.
"""
import copy
import sqlite3
import unittest

import numpy as np

import test_admission as fixtures
from mfenx_gate.admission import PolicyAuthority, ServingSession
from mfenx_gate.receipt import ReceiptError, generate_keypair, _sign, sha256


class AdmissionRecoveryTests(unittest.TestCase):
    setUp = fixtures.AdmissionTests.setUp
    policy = fixtures.AdmissionTests.policy
    admit = fixtures.AdmissionTests.admit

    def assert_inference(self, session):
        np.testing.assert_array_equal(session.run({'x': np.array([3.0], np.float32)})[0], [5.0])

    def test_signer_rotation_terminates_old_session_and_allows_readmitted_release(self):
        authority = PolicyAuthority(self.policy(), state_path=self.root / 'authority.sqlite')
        old_session = ServingSession(self.admit(), authority)
        self.assert_inference(old_session)
        old_public, old_receipt = self.public, self.receipt
        self.private, self.public = generate_keypair()
        self.receipt = _sign(self.statement, self.private, 'Rotated test authority')
        self.p.update(epoch=2, issuer_sha256=sha256(self.public),
                      approved_releases=[{'receipt_sha256':sha256(self.receipt), 'sequence':2}],
                      revoked_issuers=[sha256(old_public)], revoked_receipts=[sha256(old_receipt)])
        authority.install(self.policy())
        with self.assertRaises(ReceiptError):
            old_session.run({'x':np.array([3.0], np.float32)})
        self.assertEqual(old_session.state, 'TERMINATED')
        with ServingSession(self.admit(), authority) as new_session:
            self.assert_inference(new_session)

    def test_consistent_database_snapshot_restores_policy_and_preserves_floor(self):
        path = self.root / 'authority.sqlite'
        authority = PolicyAuthority(self.policy(), state_path=path)
        with ServingSession(self.admit(), authority) as session:
            self.assert_inference(session)
        prior = copy.deepcopy(self.p)
        self.p.update(epoch=2, minimum_sequence=2,
                      approved_releases=[{'receipt_sha256':sha256(self.receipt),'sequence':2}])
        authority.install(self.policy())
        snapshot = self.root / 'restored.sqlite'
        with sqlite3.connect(path) as source, sqlite3.connect(snapshot) as target:
            source.backup(target)
        with sqlite3.connect(snapshot) as db:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone(), ('ok',))
            self.assertEqual(db.execute("SELECT COUNT(*) FROM admission_audit WHERE event='inference-completed'").fetchone(), (1,))
        snapshot.chmod(0o600)
        with self.assertRaisesRegex(ReceiptError, 'regressed'):
            PolicyAuthority(self.policy(prior), state_path=snapshot)
        restored = PolicyAuthority(self.policy(), state_path=snapshot)
        with ServingSession(self.admit(), restored) as session:
            self.assert_inference(session)

    def test_authority_outage_denies_calls_then_requires_new_session(self):
        path = self.root / 'authority.sqlite'
        authority = PolicyAuthority(self.policy(), state_path=path)
        session = ServingSession(self.admit(), authority)
        self.assert_inference(session)
        authority.unavailable()
        with self.assertRaises(ReceiptError):
            session.run({'x':np.array([3.0],np.float32)})
        self.assertEqual(session.state, 'TERMINATED')
        reopened = PolicyAuthority(self.policy(), state_path=path)
        with ServingSession(self.admit(), reopened) as replacement:
            self.assert_inference(replacement)

    def test_lost_durable_state_denies_existing_session(self):
        path = self.root / 'authority.sqlite'
        authority = PolicyAuthority(self.policy(), state_path=path)
        session = ServingSession(self.admit(), authority)
        self.assert_inference(session)
        with sqlite3.connect(path) as db:
            db.execute('DELETE FROM admission_floor')
        with self.assertRaises(ReceiptError):
            session.run({'x':np.array([3.0],np.float32)})
        self.assertEqual(session.state, 'TERMINATED')
