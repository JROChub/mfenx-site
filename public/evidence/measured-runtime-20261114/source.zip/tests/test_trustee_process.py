"""Kernel/process enforcement using explicitly synthetic native client fixtures."""
import base64
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

import test_admission as fixtures
from mfenx_gate.encrypted import EncryptedPolicy
from mfenx_gate.receipt import ReceiptError,canonical,sha256
from mfenx_gate.trustee import retrieve_key

class TrusteeProcessTests(unittest.TestCase):
    setUp=fixtures.AdmissionTests.setUp

    def fixture(self,body):
        source=self.root/'client.c';binary=self.root/'client'
        source.write_text('#include <unistd.h>\n#include <stdlib.h>\n#include <stdio.h>\n#include <string.h>\n#include <fcntl.h>\nint main(int argc,char **argv){'+body+'}\n')
        subprocess.run(['cc','-O1',str(source),'-o',str(binary)],check=True,capture_output=True)
        ca=self.root/'ca.pem';ca.write_bytes(b'public fixture certificate')
        document={'schema':'mfenx/encrypted-admission-policy/v1','admission':self.p,
            'descriptor_sha256':sha256(b'fixture'),'broker_url':'https://fixture.invalid',
            'broker_ca_sha256':sha256(ca.read_bytes()),'trustee_client_sha256':sha256(binary.read_bytes())}
        raw=canonical(document);policy=EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))
        return binary,ca,raw,policy

    def test_client_environment_and_arguments_exclude_caller_credentials(self):
        key=bytes(range(32));encoded=base64.b64encode(key).decode()
        body='if(getenv("HTTP_PROXY")||getenv("PYTHONPATH")||getenv("HOME")||getenv("ADMIN_TOKEN"))return 70;'
        body+='if(argc!=10||strcmp(argv[5],"get-resource")||strcmp(argv[8],"--init-data"))return 71;'
        body+='puts("'+encoded+'");return 0;'
        binary,ca,raw,policy=self.fixture(body)
        with patch.dict(os.environ,{'HTTP_PROXY':'http://untrusted.invalid','PYTHONPATH':'untrusted','ADMIN_TOKEN':'fixture-admin'}):
            result=retrieve_key(policy,resource='tests/model-keys/fixture',client=binary,ca=ca)
        self.assertEqual(result,key)

    def test_output_quota_is_enforced_by_the_kernel(self):
        binary,ca,raw,policy=self.fixture('char data[8192];memset(data,65,sizeof(data));while(write(1,data,sizeof(data))>0){};return 1;')
        children=[];original=subprocess.Popen
        def observe(*args,**kwargs):
            child=original(*args,**kwargs);children.append(child);return child
        with patch('mfenx_gate.trustee.subprocess.Popen',side_effect=observe):
            with self.assertRaises(ReceiptError):retrieve_key(policy,resource='tests/model-keys/fixture',client=binary,ca=ca)
        self.assertEqual(len(children),1)
        self.assertEqual(children[0].returncode,-signal.SIGXFSZ)

    def test_key_client_dies_when_its_admission_parent_is_killed(self):
        marker=self.root/'native.pid'
        body='int fd=open('+json.dumps(str(marker))+',O_CREAT|O_EXCL|O_WRONLY,0600);if(fd<0)return 1;'
        body+='char p[32];int n=snprintf(p,sizeof(p),"%d",getpid());write(fd,p,n);close(fd);for(;;)pause();'
        binary,ca,raw,policy=self.fixture(body)
        code=('from pathlib import Path; from mfenx_gate.encrypted import EncryptedPolicy; '
              'from mfenx_gate.trustee import retrieve_key; p=EncryptedPolicy.from_bytes('+repr(raw)+',expected_sha256='+repr(sha256(raw))+'); '
              'retrieve_key(p,resource="tests/model-keys/fixture",client=Path('+repr(str(binary))+'),ca=Path('+repr(str(ca))+'))')
        parent=subprocess.Popen([sys.executable,'-I','-c',code],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        descriptor=None
        try:
            for _ in range(100):
                if marker.exists():break
                if parent.poll() is not None:self.fail('admission parent exited before native fixture startup')
                time.sleep(.05)
            self.assertTrue(marker.exists())
            descriptor=os.pidfd_open(int(marker.read_text()),0)
            parent.kill();parent.wait(timeout=5)
            self.assertTrue(select.select([descriptor],[],[],5)[0], 'key client survived its admission parent')
        finally:
            if parent.poll() is None:parent.kill();parent.wait(timeout=5)
            if descriptor is not None:
                try:signal.pidfd_send_signal(descriptor,signal.SIGKILL)
                except ProcessLookupError:pass
                os.close(descriptor)

if __name__=='__main__':unittest.main()
