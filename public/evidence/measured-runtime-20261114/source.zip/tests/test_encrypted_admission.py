"""Actual AEAD and CPU loading; key-provider doubles are not attestation evidence."""
import copy
from contextlib import closing
import importlib.util
import json
from pathlib import Path
import sqlite3
import tomllib
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

import test_admission as fixtures
from mfenx_gate.admission import PolicyAuthority, ServingSession, admit_model
from mfenx_gate.encrypted import Descriptor, EncryptedPolicy, admit_encrypted_model, encrypt_model
from mfenx_gate.receipt import ReceiptError, canonical, sha256


class EncryptedAdmissionTests(unittest.TestCase):
    def setUp(self):
        fixtures.AdmissionTests.setUp(self)
        self.package = encrypt_model(self.payload, receipt=self.receipt, trusted_public_key=self.public)
        self.ciphertext = self.root/'model.enc'; self.ciphertext.write_bytes(self.package.ciphertext)
        self.descriptor = Descriptor.from_bytes(self.package.descriptor, expected_sha256=sha256(self.package.descriptor))
        self.encrypted = {'schema':'mfenx/encrypted-admission-policy/v1', 'admission':self.p,
                         'descriptor_sha256':self.descriptor.digest, 'broker_url':'https://broker.example:8443',
                         'broker_ca_sha256':sha256(b'test certificate'),
                         'trustee_client_sha256':sha256(b'test client')}

    def policy(self, value=None):
        raw = canonical(self.encrypted if value is None else value)
        return EncryptedPolicy.from_bytes(raw, expected_sha256=sha256(raw))

    def admit(self, policy=None, **kwargs):
        return admit_encrypted_model(descriptor=self.package.descriptor, ciphertext=self.ciphertext,
            receipt=self.receipt, trusted_public_key=self.public, policy=policy or self.policy(),
            trustee_client=self.root/'client', broker_ca=self.root/'ca.pem', **kwargs)

    def test_authenticated_decryption_feeds_retained_loader_and_durable_audit(self):
        with patch('mfenx_gate.trustee.retrieve_key', return_value=self.package.key) as fetch:
            model = self.admit()
        fetch.assert_called_once()
        self.ciphertext.unlink(); self.ciphertext.write_bytes(b'X'*len(self.package.ciphertext))
        self.model.unlink()
        authority = PolicyAuthority(self.policy().admission, state_path=self.root/'authority.sqlite')
        with ServingSession(model, authority) as session:
            self.assertEqual(session.run({'x':np.array([3],np.float32)})[0].tolist(), [5.0])
        self.assertIsNotNone(model.distribution_sha256)
        with closing(sqlite3.connect(self.root/'authority.sqlite')) as db:
            evidence = db.execute('SELECT distribution FROM admission_distribution_evidence').fetchall()
            completed = db.execute("SELECT COUNT(*) FROM admission_audit WHERE event='inference-completed'").fetchone()[0]
        self.assertEqual(evidence, [(model.distribution_sha256,)])
        self.assertEqual(completed, 1)
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), ['authority.sqlite','model.enc'])

    def test_corrupted_ciphertext_never_requests_a_key_or_reaches_parser(self):
        for raw in [self.package.ciphertext[:-1], self.package.ciphertext+b'x',
                    self.package.ciphertext[:-1]+bytes([self.package.ciphertext[-1]^1])]:
            self.ciphertext.write_bytes(raw)
            with patch('mfenx_gate.trustee.retrieve_key') as fetch, patch('onnx.load_model_from_string') as parser:
                with self.assertRaises(ReceiptError):self.admit()
                fetch.assert_not_called(); parser.assert_not_called()

    def test_changed_context_with_new_descriptor_pin_still_fails_aead(self):
        raw = json.loads(self.package.descriptor)
        raw['context']['resource'] = 'other/model-keys/different'
        descriptor = canonical(raw)
        self.package = type(self.package)(descriptor, self.package.ciphertext, self.package.key)
        self.encrypted['descriptor_sha256'] = sha256(descriptor)
        with patch('mfenx_gate.trustee.retrieve_key', return_value=self.package.key), patch('onnx.load_model_from_string') as parser:
            with self.assertRaisesRegex(ReceiptError, 'authentication failed'):self.admit()
            parser.assert_not_called()

    def test_wrong_key_never_reaches_model_parser(self):
        with patch('mfenx_gate.trustee.retrieve_key', return_value=b'Z'*32), patch('onnx.load_model_from_string') as parser:
            with self.assertRaisesRegex(ReceiptError, 'authentication failed'):self.admit()
            parser.assert_not_called()

    def test_ciphertext_replaced_during_key_delivery_does_not_change_loaded_model(self):
        def replace_path(*args, **kwargs):
            self.ciphertext.unlink();self.ciphertext.write_bytes(b'X'*len(self.package.ciphertext))
            return self.package.key
        with patch('mfenx_gate.trustee.retrieve_key', side_effect=replace_path):
            model=self.admit()
        with ServingSession(model,PolicyAuthority(self.policy().admission)) as session:
            self.assertEqual(session.run({'x':np.array([3],np.float32)})[0].tolist(),[5.0])

    def test_aead_rejects_corruption_even_when_the_ciphertext_hash_is_reapproved(self):
        mutated=self.package.ciphertext[:-1]+bytes([self.package.ciphertext[-1]^1])
        self.ciphertext.write_bytes(mutated)
        raw=json.loads(self.package.descriptor);raw['ciphertext_sha256']=sha256(mutated)
        raw=canonical(raw);self.package=type(self.package)(raw,mutated,self.package.key)
        self.encrypted['descriptor_sha256']=sha256(raw)
        with patch('mfenx_gate.trustee.retrieve_key',return_value=self.package.key),patch('onnx.load_model_from_string') as parser:
            with self.assertRaisesRegex(ReceiptError,'authentication failed'):self.admit()
            parser.assert_not_called()

    def test_unapproved_descriptor_denies_before_key_delivery(self):
        self.encrypted['descriptor_sha256'] = sha256(b'unapproved')
        with patch('mfenx_gate.trustee.retrieve_key') as fetch:
            with self.assertRaises(ReceiptError):self.admit()
            fetch.assert_not_called()

    def test_revoked_release_denies_before_key_delivery(self):
        self.p['revoked_receipts'] = [sha256(self.receipt)]
        with patch('mfenx_gate.trustee.retrieve_key') as fetch:
            with self.assertRaisesRegex(ReceiptError, 'revoked'):self.admit()
            fetch.assert_not_called()

    def test_wrong_approved_contract_denies_before_key_delivery(self):
        self.p['contract_sha256'] = sha256(b'wrong contract')
        with patch('mfenx_gate.trustee.retrieve_key') as fetch:
            with self.assertRaises(ReceiptError):self.admit()
            fetch.assert_not_called()

    def test_changed_distribution_requires_new_durable_policy_epoch(self):
        first = self.policy(); path = self.root/'authority.sqlite'
        PolicyAuthority(first.admission, state_path=path)
        changed = copy.deepcopy(self.encrypted);changed['broker_url']='https://rotated.example'
        with self.assertRaisesRegex(ReceiptError, 'regressed'):
            PolicyAuthority(self.policy(changed).admission, state_path=path)
        changed['admission']['epoch'] += 1
        PolicyAuthority(self.policy(changed).admission, state_path=path)
        with self.assertRaises(ReceiptError):PolicyAuthority(first.admission, state_path=path)

    def test_policy_changes_are_bound_in_measured_init_data(self):
        first = self.policy()
        changed = copy.deepcopy(self.encrypted);changed['broker_ca_sha256']=sha256(b'other root')
        self.assertNotEqual(first.init_data,self.policy(changed).init_data)
        init=tomllib.loads(first.init_data)
        self.assertEqual((init['version'],init['algorithm']),('0.1.0','sha256'))
        claims=json.loads(init['data']['mfenx.json'])['mfenx']
        self.assertEqual(claims['descriptor_sha256'],self.descriptor.digest)
        self.assertEqual(first.admission.digest,first.digest)

    def test_non_https_or_ambiguous_broker_origins_deny(self):
        for url in ['http://broker.example','https://u:p@broker.example','https://broker.example/path',
                    'https://broker.example?key=x','https://broker.example#x','https://broker.example:0',
                    'https://broker.example:99999','https://broker.example\n','file:///key']:
            with self.subTest(url=url):
                changed=copy.deepcopy(self.encrypted);changed['broker_url']=url
                with self.assertRaises(ReceiptError):self.policy(changed)

    def test_unknown_algorithms_profiles_and_resource_paths_deny(self):
        for field,value in [('algorithm','AES-CBC'),('resource','a/../b'),('resource','a/b/c/d'),
                            ('nonce_base64','AAAA'),('model_bytes',True),('model_bytes',64*1024**2+1)]:
            raw=json.loads(self.package.descriptor);raw['context'][field]=value;raw=canonical(raw)
            with self.subTest(field=field,value=value),self.assertRaises(ReceiptError):
                Descriptor.from_bytes(raw,expected_sha256=sha256(raw))

    def test_each_encryption_has_a_fresh_key_nonce_and_resource(self):
        other=encrypt_model(self.payload,receipt=self.receipt,trusted_public_key=self.public)
        self.assertNotEqual(self.package.key,other.key)
        self.assertNotEqual(self.package.ciphertext,other.ciphertext)
        self.assertNotEqual(json.loads(self.package.descriptor)['context']['resource'],json.loads(other.descriptor)['context']['resource'])

    def test_mutable_plaintext_buffers_and_ambiguous_sources_deny(self):
        policy=fixtures.AdmissionTests.policy(self)
        for kwargs in [{'model':self.model,'model_bytes':self.payload}, {}, {'model_bytes':bytearray(self.payload)}]:
            with self.subTest(kwargs=list(kwargs)),self.assertRaises(ReceiptError):
                admit_model(receipt=self.receipt,trusted_public_key=self.public,policy=policy,**kwargs)

    def test_encrypted_descriptor_is_not_a_legacy_deployment_policy(self):
        from mfenx_gate.admission import AdmissionPolicy
        raw=canonical(self.encrypted)
        with self.assertRaises(ReceiptError):AdmissionPolicy.from_bytes(raw,expected_sha256=sha256(raw))

    def test_duplicate_and_excessive_metadata_reject(self):
        for raw in [b'{"schema":"a","schema":"b"}',b' '*65537,b'['*2000+b'0'+b']'*2000]:
            for parser in [EncryptedPolicy,Descriptor]:
                with self.subTest(parser=parser.__name__),self.assertRaises(ReceiptError):
                    parser.from_bytes(raw,expected_sha256=sha256(raw))

    def test_producer_keeps_key_outside_distribution_and_never_overwrites(self):
        script=Path(__file__).resolve().parents[1]/'examples/encrypt_release.py'
        spec=importlib.util.spec_from_file_location('encrypt_release',script)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        receipt=self.root/'receipt.json';receipt.write_bytes(self.receipt)
        public=self.root/'issuer.der';public.write_bytes(self.public)
        private=self.root/'private';private.mkdir(mode=0o700)
        kwargs=dict(model=self.model,receipt=receipt,trusted_public_key=public,
                    distribution=self.root/'distribution',key_file=private/'key.bin')
        report=module.prepare(**kwargs)
        self.assertEqual(set(p.name for p in kwargs['distribution'].iterdir()),{'model.enc','descriptor.json','build.json'})
        self.assertEqual(kwargs['key_file'].stat().st_mode & 0o777,0o600)
        key=kwargs['key_file'].read_bytes()
        self.assertEqual(len(key),32)
        self.assertNotIn(key,(kwargs['distribution']/'model.enc').read_bytes())
        self.assertEqual(report['descriptor_sha256'],sha256((kwargs['distribution']/'descriptor.json').read_bytes()))
        with self.assertRaises(OSError):module.prepare(**kwargs)
        self.assertEqual(kwargs['key_file'].read_bytes(),key)
        kwargs.update(distribution=self.root/'unsafe',key_file=self.root/'unsafe/key.bin')
        with self.assertRaises(ReceiptError):module.prepare(**kwargs)

    def test_policy_preparation_validates_independent_pins_and_drives_actual_loading(self):
        script=Path(__file__).resolve().parents[1]/'examples/prepare_encrypted_policy.py'
        spec=importlib.util.spec_from_file_location('prepare_policy',script)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        inner=self.root/'inner.json';inner.write_bytes(json.dumps(self.p).encode())
        descriptor=self.root/'descriptor.json';descriptor.write_bytes(self.package.descriptor)
        ca=self.root/'ca.pem';ca.write_bytes(b'test certificate')
        args=SimpleNamespace(admission_policy=inner,approved_admission_sha256=sha256(inner.read_bytes()),
            descriptor=descriptor,approved_descriptor_sha256=self.descriptor.digest,
            broker_ca=ca,approved_broker_ca_sha256=sha256(ca.read_bytes()),
            broker_url=self.encrypted['broker_url'],approved_trustee_client_sha256=self.encrypted['trustee_client_sha256'],
            output=self.root/'approval',cpu_tee='tdx')
        report=module.prepare(args)
        raw=(args.output/'policy.json').read_bytes()
        policy=EncryptedPolicy.from_bytes(raw,expected_sha256=report['policy_sha256'])
        self.assertEqual((args.output/'initdata.toml').read_bytes(),policy.init_data.encode('ascii'))
        with patch('mfenx_gate.trustee.retrieve_key',return_value=self.package.key):model=self.admit(policy)
        with ServingSession(model,PolicyAuthority(policy.admission)) as session:
            self.assertEqual(session.run({'x':np.array([3],np.float32)})[0].tolist(),[5.0])
        args.output=self.root/'unapproved';args.approved_admission_sha256=sha256(b'wrong policy')
        with self.assertRaises(ReceiptError):module.prepare(args)
        self.assertFalse(args.output.exists())
