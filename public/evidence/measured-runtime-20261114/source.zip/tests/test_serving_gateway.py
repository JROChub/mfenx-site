"""Actual HTTP serving over the existing loader, using synthetic release roots."""
import copy
import http.client
import json
from pathlib import Path
import secrets
import selectors
import signal
import time
import sqlite3
import subprocess
import sys
import unittest

import onnx
from onnx import TensorProto, helper

import test_admission as fixtures
from mfenx_gate.admission import PolicyAuthority
from mfenx_gate.receipt import _sign, sha256

GATEWAY = Path(__file__).resolve().parents[1] / 'examples/serving_gateway.py'


class ServingGatewayTests(unittest.TestCase):
    setUp = fixtures.AdmissionTests.setUp
    policy = fixtures.AdmissionTests.policy

    def start(self, *, expected=True, request_seconds=5):
        for name, raw in [('receipt.json', self.receipt), ('issuer.der', self.public)]:
            (self.root/name).write_bytes(raw)
        raw = json.dumps(self.p).encode()
        (self.root/'policy.json').write_bytes(raw)
        self.token = getattr(self, 'token', secrets.token_urlsafe(32))
        (self.root/'access-token').write_text(self.token)
        (self.root/'access-token').chmod(0o600)
        command = [sys.executable, '-I', str(GATEWAY), '--receipt', str(self.root/'receipt.json'),
                   '--trusted-public-key', str(self.root/'issuer.der'), '--model', str(self.model),
                   '--policy', str(self.root/'policy.json'), '--expected-policy-sha256', sha256(raw),
                   '--state', str(self.root/'authority.sqlite'), '--access-token-file', str(self.root/'access-token'),
                   '--port', '0', '--request-seconds', str(request_seconds)]
        self.process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        process = self.process
        def close():
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait(timeout=5)
            process.stdout.close()
        self.addCleanup(close)
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            self.assertTrue(selector.select(50), 'gateway failed to start or reject within its startup bound')
            result = json.loads(process.stdout.readline())
        self.assertIs(result['listening'], expected, result)
        if expected:
            self.port = result['port']
        else:
            self.assertEqual(process.wait(timeout=5), 2)
        return result

    def request(self, document=None, *, raw=None, token=None):
        data = raw if raw is not None else json.dumps(document or {'inputs':{'x':[3.5]}}).encode()
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        try:
            connection.request('POST', '/v1/infer', data, {'Content-Type':'application/json',
                               'Authorization':'Bearer ' + (self.token if token is None else token)})
            response = connection.getresponse()
            return response.status, json.loads(response.read())
        finally:
            connection.close()

    def completed(self):
        with sqlite3.connect(self.root/'authority.sqlite') as db:
            return db.execute("SELECT COUNT(*) FROM admission_audit WHERE event='inference-completed'").fetchone()[0]

    def test_authenticated_http_loads_retained_bytes_and_rejects_invalid_requests_before_execution(self):
        self.start()
        self.model.unlink(); self.model.write_bytes(b'X'*len(self.payload))
        status, output = self.request()
        self.assertEqual(status, 200)
        self.assertEqual(output['outputs'], [[5.5]])
        self.assertEqual(output['model_sha256'], sha256(self.payload))
        self.assertEqual(self.completed(), 1)
        for invalid_token in ['incorrect-token', '\xff']:
            self.assertEqual(self.request(token=invalid_token)[0], 401)
        for raw in [b'{"inputs":{"x":[3]},"inputs":{"x":[4]}}',
                    b'{"inputs":{"x":[NaN]}}', b'['*129+b'0'+b']'*129,
                    b'{"inputs":{"other":[3]}}', b'{"inputs":{"x":[[3]]}}']:
            with self.subTest(raw=raw[:60]):
                self.assertEqual(self.request(raw=raw)[0], 400)
        self.assertEqual(self.request(raw=b' '*65537)[0], 413)
        self.assertEqual(self.completed(), 1, 'rejected HTTP inputs executed inference')
        self.assertEqual(self.request()[1]['outputs'], [[5.5]])

    def test_durable_revocation_denies_http_and_old_policy_restart(self):
        self.start()
        self.assertEqual(self.request()[0], 200)
        authority = PolicyAuthority(self.policy(), state_path=self.root/'authority.sqlite')
        updated = copy.deepcopy(self.p); updated['epoch'] = 2; updated['revoked_receipts'] = [sha256(self.receipt)]
        authority.install(self.policy(updated))
        self.assertEqual(self.request()[0], 503)
        self.assertEqual(self.completed(), 1)
        self.process.terminate(); self.process.wait(timeout=5)
        self.start(expected=False)

    def test_independent_deadline_terminates_a_native_call_holding_the_gil(self):
        # PyDLL deliberately retains the GIL while libc sleeps. A Python timer
        # thread cannot enforce this boundary; the separate pidfd watcher can.
        script = ("import importlib.util,ctypes; p=" + repr(str(GATEWAY)) + "; "
                  "s=importlib.util.spec_from_file_location('gateway',p); "
                  "m=importlib.util.module_from_spec(s);s.loader.exec_module(m); "
                  "d=m.Deadline(1);d.__enter__();ctypes.PyDLL(None).sleep(10)")
        started = time.monotonic()
        result = subprocess.run([sys.executable, '-I', '-c', script], capture_output=True, timeout=5)
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertLess(time.monotonic()-started, 5)

    def test_changed_artifact_cannot_start_listener(self):
        self.model.write_bytes(b'X'*len(self.payload))
        self.start(expected=False)
        with sqlite3.connect(self.root/'authority.sqlite') as db:
            tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn('admission_audit', tables, 'a rejected model reached serving activation')

    def test_native_inference_deadline_terminates_transport_then_recovery_requires_current_authority(self):
        body = helper.make_graph([helper.make_node('Identity',['condition'],['next_condition']),
                                  helper.make_node('Identity',['value'],['next_value'])], 'loop-body',
            [helper.make_tensor_value_info('iteration',TensorProto.INT64,[]),
             helper.make_tensor_value_info('condition',TensorProto.BOOL,[]),
             helper.make_tensor_value_info('value',TensorProto.FLOAT,[1])],
            [helper.make_tensor_value_info('next_condition',TensorProto.BOOL,[]),
             helper.make_tensor_value_info('next_value',TensorProto.FLOAT,[1])])
        graph = helper.make_graph([helper.make_node('Loop',['count','condition','x'],['y'],body=body)], 'deadline',
            [helper.make_tensor_value_info('x',TensorProto.FLOAT,[1])],
            [helper.make_tensor_value_info('y',TensorProto.FLOAT,[1])],
            [helper.make_tensor('count',TensorProto.INT64,[],[100000000]),
             helper.make_tensor('condition',TensorProto.BOOL,[],[True])])
        loop = helper.make_model(graph,opset_imports=[helper.make_opsetid('',13)]);loop.ir_version=8
        raw = loop.SerializeToString(); self.model.write_bytes(raw)
        self.statement['artifact'] = {'format':'onnx','sha256':sha256(raw),'bytes':len(raw)}
        self.receipt = _sign(self.statement,self.private,'Synthetic deadline authority')
        self.p['approved_releases'] = [{'receipt_sha256':sha256(self.receipt),'sequence':1}]
        self.start(request_seconds=1)
        with self.assertRaises((http.client.RemoteDisconnected, ConnectionError)):
            self.request()
        self.assertEqual(self.process.wait(timeout=5),-signal.SIGKILL)
        self.assertEqual(self.completed(),0)
        self.model.write_bytes(self.payload)
        self.statement['artifact']={'format':'onnx','sha256':sha256(self.payload),'bytes':len(self.payload)}
        self.receipt=_sign(self.statement,self.private,'Synthetic recovery authority')
        self.p.update(epoch=2,approved_releases=[{'receipt_sha256':sha256(self.receipt),'sequence':2}])
        self.start()
        self.assertEqual(self.request()[1]['outputs'],[[5.5]])
