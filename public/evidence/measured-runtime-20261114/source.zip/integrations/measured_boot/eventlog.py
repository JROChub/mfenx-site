"""Bounded TCG2 CCEL replay for an experimental TDX EFI bootstrap.

This module does not authenticate a quote or approve firmware. Callers must
obtain RTMR values from an independently authenticated hardware quote. A matched
event log identifies measurements; it does not establish model execution.
"""
from dataclasses import dataclass
import hashlib
import struct

MAX_LOG_BYTES = 1024 * 1024
MAX_EVENTS = 1024
SHA384 = 0x000C
EFI_APPLICATION = 0x80000003
EFI_BOOT_DRIVER = 0x80000004
EFI_RUNTIME_DRIVER = 0x80000005
_ALGORITHMS = {0x0004:20, 0x000B:32, SHA384:48, 0x000D:64}


@dataclass(frozen=True)
class Event:
    register: int
    kind: int
    digests: tuple
    data: bytes

    def sha384(self):
        return dict(self.digests)[SHA384]


def parse(raw):
    if type(raw) is not bytes or not 32 <= len(raw) <= MAX_LOG_BYTES:
        raise ValueError('CCEL size outside supported bounds')
    offset = 0

    def take(n):
        nonlocal offset
        if n < 0 or offset+n > len(raw):
            raise ValueError('truncated CCEL')
        result = raw[offset:offset+n]
        offset += n
        return result

    def number(fmt):
        return struct.unpack(fmt,take(struct.calcsize(fmt)))[0]

    register,kind = struct.unpack('<II',take(8))
    if register != 1 or kind != 3 or take(20) != bytes(20):
        raise ValueError('unsupported CCEL specification event')
    spec = take(number('<I'))
    if (len(spec) < 29 or spec[:16] != b'Spec ID Event03\0'
            or spec[21] != 2 or spec[23] not in (1,2)):
        raise ValueError('unsupported CCEL specification')
    count = struct.unpack_from('<I',spec,24)[0]
    if not 1 <= count <= len(_ALGORITHMS) or len(spec) < 29+4*count:
        raise ValueError('invalid CCEL digest declaration')
    algorithms = {}
    for index in range(count):
        algorithm,size = struct.unpack_from('<HH',spec,28+4*index)
        if algorithm in algorithms or _ALGORITHMS.get(algorithm) != size:
            raise ValueError('unsupported or duplicate CCEL digest algorithm')
        algorithms[algorithm] = size
    end = 28+4*count
    if SHA384 not in algorithms or len(spec) != end+1+spec[end]:
        raise ValueError('invalid SHA-384 CCEL specification')
    events = []
    while offset < len(raw):
        if raw[offset] in (0,255):
            remaining = raw[offset:]
            if remaining == bytes([remaining[0]])*len(remaining):
                break
        if len(events) >= MAX_EVENTS:
            raise ValueError('CCEL event count exceeds limit')
        register,kind,count = struct.unpack('<III',take(12))
        if not 1 <= register <= 4 or not 1 <= count <= len(algorithms):
            raise ValueError('invalid CCEL register or digest count')
        digests = {}
        for _ in range(count):
            algorithm = number('<H')
            if algorithm not in algorithms or algorithm in digests:
                raise ValueError('invalid CCEL event digest')
            digests[algorithm] = take(algorithms[algorithm])
        if SHA384 not in digests:
            raise ValueError('CCEL event omits SHA-384')
        data = take(number('<I'))
        events.append(Event(register,kind,tuple(sorted(digests.items())),data))
    return tuple(events)


def replay(events):
    registers = [bytes(48)]*4
    for event in events:
        if event.kind != 3:
            index = event.register-1
            registers[index] = hashlib.sha384(registers[index]+event.sha384()).digest()
    return tuple(registers)


def identify_bootstrap(raw, authenticated_rtmrs, *, bootstrap_digest, kernel_digest,
                       approved_gpt, command_line, initrd_digest):
    """Match all registers and require complete independent RTMR1/2 transcripts.

    Authenticode SHA-384 values identify loaded PE sections. They are distinct
    from SHA-256 distribution-file identities. No enrollment decision is made.
    """
    if (len(authenticated_rtmrs) != 4 or any(type(x) is not bytes or len(x) != 48 for x in authenticated_rtmrs)
            or type(bootstrap_digest) is not bytes or len(bootstrap_digest) != 48
            or type(kernel_digest) is not bytes or len(kernel_digest) != 48
            or type(initrd_digest) is not bytes or len(initrd_digest) != 48
            or type(approved_gpt) is not bytes or not 100 <= len(approved_gpt) <= 65536
            or not approved_gpt.startswith(b'EFI PART')
            or type(command_line) is not str or not 0 < len(command_line) <= 4096
            or '\0' in command_line):
        raise ValueError('invalid independent measurement references')
    events = parse(raw)
    registers = replay(events)
    if registers != tuple(authenticated_rtmrs):
        raise ValueError('CCEL does not reproduce authenticated RTMR values')
    def sha(data):
        return hashlib.sha384(data).digest()
    expected_images = [
        (0x80000007,sha(b'Calling EFI Application from Boot Option')),
        (4,sha(bytes(4))),
        (0x80000006,sha(approved_gpt)),
        (EFI_APPLICATION,bootstrap_digest),
        (EFI_APPLICATION,kernel_digest),
        (0x80000007,sha(b'Exit Boot Services Invocation')),
        (0x80000007,sha(b'Exit Boot Services Returned with Success'))]
    # Event labels are not independently protected by a register extension.
    # Authorize the complete digest sequence, rather than accepting any event
    # that the supplied log labels as something other than executable code.
    if [(e.kind,e.sha384()) for e in events if e.register == 2] != expected_images:
        raise ValueError('boot image transcript differs from independent references')
    expected_inputs = [(6,sha((command_line+'\0').encode('utf-16le'))),(6,initrd_digest)]
    if [(e.kind,e.sha384()) for e in events if e.register == 3] != expected_inputs:
        raise ValueError('kernel command line or initial filesystem differs from approval')
    if any(e.kind in (EFI_APPLICATION,EFI_BOOT_DRIVER,EFI_RUNTIME_DRIVER)
           and e.register != 2 for e in events):
        raise ValueError('unexpected external executable measurement register')
    return {'schema':'mfenx/efi-bootstrap-identification/v1',
            'events':len(events),'rtmr':[x.hex() for x in registers],
            'bootstrap_authenticode_sha384':bootstrap_digest.hex(),
            'loaded_images':[bootstrap_digest.hex(),kernel_digest.hex()],
            'kernel_inputs_match':True,
            'all_registers_match':True,'bootstrap_identified':True,
            'firmware_configuration_authorized':False,
            'confidential_model_execution_qualified':False}
