"""Build a self-contained EFI RAM-root image from explicit trusted inputs.

The optional runtime tree is included in the measured initial filesystem.
Private model keys and authority credentials must remain outside that tree.
Boot success is not confidential-execution qualification. Firmware and complete
boot measurements require independent appraisal before key release.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import lzma
import re
import ipaddress
import shlex

CMDLINE = "console=ttyS0 rdinit=/init panic=-1 module.sig_enforce=1"
INIT = r'''#!/bin/busybox sh
export PATH=/bin
umask 077
busybox mount -t proc proc /proc || exit 1
busybox mount -t sysfs sysfs /sys || exit 1
busybox mount -t devtmpfs devtmpfs /dev || exit 1
exec </dev/null >/dev/console 2>&1
echo MFENX_BOOTSTRAP_REACHED
if [ "$(busybox cat /proc/cmdline)" != 'EXPECTED_CMDLINE' ]; then
    echo MFENX_BOOTSTRAP_DENIED_COMMAND_LINE
    busybox poweroff -f
fi
if [ -e /unapproved ]; then
    echo MFENX_BOOTSTRAP_DENIED_EXTERNAL_INITRD
    busybox poweroff -f
fi
echo MFENX_BOOTSTRAP_RAM_ROOT
if [ ! -c /dev/tdx_guest ]; then
    echo MFENX_BOOTSTRAP_DENIED_NO_TDX
    busybox poweroff -f
fi
echo MFENX_BOOTSTRAP_NO_KEY_RELEASE_IMPLEMENTED
busybox poweroff -f
while true; do busybox sleep 60; done
'''.replace('EXPECTED_CMDLINE', 'BOOT_IMAGE=(memdisk)/boot/vmlinuz ' + CMDLINE)

DHCP = r'''#!/bin/busybox sh
case "$1" in
bound|renew)
    busybox ip addr flush dev "$interface"
    busybox ip addr add "$ip/${mask:-24}" dev "$interface" || exit 1
    for gateway in $router; do busybox ip route replace default via "$gateway" dev "$interface"; break; done
    ;;
esac
'''

QUOTE = r'''#!/bin/busybox sh
export PATH=/bin
case "$QUERY_STRING" in *[!0-9a-f]*|'') printf 'Status: 400 Bad Request\r\n\r\n'; exit;; esac
[ "${#QUERY_STRING}" -eq 64 ] || { printf 'Status: 400 Bad Request\r\n\r\n'; exit; }
busybox mkdir /run/quote.lock 2>/dev/null || { printf 'Status: 503 Service Unavailable\r\n\r\n'; exit; }
report=/sys/kernel/config/tsm/report/mfenx-probe
trap 'busybox rmdir "$report" 2>/dev/null; busybox rmdir /run/quote.lock' EXIT
busybox mkdir "$report" 2>/dev/null || { printf 'Status: 503 Service Unavailable\r\n\r\n'; exit; }
printf '%s' "$QUERY_STRING" | busybox xxd -r -p | busybox sha512sum | busybox cut -d ' ' -f1 | busybox xxd -r -p > "$report/inblob"
busybox dd if="$report/outblob" of=/run/quote.lock/quote bs=32769 count=1 2>/dev/null || { printf 'Status: 503 Service Unavailable\r\n\r\n'; exit; }
printf 'Content-Type: application/octet-stream\r\nCache-Control: no-store\r\n\r\n'
busybox cat /run/quote.lock/quote
busybox rm /run/quote.lock/quote
'''

EVENTLOG = r'''#!/bin/busybox sh
[ -r /sys/firmware/acpi/tables/data/CCEL ] || { printf 'Status: 503 Service Unavailable\r\n\r\n'; exit; }
printf 'Content-Type: application/octet-stream\r\nCache-Control: no-store\r\n\r\n'
busybox dd if=/sys/firmware/acpi/tables/data/CCEL bs=1048577 count=1 2>/dev/null
'''

HEALTH = r'''#!/bin/busybox sh
printf 'Content-Type: text/plain\r\nCache-Control: no-store\r\n\r\n'
echo 'Public bootstrap diagnostic only. No model keys or serving implementation.'
busybox uname -r
busybox cat /proc/cmdline
busybox cat /run/probe-errors
'''

NETWORK_INIT = r'''
busybox mkdir -p /run
busybox modprobe configfs >>/run/probe-errors 2>&1 || true
busybox mount -t configfs configfs /sys/kernel/config >>/run/probe-errors 2>&1 || true
busybox modprobe tdx_guest >>/run/probe-errors 2>&1 || true
for driver in virtio_pci virtio_net e1000 e1000e; do
    busybox modprobe "$driver" >>/run/probe-errors 2>&1 || true
done
busybox ip link set lo up
for path in /sys/class/net/*; do
    interface="${path##*/}"
    [ "$interface" = lo ] && continue
    busybox ip link set "$interface" up || continue
    busybox udhcpc -i "$interface" -s /dhcp -n -q -t 8 -T 3 || continue
done
echo MFENX_BOOTSTRAP_ATTESTATION_ONLY_HTTP
busybox httpd -f -p 22 -h /www
busybox poweroff -f
while true; do busybox sleep 60; done
'''


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def copy_executable(root, source):
    """Copy a trusted build-host executable and its resolved ELF dependencies."""
    source = Path(source)
    paths = [source]
    text = subprocess.check_output(['ldd',str(source)],text=True)
    if 'not found' in text:
        raise ValueError('unresolved build-host library')
    for line in text.splitlines():
        match = re.search(r'(?:=>\s*)?(/[^\s]+)',line)
        if match:
            paths.append(Path(match.group(1)))
    for p in paths:
        target = root / p.relative_to('/')
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,target)
        target.chmod(0o755)


def build(kernel, busybox, output, module_version=None, module_root=Path('/'),
          operator_public_key=None, network=None, extra_tree=None):
    if module_version and not re.fullmatch(r'[0-9][A-Za-z0-9.+_-]{1,127}',module_version):
        raise ValueError('invalid kernel module version')
    output.mkdir(mode=0o700)
    root = output / 'root'
    for name in ['bin', 'proc', 'sys', 'dev']:
        (root / name).mkdir(parents=True)
    shutil.copyfile(busybox, root / 'bin/busybox')
    (root / 'bin/busybox').chmod(0o755)
    (root / 'bin/sh').symlink_to('busybox')
    init = INIT
    if module_version:
        init = init.replace('if [ ! -c /dev/tdx_guest ]; then', NETWORK_INIT+'\nif [ ! -c /dev/tdx_guest ]; then')
        if network:
            if set(network) != {'mac','address','gateway'} or not re.fullmatch(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}',network['mac']):
                raise ValueError('invalid diagnostic network configuration')
            address = str(ipaddress.IPv4Interface(network['address']))
            gateway = str(ipaddress.IPv4Address(network['gateway']))
            static = ('if [ "$(busybox cat "$path/address")" = '+shlex.quote(network['mac'])+' ]; then\n'
                      'busybox ip addr add '+shlex.quote(address)+' dev "$interface" || exit 1\n'
                      'busybox ip route replace default via '+shlex.quote(gateway)+' dev "$interface" || exit 1\n'
                      'continue\nfi\n')
            init = init.replace('    busybox udhcpc',static+'    busybox udhcpc')
        if operator_public_key:
            key = operator_public_key.read_text().strip()
            if not re.fullmatch(r'ssh-ed25519 [A-Za-z0-9+/]{68}(?: [^\r\n]{0,128})?',key):
                raise ValueError('an explicit operator ed25519 public key is required')
            for binary in ['/usr/sbin/sshd','/usr/lib/openssh/sshd-session','/usr/lib/openssh/sshd-auth','/usr/bin/ssh-keygen']:
                copy_executable(root,binary)
            for name in ['etc/probe','root','run/sshd','dev/pts']:
                (root/name).mkdir(parents=True,exist_ok=True)
            (root/'etc/passwd').write_text('root:x:0:0:root:/root:/bin/sh\nsshd:x:65534:65534:SSH:/run/sshd:/bin/false\n')
            (root/'etc/group').write_text('root:x:0:\nsshd:x:65534:\n')
            (root/'etc/shadow').write_text('root:NP:0:0:99999:7:::\nsshd:!:0:0:99999:7:::\n')
            (root/'etc/nsswitch.conf').write_text('passwd: files\ngroup: files\nshadow: files\nhosts: files dns\n')
            (root/'etc/hosts').write_text('127.0.0.1 localhost\n::1 localhost\n')
            (root/'bin/false').symlink_to('busybox')
            (root/'etc/probe/authorized_keys').write_text(key+'\n')
            (root/'etc/probe/sshd_config').write_text('''Port 22
HostKey /run/ssh_host_ed25519_key
AuthorizedKeysFile /etc/probe/authorized_keys
PermitRootLogin prohibit-password
PasswordAuthentication no
KbdInteractiveAuthentication no
UsePAM no
PermitEmptyPasswords no
AllowUsers root
AllowAgentForwarding no
X11Forwarding no
PermitTunnel no
PrintMotd no
PidFile /run/sshd.pid
Subsystem sftp internal-sftp
''')
            init = init.replace('busybox httpd -f -p 22 -h /www',
                "busybox mkdir -p /dev/pts\nbusybox mount -t devpts devpts /dev/pts\n"
                "/usr/bin/ssh-keygen -q -t ed25519 -N '' -f /run/ssh_host_ed25519_key\n"
                "/usr/sbin/sshd -D -e -f /etc/probe/sshd_config")
        for name, text in [('dhcp', DHCP), ('www/cgi-bin/quote', QUOTE),
                           ('www/cgi-bin/eventlog', EVENTLOG), ('www/cgi-bin/health', HEALTH)]:
            p = root / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text)
            p.chmod(0o755)
        for module in ['configfs', 'tdx_guest', 'virtio_net', 'virtio_pci', 'e1000', 'e1000e']:
            result = subprocess.run(['modprobe','--show-depends','--dirname',str(module_root),
                '--set-version',module_version,module],text=True,capture_output=True)
            if result.returncode and module in ['e1000','e1000e']:
                continue
            result.check_returncode()
            dependencies = result.stdout
            for line in dependencies.splitlines():
                if line.startswith('builtin '):
                    continue
                source = Path(line.split()[1])
                target = root / source.relative_to(module_root)
                target.parent.mkdir(parents=True, exist_ok=True)
                data = source.read_bytes()
                if source.suffix == '.xz':
                    target = target.with_suffix('')
                    data = lzma.decompress(data)
                elif source.suffix == '.zst':
                    target = target.with_suffix('')
                    data = subprocess.check_output(['zstd','--decompress','--stdout',str(source)])
                target.write_bytes(data)
        for name in ['modules.order','modules.builtin','modules.builtin.modinfo']:
            source = module_root / 'lib/modules' / module_version / name
            if source.is_file():
                shutil.copyfile(source,root / 'lib/modules' / module_version / name)
        subprocess.run(['depmod','-b',str(root),module_version],check=True)
    (root / 'init').write_text(init)
    (root / 'init').chmod(0o755)
    if extra_tree:
        # Extra files are trusted build inputs, never supplied by a model
        # package at runtime. They become part of the measured EFI image.
        for entry in extra_tree.iterdir():
            if entry.name not in ('opt','usr','lib','lib64'):
                raise ValueError('unsupported trusted runtime-tree directory')
        for source in extra_tree.rglob('*'):
            target = root/source.relative_to(extra_tree)
            if source.is_dir():
                target.mkdir(parents=True,exist_ok=True)
            elif source.is_symlink():
                if target.exists() or target.is_symlink():
                    raise ValueError('runtime tree cannot replace bootstrap paths')
                target.symlink_to(os.readlink(source))
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists():
                    if source.read_bytes() != target.read_bytes():
                        raise ValueError('runtime tree conflicts with bootstrap dependencies')
                else:
                    shutil.copy2(source,target)
    for f in root.rglob('*'):
        if not f.is_symlink():
            if f.is_dir():
                f.chmod(0o755)
            else:
                f.chmod(0o755 if f.stat().st_mode & 0o111 else 0o644)
        os.utime(f, (0, 0), follow_symlinks=False)
    root.chmod(0o755)
    os.utime(root, (0, 0))
    names = sorted(['.'] + [str(f.relative_to(root)) for f in root.rglob('*')])
    result = subprocess.run(['cpio', '--null', '-o', '--format=newc', '--reproducible',
                             '--owner=0:0'], cwd=root, input=('\0'.join(names)+'\0').encode(),
                            capture_output=True, check=True)
    (output / 'initrd.gz').write_bytes(gzip.compress(result.stdout, mtime=0))
    shutil.copyfile(kernel, output / 'vmlinuz')
    # The locked account has no password authenticator. No menu, timeout, shell,
    # disk configuration, environment block, companion image or network is used.
    cfg = 'set superusers="disabled"\nset timeout=0\n'
    cfg += 'linux (memdisk)/boot/vmlinuz ' + CMDLINE + '\n'
    cfg += 'initrd (memdisk)/boot/initrd.gz\nboot\nhalt\n'
    (output / 'grub.cfg').write_text(cfg)
    for name in ['vmlinuz', 'initrd.gz', 'grub.cfg']:
        os.utime(output / name, (0, 0))
    subprocess.run(['grub-mkstandalone', '-O', 'x86_64-efi', '--compression=none',
                    '--modules=normal linux halt reboot', '--locales=', '--fonts=',
                    '-o', str(output / 'bootstrap.efi'),
                    'boot/grub/grub.cfg='+str(output/'grub.cfg'),
                    'boot/vmlinuz='+str(output/'vmlinuz'),
                    'boot/initrd.gz='+str(output/'initrd.gz')], check=True,
                   env={**os.environ, 'SOURCE_DATE_EPOCH':'0'})
    record = {'schema':'mfenx/efi-bootstrap-probe/v1', 'command_line':CMDLINE,
              'confidential_model_execution_qualified':False,
              'key_release_implemented':False,
              'attestation_http_probe':bool(module_version and not operator_public_key),
              'operator_ssh_probe':bool(operator_public_key),
              'network':network,
              'grub_version':subprocess.check_output(['grub-mkstandalone','--version'],text=True).strip(),
              'sha256':{name:digest(output/name) for name in
                        ['bootstrap.efi','vmlinuz','initrd.gz','grub.cfg']},
              'busybox_sha256':digest(busybox)}
    (output / 'build.json').write_text(json.dumps(record,indent=2)+'\n')
    return record


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kernel', type=Path, required=True)
    parser.add_argument('--busybox', type=Path, required=True,
                        help='Explicit statically linked BusyBox binary')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--module-version', help='Include this local kernel module dependency closure and public-quote HTTP probe')
    parser.add_argument('--module-root', type=Path, default=Path('/'))
    parser.add_argument('--operator-public-key',type=Path)
    parser.add_argument('--network-config',type=Path,help='Explicit diagnostic MAC/address/gateway JSON')
    parser.add_argument('--extra-tree',type=Path,help='Trusted runtime files to include in the measured image')
    args = parser.parse_args()
    print(json.dumps(build(args.kernel.resolve(), args.busybox.resolve(),
                           args.output.resolve(), args.module_version,args.module_root.resolve(),
                           args.operator_public_key,
                           json.loads(args.network_config.read_text()) if args.network_config else None,
                           args.extra_tree.resolve() if args.extra_tree else None), indent=2))
