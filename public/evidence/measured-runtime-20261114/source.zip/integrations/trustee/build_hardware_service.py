"""Build the pinned TDX/NVIDIA verifier service against an explicit Intel QVL.

Native libraries and guest reference values require separate qualification.
This builder does not approve hardware, enroll an image, or release any key.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil

from build_client import TRUSTEE, LOCK, clone, run
from service_hardening import enforce_token_validity


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(args):
    root = args.qvl_root.resolve()
    headers = root / 'usr/include'
    libraries = root / 'usr/lib/x86_64-linux-gnu'
    header = headers / 'sgx_dcap_quoteverify.h'
    library = libraries / 'libsgx_dcap_quoteverify.so.1'
    if not header.is_file() or not library.is_file():
        raise RuntimeError('an explicit Intel DCAP QVL runtime and development-header root is required')
    if not (libraries / 'libsgx_dcap_quoteverify.so').is_file():
        raise RuntimeError('Intel DCAP QVL development linker entry is missing')
    args.output.mkdir(mode=0o700)
    source = args.output / 'trustee'
    clone(args.source, source, TRUSTEE)
    if digest(source / 'Cargo.lock') != LOCK:
        raise RuntimeError('unexpected upstream dependency lock')
    enforce_token_validity(source)
    manifest = source / 'kbs/Cargo.toml'
    text = manifest.read_text()
    old = 'features = [\n    "all-verifier",\n], optional = true }'
    new = 'features = [\n    "tdx-verifier", "nvidia-verifier",\n], optional = true }'
    if text.count(old) != 1:
        raise RuntimeError('unexpected upstream hardware-verifier declaration')
    manifest.write_text(text.replace(old, new))
    env = dict(os.environ)
    env['SGX_SDK'] = str(root / 'usr')
    env['LIBRARY_PATH'] = str(libraries)
    if args.target_dir:
        env['CARGO_TARGET_DIR'] = str(args.target_dir.resolve())
    features = 'coco-as-builtin-no-verifier,attestation-service'
    run('cargo', '+1.95.0', 'build', '--locked', '--release', '-p', 'kbs',
        '--no-default-features', '--features', features, cwd=source, env=env)
    if digest(source / 'Cargo.lock') != LOCK:
        raise RuntimeError('upstream dependency lock changed')
    target = (args.target_dir if args.target_dir else source / 'target') / 'release/kbs'
    shutil.copyfile(target, args.output / 'kbs')
    (args.output / 'kbs').chmod(0o500)
    record = {'schema': 'mfenx/trustee-hardware-service-build/v1', 'source_revision': TRUSTEE,
              'upstream_lock_sha256': LOCK, 'features': features,
              'verifiers': ['tdx', 'nvidia'], 'server_sha256': digest(target),
              'manifest_sha256': digest(manifest), 'qvl_header_sha256': digest(header),
              'qvl_library_sha256': digest(library), 'runtime_library_directory': str(libraries),
              'jwt_source_sha256': digest(source / 'kbs/src/crypto/jwt.rs'),
              'token_validity': {'leeway_seconds': 0, 'validate_nbf': True},
              'hardware_qualified': False}
    (args.output / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--target-dir', type=Path)
    parser.add_argument('--qvl-root', type=Path, required=True)
    parser.add_argument('--source', default='https://github.com/confidential-containers/trustee.git')
    build(parser.parse_args())
