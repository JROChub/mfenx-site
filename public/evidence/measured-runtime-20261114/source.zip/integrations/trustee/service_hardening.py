"""Narrow source-checked hardening shared by pinned Trustee service builds."""


def enforce_token_validity(source):
    path = source / 'kbs/src/crypto/jwt.rs'
    text = path.read_text()
    old = 'let mut validation = Validation::new(algorithm);\n    validation.validate_aud = false;'
    new = '''let mut validation = Validation::new(algorithm);
    // Deployment authority uses an independently controlled broker clock.
    // Do not silently extend short-lived attestation or admin tokens.
    validation.leeway = 0;
    validation.validate_nbf = true;
    validation.validate_aud = false;'''
    if text.count(old) != 1:
        raise RuntimeError('unexpected upstream JWT validity implementation')
    path.write_text(text.replace(old, new))
