"""Build a local-only Trustee service with the sample verifier.

The test build deliberately excludes hardware verifiers and is not a production
attestation service. It exercises real TLS, token verification, Rego and JWE.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil

from build_client import TRUSTEE, LOCK, clone, run
from service_hardening import enforce_token_validity


def build(args):
    args.output.mkdir(mode=0o700)
    source=args.output/'trustee';clone(args.source,source,TRUSTEE)
    if hashlib.sha256((source/'Cargo.lock').read_bytes()).hexdigest()!=LOCK:
        raise RuntimeError('unexpected upstream lock')
    enforce_token_validity(source)
    manifest=source/'kbs/Cargo.toml';text=manifest.read_text()
    old='features = [\n    "all-verifier",\n], optional = true }'
    if text.count(old)!=1:raise RuntimeError('unexpected hardware-verifier feature declaration')
    manifest.write_text(text.replace(old,'features = [], optional = true }'))
    env=dict(os.environ)
    if args.target_dir:env['CARGO_TARGET_DIR']=str(args.target_dir.resolve())
    features='coco-as-builtin-no-verifier,attestation-service'
    run('cargo','+1.95.0','build','--locked','--release','-p','kbs','--no-default-features',
        '--features',features,cwd=source,env=env)
    target=(args.target_dir if args.target_dir else source/'target')/'release/kbs'
    shutil.copyfile(target,args.output/'kbs');(args.output/'kbs').chmod(0o500)
    record={'schema':'mfenx/trustee-service-test-build/v1','source_revision':TRUSTEE,
            'upstream_lock_sha256':LOCK,'features':features,'hardware_verifiers':False,
            'hardware_qualified':False,'server_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
            'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
    record['jwt_source_sha256']=hashlib.sha256((source/'kbs/src/crypto/jwt.rs').read_bytes()).hexdigest()
    record['token_validity']={'leeway_seconds':0,'validate_nbf':True}
    (args.output/'build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--source',default='https://github.com/confidential-containers/trustee.git')
    p.add_argument('--target-dir',type=Path);build(p.parse_args())
