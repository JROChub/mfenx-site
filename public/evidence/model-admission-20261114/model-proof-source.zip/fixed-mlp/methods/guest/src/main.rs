#![no_main]
#![no_std]
extern crate alloc;

use alloc::vec;
use risc0_zkvm::{
    guest::env,
    sha::{Impl, Sha256},
};
risc0_zkvm::guest::entry!(main);

// Layout constants are valid only for these exact authenticated assets.
const MODEL_SHA: [u8; 32] = [
    0xef, 0xaf, 0x1b, 0xec, 0x54, 0xe8, 0xee, 0xa3, 0xd4, 0x9f, 0x6f, 0xf5, 0xab, 0xef, 0x14, 0x82,
    0xca, 0x3f, 0x69, 0x77, 0x5e, 0x59, 0x78, 0x77, 0x29, 0x13, 0x03, 0x2d, 0x75, 0xad, 0x9f, 0xf9,
];
const DATA_SHA: [u8; 32] = [
    0xb2, 0x81, 0x01, 0x9a, 0x68, 0xb5, 0xf2, 0x0f, 0x79, 0x00, 0x77, 0x4f, 0xff, 0xa8, 0x70, 0xf5,
    0x1e, 0x3a, 0x7d, 0xf2, 0x63, 0x40, 0x7d, 0x1b, 0x73, 0xa0, 0x30, 0x35, 0x87, 0x10, 0x87, 0x4d,
];

fn f32_at(bytes: &[u8], offset: usize) -> f32 {
    f32::from_le_bytes(bytes[offset..offset + 4].try_into().unwrap())
}

fn main() {
    let mut index = [0u32; 1];
    env::read_slice(&mut index);
    let row = index[0] as usize;
    assert!(row < 1797);
    let mut model = vec![0u8; 10055];
    let mut data = vec![0u8; 474918];
    env::read_slice(&mut model);
    env::read_slice(&mut data);
    assert_eq!(Impl::hash_bytes(&model).as_bytes(), MODEL_SHA);
    assert_eq!(Impl::hash_bytes(&data).as_bytes(), DATA_SHA);
    let mut hidden = [0f32; 32];
    for j in 0..32 {
        let mut sum = 0f32;
        for i in 0..64 {
            let product =
                f32_at(&data, 188 + (row * 64 + i) * 4) * f32_at(&model, 320 + (i * 32 + j) * 4);
            sum += product;
        }
        hidden[j] = (sum + f32_at(&model, 8526 + j * 4)).max(0.0);
    }
    let mut logits = [0f32; 10];
    let mut encoded = [0u8; 40];
    for k in 0..10 {
        let mut sum = 0f32;
        for j in 0..32 {
            let product = hidden[j] * f32_at(&model, 8670 + (j * 10 + k) * 4);
            sum += product;
        }
        logits[k] = sum + f32_at(&model, 9962 + k * 4);
        assert!(logits[k].is_finite());
        encoded[k * 4..k * 4 + 4].copy_from_slice(&logits[k].to_le_bytes());
    }
    let mut class = 0usize;
    for k in 1..10 {
        if logits[k] > logits[class] {
            class = k;
        }
    }
    let label = u64::from_le_bytes(data[460408 + row * 8..460416 + row * 8].try_into().unwrap());
    assert!(label < 10);
    env::commit_slice(b"MFXMLP01");
    env::commit_slice(&MODEL_SHA);
    env::commit_slice(&DATA_SHA);
    env::commit_slice(&index[0].to_le_bytes());
    env::commit_slice(&(class as u32).to_le_bytes());
    env::commit_slice(&(label as u32).to_le_bytes());
    env::commit_slice(Impl::hash_bytes(&encoded).as_bytes());
}
