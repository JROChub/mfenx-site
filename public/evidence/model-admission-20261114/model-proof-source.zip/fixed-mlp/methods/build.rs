use std::process::Command;

fn main() {
    let (_, toolchain) = rzup::Rzup::new()
        .expect("RISC Zero installation")
        .get_default_version(&rzup::Component::RustToolchain)
        .expect("RISC Zero toolchain inventory")
        .expect("install the qualified RISC Zero Rust 1.97.0 toolchain");
    let observed = Command::new(toolchain.join("bin/rustc"))
        .arg("--version")
        .output()
        .expect("qualified guest compiler");
    assert!(observed.status.success());
    assert_eq!(
        String::from_utf8(observed.stdout).unwrap().trim(),
        "rustc 1.97.0-dev (e638c6cfe 2026-07-15)",
        "requalification is required before changing the guest compiler"
    );
    std::env::set_var("RISC0_BUILD_LOCKED", "1");
    risc0_build::embed_methods();
}
