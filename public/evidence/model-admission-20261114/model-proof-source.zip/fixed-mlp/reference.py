"""Reference and witness encoder for the fixed-asset FP32 evaluation relation."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
import zipfile

import numpy as np
import onnx
from onnx import numpy_helper

MODEL_SHA = 'efaf1bec54e8eea3d49f6ff5abef1482ca3f69775e5978772913032d75ad9ff9'
DATA_SHA = 'b281019a68b5f20f7900774fffa870f51e3a7df263407d1b73a030358710874d'


def reference(model_bytes, dataset_bytes, index):
    if (len(model_bytes), hashlib.sha256(model_bytes).hexdigest()) != (10055, MODEL_SHA):
        raise ValueError('unsupported model identity')
    if (len(dataset_bytes), hashlib.sha256(dataset_bytes).hexdigest()) != (474918, DATA_SHA):
        raise ValueError('unsupported dataset identity')
    if not 0 <= index < 1797:
        raise ValueError('sample index outside evaluated dataset')
    model = onnx.load_model_from_string(model_bytes)
    tensors = {t.name: numpy_helper.to_array(t) for t in model.graph.initializer}
    expected = [('w1', 320, (64, 32)), ('b1', 8526, (32,)),
                ('w2', 8670, (32, 10)), ('b2', 9962, (10,))]
    for name, offset, shape in expected:
        tensor = tensors[name]
        assert tensor.shape == shape and tensor.dtype == np.dtype('<f4')
        raw = tensor.tobytes(order='C')
        assert model_bytes[offset:offset + len(raw)] == raw
    with zipfile.ZipFile(io.BytesIO(dataset_bytes)) as archive:
        for name, expected_offset in [('inputs.npy', 188), ('labels.npy', 460408)]:
            entry = archive.getinfo(name)
            assert entry.compress_type == zipfile.ZIP_STORED and entry.flag_bits == 0
            start = entry.header_offset
            name_len, extra_len = struct.unpack_from('<HH', dataset_bytes, start + 26)
            npy_start = start + 30 + name_len + extra_len
            array = archive.read(name)
            assert array[:8] == b'\x93NUMPY\x01\x00'
            header_len = struct.unpack_from('<H', array, 8)[0]
            assert npy_start + 10 + header_len == expected_offset
    with np.load(io.BytesIO(dataset_bytes), allow_pickle=False) as data:
        inputs, labels = data['inputs'], data['labels']
        assert inputs.shape == (1797, 64) and inputs.dtype == np.dtype('<f4')
        assert labels.shape == (1797,) and labels.dtype == np.dtype('<i8')
        hidden = np.zeros(32, dtype=np.float32)
        for j in range(32):
            total = np.float32(0)
            for i in range(64):
                total = np.float32(total + np.float32(inputs[index, i] * tensors['w1'][i, j]))
            hidden[j] = max(np.float32(0), np.float32(total + tensors['b1'][j]))
        logits = np.zeros(10, dtype=np.float32)
        for k in range(10):
            total = np.float32(0)
            for j in range(32):
                total = np.float32(total + np.float32(hidden[j] * tensors['w2'][j, k]))
            logits[k] = np.float32(total + tensors['b2'][k])
        assert np.isfinite(logits).all()
        predicted, label = int(np.argmax(logits)), int(labels[index])
    logit_digest = hashlib.sha256(logits.astype('<f4').tobytes()).digest()
    journal = (b'MFXMLP01' + bytes.fromhex(MODEL_SHA) + bytes.fromhex(DATA_SHA)
               + struct.pack('<III', index, predicted, label) + logit_digest)
    assert len(journal) == 116
    return journal, {'model_sha256': MODEL_SHA, 'dataset_sha256': DATA_SHA,
                     'index': index, 'class': predicted, 'label': label,
                     'logit_bits': [f'{n:08x}' for n in logits.view('<u4')],
                     'logit_sha256': logit_digest.hex(), 'journal_hex': journal.hex()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True, type=Path)
    parser.add_argument('--dataset', required=True, type=Path)
    parser.add_argument('--index', type=int, default=0)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    model, data = args.model.read_bytes(), args.dataset.read_bytes()
    journal, report = reference(model, data, args.index)
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / 'witness.bin').write_bytes(struct.pack('<I', args.index) + model + data)
    (args.output / 'expected-journal.bin').write_bytes(journal)
    (args.output / 'reference.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
