Fixed-asset model evaluation relation, candidate v1

This guest defines one bounded computation over the public source ONNX model
and NPZ evaluation dataset identified in `reference.py`. It is not a general
ONNX interpreter. Hashes and exact lengths are checked inside the guest before
using fixed offsets for the known 64 → 32 ReLU → 10 graph and dataset layout.
The reference independently checks those offsets against ONNX, ZIP and NumPy
parsers. Any other model or dataset requires a separately reviewed guest and
execution-profile identity.

The witness is a little-endian u32 sample index, followed by exactly 10,055
model bytes and 474,918 dataset bytes. The index must be below 1,797. All guest
allocations have fixed bounds. For each dot product, products and additions
use ordered, nonfused FP32 operations; bias follows the dot product. ReLU maps
negative hidden values to zero. Argmax chooses the first maximal class. This
relation does not assert equality with a CUDA kernel's reduction order.

The 116-byte public journal contains, in order: the eight bytes `MFXMLP01`,
32 raw model-SHA-256 bytes, 32 raw dataset-SHA-256 bytes, three little-endian
u32 values (index, predicted class, dataset label), and SHA-256 of the ten
little-endian FP32 logits. Model and dataset identities, sample index, class,
label and logit commitment are public; no confidentiality claim is made for
the already published fixture inputs.

Generate the witness and independent expected journal with the qualified
ONNX/NumPy environment:

```sh
python proofs/fixed-mlp/reference.py --model source.onnx \
  --dataset dataset.npz --index 0 --output reference-output
cargo build --locked --manifest-path proofs/fixed-mlp/methods/Cargo.toml
```

The guest and build integration pin RISC Zero SDK 3.1.0, build crate 3.0.7,
and the qualified RISC Zero Rust 1.97.0 compiler commit. Guest dependency
resolution uses its committed lockfile. A compiler change requires a new
program identity and requalification.
The program binary, image ID, toolchain identity, lockfiles, statement and
actual protocol-verification result must be retained before qualification.
Proof generation and protocol-specific verification use the existing patched
Power House `julian sfcs` backend. A core PHA fingerprint alone is insufficient.

A deployment requiring this relation must independently approve the guest
image and compare the verified public journal with its admitted model,
dataset, sample and result policy. The Linux v2 admission policy implements
that comparison through the protocol-specific verifier; its observed CUDA
activation and negative tests are recorded in `docs/qualification.md`. No general model safety, GPU execution or
whole-dataset proof follows from one indexed evaluation.
