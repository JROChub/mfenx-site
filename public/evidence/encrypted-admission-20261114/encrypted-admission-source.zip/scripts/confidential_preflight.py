"""Read-only capability diagnostics before attempting attested key delivery.

Driver output and device nodes are not cryptographic attestation evidence.
No result from this script authorizes key release or qualifies a deployment.
"""
import argparse
import json
from pathlib import Path
import shutil
import stat
import subprocess


def inspect():
    devices = {}
    for name in ["/dev/tdx_guest", "/dev/sev-guest"]:
        try:
            devices[name] = stat.S_ISCHR(Path(name).stat().st_mode)
        except OSError:
            devices[name] = False
    queries = {}
    executable = shutil.which("nvidia-smi")
    if executable:
        for option in ["--get-cpu-caps", "--get-environment", "--get-cc-feature", "--get-mem-size-info"]:
            try:
                result = subprocess.run([executable, "conf-compute", option], capture_output=True, timeout=5)
                queries[option] = {"exit_code":result.returncode,
                                   "output":result.stdout[:8192].decode("utf-8", "replace")}
            except (OSError, subprocess.TimeoutExpired):
                queries[option] = {"exit_code":None, "output":"diagnostic unavailable"}
    reasons = []
    if not any(devices.values()):reasons.append("no supported protected CPU guest interface observed")
    if not executable:reasons.append("NVIDIA diagnostic tool unavailable")
    feature = queries.get("--get-cc-feature", {})
    if feature.get("exit_code") != 0 or "CC status: ON" not in feature.get("output", ""):
        reasons.append("enabled GPU confidential mode not observed")
    return {"schema":"mfenx/confidential-preflight/v1", "guest_interfaces":devices,
            "gpu_diagnostics":queries, "missing_prerequisites":reasons,
            "hardware_qualified":False, "key_release_authorized":False,
            "next_step":"upstream cryptographic attestation and MFENX release-policy qualification"}


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args();report=inspect();raw=json.dumps(report,indent=2)+"\n"
    if args.output:args.output.write_text(raw)
    print(raw,end="")
    raise SystemExit(2 if report["missing_prerequisites"] else 0)
