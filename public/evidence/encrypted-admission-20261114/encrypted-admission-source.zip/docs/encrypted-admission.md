Encrypted model distribution and Trustee integration

Gate 1.1.0rc2 adds encrypted acquisition to the existing retained-byte ONNX
loader. Organization service 0.4.0rc2 updates its package dependency; its public
organization and licensing interfaces are unchanged. The rc1 wheels, existing
Receipt v1 transcript, CPU/CUDA profiles and Power House identities remain
unchanged historical artifacts.

Security boundary

The producer authenticates the existing finite-evaluation receipt and exact
model bytes, then generates a fresh 256-bit AES key and 96-bit nonce for each
package. AES-256-GCM authenticates the complete bounded model before any ONNX
parser receives plaintext. Each key is a separate provisioning artifact.
Ciphertext distribution does not include the key or signing material.

The implementation supports the existing self-contained ONNX limit of 64 MiB.
It uses one authenticated message, not an undocumented chunked format. Larger
models and encrypted shard serving reject rather than enter an unqualified
streaming implementation. Plaintext is an owned immutable buffer consumed by
the existing loader; no plaintext checkpoint file is created by this path.
Python and native libraries can create memory copies. Reliable zeroization,
swap protection and hardware teardown are not established by deleting a Python
reference. A qualified protected guest must cover the full plaintext lifetime.

A local development integration does not provide host-resistant confidentiality.
That guarantee requires an approved confidential VM, enabled GPU protection,
actual vendor evidence, measured workload and reference values, independently
controlled Trustee service, and successful operational qualification. A GPU
model name, diagnostic output or signed software test token cannot substitute
for those checks. Previously exposed plaintext cannot be made secret by adding
an encrypted descriptor.

Descriptor and authorization

The versioned descriptor has schema `mfenx/encrypted-model/v1`, a `context`
object and `ciphertext_sha256`. Context fields are `algorithm` (exactly
`AES-256-GCM`), `model_sha256`, `model_bytes`, `receipt_sha256`, `resource` and
`nonce_base64`. The ciphertext includes the 16-byte GCM tag. The producer uses
this exact additional authenticated data:

```
b"mfenx:encrypted-model:v1\0" + canonical(context)
```

`canonical` is Gate's existing bounded ASCII/integer JSON representation.
The raw descriptor digest is independently approved in protected deployment
policy. This is not a new Receipt v1 signature or an assertion that an adjacent
checksum authenticates a publisher. The existing signed receipt authenticates
the plaintext artifact; the independently approved descriptor binds its exact
receipt bytes, plaintext identity, ciphertext identity and key resource. Changing
context, ciphertext, nonce, model identity or receipt causes rejection under the
original approval. Resource identifiers have exactly three restricted segments.

Policy `mfenx/encrypted-admission-policy/v1` requires:

| Field | Meaning |
| --- | --- |
| `admission` | Existing v1 or v2 admission-policy object, with its contract, issuer, release, runtime, epoch and optional proof requirements |
| `descriptor_sha256` | Independently approved raw descriptor identity |
| `broker_url` | Approved HTTPS origin, without credentials, path, query or fragment |
| `broker_ca_sha256` | Approved broker CA bytes supplied to the constrained client |
| `trustee_client_sha256` | Approved actual native executable identity |

The SHA-256 of the entire outer policy is the serving policy identity. Existing
durable epoch/floor checks therefore cover descriptor, broker, root and client
changes as well as the nested release policy. Changing the wrapper at the same
epoch cannot reopen an existing durable authority. Legacy policy parsing does
not accept this wrapper, and encrypted loading does not downgrade to legacy
admission. Independently approved policy remains separate from model input.

Measured launch data

`examples/prepare_encrypted_policy.py` validates independently supplied source
pins and generates `policy.json`, `initdata.toml`, `resource-policy.rego` and
`build.json`. Launch data follows the pinned Trustee v0.22 Initdata v0.1.0
format: TOML, algorithm `sha256`, and a string-valued `data` map. Its
`mfenx.json` value identifies the descriptor, canonical nested policy, broker,
CA and client. The upstream verifier hashes the exact TOML bytes, including
newlines. The reported initdata digest must be bound into the selected guest's
launch measurement; merely passing the same string at runtime is insufficient.

The resource policy accepts exactly one `cpu0` and one `gpu0` submodule, the
selected TDX or SNP evidence class, NVIDIA evidence, affirming appraisal and
explicit hardware/executable/configuration trust-vector values. It also
requires the exact resource, empty query and matching authenticated initdata
claims. The upstream attestation service must validate endorsements, freshness,
CPU/GPU composition, firmware, debug restrictions and workload reference values
before issuing those appraisals. This resource policy cannot compensate for a
misconfigured or compromised attestation authority.

Trustee client and service

The integration uses upstream Trustee revision
`512fed65642015b849f38fb13bfdec7806639987` (v0.22.0) and guest-components
`da8d93f2797088a5f0636c8c1eeb31da73784fe8`. The source builder constrains the
upstream protocol client's HTTP transport to HTTPS, no redirects and only
explicitly supplied certificate roots. It retains the upstream nonce, evidence,
recipient-key and encrypted-resource protocol. Registry dependency versions and
checksums must remain identical to the pinned upstream lock; unrelated git
revisions cannot change. Build records identify the derived lock, features,
source patch and actual executable. Native binary byte reproducibility is not
claimed by those records.

The adapter snapshots the approved executable and CA into sealed Linux memory
objects before execution. A fresh upstream client process receives only the
approved origin, resource, CA and launch data. It cannot receive caller-selected
cached tokens, recipient key files, proxy variables or admin credentials. Key
response acquisition uses an anonymous memory file with a 4 KiB child file-size
limit. The adapter accepts only the upstream encoding of exactly 32 key bytes;
no response is written to a regular disk file, returned in an exception or
logged by the adapter. Each child has a 2 GiB address-space limit, 30 s CPU
limit, 45 s wall deadline and no core dumps. At most two acquisitions run per
adapter process. These are process controls, not fleet quotas.

The key broker must be independently controlled relative to the host attacker
being excluded. Putting both plaintext key custody and the supposedly excluded
administrator in the same trust boundary defeats that objective. The existing
DigitalOcean licensing service is not repurposed as a key broker. A trusted
local machine can host development authority without another provider account;
production availability and recovery require separate commissioning.

Producer and serving procedures

Install the rc2 candidate into a dedicated environment. Keep the key destination
in an owner-only directory outside the newly created distribution directory:

```sh
python -I examples/encrypt_release.py \
  --model /approved/model.onnx --receipt /approved/release.json \
  --trusted-public-key /approved/issuer.der \
  --distribution /new/ciphertext-package --key-file /private/model-key.bin
```

Provision the key into the independently administered Trustee resource named by
the descriptor using upstream authenticated administration. Publish only the
ciphertext package and separately authorized release evidence. Do not archive
the key destination. Existing action inputs retain their meaning; encrypted
artifacts are not passed to the legacy plaintext verification input.

Generate the wrapper and launch-policy artifacts with explicit independent
`--approved-admission-sha256`, `--approved-descriptor-sha256`,
`--approved-broker-ca-sha256` and `--approved-trustee-client-sha256` inputs to
`examples/prepare_encrypted_policy.py`. Configure and measure the approved guest,
enroll its actual reference values, and install the generated resource policy
at the authenticated Trustee service. Attestation token verification must use
independently enrolled signer roots; `insecure_header_jwk` must remain false.
The generic upstream sample/default resource policy is not the MFENX policy.

Inside that approved workload:

```sh
python -I examples/serving_gateway.py \
  --receipt /approved/release.json --trusted-public-key /approved/issuer.der \
  --model /distribution/model.enc --encrypted-descriptor /distribution/descriptor.json \
  --policy /approved/policy.json --expected-policy-sha256 "$APPROVED_POLICY_SHA256" \
  --trustee-client /approved/kbs-client --broker-ca /approved/broker-ca.pem \
  --state /private/authority.sqlite --access-token-file /private/access-token
```

Include the existing proof and lineage options when required by the nested
policy. The listener activates only after authenticated key delivery, complete
AEAD authentication, plaintext identity verification, required proof/lineage
verification and runtime loading. Durable serving evidence additionally records
the distribution-evidence digest. Broker revocation prevents subsequent key
acquisition; stopping already loaded sessions still requires the existing
serving-policy revocation and lease controls. A delivered key cannot be
cryptographically retracted from an already authorized recipient.

Qualification and cost control

`python scripts/confidential_preflight.py` performs read-only capability
diagnostics. Missing prerequisites return exit 2. Even a successful diagnostic
reports `hardware_qualified: false` and cannot authorize a key. Establish actual
provider support and minimum rental commitment before provisioning compute.
DigitalOcean documents contract-based eight-GPU bare-metal billing; ordinary
GPU prices cannot be substituted for that quote. No provider account or cloud
resource is created by these tools.

`integrations/trustee/build_test_service.py` builds a local-only service with a
sample verifier. `build_client.py --profile software-tests` builds the matching
constrained client. These builds exercise real TLS, signed-token verification,
Rego authorization and recipient-bound JWE, but contain no qualified hardware
attestation path. Explicit `tdx-nvidia` and `snp-nvidia` client build selections
require their upstream dependencies and subsequent hardware qualification;
selecting a feature does not establish that qualification.

The CPU suite includes actual AEAD and ONNX inference, changed context, wrong
keys, corrupted/truncated ciphertext, mutation during key delivery, duplicate
metadata, durable wrapper epochs and separated producer key storage. Its key
provider doubles are not attestation observations. The separately selected
Trustee suite tests the real local service and client. Sample evidence and
synthetically signed EAR fixtures are labeled software tests, never hardware
qualification. Required hardware failure, teardown, recovery and performance
tests remain commissioning requirements for each actual supported deployment.

References

- [Trustee architecture](https://confidentialcontainers.org/docs/attestation/architecture/)
- [Pinned Trustee source](https://github.com/confidential-containers/trustee/tree/512fed65642015b849f38fb13bfdec7806639987)
- [NVIDIA key-release flow](https://docs.nvidia.com/enterprise-reference-architectures/deploying-proprietary-models-confidential-compute-self-hosted-vms/latest/attestation-and-key-release-flow.html)
- [DigitalOcean bare-metal billing](https://docs.digitalocean.com/products/bare-metal-gpus/details/pricing/)
