"""Build the pinned upstream client with a narrow HTTPS trust configuration.

Only task-owned clones are modified. The original repositories and Cargo cache
remain unchanged. Hardware feature selection does not qualify the resulting VM.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tomllib

TRUSTEE = '512fed65642015b849f38fb13bfdec7806639987'
GUEST = 'da8d93f2797088a5f0636c8c1eeb31da73784fe8'
LOCK = '2825e03527615a351dde2dabe2ad25edef483c3ac627ca2e2658863264ae5087'


def run(*command, cwd=None, env=None):
    subprocess.run(command,cwd=cwd,env=env,check=True)


def clone(source, target, revision):
    run('git','init',str(target))
    run('git','-C',str(target),'remote','add','origin',source)
    run('git','-C',str(target),'fetch','--depth','1','origin',revision)
    run('git','-C',str(target),'checkout','--detach','FETCH_HEAD')
    actual=subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()
    if actual!=revision:raise RuntimeError('source revision mismatch')


def build(args):
    args.output.mkdir(mode=0o700)
    trustee=args.output/'trustee';guest=args.output/'guest-components'
    clone(args.trustee_source,trustee,TRUSTEE);clone(args.guest_source,guest,GUEST)
    original=(trustee/'Cargo.lock').read_bytes()
    if hashlib.sha256(original).hexdigest()!=LOCK:raise RuntimeError('unexpected upstream dependency lock')
    builder=guest/'attestation-agent/kbs_protocol/src/builder.rs'
    old='let mut http_client_builder = reqwest::Client::builder()\n            .cookie_store(true)'
    new='''let mut http_client_builder = reqwest::Client::builder()
            .https_only(true)
            .redirect(reqwest::redirect::Policy::none())
            .tls_certs_only([])
            .cookie_store(true)'''
    source=builder.read_text()
    if source.count(old)!=1:raise RuntimeError('unexpected upstream TLS builder')
    builder.write_text(source.replace(old,new))
    manifest=trustee/'Cargo.toml';source=manifest.read_text()
    old='kbs_protocol = { git = "https://github.com/confidential-containers/guest-components.git", rev = "'+GUEST+'", default-features = false }'
    local=os.path.relpath(guest/'attestation-agent/kbs_protocol',trustee)
    new='kbs_protocol = { path = "'+local+'", default-features = false }'
    if source.count(old)!=1:raise RuntimeError('unexpected upstream client dependency')
    manifest.write_text(source.replace(old,new))
    env=dict(os.environ)
    if args.target_dir:env['CARGO_TARGET_DIR']=str(args.target_dir.resolve())
    run('cargo','+1.95.0','update','-p','kbs_protocol',cwd=trustee,env=env)
    updated=(trustee/'Cargo.lock').read_bytes()
    def registry(raw):
        return {(p['name'],p['version'],p.get('checksum')) for p in tomllib.loads(raw.decode())['package']
                if p.get('source','').startswith('registry+')}
    if registry(original)!=registry(updated):raise RuntimeError('registry dependency versions changed')
    def git_packages(raw):
        return {(p['name'],p['version'],p['source']) for p in tomllib.loads(raw.decode())['package']
                if p.get('source','').startswith('git+')}
    if not git_packages(updated).issubset(git_packages(original)):
        raise RuntimeError('unapproved git dependency revision')
    # Updating the lock loads metadata but does not acquire every crate archive.
    # Fetch under the checked lock so a clean runner can compile offline too.
    version=subprocess.check_output(['rustc','+1.95.0','-vV'],text=True)
    host=next(line.split(': ',1)[1] for line in version.splitlines() if line.startswith('host: '))
    run('cargo','+1.95.0','fetch','--locked','--target',host,cwd=trustee,env=env)
    features={'software-tests':'default-tls', 'tdx-nvidia':'default-tls,tdx-attester,nvidia-attester',
              'snp-nvidia':'default-tls,snp-attester,nvidia-attester'}[args.profile]
    run('cargo','+1.95.0','build','--offline','--locked','--release','-p','kbs-client',
        '--no-default-features','--features',features,cwd=trustee,env=env)
    target=(args.target_dir if args.target_dir else trustee/'target')/'release/kbs-client'
    shutil.copyfile(target,args.output/'kbs-client');(args.output/'kbs-client').chmod(0o500)
    record={'schema':'mfenx/trustee-client-build/v1','trustee_revision':TRUSTEE,'guest_revision':GUEST,
            'upstream_lock_sha256':LOCK,'derived_lock_sha256':hashlib.sha256(updated).hexdigest(),
            'builder_sha256':hashlib.sha256(builder.read_bytes()).hexdigest(),
            'client_sha256':hashlib.sha256(target.read_bytes()).hexdigest(), 'features':features,
            'profile':args.profile,'hardware_qualified':False,
            'transport':{'https_only':True,'redirects':False,'system_roots':False}}
    (args.output/'build.json').write_text(json.dumps(record,indent=2)+'\n')
    shutil.copyfile(trustee/'Cargo.lock',args.output/'Cargo.lock')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--target-dir',type=Path)
    parser.add_argument('--trustee-source',default='https://github.com/confidential-containers/trustee.git')
    parser.add_argument('--guest-source',default='https://github.com/confidential-containers/guest-components.git')
    parser.add_argument('--profile',choices=['software-tests','tdx-nvidia','snp-nvidia'],required=True)
    build(parser.parse_args())
