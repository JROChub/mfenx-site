"""Real local Trustee TLS/JWE/policy tests. Sample evidence is not hardware evidence."""
from contextlib import closing
import base64
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import signal
import socket
import sqlite3
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import tomllib
import unittest
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import patch

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa, utils
from cryptography.x509.oid import NameOID
import numpy as np

import test_admission as fixtures
from mfenx_gate.admission import PolicyAuthority, ServingSession
from mfenx_gate.encrypted import Descriptor, EncryptedPolicy, admit_encrypted_model, encrypt_model
from mfenx_gate.receipt import ReceiptError, canonical, sha256
from mfenx_gate.trustee_policy import resource_policy

ROOT=Path(__file__).resolve().parents[1]

def b64url(raw):return base64.urlsafe_b64encode(raw).decode().rstrip('=')

def sign_token(payload,key,header=None):
    header=dict({'alg':'ES256','typ':'JWT'},**(header or {}))
    message=(b64url(json.dumps(header,separators=(',',':')).encode())+'.'+b64url(json.dumps(payload,separators=(',',':')).encode())).encode()
    r,s=utils.decode_dss_signature(key.sign(message,ec.ECDSA(hashes.SHA256())))
    return message.decode()+'.'+b64url(r.to_bytes(32,'big')+s.to_bytes(32,'big'))

def certificate(key,name,issuer=None,issuer_key=None,ca=False,server=False):
    now=datetime.now(timezone.utc);subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,name)])
    builder=(x509.CertificateBuilder().subject_name(subject).issuer_name(issuer.subject if issuer else subject)
             .public_key(key.public_key()).serial_number(x509.random_serial_number())
             .not_valid_before(now-timedelta(minutes=1)).not_valid_after(now+timedelta(days=1))
             .add_extension(x509.BasicConstraints(ca=ca,path_length=0 if ca else None),critical=True)
             .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()),critical=False)
             .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key((issuer_key or key).public_key()),critical=False)
             .add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=False,
                data_encipherment=False,key_agreement=False,key_cert_sign=ca,crl_sign=ca,
                encipher_only=False,decipher_only=False),critical=True))
    if server:builder=builder.add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost')]),critical=False)
    return builder.sign(issuer_key or key,hashes.SHA256())

def pem_key(key):return key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption())

@unittest.skipUnless(os.environ.get('MFENX_TRUSTEE_INTEGRATION')=='1','requires explicitly selected real local Trustee binaries')
class TrusteeIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=Path(os.environ['MFENX_TRUSTEE_BINARY']).resolve()
        cls.client=Path(os.environ['MFENX_TRUSTEE_CLIENT']).resolve()
        cls.tmp=tempfile.TemporaryDirectory(prefix='mfenx-trustee-test-');cls.base=Path(cls.tmp.name)
        cls.addClassCleanup(cls.tmp.cleanup)
        cls.base.chmod(0o700)
        tls_ca_key=ec.generate_private_key(ec.SECP256R1());tls_ca=certificate(tls_ca_key,'MFENX local test TLS CA',ca=True)
        tls_key=ec.generate_private_key(ec.SECP256R1());tls=certificate(tls_key,'localhost',tls_ca,tls_ca_key,server=True)
        cls.as_ca_key=ec.generate_private_key(ec.SECP256R1());cls.as_ca=certificate(cls.as_ca_key,'MFENX local test AS CA',ca=True)
        cls.as_key=ec.generate_private_key(ec.SECP256R1());cls.as_cert=certificate(cls.as_key,'MFENX local test AS',cls.as_ca,cls.as_ca_key)
        cls.admin_key=ec.generate_private_key(ec.SECP256R1())
        documents={'tls-ca.pem':tls_ca.public_bytes(serialization.Encoding.PEM),'tls.pem':tls.public_bytes(serialization.Encoding.PEM),
                   'tls-key.pem':pem_key(tls_key),'as-ca.pem':cls.as_ca.public_bytes(serialization.Encoding.PEM),
                   'as.pem':cls.as_cert.public_bytes(serialization.Encoding.PEM)+cls.as_ca.public_bytes(serialization.Encoding.PEM),
                   'as-key.pem':pem_key(cls.as_key),
                   'admin.pub':cls.admin_key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)}
        for name,raw in documents.items():p=cls.base/name;p.write_bytes(raw);p.chmod(0o600)
        with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        cls.url='https://localhost:'+str(port);cls.ca=cls.base/'tls-ca.pem'
        cls.context=ssl.create_default_context(cafile=str(cls.ca))
        config={'http_server':{'sockets':['127.0.0.1:'+str(port)],'insecure_http':False,'worker_count':2,
                              'private_key':str(cls.base/'tls-key.pem'),'certificate':str(cls.base/'tls.pem')},
                'attestation_token':{'trusted_certs_paths':[str(cls.base/'as-ca.pem')],'insecure_header_jwk':False},
                'attestation_service':{'type':'coco_as_builtin','rvps_config':{'type':'BuiltIn'},
                  'attestation_token_broker':{'duration_min':1,'signer':{'key_path':str(cls.base/'as-key.pem'),'cert_path':str(cls.base/'as.pem')}}},
                'admin':{'authorization_mode':'AuthenticatedAuthorization','authentication':{'bearer_jwt':{'identity_providers':[
                         {'issuer':'MFENX-local-test-admin','audience':'mfenx-local-test','public_key_uri':'file://'+str(cls.base/'admin.pub')}] }},
                         'authorization':{'regex_acl':{'acls':[{'role':'admin','allowed_endpoints':'^/kbs/.+$'}]}}},
                'storage_backend':{'storage_type':'LocalFs','backends':{'local_fs':{'dir_path':str(cls.base/'storage')}}},
                'plugins':[{'name':'resource','storage_backend_type':'kvstorage'}]}
        path=cls.base/'config.json';path.write_text(json.dumps(config))
        log=open(cls.base/'service.log','wb');cls.addClassCleanup(log.close)
        cls.process=subprocess.Popen([str(cls.server),'--config-file',str(path)],stdout=log,stderr=subprocess.STDOUT,
                                     stdin=subprocess.DEVNULL,start_new_session=True,env={'PATH':os.defpath,'RUST_LOG':'warn'})
        cls.addClassCleanup(cls.stop_server)
        last='no response'
        for _ in range(200):
            if cls.process.poll() is not None:raise RuntimeError('local Trustee startup failed: '+(cls.base/'service.log').read_text()[-2500:])
            try:
                with urlopen(cls.url+'/kbs/v0/resource-policy',context=cls.context,timeout=1):pass
            except HTTPError as error:error.close();break
            except OSError as error:last=str(error);time.sleep(.1)
        else:raise RuntimeError('local Trustee did not start: '+last+' '+(cls.base/'service.log').read_text()[-2000:])
        now=int(time.time());cls.admin_token=sign_token({'iss':'MFENX-local-test-admin','aud':'mfenx-local-test','role':'admin','iat':now,'exp':now+3600},cls.admin_key)

    @classmethod
    def stop_server(cls):
        if cls.process.poll() is None:
            os.killpg(cls.process.pid,signal.SIGTERM)
            try:cls.process.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(cls.process.pid,signal.SIGKILL);cls.process.wait(timeout=5)

    def setUp(self):
        fixtures.AdmissionTests.setUp(self)
        self.package=encrypt_model(self.payload,receipt=self.receipt,trusted_public_key=self.public)
        self.descriptor=Descriptor.from_bytes(self.package.descriptor,expected_sha256=sha256(self.package.descriptor))
        self.cipher=self.root/'model.enc';self.cipher.write_bytes(self.package.ciphertext)
        self.raw_policy={'schema':'mfenx/encrypted-admission-policy/v1','admission':self.p,'descriptor_sha256':self.descriptor.digest,
                         'broker_url':self.url,'broker_ca_sha256':sha256(self.ca.read_bytes()),'trustee_client_sha256':sha256(self.client.read_bytes())}
        self.policy=self.make_policy()
        self.admin('resource/'+self.descriptor.context['resource'],self.package.key)
        self.allow_development_sample()

    def make_policy(self):
        raw=canonical(self.raw_policy);return EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))

    def admin(self,path,body,token=None,expect=200):
        request=Request(self.url+'/kbs/v0/'+path,data=body,method='POST',headers={'Authorization':'Bearer '+(self.admin_token if token is None else token)})
        try:
            with urlopen(request,context=self.context,timeout=15) as r:status=r.status;raw=r.read(65536)
        except HTTPError as e:
            with e:status=e.code;raw=e.read(65536)
        self.assertEqual(status,expect,'unexpected Trustee admin status')
        return raw

    def install_policy(self,source):self.admin('resource-policy',json.dumps({'policy':b64url(source.encode())}).encode())

    def allow_development_sample(self):
        # This test-only rule is never generated or shipped as deployment policy.
        self.install_policy('package policy\nimport rego.v1\ndefault allow := false\nallow if { data.plugin == "resource"; input.submods.cpu0["ear.veraison.annotated-evidence"].sample }\n')

    def admit(self):
        return admit_encrypted_model(descriptor=self.package.descriptor,ciphertext=self.cipher,receipt=self.receipt,
                    trusted_public_key=self.public,policy=self.policy,trustee_client=self.client,broker_ca=self.ca)

    def direct(self,*args):
        return subprocess.run([str(self.client),'--url',self.url,'--cert-file',str(self.ca),*map(str,args)],
                              capture_output=True,timeout=45,env={'PATH':os.defpath,'RUST_LOG':'off'},cwd=self.root)

    def test_actual_fresh_attestation_resource_delivery_decryption_and_cpu_inference(self):
        model=self.admit();self.model.unlink();self.cipher.unlink();self.cipher.write_bytes(b'X'*len(self.package.ciphertext))
        with ServingSession(model,PolicyAuthority(self.policy.admission,state_path=self.root/'state.sqlite')) as session:
            self.assertEqual(session.run({'x':np.array([3],np.float32)})[0].tolist(),[5.0])
        with closing(sqlite3.connect(self.root/'state.sqlite')) as c:
            self.assertEqual(c.execute('SELECT distribution FROM admission_distribution_evidence').fetchall(),[(model.distribution_sha256,)])

    def test_strict_cpu_gpu_policy_denies_real_sample_evidence_before_model_parser(self):
        self.install_policy(resource_policy(self.policy,self.descriptor,cpu_tee='tdx'))
        with patch('onnx.load_model_from_string') as parser:
            with self.assertRaises(ReceiptError):self.admit()
            parser.assert_not_called()

    def test_unsigned_administrator_cannot_change_policy_or_resource(self):
        self.admin('resource-policy',json.dumps({'policy':b64url(b'package policy\nallow := true')}).encode(),token='invalid',expect=401)
        self.admin('resource/'+self.descriptor.context['resource'],b'X'*32,token='invalid',expect=401)
        model=self.admit()
        with ServingSession(model,PolicyAuthority(self.policy.admission)) as session:
            self.assertEqual(session.run({'x':np.array([3],np.float32)})[0].tolist(),[5.0])

    def test_key_reacquisition_and_active_serving_revocation_have_separate_effects(self):
        model=self.admit();authority=PolicyAuthority(self.policy.admission,state_path=self.root/'state.sqlite')
        with ServingSession(model,authority) as session:
            self.assertEqual(session.run({'x':np.array([3],np.float32)})[0].tolist(),[5.0])
            self.install_policy('package policy\ndefault allow := false\n')
            with self.assertRaises(ReceiptError):self.admit()
            updated=copy.deepcopy(self.raw_policy);updated['admission']['epoch']+=1
            updated['admission']['revoked_receipts']=[sha256(self.receipt)]
            raw=canonical(updated);new=EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))
            authority.install(new.admission)
            with self.assertRaises(ReceiptError):session.run({'x':np.array([3],np.float32)})
        with closing(sqlite3.connect(self.root/'state.sqlite')) as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM admission_audit WHERE event='inference-completed'").fetchone()[0],1)

    def test_attestation_token_cannot_be_used_by_another_recipient(self):
        a,b=[rsa.generate_private_key(public_exponent=65537,key_size=2048) for _ in range(2)]
        for name,key in [('a.pem',a),('b.pem',b)]:path=self.root/name;path.write_bytes(pem_key(key));path.chmod(0o600)
        attested=self.direct('attest','--tee-key-file',self.root/'a.pem','--init-data',self.policy.init_data)
        self.assertEqual(attested.returncode,0,'fresh sample protocol attestation failed')
        token=self.root/'token.jwt';token.write_bytes(attested.stdout.strip());token.chmod(0o600)
        good=self.direct('get-resource','--path',self.descriptor.context['resource'],'--tee-key-file',self.root/'a.pem','--attestation-token',token)
        self.assertEqual(good.returncode,0,'approved recipient delivery failed')
        self.assertTrue(base64.b64decode(good.stdout.strip(),validate=True)==self.package.key,'wrong key returned')
        bad=self.direct('get-resource','--path',self.descriptor.context['resource'],'--tee-key-file',self.root/'b.pem','--attestation-token',token)
        self.assertNotEqual(bad.returncode,0);self.assertEqual(bad.stdout,b'')

    def signed_claims(self,key,claims=None,signer=None,certificate_chain=None):
        signer=signer or self.as_key
        numbers=key.public_key().public_numbers()
        public={'alg':'RSA-OAEP-256','kty':'RSA','n':b64url(numbers.n.to_bytes(256,'big')),'e':b64url(numbers.e.to_bytes(3,'big'))}
        vector={'hardware':2,'executables':3,'configuration':2}
        annotated={'tdx':{'test_fixture':True},'init_data_claims':tomllib.loads(self.policy.init_data)['data'],
                   'runtime_data_claims':{'tee-pubkey':public}}
        now=int(time.time())
        payload=claims or {'iss':'CoCo-Attestation-Service','iat':now,'exp':now+60,'submods':{
            'cpu0':{'ear.status':'affirming','ear.trustworthiness-vector':vector.copy(),'ear.veraison.annotated-evidence':annotated},
            'gpu0':{'ear.status':'affirming','ear.trustworthiness-vector':vector.copy(),'ear.veraison.annotated-evidence':{'nvidia':{'test_fixture':True}}}}}
        numbers=signer.public_key().public_numbers()
        chain=certificate_chain or [self.as_cert,self.as_ca]
        jwk={'kty':'EC','crv':'P-256','alg':'ES256','x':b64url(numbers.x.to_bytes(32,'big')),'y':b64url(numbers.y.to_bytes(32,'big')),
             'x5c':[base64.b64encode(c.public_bytes(serialization.Encoding.DER)).decode() for c in chain]}
        return payload,sign_token(payload,signer,{'jwk':jwk})

    def token_resource(self,token,key):
        private=self.root/'recipient.pem';private.write_bytes(pem_key(key));private.chmod(0o600)
        path=self.root/'claims.jwt';path.write_text(token);path.chmod(0o600)
        return self.direct('get-resource','--path',self.descriptor.context['resource'],'--tee-key-file',private,'--attestation-token',path)

    def test_real_policy_engine_checks_synthetic_signed_claims_without_qualifying_hardware(self):
        self.install_policy(resource_policy(self.policy,self.descriptor,cpu_tee='tdx'))
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        claims,token=self.signed_claims(key)
        result=self.token_resource(token,key)
        self.assertEqual(result.returncode,0,'strict policy did not accept its synthetic control fixture')
        self.assertTrue(base64.b64decode(result.stdout.strip(),validate=True)==self.package.key,'unexpected key')
        cases=[]
        changed=copy.deepcopy(claims);del changed['submods']['gpu0'];cases.append(changed)
        changed=copy.deepcopy(claims);changed['submods']['gpu0']['ear.status']='contraindicated';cases.append(changed)
        changed=copy.deepcopy(claims);changed['submods']['cpu0']['ear.trustworthiness-vector']['configuration']=0;cases.append(changed)
        changed=copy.deepcopy(claims);changed['submods']['gpu0']['ear.trustworthiness-vector']['executables']=33;cases.append(changed)
        changed=copy.deepcopy(claims);changed['submods']['cpu0']['ear.veraison.annotated-evidence']['init_data_claims']={};cases.append(changed)
        changed=copy.deepcopy(claims);changed['submods']['cpu0']['ear.veraison.annotated-evidence']['sample']={};del changed['submods']['cpu0']['ear.veraison.annotated-evidence']['tdx'];cases.append(changed)
        # These signed tokens used to fit the upstream JWT library's default
        # clock-skew allowance, or its disabled not-before check.
        changed=copy.deepcopy(claims);changed['exp']=int(time.time())-2;cases.append(changed)
        changed=copy.deepcopy(claims);changed.update(nbf=int(time.time())+600,exp=int(time.time())+1200);cases.append(changed)
        for index,changed in enumerate(cases):
            with self.subTest(case=index):
                _,token=self.signed_claims(key,changed);bad=self.token_resource(token,key)
                self.assertNotEqual(bad.returncode,0);self.assertEqual(bad.stdout,b'')

    def test_unendorsed_attestation_signer_is_rejected_by_real_broker(self):
        self.install_policy(resource_policy(self.policy,self.descriptor,cpu_tee='tdx'))
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        signer=ec.generate_private_key(ec.SECP256R1());cert=certificate(signer,'unendorsed test AS',ca=True)
        _,token=self.signed_claims(key,signer=signer,certificate_chain=[cert])
        result=self.token_resource(token,key)
        self.assertNotEqual(result.returncode,0);self.assertEqual(result.stdout,b'')

    def test_resource_namespace_is_data_in_the_actual_policy_engine(self):
        self.package=encrypt_model(self.payload,receipt=self.receipt,trusted_public_key=self.public,repository='CPU_TEE')
        self.descriptor=Descriptor.from_bytes(self.package.descriptor,expected_sha256=sha256(self.package.descriptor))
        self.raw_policy['descriptor_sha256']=self.descriptor.digest;self.policy=self.make_policy()
        self.admin('resource/'+self.descriptor.context['resource'],self.package.key)
        self.install_policy(resource_policy(self.policy,self.descriptor,cpu_tee='tdx'))
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        _,token=self.signed_claims(key);result=self.token_resource(token,key)
        self.assertEqual(result.returncode,0,'resource namespace was reinterpreted as template syntax')
        self.assertTrue(base64.b64decode(result.stdout.strip(),validate=True)==self.package.key,'wrong resource returned')

    def test_snp_policy_accepts_only_its_selected_cpu_claim_type(self):
        self.install_policy(resource_policy(self.policy,self.descriptor,cpu_tee='snp'))
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        claims,token=self.signed_claims(key)
        result=self.token_resource(token,key)
        self.assertNotEqual(result.returncode,0)
        annotated=claims['submods']['cpu0']['ear.veraison.annotated-evidence']
        annotated['snp']=annotated.pop('tdx')
        _,token=self.signed_claims(key,claims);result=self.token_resource(token,key)
        self.assertEqual(result.returncode,0,'selected SNP claim fixture rejected')
        self.assertTrue(base64.b64decode(result.stdout.strip(),validate=True)==self.package.key,'wrong resource returned')

    def test_wrong_tls_root_and_changed_client_binary_deny_before_model_parser(self):
        wrong=self.root/'wrong.pem';wrong.write_bytes((self.base/'as-ca.pem').read_bytes())
        for certificate_path,client in [(wrong,self.client),(self.ca,self.root/'missing-client')]:
            with patch('onnx.load_model_from_string') as parser:
                with self.assertRaises(ReceiptError):
                    admit_encrypted_model(descriptor=self.package.descriptor,ciphertext=self.cipher,receipt=self.receipt,
                        trusted_public_key=self.public,policy=self.policy,trustee_client=client,broker_ca=certificate_path)
                parser.assert_not_called()
        changed=copy.deepcopy(self.raw_policy);changed['broker_ca_sha256']=sha256(wrong.read_bytes())
        raw=canonical(changed);policy=EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))
        with self.assertRaises(ReceiptError):
            admit_encrypted_model(descriptor=self.package.descriptor,ciphertext=self.cipher,receipt=self.receipt,
                trusted_public_key=self.public,policy=policy,trustee_client=self.client,broker_ca=wrong)

    def test_native_client_refuses_redirect_to_another_valid_https_broker(self):
        events=[];target=self.url
        class Redirect(BaseHTTPRequestHandler):
            def do_POST(self):
                events.append(self.path)
                self.send_response(307);self.send_header('Location',target+self.path)
                self.end_headers()
            do_GET=do_POST
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Redirect)
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(self.base/'tls.pem'),str(self.base/'tls-key.pem'))
        server.socket=context.wrap_socket(server.socket,server_side=True)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            changed=copy.deepcopy(self.raw_policy);changed['broker_url']='https://localhost:'+str(server.server_port)
            raw=canonical(changed);policy=EncryptedPolicy.from_bytes(raw,expected_sha256=sha256(raw))
            with self.assertRaises(ReceiptError):
                admit_encrypted_model(descriptor=self.package.descriptor,ciphertext=self.cipher,receipt=self.receipt,
                    trusted_public_key=self.public,policy=policy,trustee_client=self.client,broker_ca=self.ca)
            self.assertEqual(events,['/kbs/v0/resource/'+self.descriptor.context['resource']])
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)

    def test_gateway_loads_only_encrypted_input_and_cannot_restart_after_broker_denial(self):
        for name,raw in [('receipt.json',self.receipt),('issuer.der',self.public),('descriptor.json',self.package.descriptor),
                         ('policy.json',canonical(self.raw_policy))]: (self.root/name).write_bytes(raw)
        token=secrets.token_urlsafe(32);(self.root/'access-token').write_text(token);(self.root/'access-token').chmod(0o600)
        self.model.unlink()
        with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        command=[sys.executable,'-I',str(ROOT/'examples/serving_gateway.py'),'--receipt',str(self.root/'receipt.json'),
                 '--trusted-public-key',str(self.root/'issuer.der'),'--model',str(self.cipher),'--policy',str(self.root/'policy.json'),
                 '--expected-policy-sha256',self.policy.digest,'--state',str(self.root/'state.sqlite'),
                 '--access-token-file',str(self.root/'access-token'),'--encrypted-descriptor',str(self.root/'descriptor.json'),
                 '--trustee-client',str(self.client),'--broker-ca',str(self.ca),'--port',str(port)]
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            import select
            ready=select.select([process.stdout],[],[],50)[0]
            self.assertTrue(ready,'encrypted gateway did not initialize')
            line=process.stdout.readline();self.assertTrue(json.loads(line)['listening'],'encrypted gateway admission denied')
            self.cipher.unlink();self.cipher.write_bytes(b'X'*len(self.package.ciphertext))
            c=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
            c.request('POST','/v1/infer',json.dumps({'inputs':{'x':[3]}}),{'Content-Type':'application/json','Authorization':'Bearer '+token})
            response=c.getresponse();raw=response.read();c.close()
            self.assertEqual(response.status,200);result=json.loads(raw)
            self.assertEqual(result['outputs'],[[5.0]]);self.assertIsNotNone(result['distribution_sha256'])
        finally:
            if process.poll() is None:process.terminate()
            process.communicate(timeout=10)
        self.cipher.write_bytes(self.package.ciphertext)
        self.install_policy('package policy\ndefault allow := false\n')
        result=subprocess.run(command,capture_output=True,timeout=50)
        self.assertEqual(result.returncode,2)
        with socket.socket() as s:self.assertNotEqual(s.connect_ex(('127.0.0.1',port)),0)

if __name__=='__main__':unittest.main()
