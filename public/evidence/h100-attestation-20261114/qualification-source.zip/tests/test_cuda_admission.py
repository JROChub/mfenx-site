"""Real CUDA enforcement checks. Opt in only on an allocated GPU workload."""
import copy
import os
import json
from pathlib import Path
import time
import unittest
from unittest.mock import patch

import numpy as np
import onnx
from onnx import TensorProto, helper

import test_admission as fixtures
from mfenx_gate.admission import (AdmissionPolicy, PolicyAuthority, ServingSession,
                                   CUDA_RUNTIME_PROFILE, runtime_identity, admit_model)
from mfenx_gate.receipt import ReceiptError, _sign, sha256, canonical, verify_receipt


@unittest.skipUnless(os.environ.get("MFENX_CUDA_QUALIFICATION") == "1",
                     "requires an explicitly selected real CUDA workload")
class CudaAdmissionTests(unittest.TestCase):
    policy = fixtures.AdmissionTests.policy
    admit = fixtures.AdmissionTests.admit

    def setUp(self):
        fixtures.AdmissionTests.setUp(self)
        observed = runtime_identity(CUDA_RUNTIME_PROFILE)
        self.p.update(runtime_profile=CUDA_RUNTIME_PROFILE,
                      runtime_sha256=observed["native_sha256"],
                      runtime_provider_sha256=observed["provider_sha256"],
                      runtime_config_sha256=observed["config_sha256"])

    def test_delayed_upload_and_repeated_inference_use_retained_bytes(self):
        admitted = self.admit()
        self.model.unlink()
        self.model.write_bytes(b"X" * len(self.payload))
        with ServingSession(admitted, PolicyAuthority(self.policy())) as session:
            for _ in range(3):
                actual = session.run({"x": np.array([3.0], np.float32)})
                self.assertEqual(actual[0].tolist(), [5.0])
                self.assertEqual(session.last_output_devices, ("cuda",))
                self.assertEqual(session._session.get_providers()[0], "CUDAExecutionProvider")
                self.assertEqual(session._session.get_session_options().get_session_config_entry(
                    "session.disable_cpu_ep_fallback"), "1")
        self.assertEqual(session.state, "TERMINATED")

    def test_cuda_arena_denies_an_over_budget_standard_operator(self):
        # A real small CUDA operation is the positive control. The subsequent
        # Expand requests 3 GiB through the configured 2 GiB provider arena.
        with ServingSession(self.admit(), PolicyAuthority(self.policy())) as control:
            self.assertEqual(control.run({"x": np.array([3.0], np.float32)})[0].tolist(), [5.0])
            self.assertEqual(control.last_output_devices, ("cuda",))
        elements = 3 * 1024**3 // 4
        graph = helper.make_graph([helper.make_node("Expand", ["x", "shape"], ["y"])], "arena-limit",
            [helper.make_tensor_value_info("x", TensorProto.FLOAT, [1])],
            [helper.make_tensor_value_info("y", TensorProto.FLOAT, [elements])],
            [helper.make_tensor("shape", TensorProto.INT64, [1], [elements])])
        model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)]); model.ir_version = 8
        self.payload = model.SerializeToString(); self.model.write_bytes(self.payload)
        self.statement["artifact"].update(sha256=sha256(self.payload), bytes=len(self.payload))
        self.receipt = _sign(self.statement, self.private, "Synthetic GPU allocation-limit authority")
        self.p["approved_releases"] = [{"receipt_sha256":sha256(self.receipt), "sequence":1}]
        session = None
        with self.assertRaisesRegex(Exception, r"(?i)allocate.*3221225472|memory.*limit|arena"):
            session = ServingSession(self.admit(), PolicyAuthority(self.policy()))
            session.run({"x": np.array([3.0], np.float32)})
        if session is not None:
            self.assertEqual(session.state, "TERMINATED")

    def test_mutated_bytes_never_reach_the_parser(self):
        self.model.write_bytes(self.payload[:-1] + bytes([self.payload[-1] ^ 1]))
        with patch.object(onnx, "load_model_from_string") as parser:
            with self.assertRaises(ReceiptError):
                self.admit()
            parser.assert_not_called()

    def test_required_provider_pin_and_profile_cannot_downgrade(self):
        p = copy.deepcopy(self.p)
        del p["runtime_provider_sha256"]
        with self.assertRaises(ReceiptError):
            self.policy(p)
        p = copy.deepcopy(self.p)
        p["runtime_provider_sha256"] = sha256(b"unapproved-provider")
        with self.assertRaises(ReceiptError):
            self.admit(self.policy(p))
        p = copy.deepcopy(self.p)
        p["runtime_profile"] = fixtures.RUNTIME_PROFILE
        with self.assertRaises(ReceiptError):
            self.policy(p)

    def test_cuda_options_cannot_drift_after_admission(self):
        from mfenx_gate.admission import CUDA_PROVIDER_OPTIONS
        admitted = self.admit()
        authority = PolicyAuthority(self.policy())
        with patch.dict(CUDA_PROVIDER_OPTIONS, {"use_tf32": "1"}):
            with self.assertRaises(ReceiptError):
                ServingSession(admitted, authority)

    def test_revocation_denies_further_gpu_calls(self):
        authority = PolicyAuthority(self.policy())
        with ServingSession(self.admit(), authority) as session:
            self.assertEqual(session.run({"x": np.array([3.0], np.float32)})[0].tolist(), [5.0])
            p = copy.deepcopy(self.p)
            p["epoch"] = 2
            p["revoked_receipts"] = [sha256(self.receipt)]
            authority.install(self.policy(p))
            with self.assertRaises(ReceiptError):
                session.run({"x": np.array([3.0], np.float32)})
            self.assertEqual(session.state, "TERMINATED")

    def test_cpu_only_operator_cannot_activate_through_fallback(self):
        graph = helper.make_graph(
            [helper.make_node("StringNormalizer", ["x"], ["y"], case_change_action="LOWER")],
            "cpu-only-operator", [helper.make_tensor_value_info("x", TensorProto.STRING, [1])],
            [helper.make_tensor_value_info("y", TensorProto.STRING, [1])])
        model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
        model.ir_version = 8
        self.payload = model.SerializeToString()
        self.model.write_bytes(self.payload)
        self.statement["artifact"].update(sha256=sha256(self.payload), bytes=len(self.payload))
        self.receipt = _sign(self.statement, self.private, "Ephemeral test authority")
        self.p["approved_releases"] = [{"receipt_sha256": sha256(self.receipt), "sequence": 1}]
        admitted = self.admit()
        with self.assertRaises(Exception) as error:
            ServingSession(admitted, PolicyAuthority(self.policy()))
        self.assertRegex(str(error.exception), r"(?i)fallback|CPU|provider|kernel")

    def test_expiry_and_audit_failures_deny_gpu_activation(self):
        fixtures.AdmissionTests.test_expired_lease_does_not_execute(self)
        fixtures.AdmissionTests.test_audit_failure_denies_activation(self)

    def test_cpu_optimized_release_cannot_select_an_unqualified_operator(self):
        root = Path(os.environ["MFENX_PUBLIC_GPU_FIXTURES"])
        receipt = (root / "release-receipt.json").read_bytes()
        public = (root / "issuer-public.der").read_bytes()
        self.assertEqual(sha256(public), "sha256:b9fb4ba94e9319a347ace3f4a8fca03b06edf0bb935a1a092781c6e35384d197")
        p = copy.deepcopy(self.p)
        p.update(issuer_sha256=sha256(public), contract_sha256=json.loads(receipt)["statement"]["contract_sha256"],
                 approved_releases=[{"receipt_sha256": sha256(receipt), "sequence": 1}])
        with self.assertRaisesRegex(ReceiptError, "custom ONNX operator"):
            admit_model(receipt=receipt, trusted_public_key=public, model=root / "candidate.onnx", policy=self.policy(p))

    def test_trained_model_gpu_evaluation_receipt_and_retained_replay(self):
        import onnxruntime as ort
        from mfenx_gate.admission import CUDA_PROVIDER_OPTIONS
        root = Path(os.environ["MFENX_PUBLIC_GPU_FIXTURES"])
        contract_raw = (root / "approved-contract.json").read_bytes()
        contract = json.loads(contract_raw)
        reference_key = (root / "issuer-public.der").read_bytes()
        self.assertEqual(sha256(reference_key), "sha256:b9fb4ba94e9319a347ace3f4a8fca03b06edf0bb935a1a092781c6e35384d197")
        authenticated = verify_receipt((root / "release-receipt.json").read_bytes(), reference_key,
                                       expected_contract_digest=sha256(contract_raw))
        source = (root / "source.onnx").read_bytes()
        dataset = (root / "dataset.npz").read_bytes()
        self.assertEqual(sha256(source), contract["source"]["sha256"])
        self.assertEqual(sha256(source), authenticated["receipt"]["statement"]["parent_sha256"])
        self.assertEqual(sha256(dataset), contract["dataset"]["sha256"])
        import io
        with np.load(io.BytesIO(dataset), allow_pickle=False) as loaded:
            inputs, labels = loaded["inputs"], loaded["labels"]
        self.assertEqual(len(inputs), 1797)
        options = ort.SessionOptions()
        options.intra_op_num_threads = options.inter_op_num_threads = 1
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        reference = ort.InferenceSession(source, sess_options=options, providers=["CPUExecutionProvider"])
        observed_runtime = runtime_identity(CUDA_RUNTIME_PROFILE)
        gpu_contract = {"schema": "mfenx/cuda-qualification-contract/v1", "purpose": "test authority only",
                        "model_sha256": sha256(source), "dataset_sha256": sha256(dataset),
                        "runtime_profile": CUDA_RUNTIME_PROFILE, "runtime": observed_runtime,
                        "samples": 1797, "batch_size": 1, "required_changed_decisions": 0,
                        "maximum_absolute_logit_difference": "0.0001"}
        # Issuance evaluates the candidate before creating its release evidence;
        # this is a test evaluator, not the production serving entry.
        eval_options = ort.SessionOptions()
        eval_options.intra_op_num_threads = eval_options.inter_op_num_threads = 1
        eval_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        eval_options.add_session_config_entry("session.disable_cpu_ep_fallback", "1")
        ort.preload_dlls(cuda=True, cudnn=True, msvc=False)
        evaluator = ort.InferenceSession(source, sess_options=eval_options,
                                         providers=[("CUDAExecutionProvider", dict(CUDA_PROVIDER_OPTIONS))])
        evaluator.disable_fallback()
        source_decisions, cuda_decisions = [], []
        durations = []
        max_difference = 0.0
        for row in inputs:
            sample = row.reshape(1, -1)
            expected = reference.run(None, {"input": sample})[0]
            binding = evaluator.io_binding()
            binding.bind_cpu_input("input", sample)
            for output in evaluator.get_outputs():
                binding.bind_output(output.name, "cuda", 0)
            started = time.perf_counter_ns()
            evaluator.run_with_iobinding(binding)
            binding.synchronize_outputs()
            self.assertTrue(all(value.device_name().lower() == "cuda" for value in binding.get_outputs()))
            actual = binding.copy_outputs_to_cpu()[0]
            durations.append(time.perf_counter_ns() - started)
            source_decisions.append(int(np.argmax(expected)))
            cuda_decisions.append(int(np.argmax(actual)))
            max_difference = max(max_difference, float(np.max(np.abs(expected - actual))))
        self.assertEqual(source_decisions, cuda_decisions)
        self.assertLessEqual(max_difference, 0.0001)
        p95 = sorted(durations)[(95 * len(durations) + 99) // 100 - 1]
        report = {"schema": "mfenx/cuda-finite-observation/v1", "samples": 1797,
                  "model_sha256": sha256(source), "dataset_sha256": sha256(dataset),
                  "source_sha256": sha256(source), "runtime": observed_runtime, "output_device": "cuda",
                  "source_correct": int(np.sum(np.asarray(source_decisions) == labels)),
                  "cuda_correct": int(np.sum(np.asarray(cuda_decisions) == labels)),
                  "changed_decisions": 0, "max_absolute_logit_difference": repr(max_difference),
                  "candidate_p95_latency_ns": p95,
                  "interpretation": "new finite GPU test contract; no production authority or original CPU contract reclassification"}
        raw_report = json.dumps(report, sort_keys=True, separators=(",", ":")).encode()
        statement = copy.deepcopy(self.statement)
        statement.update(id="cuda-optdigits-qualification", artifact={"format": "onnx", "sha256": sha256(source), "bytes": len(source)},
                         parent_sha256=sha256(source), contract_sha256=sha256(canonical(gpu_contract)),
                         evaluation={"decision": "PASS", "report_sha256": sha256(raw_report), "samples": 1797,
                                     "source_correct": report["source_correct"], "candidate_correct": report["cuda_correct"],
                                     "decision_changes": 0, "candidate_p95_latency_ns": p95})
        receipt = _sign(statement, self.private, "Ephemeral GPU qualification authority")
        p = copy.deepcopy(self.p)
        p.update(contract_sha256=statement["contract_sha256"], approved_releases=[{"receipt_sha256": sha256(receipt), "sequence": 1}])
        policy = self.policy(p)
        model = self.root / "gpu-release.onnx"
        model.write_bytes(source)
        admitted = admit_model(receipt=receipt, trusted_public_key=self.public, model=model, policy=policy)
        model.unlink()
        model.write_bytes(b"X" * len(source))
        replay = []
        with ServingSession(admitted, PolicyAuthority(policy)) as session:
            for row in inputs:
                sample = row.reshape(1, -1)
                actual = session.run({"input": sample})[0]
                self.assertEqual(session.last_output_devices, ("cuda",))
                replay.append(int(np.argmax(actual)))
        self.assertEqual(replay, cuda_decisions)
        (root / "cuda-finite-observation.json").write_bytes(raw_report)
        (root / "cuda-release-receipt.json").write_bytes(receipt)
        (root / "cuda-release-public.der").write_bytes(self.public)
        (root / "cuda-approved-contract.json").write_bytes(canonical(gpu_contract))


if __name__ == "__main__":
    unittest.main()
