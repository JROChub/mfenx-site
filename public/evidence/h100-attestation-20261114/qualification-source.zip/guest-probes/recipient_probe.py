"""Real hardware recipient and resource checks using a disposable canary only."""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

root = Path('/home/ubuntu/mfenx-qualification')
base = [str(root / 'native-client-v3/kbs-client'), '--url', 'https://localhost:19443',
        '--cert-file', str(root / 'broker-ca.pem')]
records = {}
with tempfile.TemporaryDirectory(prefix='mfenx-recipient-', dir='/dev/shm') as temporary:
    directory = Path(temporary)
    for name in ['a', 'b']:
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        path = directory / (name + '.pem')
        path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
        path.chmod(0o600)
    def call(arguments):
        return subprocess.run(base + list(map(str, arguments)), capture_output=True, timeout=60,
            env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'RUST_LOG': 'warn'})
    attested = call(['attest', '--tee-key-file', directory / 'a.pem'])
    assert attested.returncode == 0, attested.stderr.decode(errors='replace')[-2000:]
    token = directory / 'token.jwt'
    token.write_bytes(attested.stdout.strip())
    token.chmod(0o600)
    # The signed EAR is public attestation evidence, not a model key.
    (root / 'hardware-canary-appraisal.jwt').write_bytes(attested.stdout.strip())
    claims = json.loads(base64.urlsafe_b64decode(attested.stdout.strip().split(b'.')[1] + b'==='))
    records['attestation'] = {'native_returncode': 0, 'cpu_gpu_submodules': sorted(claims['submods'])}
    common = ['get-resource', '--path', 'qualification/model/canary', '--attestation-token', token]
    good = call(common + ['--tee-key-file', directory / 'a.pem'])
    assert good.returncode == 0
    raw = base64.b64decode(good.stdout.strip(), validate=True)
    assert len(raw) == 32
    records['approved_recipient'] = {'returncode': 0, 'bytes': 32, 'canary_sha256': hashlib.sha256(raw).hexdigest()}
    wrong = call(common + ['--tee-key-file', directory / 'b.pem'])
    assert wrong.returncode != 0 and wrong.stdout == b''
    records['wrong_recipient'] = {'returncode': wrong.returncode, 'plaintext_bytes': len(wrong.stdout)}
    wrong_resource = call(['get-resource', '--path', 'qualification/model/not-authorized',
        '--attestation-token', token, '--tee-key-file', directory / 'a.pem'])
    assert wrong_resource.returncode != 0 and wrong_resource.stdout == b''
    records['wrong_resource'] = {'returncode': wrong_resource.returncode, 'plaintext_bytes': len(wrong_resource.stdout)}
    remaining = int(claims['exp']) - time.time() + 2
    assert 0 < remaining < 65, 'unexpected qualification-token lifetime'
    time.sleep(remaining)
    expired = call(common + ['--tee-key-file', directory / 'a.pem'])
    assert expired.returncode != 0 and expired.stdout == b''
    records['expired_token'] = {'returncode': expired.returncode, 'plaintext_bytes': len(expired.stdout),
                                'observed_at': int(time.time()), 'token_expires': claims['exp']}
print(json.dumps({'schema': 'mfenx/hardware-recipient-observation/v1', 'cases': records,
                  'model_key_used': False, 'model_admission_qualified': False}, indent=2))
