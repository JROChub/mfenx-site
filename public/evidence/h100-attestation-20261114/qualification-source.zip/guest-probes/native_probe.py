"""Probe the disposable canary without writing its plaintext response to disk."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path('/home/ubuntu/mfenx-qualification')
command = [str(root / 'native-client-v3/kbs-client'), '--url', 'https://localhost:19443',
           '--cert-file', str(root / 'broker-ca.pem'), 'get-resource',
           '--path', 'qualification/model/canary']
if len(sys.argv) > 1:
    command += ['--init-data', Path(sys.argv[1]).read_text()]
started = time.monotonic()
try:
    process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             timeout=90, env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'RUST_LOG': 'warn'})
    report = {'returncode': process.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3),
              'stderr': process.stderr[-6000:].decode(errors='replace')}
    if process.returncode == 0:
        raw = process.stdout
        if len(raw) == 45 and raw[-1:] == b'\n':
            key = base64.b64decode(raw[:-1], validate=True)
            report['key_bytes'] = len(key)
            report['canary_sha256'] = hashlib.sha256(key).hexdigest()
        else:
            report['response_format_valid'] = False
            report['response_bytes'] = len(raw)
    else:
        report['response_bytes'] = len(process.stdout)
except subprocess.TimeoutExpired:
    report = {'timeout': True, 'elapsed_seconds': round(time.monotonic() - started, 3)}
print(json.dumps(report, indent=2))
