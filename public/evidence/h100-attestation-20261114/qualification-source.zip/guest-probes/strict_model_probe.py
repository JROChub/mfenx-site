"""Observe the installed Gate/native Trustee admission boundary in the TDX VM."""
import json
from pathlib import Path
import time
from unittest.mock import patch
import onnx
from mfenx_gate.encrypted import EncryptedPolicy, admit_encrypted_model
from mfenx_gate.receipt import ReceiptError

root = Path('/home/ubuntu/mfenx-qualification')
inputs = root / 'model-probe'
approved = (inputs / 'approved-policy-sha256.txt').read_text()
policy = EncryptedPolicy.from_bytes((inputs / 'policy.json').read_bytes(), expected_sha256=approved)
started = time.monotonic()
with patch('onnx.load_model_from_string', wraps=onnx.load_model_from_string) as parser:
    try:
        admit_encrypted_model(descriptor=(inputs / 'descriptor.json').read_bytes(),
            ciphertext=inputs / 'model.enc', receipt=(inputs / 'receipt.json').read_bytes(),
            trusted_public_key=(inputs / 'issuer.der').read_bytes(), policy=policy,
            trustee_client=root / 'native-client-v3/kbs-client', broker_ca=root / 'broker-ca.pem')
    except ReceiptError as error:
        report = {'schema': 'mfenx/strict-hardware-model-probe/v1', 'admission_denied': True,
                  'error': str(error), 'onnx_parser_calls': parser.call_count,
                  'elapsed_seconds': round(time.monotonic() - started, 3),
                  'policy_sha256': approved, 'full_confidential_profile_qualified': False}
        assert parser.call_count == 0
        assert 'key delivery' in str(error)
    else:
        raise AssertionError('Unexpected admission despite unbound launch configuration')
print(json.dumps(report, indent=2))
