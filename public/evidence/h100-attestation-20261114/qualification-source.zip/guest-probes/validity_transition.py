"""Observe real canary delivery before and after strict broker JWT validity."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import time
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

root = Path('/home/ubuntu/mfenx-qualification')
base = [str(root / 'native-client-v3/kbs-client'), '--url', 'https://localhost:19443',
        '--cert-file', str(root / 'broker-ca.pem')]
records = {}
with tempfile.TemporaryDirectory(prefix='mfenx-validity-', dir='/dev/shm') as temporary:
    directory = Path(temporary)
    private = directory / 'recipient.pem'
    private.write_bytes(rsa.generate_private_key(public_exponent=65537, key_size=2048).private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    private.chmod(0o600)
    def call(args):
        return subprocess.run(base + list(map(str, args)), capture_output=True, timeout=45,
            env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'RUST_LOG': 'warn'})
    attested = call(['attest', '--tee-key-file', private])
    assert attested.returncode == 0
    token = directory / 'token.jwt'
    token.write_bytes(attested.stdout.strip())
    token.chmod(0o600)
    (root / 'hardware-validity-appraisal.jwt').write_bytes(attested.stdout.strip())
    claims = json.loads(base64.urlsafe_b64decode(attested.stdout.strip().split(b'.')[1] + b'==='))
    common = ['get-resource', '--path', 'qualification/model/canary', '--tee-key-file', private]
    good = call(common + ['--attestation-token', token])
    assert good.returncode == 0 and len(base64.b64decode(good.stdout.strip(), validate=True)) == 32
    records['unexpired_control'] = {'returncode': 0, 'canary_sha256': hashlib.sha256(base64.b64decode(good.stdout.strip())).hexdigest()}
    remaining = int(claims['exp']) - time.time() + 2
    assert 0 < remaining < 65
    time.sleep(remaining)
    expired = call(common + ['--attestation-token', token])
    records['before_patch'] = {'returncode': expired.returncode, 'plaintext_bytes': 32 if expired.returncode == 0 else 0,
        'observed_at': int(time.time()), 'token_expires': claims['exp']}
    (root / 'validity-before-patch.json').write_text(json.dumps(records, indent=2))
    assert expired.returncode == 0, 'unpatched clock-skew behavior did not reproduce'
    deadline = time.monotonic() + 45
    while not (root / 'strict-broker-ready').exists():
        if time.monotonic() >= deadline:
            raise AssertionError('strict-broker transition deadline exceeded')
        time.sleep(0.25)
    denied = call(common + ['--attestation-token', token])
    records['after_patch'] = {'returncode': denied.returncode, 'plaintext_bytes': len(denied.stdout),
        'observed_at': int(time.time()), 'token_expires': claims['exp']}
    assert denied.returncode != 0 and denied.stdout == b''
    future = call(common + ['--attestation-token', root / 'future-nbf.jwt'])
    records['future_nbf'] = {'returncode': future.returncode, 'plaintext_bytes': len(future.stdout),
        'fixture': 'same observed hardware recipient claims, re-signed by qualification authority with a future nbf'}
    assert future.returncode != 0 and future.stdout == b''
print(json.dumps({'schema': 'mfenx/broker-validity-transition/v1', 'cases': records,
                  'model_key_used': False}, indent=2))
