# Optdigits demonstration data

E. Alpaydin and C. Kaynak (1998), *Optical Recognition of Handwritten Digits*,
UCI Machine Learning Repository. DOI: https://doi.org/10.24432/C50P49.

Source: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits

The dataset is supplied under Creative Commons Attribution 4.0 International:
https://creativecommons.org/licenses/by/4.0/.

The official 1,797-row test partition was transformed into the canonical stored
NPZ representation used by CKODMK: Float32 input arrays and integer labels.
The transformed file digest is recorded in the run manifest and evaluation
contract. This attribution does not imply endorsement of MFENX by the authors
or UCI. Local measured outcomes concern this finite partition only.

The included source/candidate ONNX fixtures originate from CKODMK's retained
Optdigits demonstration; CKODMK's existing Apache-2.0 license and notices are
preserved in its unmodified distribution wheel. Gate's commercial license does
not override those existing component licenses or the dataset's CC BY 4.0 grant.
