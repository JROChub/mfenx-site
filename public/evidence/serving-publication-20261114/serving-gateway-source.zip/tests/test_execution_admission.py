"""Actual protocol verification and serving with a retained model-specific proof."""
import copy
from contextlib import chdir
import json
import os
from pathlib import Path
import sqlite3
import unittest
from unittest.mock import patch

import numpy as np
import onnx

import test_admission as fixtures
from mfenx_gate.admission import (PolicyAuthority, ServingSession, admit_model,
                                   CUDA_RUNTIME_PROFILE, runtime_identity)
from mfenx_gate.execution import ExecutionRequirement, verify_execution_proof
from mfenx_gate.receipt import ReceiptError, sha256


@unittest.skipUnless(os.environ.get('MFENX_MODEL_PROOF_QUALIFICATION') == '1',
                     'requires a real patched SFCS verifier and generated model receipt')
class ExecutionAdmissionTests(unittest.TestCase):
    policy = fixtures.AdmissionTests.policy

    def setUp(self):
        fixtures.AdmissionTests.setUp(self)
        self.proof_root = Path(os.environ['MFENX_MODEL_PROOF_FIXTURES'])
        self.fixture_root = Path(os.environ['MFENX_PUBLIC_GPU_FIXTURES'])
        self.proof = (self.proof_root / 'execution.pha').read_bytes()
        self.verifier = Path(os.environ['MFENX_PROOF_VERIFIER'])
        self.payload = (self.fixture_root / 'source.onnx').read_bytes()
        self.model.write_bytes(self.payload)
        self.receipt = (self.fixture_root / 'cuda-release-receipt.json').read_bytes()
        self.public = (self.fixture_root / 'cuda-release-public.der').read_bytes()
        receipt = json.loads(self.receipt)
        statement = json.loads(self.proof)['embedded_proof']['public_inputs']
        observed = runtime_identity(CUDA_RUNTIME_PROFILE)
        self.requirement = {'schema': 'mfenx/fixed-mlp-execution/v1',
                            'image_id': statement['image_id'], 'program_digest': statement['program_digest'],
                            'dataset_sha256': 'sha256:b281019a68b5f20f7900774fffa870f51e3a7df263407d1b73a030358710874d',
                            'sample_index': 0,
                            'journal_sha256': 'sha256:336dcb71874b27c00e9f2963020ccfdf7a9143dd4f25b31400e433f82b52bbb8',
                            'verifier_sha256': os.environ['MFENX_PROOF_VERIFIER_SHA256']}
        # The image/program pins below are established from the independently
        # retained guest build, not accepted from the proof under test.
        self.assertEqual(self.requirement['image_id'], 'risc0:392f246b67cb70cc19d07e4337b48efbf5e04cf026270c5c0e051f21f7900020')
        self.assertEqual(self.requirement['program_digest'], 'sha256:b1ed482aa92462b48d46324eaa5017bfe6dcb9f9165faebdf65d78ad9dc62120')
        self.p.update(schema='mfenx/admission-policy/v2', execution_proof=self.requirement,
                      runtime_profile=CUDA_RUNTIME_PROFILE, runtime_version=observed['version'],
                      runtime_sha256=observed['native_sha256'], runtime_provider_sha256=observed['provider_sha256'],
                      runtime_config_sha256=observed['config_sha256'], issuer_sha256=sha256(self.public),
                      contract_sha256=receipt['statement']['contract_sha256'],
                      approved_releases=[{'receipt_sha256':sha256(self.receipt), 'sequence':1}])

    def admit(self, policy=None, proof=None):
        return admit_model(receipt=self.receipt, trusted_public_key=self.public, model=self.model,
                           policy=policy or self.policy(), execution_proof=self.proof if proof is None else proof,
                           proof_verifier=self.verifier)

    def test_verified_statement_is_required_before_actual_gpu_activation(self):
        marker = self.root / 'unexpected-child-import'
        (self.root / 'resource.py').write_text(
            'open(' + repr(str(marker)) + ',"w").write("unsafe import")\n'
            'raise RuntimeError("candidate working directory imported by launcher")\n')
        with chdir(self.root):
            admitted = self.admit()
        self.assertFalse(marker.exists(), "proof launcher imported candidate-controlled code")
        self.assertEqual(admitted.execution_proof_sha256, sha256(self.proof))
        self.model.write_bytes(b'X' * len(self.payload))
        database = self.root / 'authority.sqlite'
        with ServingSession(admitted, PolicyAuthority(self.policy(), state_path=database)) as session:
            with np.load(self.fixture_root / 'dataset.npz', allow_pickle=False) as data:
                output = session.run({'input': data['inputs'][0:1]})[0]
            self.assertEqual(int(np.argmax(output)), 0)
            self.assertEqual(session.last_output_devices, ('cuda',))
        with sqlite3.connect(database) as db:
            self.assertEqual(db.execute('SELECT proof FROM admission_execution_evidence').fetchall(),
                             [(sha256(self.proof),)])

    def test_missing_proof_and_old_policy_downgrade_deny_before_parser(self):
        with patch.object(onnx, 'load_model_from_string') as parser:
            with self.assertRaises(ReceiptError):
                admit_model(receipt=self.receipt, trusted_public_key=self.public,
                            model=self.model, policy=self.policy())
            parser.assert_not_called()
        p = copy.deepcopy(self.p)
        p['schema'] = 'mfenx/admission-policy/v1'
        with self.assertRaises(ReceiptError):
            self.policy(p)
        del p['execution_proof']
        with self.assertRaises(ReceiptError):
            self.admit(self.policy(p))

    def test_valid_proof_for_wrong_program_or_dataset_is_denied(self):
        for name, value in [('image_id', 'risc0:'+'0'*64), ('program_digest', sha256(b'other-program')),
                            ('dataset_sha256', sha256(b'other-data')), ('sample_index', 1),
                            ('journal_sha256', sha256(b'other-result'))]:
            with self.subTest(name=name):
                p = copy.deepcopy(self.p)
                p['execution_proof'][name] = value
                with self.assertRaises(ReceiptError):
                    self.admit(self.policy(p))

    def test_valid_proof_cannot_authorize_an_unrelated_model(self):
        requirement = ExecutionRequirement.from_dict(self.requirement)
        with self.assertRaises(ReceiptError):
            verify_execution_proof(self.proof, requirement, model_sha256=sha256(b'other-model'),
                                   verifier=self.verifier)

    def test_valid_core_with_removed_or_changed_external_receipt_is_denied(self):
        detached = json.loads(self.proof)
        detached['embedded_proof'].pop('external_proof_attachments')
        with self.assertRaises(ReceiptError):
            self.admit(proof=json.dumps(detached).encode())
        changed = json.loads(self.proof)
        changed['embedded_proof']['external_proof_attachments'][0]['payload']['proof']['receipt_base64'] = 'AA=='
        with self.assertRaises(ReceiptError):
            self.admit(proof=json.dumps(changed).encode())

    def test_unapproved_verifier_and_oversized_evidence_are_denied(self):
        p = copy.deepcopy(self.p)
        p['execution_proof']['verifier_sha256'] = sha256(b'other-verifier')
        with self.assertRaises(ReceiptError):
            self.admit(self.policy(p))
        with self.assertRaises(ReceiptError):
            self.admit(proof=b'X' * (8*1024**2+1))


if __name__ == '__main__':
    unittest.main()
