MFENX software admission candidate

Gate 1.1.0rc1 preserves Release Receipt v1, its P-256 signature transcript and
the existing verification and issuance commands. The organization service
candidate is 0.4.0rc1. These are source and local-test candidates; they do not
replace the published Gate 1.0.0 wheel or commissioned customer installations.

CPU execution boundary

`onnx-cpu-owned-bytes/v1` supports a self-contained ONNX model of at most 64 MiB,
standard ONNX operator domains, no local functions or training extensions, and
no external tensor files or custom operators. The admission implementation
authenticates the existing finite-evaluation receipt, independently pinned
issuer and contract, explicit receipt approval and current deployment policy.
It retains immutable Python bytes, verifies their exact digest and length,
validates the model format and passes those same bytes to ONNX Runtime.
Neither the format validator nor loader reopens the original candidate path.

The approved runtime identity includes the ONNX Runtime version, SHA-256 of its
native binding and the fixed runtime configuration. CPU execution has one
intra-operation thread, one inter-operation thread and graph optimization
disabled. The candidate CPU extra pins ONNX 1.23.2 and ONNX Runtime 1.32.0.
This is a new runtime profile, not a requalification of CKODMK's existing
0.5.1 evaluator against a newer ONNX runtime. That evaluator's version check
and existing contracts remain unchanged.

The kernel, Python process, installed verifier/runtime dependencies and protected
policy authority are trusted. Python private fields are an ownership convention,
not isolation against malicious Python executing in the same process. This
profile provides no confidentiality against the host administrator. It does not
support GPU uploads, PyTorch serving, arbitrary checkpoint loaders, remote
plugins or runtime-discovered dependencies. Those paths cannot silently enter
this profile.

Protected policy

`AdmissionPolicy.from_bytes(raw, expected_sha256=...)` requires a policy digest
obtained outside the candidate package. Its schema is
`mfenx/admission-policy/v1`. Required fields are:

| Field | Enforcement |
| --- | --- |
| `scope` | Explicit tenant and deployment environment |
| `epoch`, `minimum_sequence` | Positive policy epoch and rollback floor |
| `expires_at` | UTC expiry; admission requires at most five minutes remaining |
| `runtime_profile`, `runtime_version`, `runtime_sha256`, `runtime_config_sha256` | Exact supported runtime and configuration |
| `maximum_model_bytes` | Positive limit, no greater than 64 MiB |
| `maximum_lease_seconds` | Positive serving lease, no greater than 300 seconds |
| `approved_releases` | Exact receipt-byte SHA-256 and approved release sequence |
| `revoked_receipts`, `revoked_issuers` | Explicit deny lists |
| `contract_sha256`, `issuer_sha256` | Independent evaluation-policy and issuer pins |
| `required_assurance` | Exactly `issuer-attested-finite-evaluation` |
| optional `lineage` | Required root, selected leaf, replay fingerprint and allowed transformations |

Unknown fields, runtime profiles and assurance levels reject. Integrity-only
receipts cannot satisfy this profile. `local_replay_completed` remains false:
executing a serving request does not replay CKODMK's finite evaluation contract.
No hardware, post-quantum or model execution-proof profile is enabled by a
configuration string.

`PolicyAuthority` persists epochs and rollback floors when given an owner-only
SQLite state path. Another process advancing that state invalidates a stale
session. Observed wall time is retained; a rollback exceeding one second denies
authorization. Restoring an older copy of the authority database defeats that
software state boundary, so its protection and rollback-resistant recovery are
operator responsibilities. Without a state path, authority is process-local
and is intended for development integration only.

`ServingSession` loads only an admitted handle, checks current authority before
each inference and serializes inference with close. Policy changes, revocation,
expiry or authority failure terminate its callable session. Already-running
native inference may finish; revocation does not interrupt a kernel already
executing. A fresh policy is required after epoch change. Content rollback can
be authorized by approving a new receipt/sequence for the older contents;
lowering the stored minimum sequence is rejected.

Activation and inference audit events retain model, receipt, policy, scope and
session identities in the protected local database. Audit failure prevents
activation or release of the requested output. These records are transactional
software audit data, not hardware attestations, a transparency service or an
independent signature chain. Plaintext erasure is not promised by dropping a
Python or native-runtime reference.

Resource-limited command

```sh
mfenx-gate runtime-identity
mfenx-gate run-onnx \
  --receipt release-receipt.json \
  --trusted-public-key issuer-public.der \
  --model candidate.onnx \
  --policy deployment-policy.json \
  --expected-policy-sha256 "$APPROVED_DEPLOYMENT_POLICY_SHA256" \
  --state /protected/authority.sqlite3 \
  --inputs inference-inputs.json
```

The policy, its digest, trust key and state path belong to protected deployment
configuration, never an inference request from an untrusted client. Inputs are
a bounded object mapping model input names to Float32-compatible arrays. The
command runs one request in a child; it is not a public HTTP inference service.

Verification, model parsing, loading and execution occur in the same child.
Defaults are a 2 GiB address-space limit, 30 seconds of process CPU, a 45-second
wall deadline, no core dumps, bounded output/file size and 64 descriptors. The
parent kills and reaps the process group on timeout or cancellation. At most two
children may run through one supervisor process. Input JSON is limited to 1 MiB;
returned tensor storage is limited to 256 KiB and encoded output to 1 MiB.
The child receives no inherited cloud credentials. Peak RSS and elapsed time are
observations in the result. Address space is not resident memory; a cgroup is
still required for aggregate service memory and fleet-wide concurrency limits.
This supervisor is not a native-code security sandbox or network namespace.

Bundle retention

`retain_bundle` reuses CKODMK's existing signed external-artifact envelope. A new
competing signature format is unnecessary. The independent envelope digest and
issuer key, exact inventory, byte counts and subject hashes are checked. Reads
walk directory descriptors without following symlinks, and resource limits bound
files, directory entries and total declared bytes. Each retained Linux memfd is
sealed with WRITE, GROW, SHRINK and SEAL restrictions before it is hashed.
The original pathname is not used after acquisition. Undeclared subjects cannot
be obtained through the retained object's descriptor interface.

The existing envelope verifier reads bounded private snapshots rather than
producer-controlled growing files. There is a temporary disk copy in addition
to retained memfds; this is not a zero-copy claim. Limits are 256 files,
1,024 tree entries and 512 MiB total. Callers must close returned duplicate
descriptors and the bundle. Linux file seals do not establish host confidentiality.

With `checkpoint_format="safetensors"`, the existing CKODMK inspector additionally
checks tensor and shard-index consistency against the retained snapshots.
Other serving formats are not enabled. The result remains `NOT_EVALUATED` for
behavior and does not authorize a sharded model to execute. Existing single-file
Safetensors Receipt v1 commands retain their original meaning.

Release lineage

`create_release_lineage` verifies the existing receipt and exact model bytes,
then constructs an application profile using the existing Power House Python
SDK. `mfenx/model-release-lineage/v1` binds model digest/length, exact receipt,
issuer, contract, evaluation-report commitment, parent model and transformation
declaration. It does not change PHA, Rootprint or capsule fingerprints.

The release graph is finalized before deployment policy pins its root, selected
leaf and replay fingerprint; it excludes that later policy identity, avoiding a
circular commitment. `verify_release_lineage` verifies graph integrity and each
receipt's signature, compares those independent pins, checks parent-model
continuity and rejects unapproved transformations or merges. Historical receipt
authentication uses signed issue time; deployment separately checks the current
leaf's present validity. Transformation execution remains `NOT_PROVED`.
The graph records authenticated relationships, not arbitrary success strings.

The Power House SDK is an optional separately licensed integration. Its
`power-house-sdk==0.4.1` distribution must be installed when lineage is required;
missing support fails admission. The raw model hash, receipt identity, PHA
fingerprint, Rootprint branch and replay fingerprint remain distinct.

CUDA execution boundary

`onnx-cuda12-owned-bytes/v1` is an additive Linux SDK profile. Install
`mfenx-gate[admission-cuda12]` in a separate environment; its ONNX Runtime GPU
1.26.0 and ONNX 1.23.2 pins match the tested CUDA 12.8/cuDNN 9 environment.
Do not install the CPU and GPU runtime distributions into the same environment.
The profile retains the same 64 MiB, self-contained model and standard-operator
restrictions. Python same-process code, the host kernel, driver and installed
dependencies remain trusted.

The protected policy additionally requires `runtime_provider_sha256`, the
SHA-256 of the Linux CUDA provider library. Native binding, provider library and
configuration identities are checked during admission and again before loading.
The admitted configuration identity is retained so changing provider options
between those stages cannot silently select another execution configuration.
Observe package identities with:

```sh
mfenx-gate runtime-identity --runtime-profile onnx-cuda12-owned-bytes/v1
```

`ServingSession` selects CUDA device zero, disables graph optimization and TF32,
and forbids native CPU graph placement and Python run-time fallback. ONNX Runtime
may still list a registered CPU provider; that list does not establish where a
node executed. A real CPU-only operator is the negative control for placement
enforcement. Outputs are bound to CUDA memory, checked for device residence,
then copied to the caller. No original checkpoint path is reopened for upload.

The provider arena limit is 2 GiB; this is not a total device-memory quota or an
operating-system memory limit. GPU process supervision, aggregate RAM/VRAM and
concurrency controls belong to the deployment. The bundled address-space-limited
`run-onnx` supervisor rejects CUDA policy before activation; it must not report
that GPU execution ran under its CPU qualification. The direct SDK profile is
not an independently commissioned multi-tenant inference endpoint.

Real Runpod RTX 4090 tests exercised delayed upload after pathname replacement,
changed bytes, issuer/policy/provider pins, revoked and expired authority, audit
failure and native CPU-fallback rejection. MFENX's published CPU-optimized model
uses a nonstandard operator and is rejected by this profile. Its standard ONNX
source model was separately evaluated on all 1,797 published samples under an
explicit GPU test contract. A fresh ephemeral test authority signed that result;
admission then replayed the same samples on CUDA after the candidate pathname
was replaced. Test authorities do not authorize production releases. The
original signed CPU contract is preserved and is not relabeled as GPU evidence.

Reproduce on the selected GPU runtime with the exact public fixture inventory:

```sh
MFENX_CUDA_QUALIFICATION=1 \
MFENX_PUBLIC_GPU_FIXTURES=/protected/test-fixtures \
PYTHONPATH=tests python -m unittest -v test_cuda_admission
```

Without explicit GPU selection these tests skip; a skip is not qualification.
Container image, driver, package/library identities, raw test receipt and report
must accompany each observed result. This software profile establishes no
hardware attestation, confidential execution or hardware-bound key release.

Qualification boundary

Tests execute a real CPU ONNX model and inspect its outputs. They cover source
path replacement, mutations, policy mismatch, revoked/expired authority, durable
rollback floors, clock rollback, audit failure, concurrent children and termination
of a long native loop. Bundle tests observe kernel denial of writes/truncation
and reject a signed inconsistent shard index. Browser tests interrupt real
signature verification and ONNX replay, then change issuer/model/contract inputs.

Production qualification still requires the customer's actual protected
promotion target, serving integration, runner and host hardening, operational
recovery and workload-specific numerical/performance acceptance. The existing
organization service distributes policy and registers receipts; neither action
alone activates serving. Confidential execution requires a separately qualified
attestation verifier, recipient binding and key broker. Model execution proofs
require an approved model-consuming guest and real protocol-specific proof
verification; the existing private-sum conformance guest does not prove ONNX
inference or general model safety.

Versioned model-execution requirement

Linux policy `mfenx/admission-policy/v2` requires an `execution_proof` object
in addition to the existing protected release/runtime fields. Policy v1 and
Receipt v1 retain their meanings. A v1 policy rejects the new field, and a
v2 policy rejects missing or null requirements. A supplied proof cannot be
silently accepted under a policy that does not require its defined relation.

The object has schema `mfenx/fixed-mlp-execution/v1` and requires independently
approved `image_id`, `program_digest`, `dataset_sha256`, `sample_index`,
`journal_sha256` and `verifier_sha256`. The journal pin is SHA-256 of its raw
116 bytes; it is distinct from SFCS's domain-separated journal digest. The
model identity within that journal must equal the authenticated receipt's
artifact identity. The fixed-asset guest and independent reference are in
`proofs/fixed-mlp/`. They define one indexed, ordered, nonfused FP32 evaluation;
they do not prove ONNX/CUDA runtime execution or model safety.

Pass bounded proof bytes as `execution_proof` and the operator-provisioned
patched Power House executable path as `proof_verifier` to `admit_model`.
Admission acquires the verifier into a sealed Linux memory object, verifies
its independently approved SHA-256 and executes that retained object. The
native protocol verifier checks a private proof snapshot before the adapter
compares its authenticated public statement with deployment policy. Invalid
or unrelated evidence rejects before model parsing and serving activation.
The resulting model handle and durable session audit retain the proof identity.

Each proof-verification child has a 2 GiB address-space limit, 30 s CPU limit,
45 s wall deadline, 1 MiB output-file limit and no core dumps. At most two
children run per adapter process; proof acquisition is limited to 8 MiB and
verifier acquisition to 512 MiB. These are process-local resource controls,
not fleet quotas or confidentiality. The kernel, process, Python launcher and
dynamic libraries remain trusted. The provisioned verifier must contain the
RISC Zero 3.1.0 security migration; an old receipt cannot be grandfathered in.

The existing isolated CPU worker does not accept proof inputs and therefore
cannot commission this v2 profile. The qualified path is the typed admission
and serving API exercised with the installed wheel and actual CUDA runtime.
The authenticated single-deployment gateway below exercises endpoint transport,
independent process deadlines and durable restart decisions. Aggregate fleet
supervision remains a deployment commissioning requirement.

Child interpreter startup uses trusted import paths. The CPU worker disables
working-directory module insertion while retaining the explicit SDK path;
the native-verifier launcher uses isolated Python startup and a private working
directory. Tests place malicious package and resource-module shadows in the
caller directory and require actual inference/proof verification without
executing them.

Authenticated single-deployment gateway

`examples/serving_gateway.py` is a Linux HTTP adapter over the existing typed
admission and serving API. It binds its listener only after receipt, retained
artifact, policy, required proof and runtime initialization succeed. Requests
supply Float32 input tensors; they cannot select a model, policy, authority or
loader. The access token is provisioned in an owner-only file containing at
least 32 bytes. Keep the default loopback listener behind an operator-managed
authenticated TLS boundary; the qualification run used Runpod's HTTPS proxy.

```sh
python -I examples/serving_gateway.py \
  --receipt /protected/release.json --trusted-public-key /protected/issuer.der \
  --model /protected/model.onnx --policy /protected/policy.json \
  --expected-policy-sha256 "$APPROVED_POLICY_SHA256" \
  --state /protected/authority.sqlite --access-token-file /protected/access-token \
  --execution-proof /protected/execution.pha --proof-verifier /protected/julian
```

POST `/v1/infer` accepts `{"inputs":{"input":[[0.0]]}}` only when the named
input and shape match the admitted model; this illustrative shape is not a
valid input for every model. Send the provisioned bearer token in the
Authorization header. Input acquisition is limited to 64 KiB, JSON depth to
128 and returned tensors to 256 KiB. Duplicate keys and nonfinite inputs
reject. The server serializes requests, bounds its listen backlog to four
and uses a three-second connection timeout. It is not a multi-tenant scheduler.

Admission and native inference run under a separate Linux pidfd watchdog
process. Its monotonic deadline signals the specific parent process through
a retained pidfd; PID reuse cannot redirect termination. The watchdog does
not depend on the interpreter lock. Startup fails closed when the required
process-handle mechanism is unavailable. Tests observe SIGKILL during both
a real long-running ONNX loop and a native call deliberately holding the
Python interpreter lock. Core dumps are disabled. Process termination is not
a claim about hardware zeroization or immediate cancellation of every device
operation. The native proof verifier retains its own resource limits.

The Runpod H100 endpoint test verified the required model proof before
loading, used actual CUDA output bindings after pathname replacement, denied
invalid credentials and inputs, and denied withdrawn policy before another
native call. Restoring the trusted authorization database on a replacement
node retained the epoch and release floor. The operator must protect that
database against unauthorized restoration and supply current policy before
reactivation. See [qualification.md](qualification.md) for observed boundaries.
