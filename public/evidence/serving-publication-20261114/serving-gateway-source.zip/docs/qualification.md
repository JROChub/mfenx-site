Enterprise admission qualification record

Candidate: Gate 1.1.0rc1, organization service 0.4.0rc1.
Observation date: 2026-11-14. Scope: Linux CPU/CUDA tests and Chromium browser
tests, protected immutable GitHub publication, an authenticated staging GPU endpoint and a model-consuming SFCS guest. A passing local test is not customer production qualification. Test owners
below identify the responsible component; operational ownership must be assigned
by the deployment operator before commissioning.

| ID | Owner / fixture / observation | Status and limit |
| --- | --- | --- |
| U01 | Gate receipt interoperability tests; CKODMK PCM browser replay; Power House conformance suites | Existing interfaces tested; deployed customer packages still require commissioning |
| U02 | Gate receipt and admission tests; ephemeral P-256 keys and modified statements | Local rejection observed |
| U03 | Admission tests; wrong contract and integrity-only profile | Local rejection observed |
| U04 | Admission tests; single-byte mutation | Local rejection observed before parsing |
| U05 | Admission tests; equal-length replacement | Local rejection observed before parsing |
| U06 | Admission tests; actual file mutation between metadata acquisition and read | Controlled rejection observed |
| U07 | Admission tests; pathname removed and replaced after admission | Actual inference returns the retained model's expected output |
| U08 | Admission tests; delayed CPU/CUDA loading and repeated inference | Retained bytes survive pathname replacement, GPU upload and session close; sharded lazy loading pending |
| U09 | Power House bounded-reader and capsule tests; sparse oversized file | Bounded acquisition rejects; a signed 3 GiB CUDA allocation rejects under the 2 GiB provider arena; aggregate memory remains deployment-specific |
| U10 | Power House JSON scanner tests; 10,000 nesting levels and escaped duplicate keys | Controlled rejection; existing canonical identities preserved by conformance tests |
| U11 | Retained-bundle tests; missing, extra, linked and substituted files; signed inconsistent Safetensors index | Inventory and kernel seals tested; sharded serving integration pending |
| U12 | Lineage tests; self-consistent graph outside independently approved root | Application authorization rejects |
| U13 | Patched Power House protocol verifier and model-proof admission tests | Changed or removed receipt attachments reject despite retained PHA core; generic verification alone is insufficient |
| U14 | Chromium race tests; suspend real signature verification or model load, then change inputs | Superseded success cannot re-enable download |
| U15 | GitHub protected publication run 43584975561; immutable release 445208667, asset 747114439 | Identical download verified; published asset mutation denied to both publisher and owner credentials after successful draft-edit controls; customer production authority must be enrolled separately |
| U16 | Organization policy API tests and authenticated Runpod HTTPS gateway | Registration cannot activate serving; actual CUDA output follows authenticated receipt, runtime, policy and native model-proof verification |
| U17 | Admission tests; revocation, expiry, authority outage, persistent epoch/floor and clock regression | Subsequent CPU/CUDA calls deny; actual HTTPS withdrawal before lease expiry and a separate 12 s lease-expiry trial deny without another native call; in-flight kernels may finish until the independent wall deadline |
| U18 | Qualified confidential-computing deployment | Pending; no accepted hardware profile or attestation evidence |
| U19 | Attestation verifier and external key broker | Pending; no hardware key-release qualification |
| U20 | Authenticated encrypted model distribution | Pending; no qualified encrypted distribution profile |
| U21 | SDK 3.1.0 fixed-model guest; actual generated PHA/capsule and proof-backed CUDA activation | Indexed ordered-FP32 relation verified; wrong image, model, dataset, index, result and verifier reject; no GPU-execution or general-safety proof |
| U22 | Admission tests; native ONNX loop, GIL-held libc call and migrated H100 deployment | Independent pidfd watchdog terminates stalled gateway; restored epoch 6/floor 2 rejects stale policy, epoch 7/floor 3 serves, withdrawal at epoch 8 prevents old-policy restart; fleet supervision remains operator-specific |

Operational limits

The five-minute policy window and per-call lease checks are software enforcement,
not instantaneous cancellation of an executing accelerator kernel. Persistent
state must be protected against unauthorized restoration. CPU serving tests additionally observe signer rotation, consistent SQLite snapshot
recovery with retained policy floors, authority outage and loss of durable state.
These are software effects under a trusted host; restoring an attacker-selected
older database is outside that trust boundary. The H100 test also restored a consistent authorization snapshot on a replacement node and retained the policy floor and historical audit. Customer network partitions, GPU resets, general migration, audit retention,
aggregate memory exhaustion and customer-specific numerical acceptance remain
commissioning requirements. They must not be recorded as passing based only on
successful API responses.

Reproduction

Install the candidate and its `admission-cpu` dependencies in a disposable Python
environment. Gate's existing CKODMK adapter still requires CKODMK 0.5.1; the
new CPU serving profile does not silently requalify that evaluator. Install the
separate Power House SDK 0.4.1 to run lineage tests. Run:

```sh
python -m unittest discover -s tests -v
GATE_SANDBOX_SITE_ROOT=/absolute/path/to/mfenx-site/public \
  python -m pytest control_plane/tests -q
```

The distribution tests require the candidate wheels to be built first. The
site-root override supplies static customer-runtime documentation to the
existing control-plane sandbox tests; it is not production configuration.
Browser race tests are retained in the site repository and CKODMK's
`web/tests/browser_admission_races.py`. They require Playwright and Chromium,
and exercise actual Web Crypto verification and ONNX Runtime replay.

Candidate wheels were independently built twice with identical output using
Python 3.14, setuptools 84.1.0, wheel 0.47.0 and
`SOURCE_DATE_EPOCH=1767225600`. Reproducible archives do not establish dependency
trust, host integrity or reproducible numerical behavior on other runtimes.

Model-proof observation

The fixed-model guest consumed the committed 10,055-byte ONNX source and
474,918-byte dataset and evaluated sample zero. Its verified 116-byte journal
matched the independently generated FP32 reference exactly. On the RTX 4090
qualification workload, proof generation took 18.303 s, PHA verification
1.367 s and capsule verification 1.619 s. These are single observations,
not throughput estimates. GPU activity was sampled during proving; the
proof relation itself concerns the guest computation, not a CUDA kernel.

The installed wheel passed 15 combined CUDA/proof-admission tests without
skips or failures. Proof-backed activation ran an actual CUDA inference after
pathname replacement and retained the proof identity in the durable session
audit. The isolated one-shot CPU worker does not transport proof evidence;
it denies v2 proof policies rather than satisfying them implicitly.

Extended deployment observation

The complete deployment suite ran under CPython 3.13 with checksum-pinned Caddy
2.11.9: 269 tests and 143 subtests passed, with no skips. The run executed the
frozen offline installer and installed-runtime acceptance, renewal against the
actual browser credential format, online database backup and the account,
license and payment proxies over loopback HTTP. Synthetic authorities and
provider doubles do not qualify live payment settlement or production custody.
All 22 original installer wheels were recovered from the retained public archive
and individually matched their frozen hashes; no old distribution was rebuilt.

Protected publication and serving observation

Run 43584975561 in `JROChub/model-gate-action` completed the independently
configured `mfenx-publication-qualification` environment on `main`. Release
`publication-qualification-43584975561-1` is immutable. Its 11,060-byte asset
has SHA-256 `06a64a1e220967630a52741882a5b01b7801213f3e4013a8c0881554e6b99230`.
The publisher first edited a draft successfully, then observed denial of
published mutation. An independent owner-credential trial returned HTTP 422
and a fresh download retained the same digest. These are demo release
authorities, not authorization for customer production deployment.

The final H100 SXM run passed 16 CUDA/proof tests and five gateway tests,
with zero skips, failures or errors. The installed Gate wheel matched every
SDK module in the frozen candidate. The external authenticated HTTPS request
returned CUDA outputs for sample zero after equal-length replacement of the
original model pathname. Wrong credentials and input names denied before
inference. The durable audit linked the actual completion to its receipt,
policy and verified proof. Policy withdrawal at epoch 8 occurred 35.715 s
after activation under a 60 s lease; the next request returned 503 without
another native inference call. Restart with the original model restored and
epoch 7 policy exited 2 without binding the listener; epoch 8/floor 3 remained.
The archived final run has SHA-256
`96b40634527474afec0e6c5e4dcdd00ef83ef68704cb87fc040ee52de30c26f3`.

A preceding H100 trial additionally exercised release-authority rotation,
a real 12 s lease expiry and consistent SQLite recovery. These observations
concern the bounded, serialized staging gateway, not a general fleet service.
Both H100 allocations were deleted after evidence acquisition.

The inspected Runpod H100 configuration reported CPU confidential-computing
capabilities `None`, confidential-computing environment `UNAVAILABLE`, GPU
confidential-computing status `OFF` and zero protected GPU memory. No accepted
CPU protected-guest interface was present. Consequently U18–U20 remain
unqualified: ordinary CUDA execution does not establish attested recipient
key release or host-resistant plaintext confidentiality.
