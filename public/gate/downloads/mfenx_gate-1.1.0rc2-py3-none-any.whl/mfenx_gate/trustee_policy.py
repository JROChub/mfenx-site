"""Generate a narrowly scoped Trustee v0.22 EAR resource policy.

This policy is evaluated only after Trustee authenticates the attestation token.
CPU/GPU vendor evidence appraisal and reference enrollment remain upstream duties.
"""
import tomllib

from .encrypted import Descriptor, EncryptedPolicy
from .receipt import ReceiptError, canonical


def resource_policy(policy: EncryptedPolicy, descriptor: Descriptor, *, cpu_tee: str) -> str:
    if (type(policy) is not EncryptedPolicy or type(descriptor) is not Descriptor
            or descriptor.digest != policy.descriptor_sha256 or cpu_tee not in ("tdx", "snp")):
        raise ReceiptError("resource policy requires an approved descriptor and supported CPU TEE")
    resource = canonical(descriptor.context["resource"].split("/")).decode("ascii")
    init_data = canonical(tomllib.loads(policy.init_data)["data"]).decode("ascii")
    return f'''package policy
import rego.v1

default allow := false

allow if {{
    data.plugin == "resource"
    data["resource-path"] == {resource}
    count(data.query) == 0
    count(input.submods) == 2
    cpu := input.submods.cpu0
    gpu := input.submods.gpu0
    cpu["ear.status"] == "affirming"
    gpu["ear.status"] == "affirming"
    cpu["ear.trustworthiness-vector"].hardware == 2
    cpu["ear.trustworthiness-vector"].executables == 3
    cpu["ear.trustworthiness-vector"].configuration == 2
    gpu["ear.trustworthiness-vector"].hardware == 2
    gpu["ear.trustworthiness-vector"].executables == 3
    gpu["ear.trustworthiness-vector"].configuration == 2
    cpu["ear.veraison.annotated-evidence"].{cpu_tee}
    gpu["ear.veraison.annotated-evidence"].nvidia
    cpu["ear.veraison.annotated-evidence"].init_data_claims == {init_data}
}}
'''
