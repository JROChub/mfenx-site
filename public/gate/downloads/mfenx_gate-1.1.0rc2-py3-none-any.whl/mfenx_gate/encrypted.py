"""Authenticated encrypted distribution into the existing retained-byte loader.

Hardware evidence and recipient binding are verified by the separately operated
Trustee deployment. This adapter does not manufacture an attestation decision.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass, replace
from datetime import datetime, timezone
import os
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .admission import AdmissionPolicy, MAX_MODEL_BYTES, admit_model
from .receipt import ReceiptError, canonical, parse, read_regular, sha256, verify_receipt, _digest

DESCRIPTOR_SCHEMA = "mfenx/encrypted-model/v1"
POLICY_SCHEMA = "mfenx/encrypted-admission-policy/v1"
RESOURCE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}/[A-Za-z0-9][A-Za-z0-9._-]{0,127}/[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
AAD_DOMAIN = b"mfenx:encrypted-model:v1\0"


@dataclass(frozen=True)
class EncryptedModel:
    descriptor: bytes
    ciphertext: bytes
    key: bytes


def encrypt_model(payload: bytes, *, receipt: bytes, trusted_public_key: bytes,
                  repository: str = "mfenx") -> EncryptedModel:
    """Producer operation. Each call generates a fresh AES-256 key and nonce.

    The key is a separate provisioning artifact, never part of distribution.
    """
    if type(payload) is not bytes or not 0 < len(payload) <= MAX_MODEL_BYTES:
        raise ReceiptError("encrypted distribution requires bounded immutable model bytes")
    if type(repository) is not str or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", repository):
        raise ReceiptError("invalid key repository")
    result = verify_receipt(receipt, trusted_public_key, artifact_bytes=payload)
    if result["receipt"]["statement"]["profile"] != "onnx-finite-evaluation/v1":
        raise ReceiptError("encrypted serving requires the existing finite-evaluation receipt")
    key, nonce = AESGCM.generate_key(bit_length=256), os.urandom(12)
    context = {"algorithm":"AES-256-GCM", "model_sha256":sha256(payload),
               "model_bytes":len(payload), "receipt_sha256":sha256(receipt),
               "resource":repository + "/model-keys/" + sha256(receipt)[7:] + "-" + nonce.hex(),
               "nonce_base64":base64.b64encode(nonce).decode("ascii")}
    ciphertext = AESGCM(key).encrypt(nonce, payload, AAD_DOMAIN + canonical(context))
    descriptor = canonical({"schema":DESCRIPTOR_SCHEMA, "context":context,
                            "ciphertext_sha256":sha256(ciphertext)})
    return EncryptedModel(descriptor, ciphertext, key)


@dataclass(frozen=True)
class Descriptor:
    digest: str
    context: dict
    ciphertext_sha256: str

    @classmethod
    def from_bytes(cls, raw: bytes, *, expected_sha256: str):
        _digest(expected_sha256)
        if type(raw) is not bytes or not 0 < len(raw) <= 65536 or sha256(raw) != expected_sha256:
            raise ReceiptError("encrypted descriptor does not match independent approval")
        d = parse(raw)
        if (type(d) is not dict or set(d) != {"schema", "context", "ciphertext_sha256"}
                or d["schema"] != DESCRIPTOR_SCHEMA):
            raise ReceiptError("unsupported encrypted descriptor")
        c = d["context"]
        if (type(c) is not dict or set(c) != {"algorithm", "model_sha256", "model_bytes",
                "receipt_sha256", "resource", "nonce_base64"} or c["algorithm"] != "AES-256-GCM"):
            raise ReceiptError("unsupported encryption context")
        for digest in [c["model_sha256"], c["receipt_sha256"], d["ciphertext_sha256"]]:
            _digest(digest)
        if type(c["model_bytes"]) is not int or not 0 < c["model_bytes"] <= MAX_MODEL_BYTES:
            raise ReceiptError("encrypted model exceeds supported size")
        if type(c["resource"]) is not str or not RESOURCE.fullmatch(c["resource"]):
            raise ReceiptError("invalid key resource")
        try:
            nonce = base64.b64decode(c["nonce_base64"], validate=True)
            if len(nonce) != 12 or base64.b64encode(nonce).decode("ascii") != c["nonce_base64"]:
                raise ValueError("noncanonical nonce")
        except (ValueError, TypeError) as exc:
            raise ReceiptError("invalid encryption nonce") from exc
        return cls(expected_sha256, c, d["ciphertext_sha256"])

    def acquire(self, path: Path) -> bytes:
        raw = read_regular(path, self.context["model_bytes"] + 16)
        if len(raw) != self.context["model_bytes"] + 16 or sha256(raw) != self.ciphertext_sha256:
            raise ReceiptError("encrypted artifact identity mismatch")
        return raw

    def decrypt(self, ciphertext: bytes, key: bytes) -> bytes:
        if (type(key) is not bytes or len(key) != 32 or type(ciphertext) is not bytes
                or len(ciphertext) != self.context["model_bytes"] + 16
                or sha256(ciphertext) != self.ciphertext_sha256):
            raise ReceiptError("encrypted artifact or key does not match the approved format")
        try:
            payload = AESGCM(key).decrypt(base64.b64decode(self.context["nonce_base64"]),
                                           ciphertext, AAD_DOMAIN + canonical(self.context))
        except InvalidTag as exc:
            raise ReceiptError("encrypted model authentication failed") from exc
        if len(payload) != self.context["model_bytes"] or sha256(payload) != self.context["model_sha256"]:
            raise ReceiptError("authenticated plaintext identity mismatch")
        return payload


@dataclass(frozen=True)
class EncryptedPolicy:
    digest: str
    admission: AdmissionPolicy
    descriptor_sha256: str
    broker_url: str
    broker_ca_sha256: str
    trustee_client_sha256: str
    init_data: str

    @classmethod
    def from_bytes(cls, raw: bytes, *, expected_sha256: str):
        _digest(expected_sha256)
        if type(raw) is not bytes or not 0 < len(raw) <= 65536 or sha256(raw) != expected_sha256:
            raise ReceiptError("encrypted admission policy does not match independent approval")
        p = parse(raw)
        if (type(p) is not dict or set(p) != {"schema", "admission", "descriptor_sha256",
                "broker_url", "broker_ca_sha256", "trustee_client_sha256"}
                or p["schema"] != POLICY_SCHEMA):
            raise ReceiptError("unsupported encrypted admission policy")
        for name in ["descriptor_sha256", "broker_ca_sha256", "trustee_client_sha256"]:
            _digest(p[name])
        try:
            url = urlsplit(p["broker_url"])
            if (url.scheme != "https" or not url.hostname or url.username or url.password
                    or url.path or url.query or url.fragment or url.port == 0
                    or any(c.isspace() for c in p["broker_url"])):
                raise ValueError("noncanonical broker URL")
        except (ValueError, TypeError, AttributeError) as exc:
            raise ReceiptError("key delivery requires an independently approved HTTPS broker origin") from exc
        inner = canonical(p["admission"])
        admission = AdmissionPolicy.from_bytes(inner, expected_sha256=sha256(inner))
        # The existing epoch/floor mechanism now covers the entire configuration.
        # Broker or descriptor changes at the same epoch therefore cannot reopen.
        admission = replace(admission, digest=expected_sha256)
        claims = canonical({"mfenx":{"descriptor_sha256":p["descriptor_sha256"],
            "admission_policy_sha256":sha256(inner), "broker_url":p["broker_url"],
            "broker_ca_sha256":p["broker_ca_sha256"],
            "trustee_client_sha256":p["trustee_client_sha256"]}}).decode("ascii")
        # Trustee v0.22's client sends TOML Initdata v0.1.0 with string-valued
        # data. Its verifier hashes these exact bytes, including newlines.
        init = 'version = "0.1.0"\nalgorithm = "sha256"\n[data]\n"mfenx.json" = '+json.dumps(claims)+'\n'
        return cls(expected_sha256, admission, p["descriptor_sha256"], p["broker_url"],
                   p["broker_ca_sha256"], p["trustee_client_sha256"], init)


def admit_encrypted_model(*, descriptor: bytes, ciphertext: Path, receipt: bytes,
                          trusted_public_key: bytes, policy: EncryptedPolicy,
                          trustee_client: Path, broker_ca: Path, lineage=None,
                          execution_proof: bytes | None = None, proof_verifier: Path | None = None):
    """Run inside the approved workload. Never stage decrypted model files.

    A successful key response means the configured broker released a key; it
    does not independently qualify that broker's hardware appraisal policy.
    """
    if type(policy) is not EncryptedPolicy:
        raise ReceiptError("encrypted loading requires the complete protected policy")
    if policy.admission.execution_requirement is not None and (execution_proof is None or proof_verifier is None):
        raise ReceiptError("required execution proof or protected verifier is missing")
    if policy.admission.required_lineage is not None and lineage is None:
        raise ReceiptError("required model lineage is missing")
    d = Descriptor.from_bytes(descriptor, expected_sha256=policy.descriptor_sha256)
    result = verify_receipt(receipt, trusted_public_key,
        expected_contract_digest=policy.admission.contract_sha256)
    policy.admission.authorize(sha256(receipt), sha256(trusted_public_key), now=datetime.now(timezone.utc))
    artifact = result["receipt"]["statement"]["artifact"]
    if (result["receipt"]["statement"]["profile"] != "onnx-finite-evaluation/v1"
            or d.context["receipt_sha256"] != sha256(receipt)
            or d.context["model_sha256"] != artifact["sha256"]
            or d.context["model_bytes"] != artifact["bytes"]
            or artifact["bytes"] > policy.admission.maximum_model_bytes):
        raise ReceiptError("encrypted distribution is not bound to the approved release")
    encrypted = d.acquire(ciphertext)
    from .trustee import retrieve_key
    key = retrieve_key(policy, resource=d.context["resource"], client=trustee_client, ca=broker_ca)
    try:
        payload = d.decrypt(encrypted, key)
    finally:
        # CPython immutable objects cannot provide a reliable zeroization promise.
        del key
    model = admit_model(receipt=receipt, trusted_public_key=trusted_public_key,
                        model_bytes=payload, policy=policy.admission, lineage=lineage,
                        execution_proof=execution_proof, proof_verifier=proof_verifier)
    model.distribution_sha256 = sha256(canonical({"schema":"mfenx/distribution-evidence/v1",
        "descriptor_sha256":d.digest, "ciphertext_sha256":d.ciphertext_sha256,
        "policy_sha256":policy.digest, "trustee_client_sha256":policy.trustee_client_sha256}))
    return model
