"""Bounded, canonical release attestations; no inference or data upload."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils

SCHEMA = "mfenx/release-receipt/v1"
ALGORITHM = "ecdsa-p256-sha256-p1363"
SIGN_DOMAIN = b"mfenx:release-receipt:v1:signature\0"
ROOT_DOMAIN = b"mfenx:release-receipt:v1:root\0"
MAX_RECEIPT = 65536
MAX_INTEGER = 9007199254740991
P256_ORDER = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")
FIELDS = {"id", "issued_at", "expires_at", "profile", "artifact", "parent_sha256", "contract_sha256", "evaluation"}
METRICS = {"samples", "source_correct", "candidate_correct", "decision_changes", "candidate_p95_latency_ns"}


class ReceiptError(ValueError):
    """Invalid, untrusted or mismatched release receipt."""


def sha256(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def _inspect(value: Any, depth: int = 0) -> None:
    if depth > 16:
        raise ReceiptError("receipt nesting exceeds limit")
    if value is None or type(value) is bool:
        return
    if type(value) is int and abs(value) <= MAX_INTEGER:
        return
    if type(value) is str and value.isascii() and len(value) <= 4096:
        return
    if type(value) is dict and len(value) <= 64:
        for key, child in value.items():
            if type(key) is not str or not key.isascii() or len(key) > 128:
                raise ReceiptError("unsupported object key")
            _inspect(child, depth + 1)
        return
    if type(value) is list and len(value) <= 64:
        for child in value:
            _inspect(child, depth + 1)
        return
    raise ReceiptError("receipt supports bounded ASCII, safe integers, booleans and null only")


def canonical(value: Any) -> bytes:
    _inspect(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def parse(raw: bytes) -> dict:
    if type(raw) is not bytes or not 0 < len(raw) <= MAX_RECEIPT:
        raise ReceiptError("receipt must contain 1–65536 bytes")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ReceiptError("duplicate JSON key")
            result[key] = value
        return result
    def reject(_):
        raise ReceiptError("non-integer JSON numbers are unsupported")
    try:
        value = json.loads(raw.decode("ascii"), object_pairs_hook=pairs,
                           parse_float=reject, parse_constant=reject)
        _inspect(value)
    except ReceiptError:
        raise
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise ReceiptError("malformed receipt JSON") from exc
    return value


def _keys(value: Any, keys: set[str], label: str) -> None:
    if type(value) is not dict or set(value) != keys:
        raise ReceiptError(f"unsupported {label} fields")


def _digest(value: Any) -> None:
    if type(value) is not str or not DIGEST.fullmatch(value):
        raise ReceiptError("noncanonical SHA-256 digest")


def _integer(value: Any, lower: int = 0, upper: int = MAX_INTEGER) -> None:
    if type(value) is not int or not lower <= value <= upper:
        raise ReceiptError("integer outside permitted range")


def timestamp(value: Any) -> datetime:
    if type(value) is not str or not re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", value):
        raise ReceiptError("timestamp must be canonical UTC")
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise ReceiptError("invalid timestamp") from exc


def validate_statement(s: Any, now: datetime) -> None:
    _keys(s, FIELDS, "statement")
    if type(s["id"]) is not str or not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}", s["id"]):
        raise ReceiptError("invalid release identifier")
    issued, expires = timestamp(s["issued_at"]), timestamp(s["expires_at"])
    if now.tzinfo is None or issued > now or expires <= now or expires <= issued:
        raise ReceiptError("receipt is not currently valid")
    _keys(s["artifact"], {"format", "sha256", "bytes"}, "artifact")
    _digest(s["artifact"]["sha256"])
    _integer(s["artifact"]["bytes"], 1)
    e = s["evaluation"]
    _keys(e, {"decision", "report_sha256"} | METRICS, "evaluation")
    _digest(e["report_sha256"])
    if s["profile"] == "onnx-finite-evaluation/v1":
        if s["artifact"]["format"] != "onnx" or e["decision"] != "PASS":
            raise ReceiptError("inconsistent ONNX profile")
        _digest(s["parent_sha256"])
        _digest(s["contract_sha256"])
        _integer(e["samples"], 1)
        for key in {"source_correct", "candidate_correct", "decision_changes"}:
            _integer(e[key], 0, e["samples"])
        _integer(e["candidate_p95_latency_ns"], 1)
    elif s["profile"] == "safetensors-integrity/v1":
        if (s["artifact"]["format"] != "safetensors" or e["decision"] != "NOT_EVALUATED"
                or s["parent_sha256"] is not None or s["contract_sha256"] is not None
                or any(e[key] is not None for key in METRICS)):
            raise ReceiptError("integrity receipt cannot assert behavioral admission")
    else:
        raise ReceiptError("unsupported receipt profile")


def read_regular(path: Path, maximum: int = MAX_RECEIPT) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    try:
        fd = os.open(path, flags)
        with os.fdopen(fd, "rb") as handle:
            before = os.fstat(handle.fileno())
            if not stat.S_ISREG(before.st_mode) or not 0 < before.st_size <= maximum:
                raise ReceiptError("input must be a bounded regular file")
            value = handle.read(maximum + 1)
            after = os.fstat(handle.fileno())
            if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns) or len(value) != before.st_size:
                raise ReceiptError("input changed during read")
            return value
    except OSError as exc:
        raise ReceiptError("cannot safely open input file") from exc


def hash_artifact(path: Path) -> tuple[str, int]:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    try:
        fd = os.open(path, flags)
        with os.fdopen(fd, "rb") as handle:
            before = os.fstat(handle.fileno())
            if not stat.S_ISREG(before.st_mode) or not 0 < before.st_size <= 1024**4:
                raise ReceiptError("artifact must be a nonempty regular file up to 1 TiB")
            digest = hashlib.sha256()
            total = 0
            while block := handle.read(8 * 1024 * 1024):
                total += len(block)
                if total > before.st_size:
                    raise ReceiptError("artifact grew during verification")
                digest.update(block)
            after = os.fstat(handle.fileno())
            if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns) or total != before.st_size:
                raise ReceiptError("artifact changed during verification")
            return "sha256:" + digest.hexdigest(), total
    except OSError as exc:
        raise ReceiptError("cannot safely open artifact") from exc


def generate_keypair() -> tuple[bytes, bytes]:
    key = ec.generate_private_key(ec.SECP256R1())
    return (key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                              serialization.NoEncryption()),
            key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo))


def _sign(statement: dict, private_key: bytes, issuer: str) -> bytes:
    """Internal: callers use executed workflow entry points, never PASS report imports."""
    validate_statement(statement, datetime.now(timezone.utc))
    if not isinstance(issuer, str) or not re.fullmatch(r"[\x20-\x7e]{1,128}", issuer):
        raise ReceiptError("issuer must be 1–128 printable ASCII characters")
    try:
        key = serialization.load_pem_private_key(private_key, password=None)
    except (ValueError, TypeError) as exc:
        raise ReceiptError("invalid unencrypted PKCS8 private key") from exc
    if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(key.curve, ec.SECP256R1):
        raise ReceiptError("issuer key must use P-256")
    public = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    body = {"schema": SCHEMA, "statement": statement,
            "issuer": {"name": issuer, "key_id": sha256(public), "algorithm": ALGORITHM},
            "root_id": sha256(ROOT_DOMAIN + canonical(statement))}
    r, s = utils.decode_dss_signature(key.sign(SIGN_DOMAIN + canonical(body), ec.ECDSA(hashes.SHA256())))
    signature = r.to_bytes(32, "big") + min(s, P256_ORDER - s).to_bytes(32, "big")
    return canonical({**body, "signature": {"algorithm": ALGORITHM,
                     "value_base64": base64.b64encode(signature).decode("ascii")}}) + b"\n"


def verify_receipt(raw: bytes, trusted_public_key: bytes, *, artifact: Path | None = None,
                   artifact_bytes: bytes | None = None,
                   expected_contract_digest: str | None = None, now: datetime | None = None) -> dict:
    if artifact is not None and artifact_bytes is not None:
        raise ReceiptError("supply an artifact path or immutable artifact bytes, not both")
    if artifact_bytes is not None and type(artifact_bytes) is not bytes:
        raise ReceiptError("in-memory artifact must be immutable bytes")
    receipt = parse(raw)
    _keys(receipt, {"schema", "issuer", "statement", "root_id", "signature"}, "receipt")
    if receipt["schema"] != SCHEMA:
        raise ReceiptError("unsupported receipt schema")
    validate_statement(receipt["statement"], now or datetime.now(timezone.utc))
    issuer = receipt["issuer"]
    _keys(issuer, {"name", "key_id", "algorithm"}, "issuer")
    if type(issuer["name"]) is not str or not re.fullmatch(r"[\x20-\x7e]{1,128}", issuer["name"]) or issuer["algorithm"] != ALGORITHM:
        raise ReceiptError("invalid issuer")
    if type(trusted_public_key) is not bytes or not 0 < len(trusted_public_key) <= 4096 or sha256(trusted_public_key) != issuer["key_id"]:
        raise ReceiptError("issuer is not the independently selected trusted key")
    try:
        key = serialization.load_der_public_key(trusted_public_key)
    except (ValueError, TypeError) as exc:
        raise ReceiptError("invalid SPKI trust key") from exc
    if not isinstance(key, ec.EllipticCurvePublicKey) or not isinstance(key.curve, ec.SECP256R1):
        raise ReceiptError("trust key must use P-256")
    if key.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo) != trusted_public_key:
        raise ReceiptError("noncanonical SPKI key")
    if receipt["root_id"] != sha256(ROOT_DOMAIN + canonical(receipt["statement"])):
        raise ReceiptError("receipt root mismatch")
    sig = receipt["signature"]
    _keys(sig, {"algorithm", "value_base64"}, "signature")
    if sig["algorithm"] != ALGORITHM or type(sig["value_base64"]) is not str:
        raise ReceiptError("unsupported signature")
    try:
        signature = base64.b64decode(sig["value_base64"], validate=True)
    except ValueError as exc:
        raise ReceiptError("invalid signature encoding") from exc
    if len(signature) != 64 or base64.b64encode(signature).decode() != sig["value_base64"]:
        raise ReceiptError("noncanonical signature encoding")
    r, s = int.from_bytes(signature[:32], "big"), int.from_bytes(signature[32:], "big")
    if not 1 <= r < P256_ORDER or not 1 <= s <= P256_ORDER // 2:
        raise ReceiptError("signature must be canonical low-S P-256")
    body = {name: value for name, value in receipt.items() if name != "signature"}
    try:
        key.verify(utils.encode_dss_signature(r, s), SIGN_DOMAIN + canonical(body), ec.ECDSA(hashes.SHA256()))
    except InvalidSignature as exc:
        raise ReceiptError("invalid receipt signature") from exc
    statement = receipt["statement"]
    if artifact is not None and hash_artifact(artifact) != (statement["artifact"]["sha256"], statement["artifact"]["bytes"]):
        raise ReceiptError("artifact does not match receipt")
    if artifact_bytes is not None and (sha256(artifact_bytes), len(artifact_bytes)) != (statement["artifact"]["sha256"], statement["artifact"]["bytes"]):
        raise ReceiptError("artifact bytes do not match receipt")
    if expected_contract_digest is not None:
        _digest(expected_contract_digest)
        if statement["contract_sha256"] != expected_contract_digest:
            raise ReceiptError("contract does not match independently expected policy")
    return {"status": "ATTESTATION_VERIFIED", "artifactStatus": "MATCH" if artifact is not None or artifact_bytes is not None else "NOT_CHECKED",
            "contractStatus": "MATCH" if expected_contract_digest is not None else "NOT_CHECKED" if statement["contract_sha256"] else "NOT_APPLICABLE",
            "behavioralStatus": "ISSUER_ATTESTED_FINITE_EVALUATION" if statement["profile"] == "onnx-finite-evaluation/v1" else "NOT_EVALUATED",
            "replayStatus": "NOT_PERFORMED", "receipt": receipt}
