"""Local execution adapters. No report-import or remote inference endpoint."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import uuid

from .receipt import METRICS, ReceiptError, _sign, hash_artifact, sha256


def _require_engine() -> None:
    try:
        from mfenx_ckodmk import __version__
    except ImportError as exc:
        raise ReceiptError("this command requires the separately installed CKODMK 0.5.1 engine") from exc
    if __version__ != "0.5.1":
        raise ReceiptError("unsupported CKODMK version; this adapter is qualified for 0.5.1")


def _statement(*, profile: str, artifact: dict, parent: str | None, contract: str | None,
               evaluation: dict, release_id: str | None, validity_days: int) -> dict:
    if type(validity_days) is not int or not 1 <= validity_days <= 366:
        raise ReceiptError("validity must be 1–366 days")
    now = datetime.now(timezone.utc).replace(microsecond=0)
    return {"id": release_id or uuid.uuid4().hex,
            "issued_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expires_at": (now + timedelta(days=validity_days)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "profile": profile, "artifact": artifact, "parent_sha256": parent,
            "contract_sha256": contract, "evaluation": evaluation}


def _report_digest(report: dict) -> str:
    # Report is local evidence. Only its digest enters the portable receipt.
    return sha256(json.dumps(report, sort_keys=True, separators=(",", ":"),
                             ensure_ascii=True, allow_nan=False).encode("ascii"))


def admit_onnx(*, source: Path, candidate: Path, dataset: Path, contract: Path,
               expected_contract_digest: str, private_key: bytes, issuer: str,
               release_id: str | None = None, validity_days: int = 30) -> tuple[bytes | None, dict]:
    """Execute CKODMK's gate; issue a finite-evaluation attestation only on PASS.

    The expected contract digest must come from the release authority. A key
    owner remains responsible for the local runner and the evaluation policy.
    """
    _require_engine()
    try:
        from mfenx_ckodmk.gate.runner import run_onnx_gate
    except ImportError as exc:
        raise ReceiptError("ONNX admission requires the separately installed CKODMK production engine") from exc
    report = run_onnx_gate(contract, source, candidate, dataset, expected_contract_digest)
    if report.get("decision") != "PASS":
        return None, report
    if report.get("schema") != "mfenx/ckodmk-gate-report/v1" or report["contract"]["sha256"] != expected_contract_digest:
        raise ReceiptError("execution report does not bind the expected contract")
    candidate_record = report["artifacts"]["candidate"]
    # Detect input changes between the frozen run and receipt publication.
    if hash_artifact(candidate) != (candidate_record["sha256"], candidate_record["bytes"]):
        raise ReceiptError("candidate changed after local evaluation")
    raw = report["raw_observation_evidence"]
    source_decisions, candidate_decisions, labels = raw["source_decisions"], raw["candidate_decisions"], raw["labels"]
    count = len(labels)
    if not count or len(source_decisions) != count or len(candidate_decisions) != count:
        raise ReceiptError("execution observation counts disagree")
    evaluation = {"decision": "PASS", "report_sha256": _report_digest(report), "samples": count,
                  "source_correct": sum(a == b for a, b in zip(source_decisions, labels)),
                  "candidate_correct": sum(a == b for a, b in zip(candidate_decisions, labels)),
                  "decision_changes": sum(a != b for a, b in zip(source_decisions, candidate_decisions)),
                  "candidate_p95_latency_ns": report["measurements"]["candidate_p95_latency_ns"]}
    statement = _statement(profile="onnx-finite-evaluation/v1", artifact={"format": "onnx", **candidate_record},
                           parent=report["artifacts"]["source"]["sha256"], contract=expected_contract_digest,
                           evaluation=evaluation, release_id=release_id, validity_days=validity_days)
    return _sign(statement, private_key, issuer), report


def inspect_checkpoint(root: Path, checkpoint_format: str = "safetensors") -> dict:
    _require_engine()
    try:
        from mfenx_ckodmk.scale import inspect_checkpoint_tree
    except ImportError as exc:
        raise ReceiptError("checkpoint inspection requires the separately installed CKODMK engine") from exc
    return inspect_checkpoint_tree(root, checkpoint_format=checkpoint_format)


def issue_integrity(*, model: Path, private_key: bytes, issuer: str,
                    release_id: str | None = None, validity_days: int = 30) -> tuple[bytes, dict]:
    """Issue a single-file Safetensors integrity attestation, never admission."""
    if model.suffix != ".safetensors" or model.is_symlink():
        raise ReceiptError("integrity issuance requires a regular .safetensors checkpoint")
    report = inspect_checkpoint(model.parent)
    records = report["artifact_files"]
    if len(records) != 1 or records[0]["path"] != model.name:
        raise ReceiptError("receipt v1 integrity profile requires one unsharded checkpoint")
    digest, size = hash_artifact(model)
    if records[0]["sha256"] != digest or records[0]["bytes"] != size:
        raise ReceiptError("checkpoint changed after inspection")
    statement = _statement(profile="safetensors-integrity/v1",
                           artifact={"format": "safetensors", "sha256": digest, "bytes": size},
                           parent=None, contract=None,
                           evaluation={"decision": "NOT_EVALUATED", "report_sha256": _report_digest(report),
                                       **{name: None for name in METRICS}},
                           release_id=release_id, validity_days=validity_days)
    return _sign(statement, private_key, issuer), report
