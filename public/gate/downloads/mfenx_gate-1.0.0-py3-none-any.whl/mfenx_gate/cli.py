"""Local MFENX Gate CLI; all input processing is offline."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .receipt import ReceiptError, generate_keypair, read_regular, sha256, verify_receipt
from .workflow import admit_onnx, inspect_checkpoint, issue_integrity


def publish(path: Path, value: bytes, mode: int = 0o600) -> None:
    """Publish a fully written file without replacing an existing destination."""
    fd, temporary = tempfile.mkstemp(prefix=".mfenx-gate-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            os.fchmod(handle.fileno(), mode)
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
    except OSError as exc:
        raise ReceiptError("output cannot be published; existing files are never overwritten") from exc
    finally:
        os.unlink(temporary)


def _json(value) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False, indent=2) + "\n").encode()


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mfenx-gate", description="Local model admission and free release-receipt verification")
    p.add_argument("--version", action="version", version="mfenx-gate 1.0.0")
    commands = p.add_subparsers(dest="command", required=True)
    key = commands.add_parser("keygen", help="create a local P-256 issuer keypair")
    key.add_argument("--private-key", type=Path, required=True)
    key.add_argument("--public-key", type=Path, required=True)
    verify = commands.add_parser("verify", help="verify a receipt attestation; does not replay inference")
    verify.add_argument("receipt", type=Path)
    verify.add_argument("--trusted-public-key", type=Path, required=True)
    verify.add_argument("--model", type=Path)
    verify.add_argument("--expected-contract-sha256")
    onnx = commands.add_parser("admit-onnx", help="execute CKODMK and issue only after a passing finite contract")
    for name in ("source", "candidate", "dataset", "contract"):
        onnx.add_argument("--" + name, type=Path, required=True)
    onnx.add_argument("--expected-contract-sha256", required=True)
    integrity = commands.add_parser("issue-integrity", help="inspect one Safetensors checkpoint; does not test behavior")
    integrity.add_argument("--model", type=Path, required=True)
    for command in (onnx, integrity):
        command.add_argument("--private-key", type=Path, required=True)
        command.add_argument("--issuer", required=True)
        command.add_argument("--release-id")
        command.add_argument("--validity-days", type=int, default=30)
        command.add_argument("--output", type=Path, required=True)
        command.add_argument("--report", type=Path)
    inspect = commands.add_parser("inspect-checkpoint", help="inventory a checkpoint locally")
    inspect.add_argument("--root", type=Path, required=True)
    inspect.add_argument("--format", choices=("safetensors", "pytorch"), default="safetensors")
    inspect.add_argument("--output", type=Path, required=True)
    return p


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "keygen":
            if args.private_key == args.public_key or args.private_key.exists() or args.public_key.exists():
                raise ReceiptError("key paths must be different and must not exist")
            private, public = generate_keypair()
            publish(args.private_key, private)
            publish(args.public_key, public, 0o644)
            result = {"status": "KEY_CREATED", "key_id": sha256(public)}
        elif args.command == "verify":
            result = verify_receipt(read_regular(args.receipt), read_regular(args.trusted_public_key, 4096),
                                    artifact=args.model, expected_contract_digest=args.expected_contract_sha256)
        elif args.command == "inspect-checkpoint":
            report = inspect_checkpoint(args.root, args.format)
            publish(args.output, _json(report))
            result = {"status": "INVENTORY_RECORDED", "parameter_count": report["parameter_count"],
                      "behavioralStatus": "NOT_EVALUATED"}
        else:
            if args.output.exists() or (args.report and (args.report.exists() or args.report == args.output)):
                raise ReceiptError("output paths must be distinct and must not exist")
            common = dict(private_key=read_regular(args.private_key, 4096), issuer=args.issuer,
                          release_id=args.release_id, validity_days=args.validity_days)
            if args.command == "admit-onnx":
                receipt, report = admit_onnx(source=args.source, candidate=args.candidate, dataset=args.dataset,
                                             contract=args.contract, expected_contract_digest=args.expected_contract_sha256,
                                             **common)
            else:
                receipt, report = issue_integrity(model=args.model, **common)
            if args.report:
                publish(args.report, _json(report))
            if receipt is None:
                print(json.dumps({"status": "NOT_ISSUED", "decision": report.get("decision", "BLOCK")}, sort_keys=True))
                return 3
            publish(args.output, receipt, 0o644)
            result = {"status": "ISSUED", "receipt_sha256": sha256(receipt)}
        print(json.dumps(result, sort_keys=True))
        return 0
    except (ReceiptError, ValueError, OSError, KeyError, ImportError, RuntimeError) as exc:
        print(json.dumps({"status": "REJECTED", "error": str(exc)}, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
