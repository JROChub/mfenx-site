# Customer-operated monthly license renewal

`tools/renew_license.py` is a separate delivery tool for an existing Team or
Business purchase. It does not change the Gate SDK 1.0.0 or control-plane rc3
wheel, create a purchase, change a plan or configure a scheduled task. Private
air-gap grants retain their existing manual, disconnected installation workflow.

The customer chooses whether to enable this online job. The organization runtime
continues to verify its local signed license without contacting MFENX. The job
uses the existing challenge and download API on the independently selected
license origin. That service checks payment state before issuing a new grant.
Neither the customer job nor organization runtime calls Paddle directly.

## Local key custody

The browser's stored P-256 key remains non-exportable. The job instead decrypts
the encrypted recovery file originally created by that browser, using a separate
customer-held passphrase file. It derives and checks the public-key fingerprint
against the independently supplied holder pin before making any request.
The recovery file, passphrase and private key are never uploaded. The private
key exists in local process memory; the tool does not write a plaintext private
key. Python and its cryptographic libraries do not guarantee complete memory
zeroization. A privileged local operator can read the credential or process.

Unattended renewal requires an unattended local credential. Keeping the encrypted
recovery file and its passphrase on one host is not protection against that host's
administrator or compromise. Use an operator-controlled service identity and
protect its state, backups and execution environment. This version does not
implement a hardware keystore, remote key delegation or a platform credential
manager. Do not claim the renewed runtime is hardware-bound.
The recovered key retains the holder's request authority; it is not a delegated
renewal-only key, even though this tool implements only signed license download.

Every input file and the existing output license must be a current-user-owned
regular file with mode **0600**, one hard link and no symlink in any path
component. Each immediate containing directory must be current-user-owned and
mode **0700**. Use absolute paths. The issuer public key is not secret, but the
tool requires the same protected-file convention to prevent accidental trust
configuration changes. Never derive trust pins from the downloaded license or
automatically trust the service's configuration response.

The passphrase file contains the exact UTF-8 passphrase, with no added newline.
Do not pass a passphrase as a command-line argument or environment variable.
Provision it through an administrator-controlled interactive input or secret
provisioning procedure. Backups and licenses remain sensitive; keep them outside
source control. Native systemd credential mounts commonly have different file
permissions; direct `LoadCredential` integration is not qualified by this tool.

## One-shot command

After verifying the delivered bundle and installing its runtime, use its Python
environment. All values below are placeholders, not production trust roots.
An actual installation must use the release-authenticated issuer key and issuer
key ID, the customer's own holder fingerprint, and the intended purchase ID.

```sh
/absolute/path/to/runtime-venv/bin/python /absolute/path/to/bundle/tools/renew_license.py \
  --origin https://license.mfenx.com \
  --issuer https://license.mfenx.com \
  --issuer-key /absolute/private/config/trusted-license-issuer.pem \
  --key-id TRUSTED_RELEASE_KEY_ID \
  --holder-sha256 sha256:OWN_HOLDER_FINGERPRINT \
  --license-id lic_OWN_PURCHASE_ID \
  --plan team \
  --recovery-file /absolute/private/keys/browser-recovery.json \
  --passphrase-file /absolute/private/credentials/recovery-passphrase \
  --output /absolute/private/runtime/license.json
```

`--plan` is exactly `team` or `business`. `--environment` defaults to `live`;
synthetic or Paddle sandbox testing must explicitly select `sandbox`. The HTTPS
origin and issuer must be the same exact origin, without a path, port, query or
fragment. The job neither discovers a different host from a response nor follows
redirects. HTTP proxy/environment settings are disabled; TLS certificate and
hostname validation remain enabled using the installed HTTP client's CA bundle.

The output path must be the same protected file configured as
`GATE_LICENSE_FILE` in the customer runtime. This tool creates its replacement
as its own user with mode 0600. Ensure the runtime can read that file through
the chosen customer deployment permissions; this tool does not chown files,
add shared groups or change runtime identity. A runtime running under the same
user can also read that user's renewal credentials; deployments requiring a
separate credential privilege boundary need a separately reviewed arrangement.

## Scheduling and failure behavior

First run the command interactively and check the installed grant with
`python -m gate_control.license_verify` using the same independent trust pins.
Then an operator may schedule this exact command, for example hourly with a
small randomized offset across installations. The tool does not install or
enable a timer, and no scheduler-specific integration has been qualified here.

If an authenticated matching local grant has more than 12 hours left, the job
returns `CURRENT` without reading recovery credentials or contacting the host.
Otherwise it performs one challenge request and one signed download request.
It does not perform inventory, checkout, portal or refresh calls. Download
already reconciles the paid period; an additional refresh is unnecessary.
The tool has no automatic request retry. A later scheduled run obtains a fresh
one-use challenge after any interrupted or rejected attempt.

Each response is bounded to 8 KiB, HTTPS connect/read operations are bounded,
and the Linux command-line process has a 45-second total deadline. It accepts
only an independently authenticated, unexpired grant for the pinned issuer,
key ID, holder, license ID, plan and environment. It never lengthens the signed
term, supplies a grace period or treats a redirect or payment status as a grant.

Publication writes a private temporary file, syncs it, then replaces the license
atomically in the same directory and syncs that directory. Failures before the
rename preserve the previous license. A failure after rename, including an
unconfirmed directory sync, is a publication/durability uncertainty: the new
valid file may already be installed. On any nonzero exit, inspect the current
license locally instead of assuming that either version survived. Content-free
CLI output contains only the completion state and expiry, or a generic error.

An advisory lock excludes cooperating renewals in the same output directory.
File and directory identity checks detect changes during a request, and
descriptor-relative operations never follow a substituted symlink. These are
not protection against arbitrary writes by another process with the same user
privileges or a privileged administrator.

On failure, the existing authentic license can be used only until its original
signed expiry. The customer runtime then fails closed. A long outage, missed
job, wrong credential, clock error or unpaid renewal can interrupt licensed
organization operations. A near-boundary paid term can expire before the next
scheduled run, so monitor expiry and renewal failures locally. Free SDK receipt
verification is unaffected. A successful refresh does not promise instantaneous
remote revocation: already-issued offline grants remain valid until their signed
expiry or deliberate local removal/replacement.

## Acceptance scope

The source tests exercise real P-256/Ed25519 cryptography, encrypted-backup
compatibility, exact challenge binding, invalid grants, private-file checks,
atomic replacement, concurrent renewals, bounded transport and generic error
output. A production-shaped case creates the backup through the unchanged
browser module and submits proofs to the unchanged license service, with only
the payment adapter substituted. All keys and identities in that test are
synthetic; it does not contact the public license host or make a payment.

```sh
PYTHONPATH=control_plane python -m pytest -q \
  control_plane/deploy/test_renew_license.py
```

The browser-format case requires the sibling site checkout, Playwright and
`/usr/bin/chromium` in the test environment. Tests do not install a production
scheduled job or establish that every operating system, customer identity
provider, hardware keystore or private network is supported.
