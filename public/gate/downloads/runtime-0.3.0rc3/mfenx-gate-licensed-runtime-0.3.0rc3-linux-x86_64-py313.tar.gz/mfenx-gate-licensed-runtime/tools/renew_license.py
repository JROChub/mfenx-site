#!/usr/bin/env python3
"""Customer-operated, one-shot Team/Business license renewal.

This separate delivery tool does not alter the frozen control-plane wheel. It
uses the customer's encrypted browser recovery file and a local credential;
neither is uploaded. Only two existing, proof-bound license API calls are used.
The CLI never contacts Paddle, creates purchases, changes plans or starts a timer.
"""

from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
from dataclasses import dataclass
import fcntl
import hashlib
import json
import os
from pathlib import PurePath
import re
import secrets
import signal
import stat
import sys
import time
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import httpx

from gate_control.license_verify import LicenseError, canonical, parse, verify_license


ITERATIONS = 600_000
RENEW_BEFORE = 12 * 3600
MAX_RESPONSE = 8192
PROCESS_DEADLINE = 45


class RenewalError(ValueError):
    """Errors deliberately contain no payload, path, key or provider response."""


def require(condition, message):
    if not condition:
        raise RenewalError(message)


def object_keys(value, keys):
    return isinstance(value, dict) and set(value) == set(keys)


def strict_json(raw, maximum):
    require(isinstance(raw, bytes) and len(raw) <= maximum, "Oversized document.")

    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate document member.")
            result[key] = value
        return result

    def constant(_):
        raise RenewalError("Non-finite document value.")

    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError):
        raise RenewalError("Invalid document.") from None


def decode(value, maximum, length=None):
    require(isinstance(value, str) and len(value) <= maximum, "Invalid encoded key data.")
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, TypeError):
        raise RenewalError("Invalid encoded key data.") from None
    require(base64.b64encode(raw).decode() == value and (length is None or len(raw) == length),
            "Non-canonical key data.")
    return raw


@contextmanager
def private_parent(path):
    require(isinstance(path, str) and path.startswith("/") and "\x00" not in path
            and ".." not in PurePath(path).parts, "An absolute private file path is required.")
    parts = PurePath(path).parts[1:]
    require(bool(parts), "A regular file path is required.")
    directory = None
    try:
        directory = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        for component in parts[:-1]:
            next_directory = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                     dir_fd=directory)
            os.close(directory)
            directory = next_directory
        info = os.fstat(directory)
        require(info.st_uid == os.geteuid() and stat.S_IMODE(info.st_mode) == 0o700,
                "The containing directory must be owned by this user and mode 0700.")
        yield directory, parts[-1]
    except OSError:
        raise RenewalError("Private file access failed.") from None
    finally:
        if directory is not None:
            os.close(directory)


def check_private(info, maximum):
    require(stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid() and info.st_nlink == 1
            and stat.S_IMODE(info.st_mode) == 0o600 and info.st_size <= maximum,
            "A bounded, privately owned mode-0600 regular file is required.")


def read_at(directory, name, maximum, *, optional=False):
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=directory)
    except FileNotFoundError:
        if optional:
            return None
        raise RenewalError("Required private file is unavailable.") from None
    try:
        check_private(os.fstat(fd), maximum)
        chunks, left = [], maximum + 1
        while left:
            chunk = os.read(fd, left)
            if not chunk:
                break
            chunks.append(chunk)
            left -= len(chunk)
        raw = b"".join(chunks)
        require(len(raw) <= maximum, "Private file exceeded its size limit.")
        return raw
    finally:
        os.close(fd)


def read_private(path, maximum):
    with private_parent(path) as (directory, name):
        return read_at(directory, name, maximum)


@contextmanager
def output_lock(path):
    with private_parent(path) as (directory, name):
        require(not name.startswith(".mfenx-renew-"), "Reserved output filename.")
        lock = os.open(".mfenx-renew-lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                       0o600, dir_fd=directory)
        try:
            check_private(os.fstat(lock), 0)
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RenewalError("Another renewal is running in this directory.") from None
            yield directory, name
        finally:
            os.close(lock)


def publish(directory, name, raw, previous):
    """Verify all failure-prone preparation before the same-directory rename."""
    require(read_at(directory, name, MAX_RESPONSE, optional=True) == previous,
            "The local license changed during renewal.")
    temporary = ".mfenx-renew-" + secrets.token_hex(16)
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=directory)
    renamed = False
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        require(read_at(directory, name, MAX_RESPONSE, optional=True) == previous,
                "The local license changed during renewal.")
        os.replace(temporary, name, src_dir_fd=directory, dst_dir_fd=directory)
        renamed = True
        # A directory fsync failure is post-publication uncertainty, not a claim
        # that the old file survived. The new file was fully checked before rename.
        try:
            os.fsync(directory)
        except OSError:
            raise RenewalError("Verified license installed; directory durability could not be confirmed.") from None
    finally:
        if not renamed:
            try:
                os.unlink(temporary, dir_fd=directory)
            except FileNotFoundError:
                pass


@dataclass(frozen=True)
class Settings:
    origin: str
    issuer: str
    issuer_key: str
    key_id: str
    holder_sha256: str
    license_id: str
    plan: str
    environment: str
    recovery_file: str
    passphrase_file: str
    output: str

    def validate(self):
        try:
            parsed = urlsplit(self.origin)
            host = parsed.hostname or ""
            valid = (parsed.scheme == "https" and parsed.netloc == host and parsed.port is None
                     and "." in host and all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
                                             for label in host.split("."))
                     and not parsed.path and not parsed.query and not parsed.fragment)
        except ValueError:
            valid = False
        require(valid and self.issuer == self.origin, "Pin an exact HTTPS origin and matching issuer.")
        require(bool(re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", self.key_id)), "Invalid pinned issuer key ID.")
        require(bool(re.fullmatch(r"sha256:[a-f0-9]{64}", self.holder_sha256)), "Invalid pinned holder.")
        require(bool(re.fullmatch(r"lic_[a-f0-9]{32}", self.license_id)), "Invalid pinned license ID.")
        require(self.plan in ("team", "business") and self.environment in ("live", "sandbox"),
                "Renewal requires a pinned Team/Business plan and environment.")
        require(len({self.output, self.recovery_file, self.passphrase_file, self.issuer_key}) == 4,
                "License, key, recovery and credential paths must be distinct.")


def recover_key(settings):
    backup = strict_json(read_private(settings.recovery_file, 16_384), 16_384)
    require(object_keys(backup, {"format", "version", "key_id", "public_key_spki_base64", "encryption"})
            and backup["format"] == "mfenx-license-key-backup" and type(backup["version"]) is int
            and backup["version"] == 1 and backup["key_id"] == settings.holder_sha256,
            "Unsupported or wrong-holder recovery file.")
    encryption = backup["encryption"]
    require(object_keys(encryption, {"kdf", "iterations", "salt_base64", "cipher", "iv_base64", "ciphertext_base64"})
            and encryption["kdf"] == "PBKDF2-SHA256" and type(encryption["iterations"]) is int
            and encryption["iterations"] == ITERATIONS and encryption["cipher"] == "AES-256-GCM",
            "Unsupported recovery encryption.")
    public = decode(backup["public_key_spki_base64"], 256, 91)
    require("sha256:" + hashlib.sha256(public).hexdigest() == settings.holder_sha256,
            "Recovery public identity does not match the pinned holder.")
    salt, iv = decode(encryption["salt_base64"], 32, 16), decode(encryption["iv_base64"], 24, 12)
    ciphertext = decode(encryption["ciphertext_base64"], 2048)
    require(len(ciphertext) >= 32, "Invalid recovery ciphertext.")
    password = read_private(settings.passphrase_file, 1024)
    try:
        require(len(password.decode("utf-8")) >= 12, "Invalid local recovery credential.")
    except UnicodeError:
        raise RenewalError("Invalid local recovery credential.") from None
    aad = ("mfenx:license-key-backup:v1\n" + backup["key_id"] + "\n" +
           backup["public_key_spki_base64"] + "\n" + str(ITERATIONS)).encode()
    wrapping = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITERATIONS).derive(password)
    try:
        pkcs8 = AESGCM(wrapping).decrypt(iv, ciphertext, aad)
        key = serialization.load_der_private_key(pkcs8, password=None)
        require(isinstance(key, ec.EllipticCurvePrivateKey) and isinstance(key.curve, ec.SECP256R1),
                "Recovery requires a P-256 private key.")
        derived = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        require(derived == public, "Recovered private and public keys do not match.")
    except (InvalidTag, ValueError, TypeError):
        raise RenewalError("Recovery credential or encrypted key was rejected.") from None
    # Python/library immutable buffers cannot provide a reliable zeroization
    # guarantee. No private material is serialized or logged by this tool.
    return key, backup["public_key_spki_base64"]


class HTTPS:
    """Production transport: CA/hostname validation, no proxies/redirects."""

    def post(self, url, body):
        try:
            with httpx.Client(verify=True, trust_env=False, follow_redirects=False,
                              timeout=httpx.Timeout(10, connect=5),
                              limits=httpx.Limits(max_connections=1, max_keepalive_connections=0)) as client:
                with client.stream("POST", url, content=canonical(body),
                                   headers={"Content-Type": "application/json", "Accept": "application/json",
                                            "Accept-Encoding": "identity"}) as response:
                    require(response.status_code == 200, "Licensing request rejected or unavailable.")
                    require(response.headers.get("content-type", "").split(";", 1)[0].lower() == "application/json"
                            and response.headers.get("content-encoding", "identity").lower() == "identity",
                            "Unsupported licensing response.")
                    chunks, size, started = [], 0, time.monotonic()
                    for chunk in response.iter_raw(chunk_size=MAX_RESPONSE + 1):
                        size += len(chunk)
                        require(size <= MAX_RESPONSE and time.monotonic() - started < 20,
                                "Licensing response exceeded its limits.")
                        chunks.append(chunk)
                    return strict_json(b"".join(chunks), MAX_RESPONSE)
        except httpx.HTTPError:
            raise RenewalError("Secure licensing connection failed.") from None


def verified(raw, settings, issuer_key, now):
    payload = verify_license(raw, issuer_public_key=issuer_key, key_id=settings.key_id, issuer=settings.issuer,
                             holder_key_sha256=settings.holder_sha256, environment=settings.environment, now=now)
    require(payload["license_id"] == settings.license_id and payload["plan"] == settings.plan,
            "License does not match the pinned purchase and plan.")
    return payload


def renew(settings, *, transport=None, clock=time.time):
    settings.validate()
    issuer_key = read_private(settings.issuer_key, 4096)
    # Validate the public trust-key type before decrypting a customer credential.
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    require(isinstance(serialization.load_pem_public_key(issuer_key), Ed25519PublicKey),
            "An independently pinned Ed25519 issuer key is required.")
    with output_lock(settings.output) as (directory, name):
        previous = read_at(directory, name, MAX_RESPONSE, optional=True)
        old = None
        if previous is not None:
            document = parse(previous)
            issued = document.get("payload", {}).get("issued_at") if isinstance(document, dict) else None
            require(type(issued) is int and 0 <= issued <= int(clock()), "Existing license cannot be authenticated.")
            # An expired but authentic same-purchase license may be replaced;
            # arbitrary, malformed, future or differently bound files may not.
            old = verified(previous, settings, issuer_key, issued)
            if old["expires_at"] - int(clock()) > RENEW_BEFORE:
                return {"status": "CURRENT", "expires_at": old["expires_at"]}
        key, spki = recover_key(settings)
        transport = transport or HTTPS()
        request = {"license_id": settings.license_id}
        challenge = transport.post(settings.origin + "/v1/licenses/challenge",
                                   {"public_key_spki_base64": spki, "action": "download", "request": request})
        require(object_keys(challenge, {"challenge_id", "message", "expires_at"})
                and isinstance(challenge["challenge_id"], str)
                and bool(re.fullmatch(r"[a-f0-9]{64}", challenge["challenge_id"]))
                and type(challenge["expires_at"]) is int
                and int(clock()) < challenge["expires_at"] <= int(clock()) + 120,
                "Invalid or expired licensing challenge.")
        expected = canonical({"domain": "mfenx.license.proof.v1", "origin": settings.origin,
                              "action": "download", "key_sha256": settings.holder_sha256,
                              "request_sha256": "sha256:" + hashlib.sha256(canonical(request)).hexdigest(),
                              "nonce": challenge["challenge_id"], "expires_at": challenge["expires_at"]})
        require(challenge["message"] == expected.decode("ascii"), "Challenge request binding was rejected.")
        der = key.sign(expected, ec.ECDSA(hashes.SHA256()))
        r, s = utils.decode_dss_signature(der)
        require(int(clock()) < challenge["expires_at"], "Licensing challenge expired before submission.")
        result = transport.post(settings.origin + "/v1/licenses/download",
                                {"public_key_spki_base64": spki, "request": request,
                                 "challenge_id": challenge["challenge_id"],
                                 "signature_base64": base64.b64encode(r.to_bytes(32, "big") + s.to_bytes(32, "big")).decode()})
        raw = canonical(result)
        payload = verified(raw, settings, issuer_key, int(clock()))
        require(old is None or payload["issued_at"] >= old["issued_at"], "Older license result rejected.")
        with private_parent(settings.output) as (current_directory, _):
            original_info, current_info = os.fstat(directory), os.fstat(current_directory)
            require((original_info.st_dev, original_info.st_ino) == (current_info.st_dev, current_info.st_ino),
                    "The license directory changed during renewal.")
        publish(directory, name, raw, previous)
        return {"status": "RENEWED", "expires_at": payload["expires_at"]}


def main(argv=None):
    parser = argparse.ArgumentParser(description="Renew an existing customer-held Team/Business software license")
    for name in ("origin", "issuer", "issuer-key", "key-id", "holder-sha256", "license-id",
                 "recovery-file", "passphrase-file", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--plan", choices=("team", "business"), required=True)
    parser.add_argument("--environment", choices=("live", "sandbox"), default="live")
    args = parser.parse_args(argv)

    def deadline(_signum, _frame):
        raise RenewalError("Renewal process deadline exceeded.")

    previous_handler = signal.signal(signal.SIGALRM, deadline)
    signal.setitimer(signal.ITIMER_REAL, PROCESS_DEADLINE)
    try:
        result = renew(Settings(**vars(args)))
        print(json.dumps(result, sort_keys=True))
        return 0
    except Exception:
        # Never emit provider bodies, credential paths, tracebacks or exception
        # strings. Inspect the license locally to resolve publication uncertainty.
        print("License renewal did not complete; inspect local license validity.", file=sys.stderr)
        return 1
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


if __name__ == "__main__":
    raise SystemExit(main())
