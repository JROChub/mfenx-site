r"""Repeatable, offline installed-wheel acceptance for the customer runtime.

Run with the Python version matching the supplied locked wheelhouse, for example:
  python3.13 control_plane/deploy/test_private_install.py \
    --wheel control_plane/dist/mfenx_gate_control_plane-0.3.0rc2-py3-none-any.whl \
    --wheelhouse control_plane/dist/wheelhouse

Creates and removes a temporary venv, installs only supplied local artifacts,
then tests the installed application over real loopback HTTP. Every license,
identity and receipt is synthetic. There are no production credentials, provider
calls, external listeners or customer deployment changes. JSON-lines report
actual measured cases; failures return a nonzero exit status. This is installed
candidate acceptance, not live-payment, production-OIDC or deployment evidence.
Python-level connection/DNS/UDP guards are test doubles, not an OS network sandbox.
"""

from __future__ import annotations

import argparse
import email.parser
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import zipfile


def report(case, status, started, **details):
    print(json.dumps({"case": case, "status": status,
                      "elapsed_seconds": round(time.monotonic() - started, 4),
                      **details}, sort_keys=True), flush=True)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def installed_acceptance(scratch, expected_version):
    # Imports deliberately happen only inside the isolated installed interpreter.
    import base64
    from datetime import datetime, timedelta, timezone
    import http.client
    import socket
    import threading

    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from fastapi import HTTPException
    import gate_control.licensed_app as licensed_module
    from gate_control.config import PLANS, Settings
    from gate_control.license_runtime import RuntimeSettings
    from gate_control.providers import Billing
    import mfenx_gate
    from mfenx_gate.receipt import _sign, generate_keypair, sha256
    import uvicorn

    total_started, passed = time.monotonic(), 0

    def check(name, function):
        nonlocal passed
        started = time.monotonic()
        try:
            function()
        except Exception as error:
            report(name, "fail", started, error=str(error), error_type=type(error).__name__)
            raise
        passed += 1
        report(name, "pass", started)

    def installed_identity():
        prefix = Path(sys.prefix).resolve()
        require(prefix != Path(sys.base_prefix).resolve(), "Acceptance must run inside its temporary venv")
        for module in (licensed_module, mfenx_gate, uvicorn):
            require(Path(module.__file__).resolve().is_relative_to(prefix),
                    "A runtime module was imported from outside the isolated installation")
        require(importlib.metadata.version("mfenx-gate-control-plane") == expected_version,
                "Installed control-plane version differs from supplied wheel")
        require(importlib.metadata.version("mfenx-gate") == "1.0.0", "Free SDK version was changed")

    check("installed_distribution_identity", installed_identity)
    now = [int(time.time())]
    issuer_key, holder_key = Ed25519PrivateKey.generate(), Ed25519PrivateKey.generate()
    license_path, issuer_path = scratch / "license.json", scratch / "trusted-issuer.pem"
    issuer_path.write_bytes(issuer_key.public_key().public_bytes(serialization.Encoding.PEM,
                                                                serialization.PublicFormat.SubjectPublicKeyInfo))
    holder_public = holder_key.public_key().public_bytes(serialization.Encoding.DER,
                                                       serialization.PublicFormat.SubjectPublicKeyInfo)
    holder_digest = "sha256:" + hashlib.sha256(holder_public).hexdigest()
    issuer, key_id = "https://synthetic-issuer.invalid", "synthetic-install-issuer-1"

    def canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode()

    def replace_license(plan="team", **changes):
        payload = {"schema": "mfenx.gate.key-entitlement.v1", "license_id": "lic_" + "a" * 32,
                   "holder_key_sha256": holder_digest, "plan": plan, "issued_at": now[0] - 1,
                   "expires_at": now[0] + (365 * 86400 if plan == "private" else 600),
                   "environment": "live", "issuer": issuer, "key_id": key_id,
                   "verification_metered": False, "usage_telemetry": False, **changes}
        envelope = {"payload": payload, "algorithm": "Ed25519", "key_id": key_id,
                    "signature": base64.b64encode(issuer_key.sign(canonical(payload))).decode()}
        temporary = scratch / "replacement.json"
        temporary.write_bytes(canonical(envelope))
        os.replace(temporary, license_path)

    replace_license()
    attempts = {"billing": 0, "external_network": 0}

    def denied_billing(*_args, **_kwargs):
        attempts["billing"] += 1
        raise AssertionError("Customer runtime attempted a hosted billing operation")

    # Explicit fail-fast provider double, not merely omitted credentials.
    Billing.__init__ = denied_billing
    Billing._request = denied_billing

    class CustomerIdentity:
        def verify_claims(self, token):
            if token not in ("synthetic-alice", "synthetic-bob"):
                raise HTTPException(401, "Synthetic customer identity rejected")
            return {"iss": "https://synthetic-customer-identity.invalid", "sub": token}

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(("127.0.0.1", 0))
    listener.listen(32)
    port = listener.getsockname()[1]
    original_connect, original_connect_ex, original_resolve = socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo
    original_sendto = socket.socket.sendto

    def permit(address):
        if not (isinstance(address, tuple) and len(address) >= 2 and address[:2] == ("127.0.0.1", port)):
            attempts["external_network"] += 1
            raise AssertionError("Acceptance runtime attempted outbound networking")

    def guarded_connect(sock, address):
        permit(address)
        return original_connect(sock, address)

    def guarded_connect_ex(sock, address):
        permit(address)
        return original_connect_ex(sock, address)

    def guarded_resolve(host, target_port, *args, **kwargs):
        permit((host, target_port))
        return original_resolve(host, target_port, *args, **kwargs)

    def denied_datagram(*_args, **_kwargs):
        attempts["external_network"] += 1
        raise AssertionError("Acceptance runtime attempted a datagram send")

    socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo = guarded_connect, guarded_connect_ex, guarded_resolve
    socket.socket.sendto = denied_datagram
    server = thread = None
    try:
        settings = Settings(database=str(scratch / "customer.sqlite3"),
                            public_origin="https://synthetic-customer.invalid")
        runtime = RuntimeSettings(license_file=str(license_path), issuer_key_file=str(issuer_path),
                                  issuer=issuer, key_id=key_id, holder_sha256=holder_digest,
                                  default_org_plan="private")
        app = licensed_module.create_app(settings, license_settings=runtime,
                                         oidc=CustomerIdentity(), clock=lambda: now[0])
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, loop="asyncio", ws="none",
                                                lifespan="off", access_log=False, log_level="critical",
                                                timeout_graceful_shutdown=2))
        thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=True)
        thread.start()

        def request(method, path, *, token=None, body=None, headers=None):
            connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
            configured = dict(headers or {})
            if token:
                configured["Authorization"] = "Bearer " + token
            if body is not None:
                configured["Content-Type"] = "application/json"
            try:
                connection.request(method, path, body=canonical(body) if body is not None else None, headers=configured)
                response = connection.getresponse()
                raw = response.read(65_537)
                require(len(raw) <= 65_536, "HTTP response exceeded acceptance bound")
                return response.status, json.loads(raw)
            finally:
                connection.close()

        def ready():
            deadline = time.monotonic() + 10
            while not server.started and thread.is_alive() and time.monotonic() < deadline:
                time.sleep(0.01)
            require(server.started and thread.is_alive(), "Installed HTTP runtime did not start")
            status, health = request("GET", "/health")
            require(status == 200 and health["paid_features_available"] is True, "Valid license failed HTTP readiness")
            require(health["hosted_billing_enabled"] is False and health["verification_metered"] is False,
                    "Runtime reported unexpected billing/verification policy")

        check("real_loopback_http_startup", ready)
        owner, other = "synthetic-alice", "synthetic-bob"
        status, account = request("POST", "/v1/account", token=owner, body={"organization_name": "Synthetic customer"})
        require(status == 200, "Synthetic customer could not create its own organization")
        org = account["organizations"][0]["id"]

        for plan in ("team", "business", "private"):
            def paid_plan(plan=plan):
                replace_license(plan)
                status, usage = request("GET", f"/v1/orgs/{org}/usage", token=owner)
                require(status == 200 and usage["plan"] == plan, "Signed software plan was not the effective local ceiling")
                require(usage["allowance"] == PLANS[plan]["monthly_receipts"] and usage["billing_configured"] is False,
                        "Local plan allowance or hosted-billing isolation is incorrect")
                status, issued = request("POST", f"/v1/orgs/{org}/tokens", token=owner,
                                         body={"scopes": ["receipts:read"]})
                require(status == 200, "Owner could not issue a scoped customer token")
                scoped = issued["token"]
                require(request("GET", f"/v1/orgs/{org}/receipts", token=scoped)[0] == 200,
                        "Valid receipt-read scope was rejected")
                require(request("GET", f"/v1/orgs/{org}/usage", token=scoped)[0] == 403,
                        "CLI token bypassed account-only authorization")
                require(request("POST", f"/v1/orgs/{org}/tokens", token=scoped,
                                body={"scopes": ["receipts:read"]})[0] == 403,
                        "Scoped CLI token could mint another token")
            check("signed_" + plan + "_scoped_access_and_plan", paid_plan)

        def tenant_checks():
            require(request("GET", f"/v1/orgs/{org}/receipts")[0] == 401, "License replaced authentication")
            require(request("POST", "/v1/account", token=other, body={"organization_name": "Other synthetic customer"})[0] == 200,
                    "Other synthetic identity could not register")
            require(request("GET", f"/v1/orgs/{org}/receipts", token=other)[0] == 403, "License bypassed tenant membership")

        check("customer_authentication_and_tenant_isolation", tenant_checks)
        receipt_private, receipt_public = generate_keypair()
        instant = datetime.fromtimestamp(now[0], timezone.utc)
        statement = {"id": "installed-license-acceptance",
                     "issued_at": (instant - timedelta(seconds=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                     "expires_at": (instant + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                     "profile": "onnx-finite-evaluation/v1",
                     "artifact": {"format": "onnx", "sha256": "sha256:" + "2" * 64, "bytes": 123},
                     "parent_sha256": "sha256:" + "3" * 64, "contract_sha256": "sha256:" + "1" * 64,
                     "evaluation": {"decision": "PASS", "report_sha256": "sha256:" + "4" * 64,
                                    "samples": 1000, "source_correct": 990, "candidate_correct": 990,
                                    "decision_changes": 0, "candidate_p95_latency_ns": 10000}}
        raw_receipt = _sign(statement, receipt_private, "Synthetic customer receipt issuer")
        receipt_body = {"receipt_json": raw_receipt.decode(), "retain_metadata": True}
        receipt_headers = {"Idempotency-Key": "synthetic-install-once"}

        def governed_receipt():
            require(request("POST", f"/v1/orgs/{org}/issuer-keys", token=owner, body={
                "public_key_spki_base64": base64.b64encode(receipt_public).decode()})[0] == 200, "Receipt key registration failed")
            require(request("POST", f"/v1/orgs/{org}/policies", token=owner, body={
                "evaluation_contract_sha256": "1" * 64, "allowed_issuer_key_ids": [sha256(receipt_public)],
                "allowed_formats": ["onnx"]})[0] == 200, "Customer policy registration failed")
            status, result = request("POST", f"/v1/orgs/{org}/receipts", token=owner,
                                     body=receipt_body, headers=receipt_headers)
            require(status == 200 and result["registered"] is True and result["deployment_authorized"] is False,
                    "Governed receipt registration failed or falsely authorized deployment")

        check("governed_receipt_http_registration", governed_receipt)
        for label, changes in (("expired", {"expires_at": now[0]}),
                               ("wrong_issuer", {"issuer": "https://other-issuer.invalid"}),
                               ("wrong_holder", {"holder_key_sha256": "sha256:" + "c" * 64}),
                               ("wrong_environment", {"environment": "sandbox"})):
            def rejected(changes=changes):
                replace_license(**changes)
                require(request("GET", f"/v1/orgs/{org}/receipts", token=owner)[0] == 503, "Invalid license exposed governed data")
                require(request("POST", f"/v1/orgs/{org}/tokens", token=owner,
                                body={"scopes": ["receipts:read"]})[0] == 503, "Invalid license allowed a paid mutation")
                require(request("POST", f"/v1/orgs/{org}/receipts", token=owner,
                                body=receipt_body, headers=receipt_headers)[0] == 503, "Invalid license allowed an idempotent replay")
                status, health = request("GET", "/health")
                require(status == 200 and health["paid_features_available"] is False, "Invalid license readiness failed closed incorrectly")
            check("signed_" + label + "_license_denied", rejected)

        def free_verification():
            license_path.unlink()
            require(request("GET", f"/v1/orgs/{org}/usage", token=owner)[0] == 503, "Missing license enabled governed service")
            verified = mfenx_gate.verify_receipt(raw_receipt, receipt_public,
                                                now=datetime.fromtimestamp(now[0], timezone.utc))
            require(verified["status"] == "ATTESTATION_VERIFIED", "Free local SDK verification was gated by a license")

        check("free_sdk_verification_without_software_license", free_verification)

        def restore():
            replace_license("team")
            status, usage = request("GET", f"/v1/orgs/{org}/usage", token=owner)
            require(status == 200 and usage["plan"] == "team" and usage["managed_registrations"] == 1,
                    "Atomic license restoration failed or denied requests changed usage")

        check("atomic_renewal_without_restart", restore)

        def no_hosted_billing():
            for path in (f"/v1/orgs/{org}/billing/checkout", f"/v1/orgs/{org}/billing/portal",
                         "/v1/billing/paddle/webhook", f"/v1/orgs/{org}/entitlements/offline"):
                require(request("POST", path, token=owner, body={"plan": "team"})[0] == 404,
                        "Customer runtime exposed a hosted billing operation")
            require(attempts == {"billing": 0, "external_network": 0}, "Acceptance observed provider/network attempts")

        check("no_paddle_or_external_network_calls", no_hosted_billing)
        report("installed_runtime_summary", "pass", total_started, passed=passed,
               control_plane_version=expected_version, sdk_version="1.0.0", synthetic_only=True,
               billing_attempts=attempts["billing"], external_network_attempts=attempts["external_network"])
        return 0
    finally:
        if server is not None:
            server.should_exit = True
        if thread is not None:
            thread.join(timeout=5)
            if thread.is_alive():
                raise RuntimeError("Temporary HTTP runtime did not stop")
        listener.close()
        socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo = original_connect, original_connect_ex, original_resolve
        socket.socket.sendto = original_sendto


def run_offline_install(args):
    started = time.monotonic()
    wheel, wheelhouse, requirements = args.wheel.resolve(), args.wheelhouse.resolve(), args.requirements.resolve()
    require(wheel.is_file() and wheel.suffix == ".whl", "--wheel must name an existing wheel")
    require(wheelhouse.is_dir() and requirements.is_file(), "A local wheelhouse and requirements lock are required")
    locked = [line.strip() for line in requirements.read_text().splitlines()
              if line.strip() and not line.lstrip().startswith("#")]
    require(bool(locked) and all(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*==[A-Za-z0-9][A-Za-z0-9_.+!-]*", line)
                                 for line in locked),
            "Lock must contain only exact name==version entries, never URLs or pip options")
    with zipfile.ZipFile(wheel) as archive:
        metadata_names = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
        require(len(metadata_names) == 1, "Wheel metadata is ambiguous")
        metadata = email.parser.BytesParser().parsebytes(archive.read(metadata_names[0]))
        require(metadata["Name"] == "mfenx-gate-control-plane", "Wheel is not the customer control-plane distribution")
        expected_version = metadata["Version"]
    # No customer GATE_*, Python import path, proxy or credential variables enter
    # the subprocess. --isolated ignores user pip config; the explicit null
    # config disables global/site config too (including remote find-links).
    environment = {"PATH": os.defpath, "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
                   "PIP_CONFIG_FILE": os.devnull}
    with tempfile.TemporaryDirectory(prefix="mfenx-private-install-") as temporary:
        scratch = Path(temporary).resolve()
        venv = scratch / "venv"

        def command(case, arguments, timeout=180):
            case_started = time.monotonic()
            result = subprocess.run(arguments, cwd=scratch, env=environment, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
            if result.returncode:
                report(case, "fail", case_started, exit_code=result.returncode, output=result.stdout[-12_000:])
                raise RuntimeError(case + " failed")
            report(case, "pass", case_started)

        command("create_isolated_venv", [sys.executable, "-I", "-m", "venv", str(venv)])
        python = venv / "bin/python"
        pip = [str(python), "-I", "-m", "pip", "--isolated", "--disable-pip-version-check", "install",
               "--no-index", "--no-cache-dir", "--only-binary=:all:"]
        # The lock is the complete flattened dependency set. Do not follow a
        # wheel's direct-URL Requires-Dist metadata even when --no-index is set.
        command("offline_locked_dependencies", [*pip, "--no-deps", "--find-links", str(wheelhouse), "-r", str(requirements)])
        command("offline_candidate_wheel", [*pip, "--no-deps", str(wheel)])
        command("installed_dependency_closure", [str(python), "-I", "-m", "pip", "--isolated",
                                                  "--disable-pip-version-check", "check"])
        report("artifact_identity", "pass", started, wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
               requirements_sha256=hashlib.sha256(requirements.read_bytes()).hexdigest(),
               control_plane_version=expected_version)
        result = subprocess.run([str(python), "-I", str(Path(__file__).resolve()), "--_worker", str(scratch),
                                 "--_expected-version", expected_version], cwd=scratch, env=environment, timeout=90)
        require(result.returncode == 0, "Installed HTTP acceptance failed")
    report("temporary_environment_cleanup", "pass", started, removed=True)
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--wheel", type=Path, help="Exact candidate control-plane wheel to install")
    parser.add_argument("--wheelhouse", type=Path, help="Offline wheels for every locked dependency")
    parser.add_argument("--requirements", type=Path, default=Path(__file__).resolve().parents[1] / "requirements.lock")
    parser.add_argument("--_worker", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--_expected-version", help=argparse.SUPPRESS)
    args = parser.parse_args()
    started = time.monotonic()
    try:
        if args._worker:
            return installed_acceptance(args._worker, args._expected_version)
        if not args.wheel or not args.wheelhouse:
            parser.error("--wheel and --wheelhouse are required")
        return run_offline_install(args)
    except Exception as error:
        report("acceptance_summary", "fail", started, error=str(error), error_type=type(error).__name__)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
