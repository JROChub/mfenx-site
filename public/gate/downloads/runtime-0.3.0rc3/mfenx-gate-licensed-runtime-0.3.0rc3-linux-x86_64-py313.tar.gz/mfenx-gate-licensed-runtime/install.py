"""Install the authenticated, extracted runtime bundle into a NEW local venv.

This script checks integrity, not release authenticity. Independently authenticate
the archive digest before extracting or executing it. No service is started and
no customer license, signing key or identity-provider configuration is generated.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import subprocess
import sys


class InstallError(Exception):
    pass


def directory_fd(path, *, trusted=False):
    """Walk absolute directory components without following any symlink."""
    if not path.is_absolute() or ".." in path.parts:
        raise InstallError("An absolute non-traversing directory is required")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for component in path.parts[1:]:
            next_fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = next_fd
            if trusted:
                info = os.fstat(fd)
                sticky_root = info.st_uid == 0 and bool(info.st_mode & stat.S_ISVTX)
                if info.st_uid not in (0, os.getuid()) or (info.st_mode & 0o022 and not sticky_root):
                    raise InstallError("Destination ancestry must be owner-controlled")
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_file(root, name):
    relative = PurePosixPath(name)
    if (relative.is_absolute() or ".." in relative.parts or str(relative) != name
            or not re.fullmatch(r"[A-Za-z0-9_.+/-]+", name)):
        raise InstallError("Unsafe bundle path")
    directory = directory_fd(root / relative.parent)
    try:
        fd = os.open(relative.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    finally:
        os.close(directory)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 20_000_000:
            raise InstallError("Unsafe or oversized bundle file")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(20_000_001)
        if len(raw) > 20_000_000:
            raise InstallError("Oversized bundle file")
        return raw
    finally:
        os.close(fd)


def verify_bundle(root):
    lines = read_file(root, "SHA256SUMS").decode("ascii").splitlines()
    if not 25 <= len(lines) <= 256:
        raise InstallError("Unexpected manifest size")
    expected = {}
    for line in lines:
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match or match[2] in expected or match[2] == "SHA256SUMS":
            raise InstallError("Malformed or duplicate manifest entry")
        expected[match[2]] = match[1]
        if hashlib.sha256(read_file(root, match[2])).hexdigest() != match[1]:
            raise InstallError("Bundle digest mismatch")
    observed = set()
    for parent, directories, files in os.walk(root, followlinks=False):
        for name in directories:
            if (Path(parent) / name).is_symlink():
                raise InstallError("Bundle directory symlink rejected")
        observed.update(str((Path(parent) / name).relative_to(root)) for name in files)
    if observed != set(expected) | {"SHA256SUMS"}:
        raise InstallError("Unexpected or missing bundle files")
    requirements = read_file(root, "requirements.txt").decode("ascii").splitlines()
    if len(requirements) != 22:
        raise InstallError("Expected exactly 22 locked runtime wheels")
    hashes, names = set(), set()
    for requirement in requirements:
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+!-]+) --hash=sha256:([0-9a-f]{64})", requirement)
        if not match:
            raise InstallError("Only exact hashed package requirements are permitted")
        name = re.sub(r"[-_.]+", "-", match[1]).lower()
        if name in names:
            raise InstallError("Duplicate package requirement")
        names.add(name)
        hashes.add(match[3])
    wheel_hashes = {value for name, value in expected.items() if name.startswith("wheelhouse/") and name.endswith(".whl")}
    if len(wheel_hashes) != 22 or wheel_hashes != hashes:
        raise InstallError("Requirements and wheel inventory differ")
    return expected


def check_platform():
    libc, version = platform.libc_ver()
    if (sys.implementation.name != "cpython" or sys.version_info[:2] != (3, 13)
            or platform.system() != "Linux" or platform.machine() != "x86_64"
            or libc != "glibc" or not re.fullmatch(r"\d+\.\d+(?:\.\d+)?", version)
            or tuple(map(int, version.split(".")[:2])) < (2, 34)):
        raise InstallError("This bundle requires CPython 3.13 on Linux x86_64 with glibc >= 2.34")


def install(root, destination):
    check_platform()
    verify_bundle(root)
    if not destination.is_absolute() or ".." in destination.parts:
        raise InstallError("Destination must be an absolute non-traversing path")
    if destination.is_relative_to(root):
        raise InstallError("Destination must be outside the extracted bundle")
    parent = directory_fd(destination.parent, trusted=True)
    try:
        # mkdir is exclusive, including against dangling symlinks. Existing
        # environments are never reused or overwritten.
        os.mkdir(destination.name, mode=0o700, dir_fd=parent)
        parent_identity = os.fstat(parent)
        destination_identity = os.stat(destination.name, dir_fd=parent, follow_symlinks=False)
    except BaseException:
        os.close(parent)
        raise
    environment = {"PATH": os.defpath, "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
                   "PIP_CONFIG_FILE": os.devnull}

    def run(arguments):
        def unchanged():
            checked = directory_fd(destination.parent, trusted=True)
            try:
                current_parent = os.fstat(checked)
                current = os.stat(destination.name, dir_fd=checked, follow_symlinks=False)
                if ((current_parent.st_dev, current_parent.st_ino) != (parent_identity.st_dev, parent_identity.st_ino)
                        or not stat.S_ISDIR(current.st_mode)
                        or (current.st_dev, current.st_ino) != (destination_identity.st_dev, destination_identity.st_ino)
                        or current.st_uid != os.getuid() or stat.S_IMODE(current.st_mode) != 0o700):
                    raise InstallError("Installation destination changed during execution")
            finally:
                os.close(checked)
        unchanged()
        subprocess.run(arguments, cwd=destination, env=environment, check=True, timeout=180)
        unchanged()

    # A failure intentionally leaves the new incomplete directory for inspection;
    # never recursively delete a caller-selected path.
    try:
        run([sys.executable, "-I", "-m", "venv", str(destination)])
        python = str(destination / "bin/python")
        pip = [python, "-I", "-m", "pip", "--isolated", "--disable-pip-version-check"]
        run([*pip, "install", "--no-index", "--no-cache-dir", "--no-deps", "--only-binary=:all:",
             "--require-hashes", "--find-links", str(root / "wheelhouse"), "-r", str(root / "requirements.txt")])
        run([*pip, "check"])
        run([python, "-I", "-c", "from importlib.metadata import version; "
             "assert version('mfenx-gate-control-plane') == '0.3.0rc3'; "
             "assert version('mfenx-gate') == '1.0.0'; "
             "from gate_control.licensed_app import create_app; print('Licensed runtime installation verified')"])
    finally:
        os.close(parent)
    print(json.dumps({"installed": True, "control_plane_version": "0.3.0rc3", "sdk_version": "1.0.0",
                      "service_started": False, "license_configured": False}, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path, help="Absolute path of a NEW venv; parent must exist")
    try:
        install(Path(os.path.abspath(__file__)).parent, parser.parse_args().destination)
    except (InstallError, OSError, ValueError, subprocess.SubprocessError) as error:
        print(json.dumps({"installed": False, "reason": type(error).__name__}), file=sys.stderr)
        raise SystemExit(1)
