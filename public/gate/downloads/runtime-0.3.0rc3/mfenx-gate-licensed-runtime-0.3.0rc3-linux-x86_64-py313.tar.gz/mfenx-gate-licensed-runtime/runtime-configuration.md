# Customer-operated licensed organization runtime

`gate_control.licensed_app:create_app` is the optional customer-operated
organization API. It uses the existing organization membership, customer OIDC,
scoped-token, policy, issuer-key and managed receipt-registration checks, with an
additional offline software-license boundary. It is **not** the MFENX license
host and does not create customer accounts at MFENX. Internal users and their
governed data remain in the customer's own configured database and identity
provider. The existing hosted organization factory is unchanged by default.

This boundary enforces purchased software features in an unmodified deployment.
It is not tamper-proof DRM: an operator controlling Python, files and the system
clock can modify the program. A software license is not proof of model behavior,
receipt truth, artifact binding, behavioral replay or deployment authorization.
The SDK's local receipt verification remains free, accountless and unmetered;
this factory neither intercepts nor changes it. Managed organization receipt
registration retains the existing local allowance and database usage count; that
is separate from free verification and is never reported to MFENX.

## Independent trust configuration

Set these variables in the customer-owned service environment:

```text
GATE_DATABASE=/var/lib/customer-gate/organizations.sqlite3
GATE_PUBLIC_ORIGIN=https://gate.customer.example
GATE_OIDC_ISSUER=https://identity.customer.example
GATE_OIDC_AUDIENCE=customer-gate
GATE_OIDC_JWKS_URL=https://identity.customer.example/jwks

GATE_LICENSE_FILE=/etc/customer-gate/license.json
GATE_LICENSE_ISSUER_KEY_FILE=/etc/customer-gate/trusted-license-issuer.pem
GATE_LICENSE_KEY_ID=<independently confirmed issuer key ID>
GATE_LICENSE_ISSUER=<independently confirmed HTTPS issuer identifier>
GATE_LICENSE_HOLDER_SHA256=sha256:<64 lowercase hex characters>
GATE_LICENSE_ENVIRONMENT=live

GATE_LICENSE_DEFAULT_ORG_PLAN=team
GATE_LICENSE_ORG_PLANS={"an-existing-organization-id":"developer"}
```

The example identifiers are placeholders, not MFENX production trust pins.
Obtain the Ed25519 issuer public PEM, exact issuer identifier and key ID through
an independent trusted release/operator channel. Pin the expected holder-key
digest from the customer's independently known purchase key. Never discover
trust pins from the downloaded license, a query parameter or the license host's
unauthenticated response. This runtime needs only the expected holder digest,
not the holder private key or the MFENX signing private key. It checks the signed
holder binding; it does not perform hardware binding or a new proof-of-possession
challenge per organization request. Protect configuration from other local users.

The license must be the signed `mfenx.gate.key-entitlement.v1` envelope from the
separate accountless license host, for `team`, `business` or `private`. The
verifier validates its issuer, key ID, holder digest, environment, signature,
strict field shape, validity interval and plan-specific maximum lifetime.
The license environment defaults to **live**, independently of the old hosted
Paddle settings. A sandbox license requires explicitly setting
`GATE_LICENSE_ENVIRONMENT=sandbox`; do not use this opt-in for a production
deployment. Neither Paddle credentials nor an MFENX customer-account login are
required in the customer runtime. Checkout, merchant portal, webhook,
reconciliation and old organization-license issuance routes are removed and
return 404. A deny-all billing adapter additionally prevents accidental provider
calls. Customer-selected OIDC can still contact the customer's configured IdP;
offline license validation itself makes no network calls.

Optional browser-login settings are the existing customer-owned
`GATE_OIDC_BROWSER_AUTHORIZATION_URL`, `GATE_OIDC_BROWSER_TOKEN_URL`,
`GATE_OIDC_BROWSER_CLIENT_ID` and `GATE_OIDC_BROWSER_CLIENT_SECRET`; see
`browser-auth.md`. Browser login does not substitute for an active deployment
license or organization authorization.

Run the installed candidate with:

```sh
uvicorn gate_control.licensed_app:create_app --factory --host 127.0.0.1 --port 8090
```

Use a customer-operated HTTPS reverse proxy and the same database backup and
service-isolation precautions as the existing organization API. Do not mix a
customer organization database with the MFENX accountless license-host database.

## Operator organization plans are bounded by the purchase

`GATE_LICENSE_DEFAULT_ORG_PLAN` defaults to `developer`. It explicitly selects
the local allowance for new/unlisted organizations; installing a license does
not silently elevate every organization. `GATE_LICENSE_ORG_PLANS` is an optional
bounded JSON object mapping existing organization IDs to local plans. Unknown
plans, duplicate keys and invalid identifiers fail configuration validation.
These are operator settings, not user-editable HTTP inputs. Restart after
changing organization-plan configuration.

The effective organization plan is the lesser of the configured plan and the
current signed license plan in this order:

```text
developer < team < business < private
```

For example, a configured Private organization under a Team software license
receives Team allowances. Even a configured Developer organization in this
optional licensed factory requires an active software license to access the
organization service; standalone SDK verification does not. Existing hosted
Paddle state is never rewritten to imitate a purchase. The legacy usage response
still includes local hosted-billing fields (normally `unconfigured`, zero paid-until,
and `billing_configured: false`); its effective `plan` and `allowance` come from
this local resolver, not those billing fields. They do not assert a new Paddle
purchase. The license represents a deployment-wide software entitlement; this
implementation does not introduce seats, aggregate multi-organization license
metering or permission to redistribute the software.

## Expiry, replacement and failure behavior

All organization/account endpoints and both session endpoints that can expose
memberships require an active license before entering the organization API.
This includes governed-data reads, mutations and idempotent receipt replays.
Missing, expired, premature, invalid, wrong-holder, wrong-issuer, wrong-key-ID or
wrong-environment licenses fail closed with a generic HTTP 503. A valid license
does not bypass customer identity, membership, token-scope or receipt-policy
checks. Expiry applies at each new request's admission; an already admitted
request is not retroactively canceled mid-flight. Plan-sensitive registration
and usage additionally revalidate when resolving their plan.

There is no positive license cache, stale grace period or automatic network
renewal. Every protected request opens and verifies the current license file.
Replace it atomically from a complete file in the same directory: a request then
sees either the complete old license or the complete new one. Renewal with the
same trust pins needs no restart. An in-place partial write fails closed; it
never falls back to an earlier license. Revocation is learned only when the
local license is removed/replaced or expires; offline verification cannot learn
an immediate remote refund/revocation. Protect the host clock and renew before
expiry using a separate, authorized customer procedure.

Only bounded regular files are accepted: at most 8 KiB for the license and 4 KiB
for the public PEM. Paths must be absolute without `..`; symlinks in any path
component, directories, FIFOs and device files are rejected. Descriptor-relative
no-follow file opens prevent symlink substitution races. Use real paths, not
symlink-based credential mounts. The independently trusted public key is loaded
once at startup. Installing/fixing/changing it or changing trust configuration
requires restarting the service. A missing license itself can be installed
atomically while the process remains running.

`GET /health` remains read-only and returns a small liveness response with
`paid_features_available`; it does not expose file paths, license contents,
license ID, holder digest, issuer key or customer records. It is HTTP 200 even
when paid features are unavailable. Login, callback and sign-out remain
reachable to support authentication and session revocation after expiry;
`/auth/session` and `/v1/session` remain protected because they can contain
organization memberships. There is no unauthenticated license-upload endpoint.

## Local acceptance

From the candidate repository with its locked test environment:

```sh
PYTHONPATH=control_plane:sdk python -m pytest -q \
  control_plane/tests/test_licensed_app.py \
  control_plane/tests/test_license_verify.py
```

Fixtures create real Ed25519 license signatures and exercise fail-closed request
admission, invalid authenticated claims, atomic replacement, clock expiry,
operator-plan ceilings, no provider calls, customer authorization, safe file
reads, removal of hosted billing routes, actual receipt registration and free
local verification after license expiry. These are local acceptance tests, not
evidence of a customer production deployment or a live payment.
