# Licensed organization runtime: installation candidate

This separate `0.3.0rc3` bundle adds customer-operated organization governance.
It contains the retained control-plane wheel, the unchanged Gate SDK 1.0.0 wheel
and their exact runtime dependencies. It does not contain CKODMK/ONNX execution
dependencies, a purchased license, production trust pins, customer credentials,
or a hosted account. Local model evaluation uses the separate existing SDK
admission distribution. Standalone SDK receipt verification remains free; this
add-on does not intercept standalone CLI issuance.

## Verify and install

Target: CPython 3.13, Linux x86_64, glibc 2.34 or newer. Python's `venv` and pip
bootstrap must already be available. Installation requires no package download,
root access, service registration or firewall change.

Authenticate the archive SHA-256 through an independently trusted release
channel before extracting it or running its installer. A checksum shipped beside
an archive detects corruption but does not authenticate its publisher. This
candidate is unsigned; it does not claim a signed release or commercial-launch
approval. Extract only into a new operator-owned directory. Do not let other
users modify the extracted bundle or destination parent while installing.
Destination ancestry must belong to the operator or root and reject group/other
writes; root-owned sticky temporary directories are allowed. The installer checks
directory identities between subprocess steps. This is an operator-controlled
filesystem workflow, not a defense against concurrent replacement by that same
operator or root, who already control the interpreter and installation.

From the extracted `mfenx-gate-licensed-runtime` directory:

```sh
python3.13 -I install.py /absolute/path/to/new-runtime-venv
```

The installer verifies the complete file manifest, rejects extra files,
symlinks/traversal and existing destinations, and installs only the 22 hashed
wheels with isolated, dependency-disabled, index-disabled pip. It checks installed
dependency closure and both MFENX package versions. A failed install leaves its
new incomplete directory for inspection; it never removes an existing directory.
Do not edit the extracted bundle before installation or place the venv inside it.

`SOFTWARE-INVENTORY.json` records original package metadata and notice locations.
`notices/` retains the original license/notice files from dependency wheels.
The original MFENX terms are `LICENSE` and `VERIFIER-TERMS.txt`. These records are
not legal advice, a vulnerability assessment, a certification or new license
rights. `BUILD-PROVENANCE.json` identifies packaging inputs; wheels are not rebuilt.

## Configure and run

Follow `runtime-configuration.md`. Supply a customer-owned database and identity
provider, an independently trusted issuer public key/key ID, exact issuer,
holder-key digest and the signed license file. Keep the purchase private key and
MFENX issuer private key out of the runtime. The default license environment is
live; sandbox acceptance requires explicit sandbox configuration.

```sh
/absolute/path/to/new-runtime-venv/bin/uvicorn \
  gate_control.licensed_app:create_app --factory \
  --host 127.0.0.1 --port 8090 --workers 1 --no-access-log
```

Do not substitute `gate_control.app:create_app`: that is the separate legacy
organization factory, not the licensed entry point. Configure the customer-owned
TLS proxy and process isolation before remote use. No service is auto-started.
Missing, expired or incorrectly bound licenses reject governed requests. Valid
licenses do not replace customer authorization. Offline licenses remain valid
until their signed expiry; cancellation prevents fresh issuance, not use of a
previously issued offline grant before expiry.

An optional one-shot Team/Business renewal tool is included at
`tools/renew_license.py`; see [customer-operated renewal](docs/customer-license-renewal.md).
It uses customer-held recovery credentials and independently configured trust
pins. Nothing schedules or enrolls it automatically. Private air-gap grants use
manual, disconnected license installation; no new network requirement is added
to the licensed runtime or standalone receipt verifier.

## Installed acceptance

Create a new temporary, operator-owned scratch directory outside the bundle:

```sh
/absolute/path/to/new-runtime-venv/bin/python -I acceptance.py \
  --_worker /absolute/path/to/empty-scratch --_expected-version 0.3.0rc3
```

This runs the retained 14-case installed acceptance worker using real loopback
HTTP, synthetic licenses/identities and Python-level network guards. It tests
paid plan ceilings, authorization, invalid/expired claims, atomic renewal, free
SDK verification and absence of hosted billing. The guards are test doubles,
not an OS network sandbox. It does not establish production IdP compatibility,
model behavior, performance capacity, customer deployment or a real payment.

This is a local distribution candidate. Customer delivery, production trust
distribution and live-payment approval are separate release decisions.
